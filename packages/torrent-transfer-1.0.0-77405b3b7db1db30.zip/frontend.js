const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveComponent = runtime.resolveComponent;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1 = { class: "d-flex align-center justify-space-between mb-4" };
const _hoisted_2 = { class: "d-flex ga-2" };
const _hoisted_3 = { class: "text-body-2" };
const _hoisted_4 = { class: "text-h5" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "SeedStatistics",
  props: {
    pluginId: {},
    request: { type: Function },
    cardComponent: {},
    buttonComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiCard = props.cardComponent, UiButton = props.buttonComponent, UiAlert = props.alertComponent;
    const report = ref({ counts: {}, items: [] }), loading = ref(false), error = ref("");
    const names = { submitted: "已提交", checking: "校验中", ready: "待确认", seeding: "做种中", paused: "已暂停", failed: "失败", attention: "需检查", duplicate: "已存在", missing: "任务已变化" };
    const items = computed(() => report.value.items.map((item) => ({
      ...item,
      statusLabel: names[item.status] || item.status,
      date: item.timestamp ? new Date(item.timestamp * 1e3).toLocaleString("zh-CN") : "—"
    })));
    const headers = [{ title: "任务", key: "name" }, { title: "状态", key: "statusLabel" }, { title: "时间", key: "date" }, { title: "说明", key: "error" }];
    const totals = computed(() => [
      { label: "做种中", count: report.value.counts.seeding || 0 },
      { label: "待校验", count: (report.value.counts.checking || 0) + (report.value.counts.submitted || 0) },
      { label: "已暂停", count: report.value.counts.paused || 0 },
      { label: "需处理", count: (report.value.counts.failed || 0) + (report.value.counts.attention || 0) }
    ]);
    async function load() {
      loading.value = true;
      error.value = "";
      try {
        report.value = await props.request(`/plugins/${props.pluginId}/api/statistics`);
      } catch (cause) {
        error.value = cause instanceof Error ? cause.message : "读取统计失败";
      } finally {
        loading.value = false;
      }
    }
    async function check() {
      loading.value = true;
      error.value = "";
      try {
        await props.request(`/plugins/${props.pluginId}/api/check`, { method: "POST", body: "{}" });
        await load();
      } catch (cause) {
        error.value = cause instanceof Error ? cause.message : "检查失败";
      } finally {
        loading.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      const _component_VCardText = resolveComponent("VCardText");
      const _component_VCol = resolveComponent("VCol");
      const _component_VRow = resolveComponent("VRow");
      const _component_VDataTable = resolveComponent("VDataTable");
      return openBlock(), createBlock(unref(UiCard), null, {
        default: withCtx(() => [
          createVNode(_component_VCardText, null, {
            default: withCtx(() => [
              createElementVNode("div", _hoisted_1, [
                _cache[2] || (_cache[2] = createElementVNode(
                  "span",
                  null,
                  "任务统计",
                  -1
                  /* CACHED */
                )),
                createElementVNode("div", _hoisted_2, [
                  createVNode(unref(UiButton), {
                    variant: "text",
                    loading: loading.value,
                    onClick: check
                  }, {
                    default: withCtx(() => [..._cache[0] || (_cache[0] = [
                      createTextVNode(
                        "检查校验",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  }, 8, ["loading"]),
                  createVNode(unref(UiButton), {
                    variant: "text",
                    loading: loading.value,
                    onClick: load
                  }, {
                    default: withCtx(() => [..._cache[1] || (_cache[1] = [
                      createTextVNode(
                        "刷新",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  }, 8, ["loading"])
                ])
              ]),
              error.value ? (openBlock(), createBlock(unref(UiAlert), {
                key: 0,
                type: "error",
                class: "mb-4"
              }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(error.value),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              })) : createCommentVNode("v-if", true),
              createVNode(_component_VRow, null, {
                default: withCtx(() => [
                  (openBlock(true), createElementBlock(
                    Fragment,
                    null,
                    renderList(totals.value, (total) => {
                      return openBlock(), createBlock(
                        _component_VCol,
                        {
                          key: total.label,
                          cols: "6",
                          md: "3"
                        },
                        {
                          default: withCtx(() => [
                            createVNode(
                              unref(UiCard),
                              { variant: "tonal" },
                              {
                                default: withCtx(() => [
                                  createVNode(
                                    _component_VCardText,
                                    null,
                                    {
                                      default: withCtx(() => [
                                        createElementVNode(
                                          "div",
                                          _hoisted_3,
                                          toDisplayString(total.label),
                                          1
                                          /* TEXT */
                                        ),
                                        createElementVNode(
                                          "div",
                                          _hoisted_4,
                                          toDisplayString(total.count),
                                          1
                                          /* TEXT */
                                        )
                                      ]),
                                      _: 2
                                      /* DYNAMIC */
                                    },
                                    1024
                                    /* DYNAMIC_SLOTS */
                                  )
                                ]),
                                _: 2
                                /* DYNAMIC */
                              },
                              1024
                              /* DYNAMIC_SLOTS */
                            )
                          ]),
                          _: 2
                          /* DYNAMIC */
                        },
                        1024
                        /* DYNAMIC_SLOTS */
                      );
                    }),
                    128
                    /* KEYED_FRAGMENT */
                  ))
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_VDataTable, {
                headers,
                items: items.value,
                loading: loading.value,
                "items-per-page": 10,
                "item-value": "id",
                density: "compact",
                "no-data-text": "暂无任务记录"
              }, null, 8, ["items", "loading"])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    pluginId: {},
    request: { type: Function },
    cardComponent: {},
    buttonComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1, {
        "plugin-id": props.pluginId,
        request: props.request,
        "card-component": props.cardComponent,
        "button-component": props.buttonComponent,
        "alert-component": props.alertComponent
      }, null, 8, ["plugin-id", "request", "card-component", "button-component", "alert-component"]);
    };
  }
});
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  sdk.registerContribution?.({ pluginId: "torrent-transfer", slot: "plugin.statistics", key: "seeding-statistics", component: defineComponent2({
    props: { context: { type: Object, required: true } },
    setup() {
      return () => h(_sfc_main, {
        pluginId: "torrent-transfer",
        request: sdk.request,
        cardComponent: sdk.ui.components.Card,
        buttonComponent: sdk.ui.components.Button,
        alertComponent: sdk.ui.components.Alert
      });
    }
  }) });
}
export {
  install
};
