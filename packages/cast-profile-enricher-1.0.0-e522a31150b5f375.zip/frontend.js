if (typeof document !== "undefined") { const id = "cast_profile_enricher"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.cast-editor[data-v-55d17187]{display:grid;row-gap:var(--app-plugin-config-row-gap,14px);column-gap:var(--app-plugin-config-column-gap,16px);align-items:start;color:var(--app-text)}.cast-editor[data-v-55d17187] .v-field{border-radius:11px}\r\n\n.cast-stat-dialog[data-v-2f528c3b]{display:flex;max-height:calc(100dvh - 32px);overflow:hidden;flex-direction:column;border:1px solid var(--app-border-subtle);border-radius:18px!important;background:var(--app-dialog-surface)!important;color:var(--app-text)}\n.cast-stat-header[data-v-2f528c3b]{display:flex;box-sizing:border-box;height:var(--app-plugin-dialog-header-height,58px);min-height:var(--app-plugin-dialog-header-height,58px);max-height:var(--app-plugin-dialog-header-height,58px);flex:0 0 var(--app-plugin-dialog-header-height,58px);align-items:center;justify-content:space-between;gap:12px;padding:6px 24px;border-bottom:1px solid var(--app-border-subtle)}\n.cast-stat-header h2[data-v-2f528c3b]{margin:0;font-size:18px;font-weight:750;line-height:1.2}\n.cast-stat-content[data-v-2f528c3b]{display:grid;min-height:0;gap:18px;overflow:auto;padding:20px 24px;background:var(--app-surface-subtle)}\n.cast-stat-message[data-v-2f528c3b]{min-height:220px;margin:0;display:grid;place-items:center;color:var(--app-text-muted)}\n.cast-metrics[data-v-2f528c3b]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:0 0 6px}.cast-metrics>div[data-v-2f528c3b]{min-width:0;padding:15px 16px;border:1px solid var(--app-border-subtle);border-radius:12px;background:var(--app-surface-muted)}.cast-metrics dt[data-v-2f528c3b]{color:var(--app-text-muted);font-size:12px}.cast-metrics dd[data-v-2f528c3b]{margin:10px 0 0;color:var(--app-text);font-size:24px;font-weight:600;font-variant-numeric:tabular-nums}\n.cast-tone--blue[data-v-2f528c3b]{--cast-tone:#2f74ee}.cast-tone--violet[data-v-2f528c3b]{--cast-tone:#7451d5}.cast-tone--green[data-v-2f528c3b]{--cast-tone:#29a866}.cast-tone--amber[data-v-2f528c3b]{--cast-tone:#e49312}.cast-tone--red[data-v-2f528c3b]{--cast-tone:#e4525d}\n.cast-latest[data-v-2f528c3b]{padding:18px 20px;border:1px solid var(--app-border-subtle);border-radius:14px;background:var(--app-surface)}.cast-latest-heading[data-v-2f528c3b]{display:flex;align-items:center;gap:10px}.cast-latest-heading h3[data-v-2f528c3b]{margin:0;font-size:15px}.cast-latest-heading time[data-v-2f528c3b]{margin-left:auto;color:var(--app-text-muted);font-size:11px;font-variant-numeric:tabular-nums}.cast-latest>p[data-v-2f528c3b]{margin:15px 0;color:var(--app-text);font-size:12px;line-height:1.6}.cast-result-bar[data-v-2f528c3b]{display:flex;height:7px;overflow:hidden;border-radius:999px;background:var(--app-surface-muted)}.cast-result-bar span[data-v-2f528c3b]{min-width:0;background:var(--cast-tone)}.cast-result-legend[data-v-2f528c3b]{display:flex;flex-wrap:wrap;gap:10px 22px;padding:0;margin:14px 0 0;list-style:none}.cast-result-legend li[data-v-2f528c3b]{display:flex;align-items:center;gap:6px;color:var(--app-text-secondary);font-size:11px}.cast-result-legend i[data-v-2f528c3b]{width:7px;height:7px;border-radius:50%;background:var(--cast-tone)}.cast-result-legend strong[data-v-2f528c3b]{color:var(--app-text)}\n.cast-stat-actions[data-v-2f528c3b]{display:flex;flex:0 0 auto;justify-content:flex-end;padding:10px 20px;border-top:1px solid var(--app-border-subtle);background:var(--app-surface-raised)}\n@media(max-width:700px){.cast-stat-content[data-v-2f528c3b]{padding:16px}.cast-stat-header[data-v-2f528c3b]{padding:6px 16px}.cast-stat-header h2[data-v-2f528c3b]{font-size:16px}.cast-metrics[data-v-2f528c3b]{grid-template-columns:repeat(2,minmax(0,1fr))}.cast-latest-heading[data-v-2f528c3b]{align-items:flex-start;flex-wrap:wrap}.cast-latest-heading time[data-v-2f528c3b]{width:100%;margin-left:0}}\n@media(max-width:420px){.cast-metrics[data-v-2f528c3b]{grid-template-columns:1fr}}\r\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\r\n * Values mirror the host application's standard configuration dialog and\r\n * operational content density. Keep business-specific layouts in each plugin.\r\n */\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .signin-page,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace,\r\n  .signin-stat-dialog,\r\n  .cc-statistics-dialog,\r\n  .douban-dialog,\r\n  .maoyan-dialog,\r\n  .cover-history\r\n) {\r\n  color: var(--app-text, #1a2434);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field) {\r\n  min-height: var(--app-control-height, 52px);\r\n  border-radius: var(--app-control-radius, 11px);\r\n  background: var(--control-surface, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field__input) {\r\n  min-width: 0;\r\n  min-height: var(--app-control-height, 52px) !important;\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-label.v-field-label) {\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-label, 11px);\r\n}\r\n\r\n/* Custom plugin editors render Vuetify switches directly instead of through\r\n * the host's InlineSwitchRow. Pin their copy to the host's compact form-label\r\n * treatment so Vuetify's larger body label cannot change the visual scale. */\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-switch, .v-checkbox, .v-radio) .v-label {\r\n  color: var(--app-text-secondary, #657087) !important;\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-label, 13px) !important;\r\n  font-weight: var(--app-font-weight-regular, 400) !important;\r\n  line-height: 1.35;\r\n  opacity: 1;\r\n}\r\n\r\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .traffic-dialog, .cover-history) {\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border, #dfe4ee) !important;\r\n  border-radius: 18px !important;\r\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\r\n  color: var(--app-text, #202939);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) {\r\n  min-height: 80px;\r\n  padding: 18px 20px !important;\r\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) h2 {\r\n  margin: 0;\r\n  color: var(--app-text, #202939);\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-heading, 750) !important;\r\n  line-height: 1.2;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header\r\n) p {\r\n  margin: 3px 0 0;\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: var(--app-font-size-helper, 10px) !important;\r\n  line-height: 1.4;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__content,\r\n  .cc-statistics-content,\r\n  .douban-dialog__content,\r\n  .traffic-dialog-body,\r\n  .maoyan-dialog__content,\r\n  .cover-history > main\r\n) {\r\n  padding: 20px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__actions,\r\n  .cc-statistics-actions,\r\n  .douban-dialog__actions,\r\n  .traffic-dialog-actions,\r\n  .maoyan-dialog__actions,\r\n  .cover-history > footer\r\n) {\r\n  min-height: 64px;\r\n  padding: 13px 18px !important;\r\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface-raised, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) {\r\n  gap: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) > div {\r\n  min-width: 0;\r\n  padding: 15px 16px !important;\r\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  border-radius: 12px !important;\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) dt,\r\n:where(.cover-history .metrics) span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics\r\n) dd,\r\n:where(.cover-history .metrics) strong {\r\n  margin-top: 7px;\r\n  color: var(--app-text, #202939);\r\n  font-family: inherit !important;\r\n  font-size: var(--app-font-size-metric, 24px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  font-variant-numeric: tabular-nums;\r\n  line-height: 1.15;\r\n}\r\n\r\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\r\n.cookie-metric dd > span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 11px !important;\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n.signin-stat-results {\r\n  border-radius: 12px !important;\r\n}\r\n\r\n.signin-stat-results > header {\r\n  min-height: 44px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article {\r\n  min-height: 68px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article strong {\r\n  color: var(--app-text, #202939);\r\n  font-size: 13px;\r\n  font-weight: var(--app-font-weight-medium, 650);\r\n}\r\n\r\n.signin-stat-results article p {\r\n  font-size: 12px !important;\r\n}\r\n\r\n.signin-stat-results :is(article span, time) {\r\n  font-size: 10px !important;\r\n}\r\n\r\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\r\n  min-width: 0;\r\n  color: var(--app-text, #17243a);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  line-height: 1.5;\r\n}\r\n\r\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\r\n  font-size: 27px !important;\r\n  font-weight: 750;\r\n  line-height: 1.15;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  line-height: 1.3;\r\n}\r\n\r\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\r\n  min-height: 40px;\r\n  border-radius: 9px !important;\r\n  font-size: 13px;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\r\n  min-height: 52px;\r\n  border-radius: 11px;\r\n  color: var(--app-text-secondary, #657087);\r\n  font: inherit;\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n@media (max-width: 700px) {\r\n  :where(\r\n    .signin-stat-dialog__header,\r\n    .cc-statistics-header,\r\n    .douban-dialog__header,\r\n    .traffic-dialog-heading,\n    .maoyan-dialog__header,\n    .cover-history > header,\r\n    .signin-stat-dialog__content,\r\n    .cc-statistics-content,\r\n    .douban-dialog__content,\r\n    .traffic-dialog-body,\n    .maoyan-dialog__content,\n    .cover-history > main\r\n  ) {\r\n    padding: 16px !important;\r\n  }\r\n}\r\n\r\n/* Legacy-host fallback. On current hosts, the public form owns these tokens. */\r\n:where(.app-form-layout) {\r\n  display: grid;\r\n  grid-template-columns: repeat(var(--app-plugin-config-columns, 2), minmax(0, 1fr));\r\n  row-gap: var(--app-plugin-config-row-gap, 14px);\r\n  column-gap: var(--app-plugin-config-column-gap, 16px);\r\n}\r\n@media (max-width: 760px) {\r\n  :where(.app-form-layout) { grid-template-columns: minmax(0, 1fr); }\r\n}\r\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const normalizeStyle = runtime.normalizeStyle;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveComponent = runtime.resolveComponent;
const resolveDynamicComponent = runtime.resolveDynamicComponent;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1$1 = { class: "cast-editor plugin-config-grid app-form-layout" };
const ID$1 = "cast-profile-enricher";
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "CastProfileEditor",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    request: { type: Function },
    cronFieldComponent: {}
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const servers = ref([]);
    const loadingServers = ref(false);
    const serverError = ref("");
    const cronField = {
      key: "cron",
      input_type: "cron",
      label: "执行周期",
      placeholder: "5位cron表达式，留空自动"
    };
    const selectedServers = computed(() => Array.isArray(props.modelValue.selected_servers) ? props.modelValue.selected_servers.map(String) : []);
    const selectedEvent = computed(() => {
      const value = String(props.modelValue.trigger_event || "").trim();
      return value || null;
    });
    const serverItems = computed(() => {
      const known = new Set(servers.value.map((item) => item.id));
      return [
        ...servers.value,
        ...selectedServers.value.filter((id) => !known.has(id)).map((id) => ({ id, label: `已失效资源（${id}）` }))
      ];
    });
    function update(key, value) {
      emit("update:modelValue", { ...props.modelValue, [key]: value });
    }
    async function loadServers() {
      loadingServers.value = true;
      serverError.value = "";
      try {
        const data = await props.request(
          `/plugins/${ID$1}/sdk/resources/media_server?capability=read&capability=write_metadata&limit=100`
        );
        servers.value = Array.isArray(data.items) ? data.items : [];
      } catch (error) {
        servers.value = [];
        serverError.value = error instanceof Error ? error.message : "媒体服务器读取失败";
      } finally {
        loadingServers.value = false;
      }
    }
    onMounted(loadServers);
    return (_ctx, _cache) => {
      const _component_VSwitch = resolveComponent("VSwitch");
      const _component_VSelect = resolveComponent("VSelect");
      const _component_VTextField = resolveComponent("VTextField");
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createVNode(_component_VSwitch, {
          label: "启用定时生成",
          "model-value": Boolean(__props.modelValue.enabled),
          disabled: __props.disabled,
          color: "primary",
          "hide-details": "",
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => update("enabled", $event))
        }, null, 8, ["model-value", "disabled"]),
        (openBlock(), createBlock(resolveDynamicComponent(__props.cronFieldComponent), {
          "model-value": __props.modelValue.cron || "",
          field: cronField,
          disabled: __props.disabled,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => update("cron", $event))
        }, null, 8, ["model-value", "disabled"])),
        createVNode(_component_VSelect, {
          label: "触发事件",
          "model-value": selectedEvent.value,
          disabled: __props.disabled,
          items: [
            { value: "organizer.completed", title: "整理完成" },
            { value: "sync.completed", title: "同步完成" },
            { value: "metadata.scrape.completed", title: "刮削完成" }
          ],
          clearable: "",
          variant: "outlined",
          "hide-details": "",
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => update("trigger_event", $event ?? null))
        }, null, 8, ["model-value", "disabled"]),
        createVNode(_component_VTextField, {
          label: "触发后延迟执行（秒）",
          type: "number",
          min: "0",
          max: "3600",
          "model-value": __props.modelValue.scrape_delay ?? 60,
          disabled: __props.disabled || !selectedEvent.value,
          variant: "outlined",
          "hide-details": "",
          "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => update("scrape_delay", Number($event)))
        }, null, 8, ["model-value", "disabled"]),
        createVNode(_component_VSwitch, {
          label: "补充人物简介",
          "model-value": __props.modelValue.update_biography !== false,
          disabled: __props.disabled,
          color: "primary",
          "hide-details": "",
          "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => update("update_biography", $event))
        }, null, 8, ["model-value", "disabled"]),
        createVNode(_component_VSelect, {
          label: "处理范围",
          "model-value": __props.modelValue.condition || "missing_any",
          disabled: __props.disabled,
          items: [
            { value: "all", title: "全部人物" },
            { value: "missing_any", title: "姓名或角色未中文化" },
            { value: "missing_name", title: "姓名未中文化" },
            { value: "missing_role", title: "角色未中文化" }
          ],
          variant: "outlined",
          "hide-details": "",
          "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => update("condition", $event))
        }, null, 8, ["model-value", "disabled"]),
        createVNode(_component_VSwitch, {
          label: "移除无法完善的人物",
          "model-value": Boolean(__props.modelValue.remove_unresolved),
          disabled: __props.disabled,
          color: "primary",
          "hide-details": "",
          "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => update("remove_unresolved", $event))
        }, null, 8, ["model-value", "disabled"]),
        createVNode(_component_VSelect, {
          class: "server-select",
          label: "媒体服务器",
          items: serverItems.value,
          "item-title": "label",
          "item-value": "id",
          "model-value": selectedServers.value,
          multiple: "",
          chips: "",
          "closable-chips": "",
          clearable: "",
          variant: "outlined",
          "hide-details": "auto",
          loading: loadingServers.value,
          disabled: __props.disabled,
          "error-messages": serverError.value || void 0,
          "no-data-text": "暂无可用媒体服务器",
          "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => update("selected_servers", $event || []))
        }, null, 8, ["items", "model-value", "loading", "disabled", "error-messages"])
      ]);
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const CastProfileEditorView = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-55d17187"]]);
const _hoisted_1 = { class: "cast-stat-header" };
const _hoisted_2 = { class: "cast-stat-content" };
const _hoisted_3 = {
  key: 0,
  class: "cast-stat-message",
  role: "status"
};
const _hoisted_4 = {
  class: "cast-metrics",
  "aria-label": "处理指标"
};
const _hoisted_5 = {
  class: "cast-latest",
  "aria-label": "本次处理"
};
const _hoisted_6 = { class: "cast-latest-heading" };
const _hoisted_7 = {
  key: 0,
  role: "status"
};
const _hoisted_8 = {
  class: "cast-result-bar",
  "aria-hidden": "true"
};
const _hoisted_9 = {
  class: "cast-result-legend",
  "aria-label": "处理结果"
};
const _hoisted_10 = { class: "cast-stat-actions" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: {},
    buttonComponent: {},
    cardComponent: {},
    dialogComponent: {},
    chipComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiButton = props.buttonComponent;
    const UiCard = props.cardComponent;
    const UiDialog = props.dialogComponent;
    const UiChip = props.chipComponent;
    const UiAlert = props.alertComponent;
    const latest = ref(null);
    const progress = ref({});
    const loading = ref(false);
    const error = ref("");
    function count(value) {
      const parsed = Number(value || 0);
      return Number.isFinite(parsed) ? Math.max(0, Math.trunc(parsed)) : 0;
    }
    const running = computed(() => progress.value.status === "running" && ["running", "pending"].includes(latest.value?.status || ""));
    const result = computed(() => running.value ? progress.value : latest.value?.result || {});
    const metrics = computed(() => [
      { label: "检查媒体", value: count(result.value.scanned_media) },
      { label: "检查人物", value: count(result.value.scanned_people) },
      { label: "更新资料", value: count(result.value.updated_profiles) },
      { label: "更新图片", value: count(result.value.updated_images) },
      { label: "中文姓名", value: count(result.value.updated_names) },
      { label: "中文角色", value: count(result.value.updated_roles) },
      { label: "中文简介", value: count(result.value.updated_biographies) },
      { label: "缓存命中", value: count(result.value.cache_hits) }
    ]);
    const outcomes = computed(() => [
      { label: "资料更新", value: count(result.value.updated_profiles), tone: "green" },
      { label: "图片更新", value: count(result.value.updated_images), tone: "blue" },
      { label: "处理失败", value: count(result.value.failures), tone: "red" }
    ]);
    const outcomeTotal = computed(() => outcomes.value.reduce((total, item) => total + item.value, 0));
    const state = computed(() => latest.value?.display_status || latest.value?.status || "empty");
    const statePresentation = computed(() => ({
      completed: { label: "已完成", color: "success" },
      partial: { label: "部分完成", color: "warning" },
      failed: { label: "执行失败", color: "error" },
      running: { label: "正在处理", color: "primary" },
      pending: { label: "等待执行", color: "primary" },
      skipped: { label: "已跳过", color: void 0 },
      empty: { label: "暂无记录", color: void 0 }
    })[state.value] || { label: "已结束", color: void 0 });
    const summary = computed(() => {
      if (!latest.value) return "任务运行后将在这里显示处理结果";
      const data = result.value;
      const parts = [
        `检查 ${count(data.scanned_media)} 部媒体 · ${count(data.scanned_people)} 位人物`,
        `更新资料 ${count(data.updated_profiles)} 条、图片 ${count(data.updated_images)} 张`
      ];
      if (count(data.removed_people)) parts.push(`移除人物 ${count(data.removed_people)}`);
      if (count(data.failures)) parts.push(`失败 ${count(data.failures)}`);
      parts.push(`来源无中文角色 ${count(data.no_chinese_role)}，人物未匹配 ${count(data.unmatched_people)}，请求失败 ${count(data.request_failures)}`);
      if (count(data.resumed_media)) parts.push(`断点跳过已处理作品 ${count(data.resumed_media)}`);
      if (count(data.skipped_people)) parts.push(`无变更人物条目 ${count(data.skipped_people)}`);
      return parts.join("，");
    });
    function localTime(value) {
      if (!value) return "尚未执行";
      const text = String(value);
      const date = new Date(/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(text) ? `${text.replace(" ", "T")}Z` : text);
      return Number.isFinite(date.getTime()) ? date.toLocaleString("zh-CN", { hour12: false }) : text;
    }
    async function load() {
      if (loading.value) return;
      loading.value = true;
      error.value = "";
      try {
        const payload = await props.request("/plugins/cast-profile-enricher/runs?limit=1");
        latest.value = payload.items?.[0] || null;
        progress.value = await props.request("/plugins/cast-profile-enricher/api/progress");
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "统计数据加载失败";
      } finally {
        loading.value = false;
      }
    }
    let poll;
    onMounted(() => {
      void load();
      poll = setInterval(() => void load(), 5e3);
    });
    function stopPolling() {
      clearInterval(poll);
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(
        unref(UiDialog),
        {
          "model-value": true,
          "max-width": 900,
          width: "calc(100vw - 32px)",
          onVnodeUnmounted: stopPolling,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = (open) => {
            if (!open) __props.context.close();
          })
        },
        {
          default: withCtx(() => [
            createVNode(unref(UiCard), { class: "cast-stat-dialog" }, {
              default: withCtx(() => [
                createElementVNode("header", _hoisted_1, [
                  _cache[1] || (_cache[1] = createElementVNode(
                    "h2",
                    null,
                    "演职员资料完善 · 数据统计",
                    -1
                    /* CACHED */
                  )),
                  createVNode(unref(UiButton), {
                    class: "app-dialog-close",
                    icon: "mdi-close",
                    variant: "text",
                    "aria-label": "关闭",
                    onClick: __props.context.close
                  }, null, 8, ["onClick"])
                ]),
                createElementVNode("main", _hoisted_2, [
                  loading.value && !latest.value ? (openBlock(), createElementBlock("p", _hoisted_3, "正在读取处理结果…")) : error.value ? (openBlock(), createBlock(unref(UiAlert), {
                    key: 1,
                    type: "error",
                    variant: "tonal"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(
                        toDisplayString(error.value),
                        1
                        /* TEXT */
                      )
                    ]),
                    _: 1
                    /* STABLE */
                  })) : (openBlock(), createElementBlock(
                    Fragment,
                    { key: 2 },
                    [
                      createElementVNode("dl", _hoisted_4, [
                        (openBlock(true), createElementBlock(
                          Fragment,
                          null,
                          renderList(metrics.value, (metric) => {
                            return openBlock(), createElementBlock("div", {
                              key: metric.label
                            }, [
                              createElementVNode(
                                "dt",
                                null,
                                toDisplayString(metric.label),
                                1
                                /* TEXT */
                              ),
                              createElementVNode(
                                "dd",
                                null,
                                toDisplayString(metric.value),
                                1
                                /* TEXT */
                              )
                            ]);
                          }),
                          128
                          /* KEYED_FRAGMENT */
                        ))
                      ]),
                      createElementVNode("section", _hoisted_5, [
                        createElementVNode("div", _hoisted_6, [
                          _cache[2] || (_cache[2] = createElementVNode(
                            "h3",
                            null,
                            "本次处理",
                            -1
                            /* CACHED */
                          )),
                          createVNode(unref(UiChip), {
                            color: statePresentation.value.color,
                            size: "small",
                            variant: "tonal"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(
                                toDisplayString(statePresentation.value.label),
                                1
                                /* TEXT */
                              )
                            ]),
                            _: 1
                            /* STABLE */
                          }, 8, ["color"]),
                          createElementVNode(
                            "time",
                            null,
                            toDisplayString(localTime(latest.value?.finished_at || latest.value?.started_at)),
                            1
                            /* TEXT */
                          )
                        ]),
                        createElementVNode(
                          "p",
                          null,
                          toDisplayString(summary.value),
                          1
                          /* TEXT */
                        ),
                        running.value ? (openBlock(), createElementBlock(
                          "p",
                          _hoisted_7,
                          "正在处理：" + toDisplayString(progress.value.current_media?.join("、") || "准备扫描") + " · 来源 " + toDisplayString(progress.value.source || "媒体服务器") + " · 已用时 " + toDisplayString(Math.floor(count(progress.value.elapsed_seconds) / 60)) + " 分钟",
                          1
                          /* TEXT */
                        )) : createCommentVNode("v-if", true),
                        createElementVNode("div", _hoisted_8, [
                          (openBlock(true), createElementBlock(
                            Fragment,
                            null,
                            renderList(outcomes.value, (outcome) => {
                              return openBlock(), createElementBlock(
                                "span",
                                {
                                  key: outcome.label,
                                  class: normalizeClass(`cast-tone--${outcome.tone}`),
                                  style: normalizeStyle({ flex: outcomeTotal.value ? outcome.value : outcome.tone === "green" ? 1 : 0 })
                                },
                                null,
                                6
                                /* CLASS, STYLE */
                              );
                            }),
                            128
                            /* KEYED_FRAGMENT */
                          ))
                        ]),
                        createElementVNode("ul", _hoisted_9, [
                          (openBlock(true), createElementBlock(
                            Fragment,
                            null,
                            renderList(outcomes.value, (outcome) => {
                              return openBlock(), createElementBlock(
                                "li",
                                {
                                  key: outcome.label,
                                  class: normalizeClass(`cast-tone--${outcome.tone}`)
                                },
                                [
                                  _cache[3] || (_cache[3] = createElementVNode(
                                    "i",
                                    null,
                                    null,
                                    -1
                                    /* CACHED */
                                  )),
                                  createTextVNode(
                                    toDisplayString(outcome.label) + " ",
                                    1
                                    /* TEXT */
                                  ),
                                  createElementVNode(
                                    "strong",
                                    null,
                                    toDisplayString(outcome.value),
                                    1
                                    /* TEXT */
                                  )
                                ],
                                2
                                /* CLASS */
                              );
                            }),
                            128
                            /* KEYED_FRAGMENT */
                          ))
                        ])
                      ])
                    ],
                    64
                    /* STABLE_FRAGMENT */
                  ))
                ]),
                createElementVNode("footer", _hoisted_10, [
                  createVNode(unref(UiButton), {
                    "prepend-icon": "mdi-refresh",
                    variant: "text",
                    loading: loading.value,
                    onClick: load
                  }, {
                    default: withCtx(() => [..._cache[4] || (_cache[4] = [
                      createTextVNode(
                        "刷新",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  }, 8, ["loading"])
                ])
              ]),
              _: 1
              /* STABLE */
            })
          ]),
          _: 1
          /* STABLE */
        },
        512
        /* NEED_PATCH */
      );
    };
  }
});
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-2f528c3b"]]);
function orderedFields(fields, order) {
  return order.flatMap((key) => {
    const field = fields.find((candidate) => candidate.key === key);
    return field ? [{ ...field }] : [];
  });
}
const ID = "cast-profile-enricher";
function createEditor(sdk) {
  return sdk.vue.defineComponent({
    name: "CastProfileEditor",
    inheritAttrs: false,
    props: {
      modelValue: { type: Object, required: true },
      disabled: Boolean,
      fields: { type: Array, default: () => [] }
    },
    emits: ["update:modelValue"],
    setup(props, { emit }) {
      return () => sdk.ui.components.SchemaFields && props.fields.length ? sdk.vue.h(sdk.ui.components.SchemaFields, {
        modelValue: props.modelValue,
        disabled: props.disabled,
        pluginId: ID,
        compact: true,
        class: "standard-config-fields plugin-config-grid app-form-layout",
        fields: orderedFields(props.fields, ["enabled", "cron", "trigger_event", "scrape_delay", "update_biography", "condition", "remove_unresolved", "selected_servers"]).map((field) => ({ ...field, icon: void 0, disabled: field.disabled || field.key === "scrape_delay" && !props.modelValue.trigger_event })),
        "onUpdate:modelValue": (value) => emit("update:modelValue", value)
      }) : sdk.vue.h(CastProfileEditorView, {
        modelValue: props.modelValue,
        disabled: props.disabled,
        request: sdk.request,
        cronFieldComponent: sdk.ui.components.CronField,
        "onUpdate:modelValue": (value) => emit("update:modelValue", value)
      });
    }
  });
}
function install(sdk) {
  const { Alert, Button, Card, Chip, Dialog } = sdk.ui.components;
  sdk.registerEditor({ domain: "plugin", key: ID, component: createEditor(sdk) });
  sdk.registerContribution?.({
    pluginId: ID,
    slot: "plugin.statistics",
    key: "overview",
    component: sdk.vue.defineComponent({
      name: "CastProfileStatistics",
      inheritAttrs: false,
      props: { context: { type: Object, required: true } },
      setup(props, { attrs }) {
        return () => sdk.vue.h(StatisticsView, {
          ...attrs,
          context: props.context,
          request: sdk.request,
          alertComponent: Alert,
          buttonComponent: Button,
          cardComponent: Card,
          chipComponent: Chip,
          dialogComponent: Dialog
        });
      }
    })
  });
}
export {
  install
};
