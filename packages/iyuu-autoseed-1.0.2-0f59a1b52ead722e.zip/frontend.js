if (typeof document !== "undefined") { const id = "iyuu_autoseed"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.seed-statistics-dialog[data-v-7ef724e2]{display:flex;flex-direction:column;max-height:calc(100dvh - 32px);overflow:hidden;border:1px solid var(--app-border);border-radius:var(--app-dialog-radius, 16px)!important;background:var(--app-dialog-surface,var(--app-surface,#fff))!important;color:var(--app-text);font-family:var(--app-font-family,inherit);font-size:var(--app-font-size-body,14px)}\n.seed-statistics-header[data-v-7ef724e2]{display:flex;box-sizing:border-box;flex:0 0 var(--app-plugin-dialog-header-height,58px);min-height:var(--app-plugin-dialog-header-height,58px);align-items:center;justify-content:space-between;gap:12px;padding:6px 24px;border-bottom:1px solid var(--app-border-subtle)}\n.seed-statistics-header h2[data-v-7ef724e2]{margin:0;font-size:var(--app-font-size-section-title,18px);font-weight:var(--app-font-weight-heading, 600);line-height:1.2;overflow-wrap:anywhere}\n.seed-statistics-content[data-v-7ef724e2]{display:grid;gap:18px;min-height:0;min-width:0;overflow:auto;padding:20px}\n.seed-statistics-metrics[data-v-7ef724e2]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:0}\n.seed-statistics-metrics>div[data-v-7ef724e2]{min-width:0;padding:15px 16px;border:1px solid var(--app-border-subtle);border-radius:12px;background:var(--app-surface-muted)}\n.seed-statistics-metrics dt[data-v-7ef724e2]{color:var(--app-text-muted);font-size:12px}\n.seed-statistics-metrics dd[data-v-7ef724e2]{margin:7px 0 0;color:var(--app-text);font-family:inherit;font-size:var(--app-font-size-metric,24px);font-weight:var(--app-font-weight-metric, 600);font-variant-numeric:tabular-nums;line-height:1.15;overflow-wrap:anywhere}\n.seed-statistics-table[data-v-7ef724e2]{min-width:0;overflow:auto;border:1px solid var(--app-border-subtle);border-radius:var(--app-radius-panel, 12px)}\n.seed-statistics-actions[data-v-7ef724e2]{display:flex;flex:0 0 auto;align-items:center;justify-content:flex-end;gap:8px;padding:10px 18px;border-top:1px solid var(--app-border-subtle);background:var(--app-surface,#fff)}\n.seed-statistics-pagination[data-v-7ef724e2]{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;min-width:0;font-size:12px;color:var(--app-text-muted)}\n.seed-statistics-pagination>div[data-v-7ef724e2]{display:flex;align-items:center;gap:6px;max-width:100%}\n.seed-statistics-pagination button[data-v-7ef724e2]{display:grid;place-items:center;flex:0 0 32px;width:32px;height:32px;padding:0;border:0;border-radius:8px;background:none;color:inherit;cursor:pointer}\n.seed-statistics-pagination .v-icon[data-v-7ef724e2]{font-size:18px}\n.seed-statistics-pagination input[data-v-7ef724e2]{box-sizing:border-box;min-width:0;width:48px;height:32px;text-align:center;border:1px solid var(--app-border-subtle);border-radius:8px;padding:5px;background:var(--app-surface);color:inherit;font:inherit;appearance:textfield;-moz-appearance:textfield}\n.seed-statistics-pagination input[data-v-7ef724e2]::-webkit-inner-spin-button,.seed-statistics-pagination input[data-v-7ef724e2]::-webkit-outer-spin-button{appearance:none;margin:0}\n.seed-statistics-pagination button[data-v-7ef724e2]:disabled,.seed-statistics-pagination input[data-v-7ef724e2]:disabled{opacity:.35;cursor:default}\n.seed-statistics-pagination button[data-v-7ef724e2]:focus-visible,.seed-statistics-pagination input[data-v-7ef724e2]:focus-visible{outline:2px solid rgb(var(--v-theme-primary));outline-offset:2px}\n@media(max-width:700px){.seed-statistics-pagination>div[data-v-7ef724e2]{gap:4px}}\n@media(max-width:700px){.seed-statistics-header[data-v-7ef724e2]{padding:6px 16px}.seed-statistics-content[data-v-7ef724e2]{padding:16px}.seed-statistics-metrics[data-v-7ef724e2]{grid-template-columns:repeat(2,minmax(0,1fr))}}\r\n\n.iyuu-config[data-v-dbbd6a92]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px 16px;align-items:start;color:var(--app-text);font-family:var(--app-font-family,inherit);font-size:var(--app-font-size-body,14px)}\n.iyuu-config[data-v-dbbd6a92]>*{min-width:0}\n@media(max-width:700px){.iyuu-config[data-v-dbbd6a92]{grid-template-columns:minmax(0,1fr)}}\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveComponent = runtime.resolveComponent;
const resolveDynamicComponent = runtime.resolveDynamicComponent;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1$1 = { class: "seed-statistics-header" };
const _hoisted_2 = ["aria-busy"];
const _hoisted_3 = {
  class: "seed-statistics-metrics",
  "aria-label": "任务统计"
};
const _hoisted_4 = { class: "seed-statistics-table" };
const _hoisted_5 = {
  class: "seed-statistics-pagination",
  "aria-label": "任务记录分页"
};
const _hoisted_6 = ["disabled"];
const _hoisted_7 = ["disabled"];
const _hoisted_8 = ["value", "max", "disabled"];
const _hoisted_9 = ["disabled"];
const _hoisted_10 = ["disabled"];
const _hoisted_11 = { class: "seed-statistics-actions" };
const pageSize = 10;
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "SeedStatistics",
  props: {
    context: {},
    dialogComponent: {},
    pluginId: {},
    request: { type: Function },
    cardComponent: {},
    buttonComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiCard = props.cardComponent, UiButton = props.buttonComponent, UiAlert = props.alertComponent;
    const UiDialog = props.dialogComponent;
    const title = computed(() => `${props.context.installation?.name || "插件"} · 数据统计`);
    const report = ref({ counts: {}, items: [] }), loading = ref(false), error = ref("");
    const names = { submitted: "已提交", checking: "校验中", ready: "待确认", seeding: "做种中", paused: "已暂停", failed: "失败", attention: "需检查", duplicate: "已存在", missing: "任务已变化" };
    const items = computed(() => report.value.items.map((item) => ({
      ...item,
      statusLabel: names[item.status] || item.status,
      date: item.timestamp ? new Date(item.timestamp * 1e3).toLocaleString("zh-CN") : "—"
    })));
    const page = ref(1);
    const pages = computed(() => Math.max(1, Math.ceil(items.value.length / pageSize)));
    function changePage(value) {
      page.value = Math.min(pages.value, Math.max(1, Math.trunc(Number(value) || 1)));
    }
    function inputPage(event) {
      const input = event.target;
      changePage(Number(input.value));
      input.value = String(page.value);
    }
    function inputPageKey(event) {
      if (event.key !== "Enter") return;
      event.preventDefault();
      inputPage(event);
    }
    const headers = [{ title: "任务", key: "name" }, { title: "状态", key: "statusLabel" }, { title: "时间", key: "date" }, { title: "说明", key: "error" }];
    const totals = computed(() => [
      { label: "做种中", count: report.value.counts.seeding || 0 },
      { label: "待校验", count: (report.value.counts.checking || 0) + (report.value.counts.submitted || 0) },
      { label: "已暂停", count: report.value.counts.paused || 0 },
      { label: "需处理", count: (report.value.counts.failed || 0) + (report.value.counts.attention || 0) }
    ]);
    async function load() {
      if (loading.value) return;
      loading.value = true;
      error.value = "";
      try {
        report.value = await props.request(`/plugins/${props.pluginId}/api/statistics`);
        changePage(page.value);
      } catch (cause) {
        error.value = cause instanceof Error ? cause.message : "读取统计失败";
      } finally {
        loading.value = false;
      }
    }
    async function check() {
      if (loading.value) return;
      loading.value = true;
      error.value = "";
      try {
        await props.request(`/plugins/${props.pluginId}/api/check`, { method: "POST", body: "{}" });
        report.value = await props.request(`/plugins/${props.pluginId}/api/statistics`);
        changePage(page.value);
      } catch (cause) {
        error.value = cause instanceof Error ? cause.message : "检查失败";
      } finally {
        loading.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      const _component_VDataTable = resolveComponent("VDataTable");
      const _component_VIcon = resolveComponent("VIcon");
      return openBlock(), createBlock(unref(UiDialog), {
        "model-value": true,
        "max-width": 980,
        width: "calc(100vw - 32px)",
        scrollable: "",
        "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => !$event && __props.context.close())
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "seed-statistics-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1$1, [
                createElementVNode(
                  "h2",
                  null,
                  toDisplayString(title.value),
                  1
                  /* TEXT */
                ),
                createVNode(unref(UiButton), {
                  class: "app-dialog-close",
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: _cache[0] || (_cache[0] = ($event) => __props.context.close())
                })
              ]),
              createElementVNode("section", {
                class: "seed-statistics-content",
                "aria-busy": loading.value
              }, [
                error.value ? (openBlock(), createBlock(unref(UiAlert), {
                  key: 0,
                  type: "error",
                  variant: "tonal",
                  role: "alert"
                }, {
                  default: withCtx(() => [
                    createTextVNode(
                      toDisplayString(error.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  _: 1
                  /* STABLE */
                })) : createCommentVNode("v-if", true),
                createElementVNode("dl", _hoisted_3, [
                  (openBlock(true), createElementBlock(
                    Fragment,
                    null,
                    renderList(totals.value, (total) => {
                      return openBlock(), createElementBlock("div", {
                        key: total.label
                      }, [
                        createElementVNode(
                          "dt",
                          null,
                          toDisplayString(total.label),
                          1
                          /* TEXT */
                        ),
                        createElementVNode(
                          "dd",
                          null,
                          toDisplayString(total.count),
                          1
                          /* TEXT */
                        )
                      ]);
                    }),
                    128
                    /* KEYED_FRAGMENT */
                  ))
                ]),
                createElementVNode("div", _hoisted_4, [
                  createVNode(_component_VDataTable, {
                    headers,
                    items: items.value,
                    loading: loading.value,
                    page: page.value,
                    "items-per-page": pageSize,
                    "hide-default-footer": "",
                    "onUpdate:page": changePage,
                    "item-value": "id",
                    density: "compact",
                    "no-data-text": "暂无任务记录"
                  }, null, 8, ["items", "loading", "page"])
                ]),
                createElementVNode("nav", _hoisted_5, [
                  createElementVNode(
                    "span",
                    null,
                    "最近 " + toDisplayString(items.value.length) + " 条记录",
                    1
                    /* TEXT */
                  ),
                  createElementVNode("div", null, [
                    createElementVNode("button", {
                      type: "button",
                      "aria-label": "第一页",
                      disabled: loading.value || page.value <= 1,
                      onClick: _cache[1] || (_cache[1] = ($event) => changePage(1))
                    }, [
                      createVNode(_component_VIcon, { icon: "mdi-page-first" })
                    ], 8, _hoisted_6),
                    createElementVNode("button", {
                      type: "button",
                      "aria-label": "上一页",
                      disabled: loading.value || page.value <= 1,
                      onClick: _cache[2] || (_cache[2] = ($event) => changePage(page.value - 1))
                    }, [
                      createVNode(_component_VIcon, { icon: "mdi-chevron-left" })
                    ], 8, _hoisted_7),
                    createElementVNode("input", {
                      value: page.value,
                      "aria-label": "页码",
                      type: "number",
                      inputmode: "numeric",
                      min: "1",
                      max: pages.value,
                      disabled: loading.value,
                      onChange: inputPage,
                      onKeydown: inputPageKey
                    }, null, 40, _hoisted_8),
                    createElementVNode(
                      "span",
                      null,
                      "/ " + toDisplayString(pages.value),
                      1
                      /* TEXT */
                    ),
                    createElementVNode("button", {
                      type: "button",
                      "aria-label": "下一页",
                      disabled: loading.value || page.value >= pages.value,
                      onClick: _cache[3] || (_cache[3] = ($event) => changePage(page.value + 1))
                    }, [
                      createVNode(_component_VIcon, { icon: "mdi-chevron-right" })
                    ], 8, _hoisted_9),
                    createElementVNode("button", {
                      type: "button",
                      "aria-label": "最后一页",
                      disabled: loading.value || page.value >= pages.value,
                      onClick: _cache[4] || (_cache[4] = ($event) => changePage(pages.value))
                    }, [
                      createVNode(_component_VIcon, { icon: "mdi-page-last" })
                    ], 8, _hoisted_10)
                  ])
                ])
              ], 8, _hoisted_2),
              createElementVNode("footer", _hoisted_11, [
                createVNode(unref(UiButton), {
                  variant: "text",
                  disabled: loading.value,
                  onClick: check
                }, {
                  default: withCtx(() => [..._cache[6] || (_cache[6] = [
                    createTextVNode(
                      "检查校验",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["disabled"]),
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: loading.value,
                  disabled: loading.value,
                  onClick: load
                }, {
                  default: withCtx(() => [..._cache[7] || (_cache[7] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading", "disabled"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const SeedStatistics = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-7ef724e2"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    dialogComponent: {},
    pluginId: {},
    request: { type: Function },
    cardComponent: {},
    buttonComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _cache) => {
      return openBlock(), createBlock(SeedStatistics, {
        context: props.context,
        "dialog-component": props.dialogComponent,
        "plugin-id": props.pluginId,
        request: props.request,
        "card-component": props.cardComponent,
        "button-component": props.buttonComponent,
        "alert-component": props.alertComponent
      }, null, 8, ["context", "dialog-component", "plugin-id", "request", "card-component", "button-component", "alert-component"]);
    };
  }
});
const _hoisted_1 = {
  class: "iyuu-config",
  autocomplete: "off",
  "data-1p-ignore": "",
  "data-lpignore": "true"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ConfigEditor",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    fields: {},
    schemaFieldsComponent: {},
    request: { type: Function }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const fields = computed(() => (props.fields || []).filter((field) => field.visible !== false && field.key !== "onlyonce"));
    const error = ref("");
    const restoring = ref(false);
    let edited = false;
    function update(key, value) {
      if (key === "token") edited = true;
      emit("update:modelValue", {
        ...props.modelValue,
        [key]: value ?? "",
        ...key === "token" ? { token_clear: !value } : {}
      });
    }
    async function restore() {
      if (edited || props.modelValue.token || restoring.value) return;
      restoring.value = true;
      error.value = "";
      try {
        const result = await props.request("/plugins/iyuu-autoseed/config/secret/token");
        if (!edited) emit("update:modelValue", { ...props.modelValue, token: result.value || "", token_clear: false });
      } catch {
        error.value = "IYUU Token 读取失败，请重试";
      } finally {
        restoring.value = false;
      }
    }
    onMounted(restore);
    return (_ctx, _cache) => {
      const _component_VTextField = resolveComponent("VTextField");
      const _component_VTextarea = resolveComponent("VTextarea");
      return openBlock(), createElementBlock("div", _hoisted_1, [
        (openBlock(true), createElementBlock(
          Fragment,
          null,
          renderList(fields.value, (field) => {
            return openBlock(), createElementBlock(
              Fragment,
              {
                key: field.key
              },
              [
                field.key === "token" ? (openBlock(), createBlock(_component_VTextField, {
                  key: 0,
                  "model-value": __props.modelValue.token || "",
                  label: field.label,
                  type: "text",
                  autocomplete: "off",
                  name: "iyuu-access-value",
                  "data-1p-ignore": "",
                  "data-lpignore": "true",
                  disabled: __props.disabled,
                  "error-messages": error.value,
                  "hide-details": "auto",
                  "append-inner-icon": error.value ? "mdi-refresh" : void 0,
                  "onClick:appendInner": restore,
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => update("token", $event))
                }, null, 8, ["model-value", "label", "disabled", "error-messages", "append-inner-icon"])) : field.key === "nopaths" ? (openBlock(), createBlock(_component_VTextarea, {
                  key: 1,
                  "model-value": __props.modelValue.nopaths || "",
                  label: field.label,
                  disabled: __props.disabled,
                  rows: 1,
                  "auto-grow": false,
                  "no-resize": false,
                  autocomplete: "off",
                  "hide-details": "auto",
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => update("nopaths", $event))
                }, null, 8, ["model-value", "label", "disabled"])) : (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
                  key: 2,
                  "model-value": __props.modelValue,
                  fields: [field],
                  disabled: __props.disabled,
                  "plugin-id": "iyuu-autoseed",
                  layout: { columns: 1 },
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => emit("update:modelValue", $event))
                }, null, 8, ["model-value", "fields", "disabled"]))
              ],
              64
              /* STABLE_FRAGMENT */
            );
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ]);
    };
  }
});
const ConfigEditor = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-dbbd6a92"]]);
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const schemaFields = sdk.ui.components.SchemaFields;
  if (schemaFields) sdk.registerEditor({
    domain: "plugin",
    key: "iyuu-autoseed",
    component: defineComponent2({
      inheritAttrs: false,
      props: { modelValue: { type: Object, required: true }, disabled: Boolean },
      emits: ["update:modelValue"],
      setup(props, { attrs, emit }) {
        return () => h(ConfigEditor, {
          ...attrs,
          modelValue: props.modelValue,
          disabled: props.disabled,
          request: sdk.request,
          schemaFieldsComponent: schemaFields,
          "onUpdate:modelValue": (value) => emit("update:modelValue", value)
        });
      }
    })
  });
  sdk.registerContribution?.({ pluginId: "iyuu-autoseed", slot: "plugin.statistics", key: "seeding-statistics", component: defineComponent2({
    inheritAttrs: false,
    props: { context: { type: Object, required: true } },
    setup(props) {
      return () => h(_sfc_main$1, {
        context: props.context,
        pluginId: "iyuu-autoseed",
        request: sdk.request,
        cardComponent: sdk.ui.components.Card,
        buttonComponent: sdk.ui.components.Button,
        alertComponent: sdk.ui.components.Alert,
        dialogComponent: sdk.ui.components.Dialog
      });
    }
  }) });
}
export {
  install
};
