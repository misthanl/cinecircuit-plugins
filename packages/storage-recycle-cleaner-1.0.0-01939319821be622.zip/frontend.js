if (typeof document !== "undefined") { const id = "storage_recycle_cleaner"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.recycle-statistics[data-v-9d5c1a0e]{display:flex;flex-direction:column;max-height:calc(100dvh - 32px);border:1px solid var(--app-border);border-radius:18px!important;background:var(--app-dialog-surface)!important;color:var(--app-text);font-family:var(--app-font-family,inherit);font-size:var(--app-font-size-body,14px)}\n.recycle-header[data-v-9d5c1a0e]{display:flex;box-sizing:border-box;flex:0 0 var(--app-plugin-dialog-header-height,58px);height:var(--app-plugin-dialog-header-height,58px);align-items:center;justify-content:space-between;gap:12px;padding:6px 24px;border-bottom:1px solid var(--app-border-subtle)}\n.recycle-header h2[data-v-9d5c1a0e]{margin:0;font-size:var(--app-font-size-section-title,18px);font-weight:700;line-height:1.2}\n.recycle-content[data-v-9d5c1a0e]{min-height:0;overflow:auto;padding:20px}.recycle-actions[data-v-9d5c1a0e]{display:flex;justify-content:flex-end;padding:12px 20px;border-top:1px solid var(--app-border-subtle)}\n.recycle-message[data-v-9d5c1a0e]{padding:32px 0;text-align:center;color:var(--app-text-muted)}\n.recycle-overview[data-v-9d5c1a0e]{display:grid;gap:20px;min-width:0}.recycle-heading[data-v-9d5c1a0e]{display:flex;align-items:baseline;justify-content:space-between;gap:12px}.recycle-heading h3[data-v-9d5c1a0e]{margin:0;font-size:var(--app-font-size-body,14px);font-weight:650}.recycle-heading>span[data-v-9d5c1a0e]{font-size:var(--app-font-size-helper,12px);color:var(--app-text-muted)}\n.recycle-metrics[data-v-9d5c1a0e]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:0}.recycle-metric[data-v-9d5c1a0e]{padding:16px;border:1px solid color-mix(in srgb,var(--tone) 18%,transparent);border-radius:12px;background:color-mix(in srgb,var(--tone) 5%,transparent)}\n.tone-neutral[data-v-9d5c1a0e]{--tone:var(--app-text-secondary)}.tone-success[data-v-9d5c1a0e]{--tone:rgb(var(--v-theme-success))}.tone-error[data-v-9d5c1a0e]{--tone:rgb(var(--v-theme-error))}.tone-primary[data-v-9d5c1a0e]{--tone:rgb(var(--v-theme-primary))}\n.recycle-metric dt[data-v-9d5c1a0e]{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:var(--app-font-size-label,13px);color:var(--app-text-secondary)}.recycle-metric dt .v-icon[data-v-9d5c1a0e]{color:var(--tone)}\n.recycle-metric dd[data-v-9d5c1a0e]{display:flex;align-items:baseline;gap:6px;margin:12px 0 0;color:var(--tone);font-size:calc(var(--app-font-size-body,14px) * 2);font-weight:700;line-height:1.15;font-variant-numeric:tabular-nums}.recycle-metric dd span[data-v-9d5c1a0e]{font-size:var(--app-font-size-helper,12px);font-weight:400;color:var(--app-text-muted)}\n.recycle-schedule[data-v-9d5c1a0e]{display:flex;align-items:center;gap:12px;padding-top:20px;border-top:1px solid var(--app-border-subtle)}.recycle-clock[data-v-9d5c1a0e]{display:grid;place-items:center;width:42px;height:42px;flex:0 0 auto;border-radius:12px;color:rgb(var(--v-theme-primary));background:rgba(var(--v-theme-primary),.08)}.recycle-time[data-v-9d5c1a0e]{display:grid;flex:1;gap:5px;min-width:0}.recycle-time>span[data-v-9d5c1a0e]{font-size:var(--app-font-size-helper,12px);color:var(--app-text-muted)}.recycle-time strong[data-v-9d5c1a0e]{font-size:var(--app-font-size-body,14px);font-weight:600;overflow-wrap:anywhere}\n@media(max-width:760px){.recycle-header[data-v-9d5c1a0e]{padding:6px 16px}.recycle-metrics[data-v-9d5c1a0e]{grid-template-columns:repeat(2,minmax(0,1fr))}.recycle-schedule[data-v-9d5c1a0e]{flex-wrap:wrap}}\r\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\r\n * Values mirror the host application's standard configuration dialog and\r\n * operational content density. Keep business-specific layouts in each plugin.\r\n */\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .signin-page,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace,\r\n  .signin-stat-dialog,\r\n  .cc-statistics-dialog,\r\n  .douban-dialog,\r\n  .maoyan-dialog,\r\n  .cover-history\r\n) {\r\n  color: var(--app-text, #1a2434);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field) {\r\n  min-height: var(--app-control-height, 52px);\r\n  border-radius: var(--app-control-radius, 11px);\r\n  background: var(--control-surface, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field__input) {\r\n  min-width: 0;\r\n  min-height: var(--app-control-height, 52px) !important;\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-label.v-field-label) {\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-label, 11px);\r\n}\r\n\r\n/* Custom plugin editors render Vuetify switches directly instead of through\r\n * the host's InlineSwitchRow. Pin their copy to the host's compact form-label\r\n * treatment so Vuetify's larger body label cannot change the visual scale. */\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-switch, .v-checkbox, .v-radio) .v-label {\r\n  color: var(--app-text-secondary, #657087) !important;\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-label, 13px) !important;\r\n  font-weight: var(--app-font-weight-regular, 400) !important;\r\n  line-height: 1.35;\r\n  opacity: 1;\r\n}\r\n\r\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .traffic-dialog, .cover-history) {\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border, #dfe4ee) !important;\r\n  border-radius: 18px !important;\r\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\r\n  color: var(--app-text, #202939);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) {\r\n  min-height: 80px;\r\n  padding: 18px 20px !important;\r\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) h2 {\r\n  margin: 0;\r\n  color: var(--app-text, #202939);\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-heading, 750) !important;\r\n  line-height: 1.2;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header\r\n) p {\r\n  margin: 3px 0 0;\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: var(--app-font-size-helper, 10px) !important;\r\n  line-height: 1.4;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__content,\r\n  .cc-statistics-content,\r\n  .douban-dialog__content,\r\n  .traffic-dialog-body,\r\n  .maoyan-dialog__content,\r\n  .cover-history > main\r\n) {\r\n  padding: 20px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__actions,\r\n  .cc-statistics-actions,\r\n  .douban-dialog__actions,\r\n  .traffic-dialog-actions,\r\n  .maoyan-dialog__actions,\r\n  .cover-history > footer\r\n) {\r\n  min-height: 64px;\r\n  padding: 13px 18px !important;\r\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface-raised, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) {\r\n  gap: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) > div {\r\n  min-width: 0;\r\n  padding: 15px 16px !important;\r\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  border-radius: 12px !important;\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) dt,\r\n:where(.cover-history .metrics) span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics\r\n) dd,\r\n:where(.cover-history .metrics) strong {\r\n  margin-top: 7px;\r\n  color: var(--app-text, #202939);\r\n  font-family: inherit !important;\r\n  font-size: var(--app-font-size-metric, 24px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  font-variant-numeric: tabular-nums;\r\n  line-height: 1.15;\r\n}\r\n\r\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\r\n.cookie-metric dd > span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 11px !important;\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n.signin-stat-results {\r\n  border-radius: 12px !important;\r\n}\r\n\r\n.signin-stat-results > header {\r\n  min-height: 44px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article {\r\n  min-height: 68px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article strong {\r\n  color: var(--app-text, #202939);\r\n  font-size: 13px;\r\n  font-weight: var(--app-font-weight-medium, 650);\r\n}\r\n\r\n.signin-stat-results article p {\r\n  font-size: 12px !important;\r\n}\r\n\r\n.signin-stat-results :is(article span, time) {\r\n  font-size: 10px !important;\r\n}\r\n\r\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\r\n  min-width: 0;\r\n  color: var(--app-text, #17243a);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  line-height: 1.5;\r\n}\r\n\r\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\r\n  font-size: 27px !important;\r\n  font-weight: 750;\r\n  line-height: 1.15;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  line-height: 1.3;\r\n}\r\n\r\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\r\n  min-height: 40px;\r\n  border-radius: 9px !important;\r\n  font-size: 13px;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\r\n  min-height: 52px;\r\n  border-radius: 11px;\r\n  color: var(--app-text-secondary, #657087);\r\n  font: inherit;\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n@media (max-width: 700px) {\r\n  :where(\r\n    .signin-stat-dialog__header,\r\n    .cc-statistics-header,\r\n    .douban-dialog__header,\r\n    .traffic-dialog-heading,\n    .maoyan-dialog__header,\n    .cover-history > header,\r\n    .signin-stat-dialog__content,\r\n    .cc-statistics-content,\r\n    .douban-dialog__content,\r\n    .traffic-dialog-body,\n    .maoyan-dialog__content,\n    .cover-history > main\r\n  ) {\r\n    padding: 16px !important;\r\n  }\r\n}\r\n\r\n/* Legacy-host fallback. On current hosts, the public form owns these tokens. */\r\n:where(.app-form-layout) {\r\n  display: grid;\r\n  grid-template-columns: repeat(var(--app-plugin-config-columns, 2), minmax(0, 1fr));\r\n  row-gap: var(--app-plugin-config-row-gap, 14px);\r\n  column-gap: var(--app-plugin-config-column-gap, 16px);\r\n}\r\n@media (max-width: 760px) {\r\n  :where(.app-form-layout) { grid-template-columns: minmax(0, 1fr); }\r\n}\r\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveComponent = runtime.resolveComponent;
const resolveDynamicComponent = runtime.resolveDynamicComponent;
const toDisplayString = runtime.toDisplayString;
const withCtx = runtime.withCtx;
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "SavedSecretField",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    label: {},
    endpoint: {},
    request: { type: Function }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const restored = ref("");
    const edited = ref(false);
    const visible = ref(false);
    const error = ref("");
    const value = computed(() => edited.value ? String(props.modelValue || "") : String(props.modelValue || restored.value));
    let pending = null;
    async function load() {
      if (edited.value || value.value) return;
      pending ||= props.request(props.endpoint).then((result) => {
        if (!edited.value) restored.value = result.value || "";
      }).finally(() => {
        pending = null;
      });
      await pending;
    }
    async function restore() {
      error.value = "";
      try {
        await load();
        return true;
      } catch {
        error.value = "密钥读取失败，请点击眼睛重试";
        return false;
      }
    }
    async function toggle() {
      if (props.disabled) return;
      if (visible.value) {
        visible.value = false;
        return;
      }
      if (await restore()) visible.value = true;
    }
    function update(next) {
      edited.value = true;
      restored.value = "";
      emit("update:modelValue", next || "");
    }
    onMounted(restore);
    return (_ctx, _cache) => {
      const _component_VTextField = resolveComponent("VTextField");
      return openBlock(), createBlock(_component_VTextField, {
        "model-value": value.value,
        disabled: __props.disabled,
        label: __props.label,
        type: visible.value ? "text" : "password",
        "prepend-inner-icon": "mdi-lock-outline",
        "append-inner-icon": visible.value ? "mdi-eye-off-outline" : "mdi-eye-outline",
        autocomplete: "off",
        "hide-details": !error.value,
        "error-messages": error.value,
        "onClick:appendInner": toggle,
        "onUpdate:modelValue": update
      }, null, 8, ["model-value", "disabled", "label", "type", "append-inner-icon", "hide-details", "error-messages"]);
    };
  }
});
function orderedFields(fields, order) {
  return order.flatMap((key) => {
    const field = fields.find((candidate) => candidate.key === key);
    return field ? [{ ...field }] : [];
  });
}
const _hoisted_1$1 = { class: "plugin-config-grid app-form-layout" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ConfigEditor",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    fields: {},
    schemaFieldsComponent: {},
    request: { type: Function }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const top = computed(() => orderedFields(props.fields || [], ["enabled", "cron", "storage_id"]));
    const bottom = computed(() => orderedFields(props.fields || [], ["confirm_permanent", "notification_enabled"]));
    const password = computed(() => props.fields?.find((field) => field.key === "password"));
    const formValue = computed(() => ({ ...props.modelValue, storage_id: props.modelValue.storage_id || null }));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        (openBlock(true), createElementBlock(
          Fragment,
          null,
          renderList(top.value, (field) => {
            return openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
              key: field.key,
              fields: [field],
              "model-value": formValue.value,
              disabled: __props.disabled,
              compact: "",
              "plugin-id": "storage-recycle-cleaner",
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:modelValue", $event))
            }, null, 8, ["fields", "model-value", "disabled"]);
          }),
          128
          /* KEYED_FRAGMENT */
        )),
        createVNode(_sfc_main$2, {
          "model-value": __props.modelValue.password,
          disabled: __props.disabled,
          label: password.value?.label || "回收站安全密钥",
          request: __props.request,
          endpoint: "/plugins/storage-recycle-cleaner/config/secret/password",
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => emit("update:modelValue", { ...__props.modelValue, password: $event, password_clear: false }))
        }, null, 8, ["model-value", "disabled", "label", "request"]),
        (openBlock(true), createElementBlock(
          Fragment,
          null,
          renderList(bottom.value, (field) => {
            return openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
              key: field.key,
              fields: [field],
              "model-value": formValue.value,
              disabled: __props.disabled,
              compact: "",
              "plugin-id": "storage-recycle-cleaner",
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => emit("update:modelValue", $event))
            }, null, 8, ["fields", "model-value", "disabled"]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ]);
    };
  }
});
const _hoisted_1 = { class: "recycle-header" };
const _hoisted_2 = { class: "recycle-content" };
const _hoisted_3 = {
  key: 0,
  class: "recycle-message",
  role: "status"
};
const _hoisted_4 = {
  key: 2,
  class: "recycle-overview",
  "aria-label": "回收站清理概览"
};
const _hoisted_5 = { class: "recycle-metrics" };
const _hoisted_6 = { class: "recycle-schedule" };
const _hoisted_7 = { class: "recycle-clock" };
const _hoisted_8 = { class: "recycle-time" };
const _hoisted_9 = { class: "recycle-actions" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: {},
    buttonComponent: {},
    cardComponent: {},
    dialogComponent: {},
    chipComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const runs = ref([]);
    const loading = ref(false);
    const error = ref(false);
    const metrics = computed(() => {
      const states = runs.value.map((run) => run.display_status || run.status || "");
      const count = (values) => states.filter((state) => values.includes(state)).length;
      return [
        { label: "清理次数", count: count(["completed", "failed", "partial", "running", "pending"]), tone: "neutral", icon: "mdi-trash-can-outline" },
        { label: "成功", count: count(["completed"]), tone: "success", icon: "mdi-check-circle-outline" },
        { label: "失败", count: count(["failed", "partial"]), tone: "error", icon: "mdi-close-circle-outline" },
        { label: "进行中", count: count(["running", "pending"]), tone: "primary", icon: "mdi-refresh" }
      ];
    });
    const scheduled = computed(() => {
      const installation = props.context.installation;
      const config = installation?.config;
      return Boolean(installation?.enabled && config && typeof config === "object" && "enabled" in config && config.enabled === true);
    });
    const nextRun = computed(() => {
      if (!scheduled.value) return "未启用";
      const value = props.context.installation?.next_run_at;
      if (!value) return "等待调度";
      const normalized = /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(value) ? `${value.replace(" ", "T")}Z` : value;
      const date = new Date(normalized);
      return Number.isFinite(date.getTime()) ? date.toLocaleString("zh-CN", { hour12: false }) : "等待调度";
    });
    async function load() {
      if (loading.value) return;
      loading.value = true;
      error.value = false;
      try {
        runs.value = (await props.request("/plugins/storage-recycle-cleaner/runs?limit=100")).items || [];
      } catch {
        error.value = true;
      } finally {
        loading.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      const _component_VIcon = resolveComponent("VIcon");
      return openBlock(), createBlock(resolveDynamicComponent(__props.dialogComponent), {
        "model-value": true,
        "max-width": 780,
        width: "calc(100vw - 32px)",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = (open) => {
          if (!open) __props.context.close();
        })
      }, {
        default: withCtx(() => [
          (openBlock(), createBlock(resolveDynamicComponent(__props.cardComponent), { class: "recycle-statistics" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1, [
                _cache[1] || (_cache[1] = createElementVNode(
                  "h2",
                  null,
                  "网盘回收站清理 · 数据统计",
                  -1
                  /* CACHED */
                )),
                (openBlock(), createBlock(resolveDynamicComponent(__props.buttonComponent), {
                  class: "app-dialog-close",
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: __props.context.close
                }, null, 8, ["onClick"]))
              ]),
              createElementVNode("main", _hoisted_2, [
                loading.value ? (openBlock(), createElementBlock("p", _hoisted_3, "正在读取插件统计…")) : error.value ? (openBlock(), createBlock(resolveDynamicComponent(__props.alertComponent), {
                  key: 1,
                  type: "error",
                  variant: "tonal"
                }, {
                  default: withCtx(() => [..._cache[2] || (_cache[2] = [
                    createTextVNode(
                      "统计加载失败，请点击刷新重试。",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                })) : (openBlock(), createElementBlock("section", _hoisted_4, [
                  _cache[5] || (_cache[5] = createElementVNode(
                    "div",
                    { class: "recycle-heading" },
                    [
                      createElementVNode("h3", null, "运行概览"),
                      createElementVNode("span", null, "最近 100 次运行")
                    ],
                    -1
                    /* CACHED */
                  )),
                  createElementVNode("dl", _hoisted_5, [
                    (openBlock(true), createElementBlock(
                      Fragment,
                      null,
                      renderList(metrics.value, (metric) => {
                        return openBlock(), createElementBlock(
                          "div",
                          {
                            key: metric.label,
                            class: normalizeClass(["recycle-metric", `tone-${metric.tone}`])
                          },
                          [
                            createElementVNode("dt", null, [
                              createElementVNode(
                                "span",
                                null,
                                toDisplayString(metric.label),
                                1
                                /* TEXT */
                              ),
                              createVNode(_component_VIcon, {
                                icon: metric.icon,
                                size: 18
                              }, null, 8, ["icon"])
                            ]),
                            createElementVNode("dd", null, [
                              createTextVNode(
                                toDisplayString(metric.count),
                                1
                                /* TEXT */
                              ),
                              _cache[3] || (_cache[3] = createElementVNode(
                                "span",
                                null,
                                "次",
                                -1
                                /* CACHED */
                              ))
                            ])
                          ],
                          2
                          /* CLASS */
                        );
                      }),
                      128
                      /* KEYED_FRAGMENT */
                    ))
                  ]),
                  createElementVNode("div", _hoisted_6, [
                    createElementVNode("span", _hoisted_7, [
                      createVNode(_component_VIcon, {
                        icon: "mdi-clock-outline",
                        size: 22
                      })
                    ]),
                    createElementVNode("div", _hoisted_8, [
                      _cache[4] || (_cache[4] = createElementVNode(
                        "span",
                        null,
                        "下次执行",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "strong",
                        null,
                        toDisplayString(nextRun.value),
                        1
                        /* TEXT */
                      )
                    ]),
                    (openBlock(), createBlock(resolveDynamicComponent(__props.chipComponent), {
                      color: scheduled.value ? "primary" : void 0,
                      size: "small",
                      variant: "tonal"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(
                          toDisplayString(scheduled.value ? "定时清理已启用" : "定时清理未启用"),
                          1
                          /* TEXT */
                        )
                      ]),
                      _: 1
                      /* STABLE */
                    }, 8, ["color"]))
                  ])
                ]))
              ]),
              createElementVNode("footer", _hoisted_9, [
                (openBlock(), createBlock(resolveDynamicComponent(__props.buttonComponent), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: loading.value,
                  onClick: load
                }, {
                  default: withCtx(() => [..._cache[6] || (_cache[6] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading"]))
              ])
            ]),
            _: 1
            /* STABLE */
          }))
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-9d5c1a0e"]]);
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const { Button, Card, Dialog, Chip, Alert } = sdk.ui.components;
  sdk.registerContribution({
    pluginId: "storage-recycle-cleaner",
    slot: "plugin.statistics",
    key: "overview",
    component: defineComponent2({
      props: { context: { type: Object, required: true } },
      setup(props) {
        return () => h(StatisticsView, {
          context: props.context,
          request: sdk.request,
          buttonComponent: Button,
          cardComponent: Card,
          dialogComponent: Dialog,
          chipComponent: Chip,
          alertComponent: Alert
        });
      }
    })
  });
  const schemaFields = sdk.ui.components.SchemaFields;
  if (!schemaFields) throw new Error("请更新主程序以使用公共配置表单");
  sdk.registerEditor({
    domain: "plugin",
    key: "storage-recycle-cleaner",
    component: defineComponent2({
      inheritAttrs: false,
      props: { modelValue: { type: Object, required: true }, disabled: Boolean },
      emits: ["update:modelValue"],
      setup(props, { attrs, emit }) {
        return () => h(_sfc_main$1, {
          ...attrs,
          modelValue: props.modelValue,
          disabled: props.disabled,
          request: sdk.request,
          schemaFieldsComponent: schemaFields,
          "onUpdate:modelValue": (value) => emit("update:modelValue", value)
        });
      }
    })
  });
}
export {
  install
};
