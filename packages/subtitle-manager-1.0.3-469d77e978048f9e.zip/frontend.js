if (typeof document !== "undefined") { const id = "subtitle_manager"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "/* Preserve cascade order across the workspace layout layers. */\n.subtitle-host-notice--notification-only { display: none !important;\n}\n.subtitle-workspace {\n  --subtitle-provider-assrt: 124, 58, 237;\r\n  width: 100%;\r\n  min-width: 0;\r\n  height: auto;\r\n  min-height: calc(100vh - 102px);\r\n  color: var(--app-text);\n}\r\n\r\n/* Source rail: keep the aggregate fixed while providers move like a film strip. */\n.subtitle-source-filter {\r\n  display: flex;\r\n  min-width: 0;\r\n  align-items: stretch;\n}\n.subtitle-source-all {\r\n  z-index: 4;\r\n  flex: 0 0 auto;\n}\n.subtitle-source-scroller {\r\n  position: relative;\r\n  min-width: 0;\r\n  flex: 1 1 auto;\r\n  overflow: hidden;\n}\n.subtitle-source-scroller::before,\r\n.subtitle-source-scroller::after {\r\n  position: absolute;\r\n  z-index: 2;\r\n  top: 0;\r\n  bottom: 0;\r\n  width: 42px;\r\n  pointer-events: none;\r\n  content: \"\";\r\n  opacity: 0;\r\n  transition: opacity 0.16s ease;\n}\n.subtitle-source-scroller::before {\r\n  left: 0;\r\n  background: linear-gradient(90deg, var(--app-surface) 18%, transparent);\n}\n.subtitle-source-scroller::after {\r\n  right: 0;\r\n  background: linear-gradient(270deg, var(--app-surface) 18%, transparent);\n}\n.subtitle-source-scroller.can-scroll-left::before,\r\n.subtitle-source-scroller.can-scroll-right::after {\r\n  opacity: 1;\n}\n.subtitle-source-list {\r\n  scroll-behavior: smooth;\r\n  overscroll-behavior-inline: contain;\n}\n.subtitle-source-navigation {\r\n  z-index: 4;\r\n  display: flex;\r\n  flex: 0 0 auto;\r\n  align-items: center;\r\n  gap: 4px;\r\n  padding: 0 8px;\r\n  border-left: 1px solid var(--app-border-subtle);\r\n  background: var(--app-surface);\n}\n.subtitle-source-arrow {\r\n  display: grid;\r\n  width: 30px;\r\n  height: 30px;\r\n  padding: 0;\r\n  place-items: center;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-radius: 9px;\r\n  background: var(--app-surface);\r\n  box-shadow: 0 4px 12px rgba(15, 23, 42, 0.1);\r\n  color: var(--app-text-secondary);\n}\n.subtitle-source-arrow span {\r\n  width: 7px;\r\n  height: 7px;\r\n  transform: rotate(45deg);\r\n  border-bottom: 2px solid currentColor;\r\n  border-left: 2px solid currentColor;\n}\n.subtitle-source-arrow.is-right span {\r\n  transform: rotate(225deg);\n}\n.subtitle-source-arrow:hover,\r\n.subtitle-source-arrow:focus-visible {\r\n  border-color: rgba(var(--v-theme-primary), 0.45);\r\n  color: rgb(var(--v-theme-primary));\r\n  outline: none;\n}\n.subtitle-source-arrow:disabled {\r\n  border-color: transparent;\r\n  box-shadow: none;\r\n  color: var(--app-text-disabled, #a8b2c2);\r\n  cursor: default;\r\n  opacity: 0.55;\n}\n@media (prefers-reduced-motion: reduce) {\n.subtitle-source-list { scroll-behavior: auto;\n}\n.subtitle-source-scroller::before,\r\n  .subtitle-source-scroller::after { transition: none;\n}\n}\n.subtitle-workspace * {\r\n  box-sizing: border-box;\n}\n.subtitle-browser {\r\n  display: flex;\r\n  min-height: calc(100vh - 102px);\r\n  min-width: 0;\r\n  flex-direction: column;\r\n  overflow: clip;\r\n  border: 1px solid var(--app-border);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--app-surface);\r\n  box-shadow: 0 1px 3px var(--app-shadow-color);\n}\n.subtitle-toolbar {\r\n  display: flex;\r\n  min-height: 64px;\r\n  flex: 0 0 auto;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  gap: 20px;\r\n  padding: 10px 16px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-heading {\r\n  display: flex;\r\n  min-width: 0;\r\n  align-items: baseline;\r\n  gap: 12px;\n}\n.subtitle-heading h1 {\r\n  margin: 0;\r\n  color: var(--app-text);\r\n  font-size: var(--app-font-size-section-title, 18px);\r\n  font-weight: var(--app-font-weight-heading, 600);\r\n  line-height: 1.3;\n}\n.subtitle-heading span {\r\n  overflow: hidden;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-controls {\r\n  display: flex;\r\n  min-width: 320px;\r\n  max-width: 650px;\r\n  flex: 1;\r\n  align-items: center;\r\n  justify-content: flex-end;\r\n  gap: 8px;\n}\n.subtitle-search-wrap {\r\n  position: relative;\r\n  width: min(430px, 100%);\n}\n.subtitle-search-icon {\r\n  position: absolute;\r\n  top: 50%;\r\n  left: 14px;\r\n  width: 14px;\r\n  height: 14px;\r\n  transform: translateY(-55%);\r\n  border: 2px solid var(--app-text-muted);\r\n  border-radius: 50%;\r\n  pointer-events: none;\n}\n.subtitle-search-icon:after {\r\n  position: absolute;\r\n  right: -5px;\r\n  bottom: -3px;\r\n  width: 6px;\r\n  height: 2px;\r\n  transform: rotate(45deg);\r\n  border-radius: 1px;\r\n  background: var(--app-text-muted);\r\n  content: \"\";\n}\n.subtitle-search {\r\n  width: 100%;\r\n  height: var(--app-control-height-compact, 40px);\r\n  padding: 0 14px 0 38px;\r\n  border: 1px solid var(--app-border);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  outline: none;\r\n  background: var(--app-surface);\r\n  color: var(--app-text);\r\n  font: inherit;\n}\n.subtitle-search::placeholder {\r\n  color: var(--app-text-muted);\n}\n.subtitle-search:focus {\r\n  border-color: rgb(var(--v-theme-primary));\r\n  box-shadow: 0 0 0 3px rgba(var(--v-theme-primary), 0.1);\n}\n.subtitle-action,\r\n.subtitle-icon-button,\r\n.subtitle-text-button {\r\n  border: 0;\r\n  border-radius: var(--app-control-radius, 12px);\r\n  font: inherit;\r\n  cursor: pointer;\n}\n.subtitle-action {\r\n  height: var(--app-control-height-compact, 40px);\r\n  padding: 0 12px;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  font-weight: var(--app-font-weight-medium, 500);\r\n  white-space: nowrap;\n}\n.subtitle-action.is-primary {\r\n  background: rgb(var(--v-theme-primary));\r\n  color: rgb(var(--v-theme-on-primary, 255, 255, 255));\n}\n.subtitle-action.is-secondary {\r\n  border: 1px solid var(--app-border);\r\n  background: var(--app-surface);\r\n  color: rgb(var(--v-theme-primary));\n}\n.subtitle-action.is-danger {\r\n  background: rgb(var(--v-theme-error));\r\n  color: rgb(var(--v-theme-on-error, 255, 255, 255));\n}\n.subtitle-icon-button {\r\n  width: var(--app-control-height-compact, 40px);\r\n  height: var(--app-control-height-compact, 40px);\r\n  border: 1px solid var(--app-border);\r\n  background: var(--app-icon-surface, var(--app-surface));\r\n  color: var(--app-text-secondary);\r\n  font-size: 22px;\n}\n.subtitle-action:hover:not(:disabled),\r\n.subtitle-icon-button:hover:not(:disabled) {\r\n  filter: brightness(0.97);\n}\n.subtitle-action:disabled,\r\n.subtitle-icon-button:disabled,\r\n.subtitle-text-button:disabled {\r\n  cursor: not-allowed;\r\n  opacity: 0.45;\n}\n.subtitle-action:focus-visible,\r\n.subtitle-icon-button:focus-visible,\r\n.subtitle-text-button:focus-visible,\r\n.subtitle-media:focus-visible,\r\n.subtitle-upload-file:focus-within {\r\n  outline: 2px solid rgba(var(--v-theme-primary), 0.48);\r\n  outline-offset: 2px;\n}\n.subtitle-notice {\r\n  min-height: 34px;\r\n  margin: 0;\r\n  padding: 8px 16px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\r\n  background: var(--app-surface-subtle);\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-notice.is-error {\r\n  background: rgba(var(--v-theme-error), 0.06);\r\n  color: rgb(var(--v-theme-error));\n}\n.subtitle-layout {\r\n  display: grid;\r\n  min-height: calc(100vh - 166px);\r\n  flex: 0 0 auto;\r\n  align-items: stretch;\r\n  grid-template-columns: minmax(300px, 34%) minmax(0, 1fr);\n}\n.subtitle-sidebar {\r\n  position: sticky;\r\n  top: 0;\r\n  display: flex;\r\n  min-width: 0;\r\n  height: calc(100vh - 102px);\r\n  max-height: calc(100vh - 102px);\r\n  min-height: 420px;\r\n  align-self: start;\r\n  flex-direction: column;\r\n  overflow: hidden;\r\n  border-right: 1px solid var(--app-border-subtle);\n}\n.subtitle-section-heading {\r\n  display: flex;\r\n  min-height: 48px;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  gap: 12px;\r\n  padding: 0 16px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-section-heading h2 {\r\n  margin: 0;\r\n  color: var(--app-text);\r\n  font-size: var(--app-font-size-body, 14px);\r\n  font-weight: var(--app-font-weight-medium, 500);\n}\n.subtitle-section-heading span {\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-list {\r\n  min-height: 0;\r\n  flex: 1;\r\n  overflow: auto;\n}\n.subtitle-media {\r\n  position: relative;\r\n  display: grid;\r\n  width: 100%;\r\n  min-height: 64px;\r\n  grid-template-columns: 22px minmax(0, 1fr) auto;\r\n  align-items: center;\r\n  gap: 10px;\r\n  padding: 8px 14px;\r\n  border: 0;\r\n  border-bottom: 1px solid var(--app-border-subtle);\r\n  background: transparent;\r\n  color: var(--app-text);\r\n  text-align: left;\r\n  cursor: pointer;\n}\n.subtitle-media:hover {\r\n  background: var(--app-surface-subtle);\n}\n.subtitle-media.is-active {\r\n  background: var(--app-surface-selected, rgba(var(--v-theme-primary), 0.08));\n}\n.subtitle-rail {\r\n  position: absolute;\r\n  top: 8px;\r\n  bottom: 8px;\r\n  left: 0;\r\n  width: 3px;\r\n  border-radius: 0 3px 3px 0;\r\n  background: transparent;\n}\n.subtitle-media.is-active .subtitle-rail {\r\n  background: rgb(var(--v-theme-primary));\n}\n.subtitle-media-icon {\r\n  display: grid;\r\n  width: 22px;\r\n  height: 25px;\r\n  place-items: center;\r\n  border-radius: 4px;\r\n  background: var(--app-icon-surface, var(--app-surface-muted));\r\n  color: var(--app-text-muted);\r\n  font-size: 10px;\n}\n.subtitle-media-copy {\r\n  min-width: 0;\n}\n.subtitle-media strong,\r\n.subtitle-media small {\r\n  display: block;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-media strong {\r\n  font-size: 13px;\r\n  font-weight: var(--app-font-weight-medium, 500);\n}\n.subtitle-media small {\r\n  margin-top: 3px;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-count {\r\n  padding: 3px 8px;\r\n  border-radius: 999px;\r\n  background: var(--app-surface-muted);\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  white-space: nowrap;\n}\n.subtitle-detail {\r\n  display: flex;\r\n  min-width: 0;\r\n  min-height: 0;\r\n  flex-direction: column;\r\n  overflow: hidden;\n}\n.subtitle-detail-heading {\r\n  padding: 15px 20px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-detail-heading h2 {\r\n  overflow: hidden;\r\n  margin: 0;\r\n  color: var(--app-text);\r\n  font-size: 16px;\r\n  font-weight: 600;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-detail-heading p {\r\n  overflow: hidden;\r\n  margin: 7px 0 0;\r\n  padding: 8px 10px;\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--app-surface-subtle);\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-files-section {\r\n  min-height: 240px;\r\n  flex: 1 0 auto;\r\n  padding: 0 20px;\n}\n.subtitle-files-heading {\r\n  padding: 0;\r\n  border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-file-list,\r\n.subtitle-online-results {\r\n  border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-file {\r\n  display: flex;\r\n  min-height: 58px;\r\n  align-items: center;\r\n  gap: 10px;\r\n  padding: 8px 0;\r\n  border-bottom: 1px solid var(--app-border-subtle);\r\n  color: var(--app-text);\r\n  text-decoration: none;\n}\n.subtitle-file:last-child {\r\n  border-bottom: 0;\n}\n.subtitle-file-mark {\r\n  display: grid;\r\n  width: 28px;\r\n  height: 32px;\r\n  flex: 0 0 auto;\r\n  place-items: center;\r\n  border-radius: var(--app-radius-chip);\r\n  background: var(--app-surface-muted);\r\n  color: rgb(var(--v-theme-primary));\r\n  font-size: 9px;\r\n  font-weight: 500;\n}\n.subtitle-file-copy {\r\n  min-width: 0;\r\n  flex: 1;\n}\n.subtitle-file-copy strong,\r\n.subtitle-file-copy small {\r\n  display: block;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-file-copy strong {\r\n  font-size: 13px;\r\n  font-weight: var(--app-font-weight-medium, 500);\n}\n.subtitle-file-copy small {\r\n  margin-top: 3px;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-text-button {\r\n  padding: 6px 8px;\r\n  background: transparent;\r\n  color: rgb(var(--v-theme-primary));\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-text-button:hover {\r\n  background: var(--app-surface-selected, rgba(var(--v-theme-primary), 0.08));\n}\n.subtitle-text-button.is-danger {\r\n  color: rgb(var(--v-theme-error));\n}\n.subtitle-search-actions {\r\n  display: flex;\r\n  padding: 14px 0;\n}\n.subtitle-empty {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-body, 14px);\r\n  text-align: center;\n}\n.subtitle-empty-list {\r\n  min-height: 150px;\n}\n.subtitle-empty-files {\r\n  min-height: 250px;\r\n  flex-direction: column;\r\n  gap: 8px;\n}\n.subtitle-empty-files strong {\r\n  color: var(--app-text-secondary);\r\n  font-weight: var(--app-font-weight-medium, 500);\n}\n.subtitle-empty-files small {\r\n  margin-bottom: 8px;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-empty-inline {\r\n  min-height: 44px;\r\n  padding: 11px 0;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-empty-icon {\r\n  display: grid;\r\n  width: 40px;\r\n  height: 46px;\r\n  margin-bottom: 4px;\r\n  place-items: center;\r\n  border: 2px solid var(--app-border);\r\n  border-radius: 7px;\r\n  color: var(--app-text-muted);\r\n  font-size: 16px;\r\n  font-weight: 800;\n}\n.subtitle-results-heading {\r\n  padding: 12px 0 6px;\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  font-weight: var(--app-font-weight-medium, 500);\n}\n.subtitle-results-heading span {\r\n  font-weight: var(--app-font-weight-regular, 400);\n}\n.subtitle-upload-section {\r\n  display: grid;\r\n  flex: 0 0 auto;\r\n  grid-template-columns: minmax(220px, 1fr) 170px auto;\r\n  align-items: end;\r\n  gap: 10px;\r\n  padding: 14px 20px;\r\n  border-top: 1px solid var(--app-border-subtle);\r\n  background: var(--app-surface);\n}\n.subtitle-upload-file {\r\n  position: relative;\r\n  display: grid;\r\n  height: var(--app-control-height, 52px);\r\n  min-width: 0;\r\n  grid-template-columns: auto minmax(0, 1fr);\r\n  align-items: center;\r\n  gap: 10px;\r\n  padding: 0 12px;\r\n  border: 1px solid var(--app-border);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  cursor: pointer;\n}\n.subtitle-upload-file > span {\r\n  padding: 5px 8px;\r\n  border: 1px solid var(--app-border);\r\n  border-radius: calc(var(--app-control-radius, 12px) - 3px);\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  white-space: nowrap;\n}\n.subtitle-upload-file > strong {\r\n  overflow: hidden;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-upload-file input {\r\n  position: absolute;\r\n  width: 1px;\r\n  height: 1px;\r\n  overflow: hidden;\r\n  clip: rect(0 0 0 0);\r\n  white-space: nowrap;\n}\n.subtitle-upload-section > .subtitle-action {\r\n  height: var(--app-control-height, 52px);\n}\n.subtitle-identity {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  align-items: center;\r\n  gap: 6px;\r\n  margin-top: 9px;\n}\n.subtitle-identity span {\r\n  padding: 3px 7px;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--app-surface-muted);\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-identity small {\r\n  overflow: hidden;\r\n  max-width: 100%;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-detail-heading .subtitle-identity-warning {\r\n  margin-top: 6px;\r\n  background: rgba(var(--v-theme-warning), 0.08);\r\n  color: rgb(var(--v-theme-warning));\n}\n.subtitle-online-panel {\r\n  margin: 0 0 16px;\r\n  border-top: 1px solid var(--app-border-subtle);\n}\n.subtitle-online-controls {\r\n  display: grid;\r\n  grid-template-columns: minmax(240px, 1fr) auto auto;\r\n  align-items: center;\r\n  gap: 8px;\r\n  padding: 8px 0 12px;\n}\n.subtitle-online-query {\r\n  height: var(--app-control-height-compact, 40px);\r\n  min-height: var(--app-control-height-compact, 40px);\r\n  padding-left: 12px;\n}\n.subtitle-season-toggle {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  white-space: nowrap;\r\n  cursor: pointer;\r\n  user-select: none;\n}\n.subtitle-season-toggle input {\r\n  cursor: pointer;\n}\n.subtitle-source-progress,\r\n.subtitle-manual-actions {\r\n  padding: 10px 12px;\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--app-surface-subtle);\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\n}\r\n\r\n/* Notices must never consume the workspace remainder in the flex column. */\n.subtitle-host-notice { flex: 0 0 auto; min-height: 0;\n}\n.subtitle-source-list {\r\n  display: grid;\r\n  grid-template-columns: repeat(auto-fit, minmax(145px, 1fr));\r\n  gap: 6px;\r\n  margin-bottom: 8px;\n}\n.subtitle-source {\r\n  width: 100%;\r\n  appearance: none;\r\n  display: grid;\r\n  grid-template-columns: minmax(0, 1fr) auto;\r\n  gap: 2px 8px;\r\n  padding: 8px 10px;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--app-surface);\r\n  color: inherit;\r\n  font: inherit;\r\n  text-align: left;\r\n  cursor: pointer;\r\n  transition:\r\n    border-color 0.16s ease,\r\n    background-color 0.16s ease,\r\n    box-shadow 0.16s ease;\n}\n.subtitle-source:hover {\r\n  background: var(--app-surface-subtle);\n}\n.subtitle-source:focus-visible {\r\n  outline: 2px solid rgba(var(--v-theme-primary), 0.42);\r\n  outline-offset: 2px;\n}\n.subtitle-source.is-active {\r\n  border-color: rgba(var(--v-theme-primary), 0.62);\r\n  background: var(--app-surface-selected, rgba(var(--v-theme-primary), 0.08));\r\n  box-shadow: inset 0 0 0 1px rgba(var(--v-theme-primary), 0.16);\n}\n.subtitle-source strong,\r\n.subtitle-source span,\r\n.subtitle-source small {\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-source span {\r\n  color: var(--app-text-muted);\n}\n.subtitle-source small {\r\n  grid-column: 1/-1;\r\n  color: rgb(var(--v-theme-error));\n}\n.subtitle-source.is-ready {\r\n  border-left: 3px solid rgb(var(--v-theme-success));\n}\n.subtitle-source.is-restricted {\r\n  border-left: 3px solid rgb(var(--v-theme-warning));\n}\n.subtitle-source.is-error {\r\n  border-left: 3px solid rgb(var(--v-theme-error));\n}\n.subtitle-online-file {\r\n  cursor: pointer;\n}\n.subtitle-online-file input[type=\"radio\"] {\r\n  cursor: pointer;\n}\n.subtitle-online-file input[type=\"radio\"]:disabled {\r\n  cursor: not-allowed;\n}\n.subtitle-provider-mark.is-assrt {\r\n  background: rgba(var(--subtitle-provider-assrt), 0.1);\r\n  color: rgb(var(--subtitle-provider-assrt));\n}\n.subtitle-provider-mark.is-opensubtitles {\r\n  background: rgba(var(--v-theme-success), 0.1);\r\n  color: rgb(var(--v-theme-success));\n}\n.subtitle-provider-mark.is-zimuku {\r\n  background: rgba(var(--v-theme-warning), 0.12);\r\n  color: rgb(var(--v-theme-warning));\n}\n.subtitle-provider-mark.is-other {\r\n  color: var(--app-text-secondary);\n}\n.subtitle-dialog-backdrop {\r\n  position: fixed;\r\n  z-index: 2200;\r\n  top: 0;\r\n  left: calc(100% - 100vw);\r\n  width: 100vw;\r\n  height: 100vh;\r\n  display: grid;\r\n  padding: 20px;\r\n  background: rgba(15, 23, 42, 0.52);\r\n  place-items: center;\n}\n.subtitle-dialog {\r\n  width: min(100%, 480px);\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border);\r\n  border-radius: var(--app-dialog-radius, 17px);\r\n  background: var(--app-surface);\r\n  box-shadow: 0 24px 64px rgba(15, 23, 42, 0.22);\n}\n.subtitle-dialog-heading {\r\n  display: flex;\r\n  position: relative;\r\n  align-items: center;\r\n  gap: 0;\r\n  padding: 15px 52px 13px 20px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-dialog-symbol {\r\n  display: none;\n}\n.subtitle-dialog-symbol.is-timeline::before,\r\n.subtitle-dialog-symbol.is-timeline::after {\r\n  position: absolute;\r\n  content: \"\";\n}\n.subtitle-dialog-symbol.is-timeline::before {\r\n  width: 20px;\r\n  height: 2px;\r\n  border-radius: 2px;\r\n  background: currentColor;\r\n  box-shadow: 0 -6px 0 rgba(var(--v-theme-primary), 0.42), 0 6px 0 rgba(var(--v-theme-primary), 0.42);\n}\n.subtitle-dialog-symbol.is-timeline::after {\r\n  width: 4px;\r\n  height: 4px;\r\n  border: 2px solid currentColor;\r\n  border-radius: 50%;\r\n  background: var(--app-surface);\n}\n.subtitle-dialog-symbol.is-danger {\r\n  background: rgba(var(--v-theme-error), 0.1);\r\n  color: rgb(var(--v-theme-error));\n}\n.subtitle-dialog-heading h2 {\r\n  margin: 0;\r\n  color: var(--app-text);\r\n  font-size: 16px;\r\n  font-weight: 600;\n}\n.subtitle-dialog-heading p {\r\n  margin: 3px 0 0;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-dialog-close {\r\n  position: absolute;\r\n  top: 14px;\r\n  right: 18px;\r\n  width: 30px;\r\n  height: 30px;\r\n  padding: 0;\r\n  border: 0;\r\n  border-radius: 8px;\r\n  background: transparent;\r\n  color: var(--app-text-muted);\r\n  font-size: 22px;\r\n  line-height: 1;\r\n  cursor: pointer;\n}\n.subtitle-dialog-close:hover:not(:disabled) {\r\n  background: var(--app-surface-muted);\r\n  color: var(--app-text);\n}\n.subtitle-dialog-body {\r\n  padding: 14px 20px 8px;\n}\n.subtitle-upload-dialog {\r\n  width: min(100%, 500px);\n}\n.subtitle-upload-dialog-body {\r\n  display: grid;\r\n  gap: 10px;\n}\n.subtitle-upload-dialog-body .subtitle-dialog-target {\r\n  margin-bottom: 0;\n}\n.subtitle-upload-dialog-body .subtitle-upload-file {\r\n  height: 52px;\r\n  background: var(--app-surface-subtle);\n}\n.subtitle-upload-dialog-body .subtitle-dialog-error {\r\n  margin: 0;\n}\n.subtitle-delete-dialog {\r\n  width: min(100%, 460px);\n}\n.subtitle-delete-dialog-body {\r\n  padding-bottom: 12px;\n}\n.subtitle-delete-message {\r\n  margin: 0 0 10px;\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-body, 14px);\n}\n.subtitle-delete-dialog-body .subtitle-dialog-file {\r\n  margin-bottom: 0;\n}\n.subtitle-dialog-file {\r\n  display: block;\r\n  overflow: hidden;\r\n  margin-bottom: 14px;\r\n  padding: 8px 10px;\r\n  border-radius: 9px;\r\n  background: var(--app-surface-subtle);\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-dialog-target {\r\n  display: flex;\r\n  min-width: 0;\r\n  min-height: 40px;\r\n  align-items: center;\r\n  gap: 10px;\r\n  margin-bottom: 11px;\r\n  padding: 8px 10px;\r\n  border: 0;\r\n  border-radius: 8px;\r\n  background: var(--app-surface-subtle);\n}\n.subtitle-dialog-target.is-danger {\r\n  background: rgba(var(--v-theme-error), 0.055);\n}\n.subtitle-dialog-target span {\r\n  flex: 0 0 auto;\r\n  color: var(--app-text-muted);\r\n  font-size: 10px;\n}\n.subtitle-dialog-target strong {\r\n  overflow: hidden;\r\n  color: var(--app-text-secondary);\r\n  font-size: 12px;\r\n  font-weight: var(--app-font-weight-medium, 500);\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-adjustment-field {\r\n  display: grid;\r\n  grid-template-columns: 76px minmax(0, 1fr);\r\n  align-items: center;\r\n  gap: 10px;\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  font-weight: var(--app-font-weight-medium, 500);\n}\n.subtitle-field-heading {\r\n  color: var(--app-text-secondary);\r\n  font-size: 11px;\n}\n.subtitle-adjustment-input {\r\n  display: flex;\r\n  height: var(--app-control-height, 40px);\r\n  align-items: center;\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--app-surface);\n}\n.subtitle-adjustment-input input {\r\n  width: 100%;\r\n  min-width: 0;\r\n  height: 100%;\r\n  flex: 1 1 auto;\r\n  padding: 0 12px;\r\n  border: 0;\r\n  outline: 0;\r\n  background: transparent;\r\n  color: var(--app-text);\r\n  font: inherit;\n}\n.subtitle-adjustment-input > span {\r\n  display: grid;\r\n  height: 24px;\r\n  padding: 0 12px;\r\n  border-left: 1px solid var(--app-border-subtle);\r\n  color: var(--app-text-muted);\r\n  font-size: 11px;\r\n  place-items: center;\n}\n.subtitle-adjustment-input:focus-within {\r\n  border-color: rgb(var(--v-theme-primary));\r\n  box-shadow: 0 0 0 3px rgba(var(--v-theme-primary), 0.12);\n}\n.subtitle-dialog-body > small {\r\n  display: block;\r\n  margin: 7px 0 0 86px;\r\n  padding: 0;\r\n  background: transparent;\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-dialog-body > small b {\r\n  color: var(--app-text-secondary);\r\n  font-weight: var(--app-font-weight-medium, 500);\n}\n.subtitle-dialog-error {\r\n  margin: 12px 0 0;\r\n  color: rgb(var(--v-theme-error));\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-dialog-actions {\r\n  display: flex;\r\n  justify-content: flex-end;\r\n  gap: 8px;\r\n  padding: 9px 20px 14px;\r\n  border-top: 1px solid var(--app-border-subtle);\n}\n.subtitle-dialog-actions .subtitle-action {\r\n  min-width: 88px;\n}\n.subtitle-preview-dialog {\r\n  display: flex;\r\n  width: min(1080px, calc(100vw - 40px));\r\n  height: min(720px, calc(100vh - 40px));\r\n  min-height: 480px;\r\n  flex-direction: column;\n}\n.subtitle-host-dialog-content {\r\n  width: auto !important;\r\n  max-width: calc(100% - 20px) !important;\r\n  margin: 10px !important;\n}\n.subtitle-host-dialog-content > .subtitle-dialog {\r\n  overflow: hidden;\r\n  margin: 0;\n}\n.subtitle-mobile-search-dialog {\r\n  width: min(440px, calc(100vw - 28px));\n}\n.subtitle-preview-dialog.is-single {\r\n  width: min(820px, calc(100vw - 40px));\n}\n.subtitle-preview-dialog-body {\r\n  display: grid;\r\n  min-height: 0;\r\n  flex: 1 1 auto;\r\n  grid-template-columns: minmax(260px, 340px) minmax(0, 1fr);\r\n  overflow: hidden;\n}\n.subtitle-preview-dialog.is-single .subtitle-preview-dialog-body {\r\n  grid-template-columns: minmax(0, 1fr);\n}\n.subtitle-preview-files {\r\n  display: flex;\r\n  min-width: 0;\r\n  min-height: 0;\r\n  flex-direction: column;\r\n  border-right: 1px solid var(--app-border-subtle);\r\n  background: var(--app-surface-subtle);\n}\n.subtitle-preview-files-heading {\r\n  display: flex;\r\n  min-height: 46px;\r\n  flex: 0 0 auto;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  gap: 12px;\r\n  padding: 0 16px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\r\n  color: var(--app-text);\r\n  cursor: default;\r\n  font-size: 12px;\r\n  font-weight: 500;\n}\n.subtitle-preview-files-heading small {\r\n  margin-left: 4px;\r\n  color: var(--app-text-muted);\r\n  font-size: 11px;\r\n  font-weight: 500;\n}\n.subtitle-preview-select-all {\r\n  display: inline-flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n  color: var(--app-text-secondary);\r\n  cursor: pointer;\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  user-select: none;\n}\n.subtitle-preview-select-all input,\r\n.subtitle-preview-file > input {\r\n  width: 15px;\r\n  height: 15px;\r\n  margin: 0;\r\n  accent-color: rgb(var(--v-theme-primary));\r\n  cursor: pointer;\n}\n.subtitle-preview-file-list {\r\n  min-height: 0;\r\n  flex: 1 1 auto;\r\n  overflow: auto;\r\n  overscroll-behavior: contain;\r\n  scrollbar-color: var(--app-border) transparent;\r\n  scrollbar-width: thin;\n}\n.subtitle-preview-file {\r\n  position: relative;\r\n  display: grid;\r\n  min-height: 66px;\r\n  grid-template-columns: 15px minmax(0, 1fr) 8px;\r\n  align-items: center;\r\n  gap: 10px;\r\n  padding: 7px 14px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\r\n  background: var(--app-surface);\n}\n.subtitle-preview-file::before {\r\n  position: absolute;\r\n  top: 0;\r\n  bottom: 0;\r\n  left: 0;\r\n  width: 3px;\r\n  background: rgb(var(--v-theme-primary));\r\n  content: \"\";\r\n  opacity: 0;\n}\n.subtitle-preview-file.is-active {\r\n  background: rgba(var(--v-theme-primary), 0.07);\n}\n.subtitle-preview-file.is-active::before {\r\n  opacity: 1;\n}\n.subtitle-preview-file-open {\r\n  display: grid;\r\n  min-width: 0;\r\n  grid-template-columns: 38px minmax(0, 1fr);\r\n  align-items: center;\r\n  gap: 10px;\r\n  padding: 0;\r\n  border: 0;\r\n  outline: 0;\r\n  background: transparent;\r\n  color: inherit;\r\n  cursor: pointer;\r\n  text-align: left;\n}\n.subtitle-preview-file-open:focus-visible {\r\n  border-radius: 7px;\r\n  box-shadow: 0 0 0 2px rgba(var(--v-theme-primary), 0.35);\n}\n.subtitle-preview-format {\r\n  display: grid;\r\n  width: 38px;\r\n  height: 30px;\r\n  border-radius: var(--app-radius-chip);\r\n  place-items: center;\r\n  background: rgba(var(--v-theme-primary), 0.1);\r\n  color: rgb(var(--v-theme-primary));\r\n  font-size: 9px;\r\n  font-weight: 500;\r\n  text-transform: uppercase;\n}\n.subtitle-preview-format.is-ass,\r\n.subtitle-preview-format.is-ssa {\r\n  background: rgba(var(--v-theme-warning), 0.13);\r\n  color: rgb(var(--v-theme-warning));\n}\n.subtitle-preview-file-copy,\r\n.subtitle-preview-current-copy {\r\n  display: grid;\r\n  min-width: 0;\r\n  gap: 4px;\n}\n.subtitle-preview-file-copy strong,\r\n.subtitle-preview-current-copy strong {\r\n  overflow: hidden;\r\n  color: var(--app-text);\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-preview-file-copy small,\r\n.subtitle-preview-current-copy small {\r\n  overflow: hidden;\r\n  color: var(--app-text-muted);\r\n  font-size: 10px;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-preview-valid,\r\n.subtitle-preview-check i {\r\n  width: 8px;\r\n  height: 8px;\r\n  border-radius: 50%;\r\n  background: rgb(var(--v-theme-success));\n}\n.subtitle-preview-content {\r\n  display: flex;\r\n  min-width: 0;\r\n  min-height: 0;\r\n  flex-direction: column;\r\n  padding: 16px;\r\n  background: var(--app-surface);\n}\n.subtitle-preview-current {\r\n  display: grid;\r\n  min-height: 68px;\r\n  flex: 0 0 auto;\r\n  grid-template-columns: 38px minmax(0, 1fr) auto;\r\n  align-items: center;\r\n  gap: 12px;\r\n  padding: 10px 12px;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-radius: 10px 10px 0 0;\n}\n.subtitle-preview-current-copy strong {\r\n  font-size: 11px;\r\n  font-weight: 500;\n}\n.subtitle-preview-check {\r\n  display: inline-flex;\r\n  align-items: center;\r\n  gap: 7px;\r\n  color: var(--app-text-secondary);\r\n  font-size: 11px;\r\n  white-space: nowrap;\n}\n.subtitle-preview-excerpt {\r\n  min-width: 0;\r\n  min-height: 0;\r\n  flex: 1 1 auto;\r\n  margin: 0;\r\n  padding: 18px;\r\n  overflow: auto;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-top: 0;\r\n  border-radius: 0 0 10px 10px;\r\n  background: var(--app-surface-subtle);\r\n  color: var(--app-text-secondary);\r\n  font: 12px/1.75 ui-monospace, SFMono-Regular, Consolas, monospace;\r\n  white-space: pre-wrap;\n}\n.subtitle-preview-footer {\r\n  display: flex;\r\n  min-height: 72px;\r\n  flex: 0 0 auto;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  gap: 16px;\r\n  padding: 12px 20px;\r\n  border-top: 1px solid var(--app-border-subtle);\r\n  color: var(--app-text-secondary);\r\n  font-size: 11px;\n}\n@media (max-width: 700px) {\n.subtitle-preview-dialog {\r\n    width: calc(100vw - 20px);\r\n    height: calc(100vh - 20px);\n}\n.subtitle-preview-dialog-body {\r\n    grid-template-columns: minmax(0, 1fr);\r\n    grid-template-rows: minmax(150px, 34%) minmax(0, 1fr);\n}\n.subtitle-preview-dialog.is-single .subtitle-preview-dialog-body {\r\n    grid-template-rows: minmax(0, 1fr);\n}\n.subtitle-preview-files {\r\n    border-right: 0;\r\n    border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-preview-content {\r\n    padding: 10px;\n}\n}\n.subtitle-captcha-list {\r\n  display: grid;\r\n  gap: 8px;\r\n  margin: 4px 0 10px;\n}\n.subtitle-captcha-card {\r\n  display: grid;\r\n  grid-template-columns: auto minmax(0, 1fr);\r\n  gap: 6px 10px;\r\n  align-items: center;\r\n  padding: 10px;\r\n  border: 1px solid rgb(var(--v-theme-warning));\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: rgba(var(--v-theme-warning), 0.06);\n}\n.subtitle-captcha-image {\r\n  display: block;\r\n  max-width: 120px;\r\n  max-height: 48px;\r\n  border-radius: 5px;\r\n  background: var(--app-surface-subtle);\n}\n.subtitle-captcha-copy {\r\n  min-width: 0;\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  line-height: 1.4;\n}\n.subtitle-captcha-controls {\r\n  grid-column: 1/-1;\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\n}\n.subtitle-captcha-input {\r\n  min-width: 0;\r\n  flex: 1;\r\n  height: var(--app-control-height-compact, 40px);\r\n  min-height: var(--app-control-height-compact, 40px);\r\n  padding: 0 10px;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--app-surface);\r\n  color: var(--app-text-primary);\r\n  font: inherit;\n}\n.subtitle-captcha-input:focus {\r\n  border-color: rgb(var(--v-theme-primary));\r\n  outline: none;\n}\n.subtitle-online-file {\r\n  cursor: pointer;\n}\n.subtitle-online-file :is(\r\n    .subtitle-file-mark,\r\n    .subtitle-file-copy,\r\n    .subtitle-file-copy strong,\r\n    .subtitle-file-copy small\r\n  ) {\r\n  cursor: pointer;\n}\n.subtitle-online-file > input {\r\n  accent-color: rgb(var(--v-theme-primary));\n}\n.subtitle-online-file:hover {\r\n  background: var(--app-surface-subtle);\n}\n.subtitle-online-file .subtitle-text-button {\r\n  text-decoration: none;\n}\n.subtitle-preview-action {\r\n  display: flex;\r\n  justify-content: flex-end;\r\n  padding: 10px 0;\n}\n.subtitle-manual-actions {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  gap: 7px;\r\n  margin-top: 8px;\n}\n.subtitle-manual-actions a {\r\n  color: rgb(var(--v-theme-primary));\n}\n.subtitle-preview-list {\r\n  margin-top: 10px;\r\n  border-top: 1px solid var(--app-border-subtle);\n}\n.subtitle-preview-item {\r\n  padding: 10px 0;\r\n  border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-preview-item label {\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-preview-item pre {\r\n  max-height: 150px;\r\n  margin: 8px 0 0;\r\n  padding: 10px;\r\n  overflow: auto;\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--app-surface-subtle);\r\n  color: var(--app-text-secondary);\r\n  font:\r\n    11px/1.55 ui-monospace,\r\n    SFMono-Regular,\r\n    Consolas,\r\n    monospace;\r\n  white-space: pre-wrap;\n}\r\n/* Compact workspace hierarchy: one rail links the selected media and source. */\n.subtitle-browser {\r\n  border-radius: 14px;\r\n  box-shadow: 0 8px 28px rgba(15, 23, 42, 0.05);\n}\n.subtitle-toolbar {\r\n  min-height: 68px;\r\n  padding: 12px 18px;\n}\n.subtitle-heading::before {\r\n  display: grid;\r\n  width: 30px;\r\n  height: 30px;\r\n  flex: 0 0 auto;\r\n  place-items: center;\r\n  border: 2px solid rgb(var(--v-theme-primary));\r\n  border-radius: 8px;\r\n  color: rgb(var(--v-theme-primary));\r\n  content: \"CC\";\r\n  font-size: 9px;\r\n  font-weight: 800;\r\n  letter-spacing: -0.04em;\n}\n.subtitle-heading h1 {\r\n  font-size: 19px;\n}\n.subtitle-layout {\r\n  grid-template-columns: 300px minmax(0, 1fr);\n}\n.subtitle-sidebar {\r\n  background: var(--app-surface);\n}\n.subtitle-media {\r\n  min-height: 68px;\r\n  grid-template-columns: 26px minmax(0, 1fr) auto;\r\n  padding: 9px 16px;\n}\n.subtitle-media-icon {\r\n  width: 24px;\r\n  height: 28px;\n}\n.subtitle-media.is-active .subtitle-rail {\r\n  top: 0;\r\n  bottom: 0;\r\n  width: 3px;\r\n  border-radius: 0;\n}\n.subtitle-local-list > .subtitle-file-list,\r\n.subtitle-online-results > .subtitle-file-list {\r\n  min-height: 0;\r\n  flex: 1 1 auto;\r\n  overflow: auto;\r\n  overscroll-behavior: contain;\n}\n.subtitle-count {\r\n  padding: 0;\r\n  background: transparent;\n}\n.subtitle-detail-heading {\r\n  padding: 18px 24px 16px;\n}\n.subtitle-detail-heading h2 {\r\n  font-size: 20px;\r\n  letter-spacing: -0.015em;\n}\n.subtitle-detail-heading p {\r\n  margin-top: 6px;\r\n  padding: 0;\r\n  border-radius: 0;\r\n  background: transparent;\n}\n.subtitle-identity {\r\n  gap: 0;\r\n  margin-top: 8px;\n}\n.subtitle-identity span {\r\n  padding: 0;\r\n  border: 0;\r\n  border-radius: 0;\r\n  background: transparent;\n}\n.subtitle-identity span + span::before {\r\n  margin: 0 7px;\r\n  color: var(--app-border);\r\n  content: \"·\";\n}\n.subtitle-identity small {\r\n  width: 100%;\r\n  margin-top: 5px;\n}\n.subtitle-files-section {\r\n  min-height: 0;\r\n  padding: 0 24px 18px;\n}\n.subtitle-files-heading {\r\n  min-height: 58px;\n}\n.subtitle-section-title,\r\n.subtitle-local-actions {\r\n  display: flex;\r\n  align-items: center;\n}\n.subtitle-section-title {\r\n  gap: 9px;\n}\n.subtitle-section-title span {\r\n  color: var(--app-text-muted);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-local-actions {\r\n  gap: 8px;\n}\n.subtitle-action.is-compact {\r\n  height: 34px;\r\n  padding: 0 13px;\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-file-list {\r\n  border-bottom: 0;\n}\n.subtitle-file-list .subtitle-file {\r\n  min-height: 52px;\n}\n.subtitle-search-actions {\r\n  display: none;\n}\n.subtitle-upload-section {\r\n  margin: 10px 0 14px;\r\n  padding: 10px;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--app-surface-subtle);\n}\n.subtitle-upload-file,\r\n.subtitle-upload-section > .subtitle-action {\r\n  height: var(--app-control-height-compact, 40px);\n}\n.subtitle-online-panel {\r\n  margin: 10px 0 0;\r\n  border-top: 1px solid var(--app-border-subtle);\n}\n.subtitle-online-controls {\r\n  padding: 0 0 12px;\n}\n.subtitle-source-progress {\r\n  margin-bottom: 10px;\r\n  padding: 8px 10px;\n}\n.subtitle-source-filter {\r\n  display: grid;\r\n  grid-template-columns: auto minmax(0, 1fr);\r\n  align-items: stretch;\r\n  border-top: 1px solid var(--app-border-subtle);\r\n  border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-source-label {\r\n  display: flex;\r\n  align-items: center;\r\n  padding-right: 15px;\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\r\n  font-weight: var(--app-font-weight-medium, 500);\r\n  white-space: nowrap;\n}\n.subtitle-source-list {\r\n  display: flex;\r\n  min-width: 0;\r\n  gap: 0;\r\n  margin: 0;\r\n  overflow-x: auto;\n}\n.subtitle-source {\r\n  position: relative;\r\n  display: flex;\r\n  width: auto;\r\n  min-width: max-content;\r\n  min-height: 48px;\r\n  align-items: center;\r\n  gap: 7px;\r\n  padding: 0 14px;\r\n  border: 0;\r\n  border-left: 1px solid var(--app-border-subtle);\r\n  border-radius: 0;\r\n  background: transparent;\r\n  box-shadow: none;\r\n  text-align: center;\n}\n.subtitle-source::after {\r\n  position: absolute;\r\n  right: 12px;\r\n  bottom: 0;\r\n  left: 12px;\r\n  height: 3px;\r\n  transform: scaleX(0);\r\n  border-radius: 3px 3px 0 0;\r\n  background: rgb(var(--v-theme-primary));\r\n  content: \"\";\r\n  transition: transform 0.16s ease;\n}\n.subtitle-source:hover {\r\n  background: var(--app-surface-subtle);\n}\n.subtitle-source.is-active {\r\n  border-color: var(--app-border-subtle);\r\n  background: transparent;\r\n  box-shadow: none;\n}\n.subtitle-source.is-active::after {\r\n  transform: scaleX(1);\n}\n.subtitle-source.is-ready,\r\n.subtitle-source.is-restricted,\r\n.subtitle-source.is-error {\r\n  border-left-width: 1px;\r\n  border-left-color: var(--app-border-subtle);\n}\n.subtitle-source-dot {\r\n  width: 8px;\r\n  height: 8px;\r\n  flex: 0 0 auto;\r\n  border-radius: 50%;\r\n  background: var(--app-text-muted);\n}\n.subtitle-source.is-ready .subtitle-source-dot {\r\n  background: rgb(var(--v-theme-success));\n}\n.subtitle-source.is-restricted .subtitle-source-dot {\r\n  background: rgb(var(--v-theme-warning));\n}\n.subtitle-source.is-error .subtitle-source-dot {\r\n  background: rgb(var(--v-theme-error));\n}\n.subtitle-source strong,\r\n.subtitle-source span {\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-online-results {\r\n  margin-top: 10px;\r\n  overflow: auto;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-radius: var(--app-control-radius, 12px);\n}\n.subtitle-online-file {\r\n  min-height: 68px;\r\n  padding: 9px 14px;\r\n  cursor: default;\n}\n.subtitle-online-file :is(\r\n    .subtitle-file-mark,\r\n    .subtitle-file-copy,\r\n    .subtitle-file-copy strong,\r\n    .subtitle-file-copy small\r\n  ) {\r\n  cursor: default;\n}\n.subtitle-online-file .subtitle-file-mark {\r\n  width: 34px;\r\n  height: 38px;\r\n  border-radius: var(--app-radius-chip, 6px);\r\n  font-size: 9px;\n}\n.subtitle-online-file .subtitle-file-copy strong {\r\n  font-size: 13px;\n}\n.subtitle-online-file .subtitle-file-copy small {\r\n  display: inline-block;\r\n  max-width: calc(100% - 70px);\n}\n.subtitle-source-link {\r\n  display: grid;\r\n  width: 30px;\r\n  height: 30px;\r\n  flex: 0 0 auto;\r\n  place-items: center;\r\n  border-radius: 7px;\r\n  color: var(--app-text-muted);\r\n  font-size: 17px;\r\n  text-decoration: none;\n}\n.subtitle-source-link:hover,\r\n.subtitle-source-link:focus-visible {\r\n  background: var(--app-surface-muted);\r\n  color: rgb(var(--v-theme-primary));\r\n  outline: none;\n}\n.subtitle-online-actions {\r\n  flex: 0 0 auto;\r\n  gap: 6px;\n}\n.subtitle-preview-action {\r\n  position: sticky;\r\n  z-index: 2;\r\n  bottom: 0;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 10px 14px;\r\n  border-top: 1px solid var(--app-border-subtle);\r\n  background: var(--app-surface);\r\n  box-shadow: 0 -8px 20px rgba(15, 23, 42, 0.03);\n}\n.subtitle-preview-action > span {\r\n  color: var(--app-text-secondary);\r\n  font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-manual-actions {\r\n  margin-top: 18px;\r\n  padding: 8px 10px;\n}\n@media (max-width: 900px) {\n.subtitle-workspace {\r\n    height: auto;\r\n    min-height: 0;\n}\n.subtitle-layout {\r\n    grid-template-columns: 1fr;\n}\n.subtitle-sidebar {\r\n    position: static;\r\n    height: auto;\r\n    max-height: 310px;\r\n    min-height: 0;\r\n    border-right: 0;\r\n    border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-detail {\r\n    min-height: 480px;\r\n    overflow: visible;\n}\n.subtitle-source-filter {\r\n    grid-template-columns: 1fr;\n}\n.subtitle-source-label {\r\n    padding: 9px 0 3px;\n}\n}\r\n/* Final tabbed subtitle workbench. */\n.subtitle-heading::before {\r\n  display: none;\n}\n.subtitle-toolbar {\r\n  min-height: 52px;\r\n  padding: 6px 14px;\n}\n.subtitle-heading h1 {\r\n  font-size: 17px;\n}\n.subtitle-sidebar-search {\r\n  position: relative;\r\n  display: block;\r\n  min-width: 0;\r\n  flex: 1 1 auto;\r\n  margin: 0;\n}\n.subtitle-sidebar-tools {\r\n  display: flex;\r\n  flex: 0 0 auto;\r\n  align-items: center;\r\n  gap: 8px;\r\n  padding: 8px 12px;\n}\n.subtitle-sidebar-search .subtitle-search {\r\n  height: 34px;\r\n  min-height: 34px;\r\n  padding-right: 34px;\r\n  padding-left: 36px;\r\n  background: var(--app-surface);\r\n  font-size: 12px;\n}\n.subtitle-sidebar-search .subtitle-search-icon {\r\n  left: 13px;\n}\n.subtitle-sidebar-search > button {\r\n  position: absolute;\r\n  top: 50%;\r\n  right: 8px;\r\n  display: grid;\r\n  width: 24px;\r\n  height: 24px;\r\n  transform: translateY(-50%);\r\n  place-items: center;\r\n  border: 0;\r\n  border-radius: 50%;\r\n  background: var(--app-surface-muted);\r\n  color: var(--app-text-muted);\r\n  font: inherit;\r\n  cursor: pointer;\n}\n.subtitle-sidebar-refresh {\r\n  width: 34px;\r\n  height: 34px;\r\n  flex: 0 0 34px;\r\n  border-radius: var(--app-radius-action, 8px);\r\n  font-size: 19px;\n}\n.subtitle-poster {\r\n  display: grid;\r\n  width: 64px;\r\n  height: 86px;\r\n  flex: 0 0 auto;\r\n  overflow: hidden;\r\n  place-items: center;\r\n  border-radius: 7px;\r\n  background: var(--app-surface-muted);\r\n  color: var(--app-text-muted);\r\n  font-size: 11px;\r\n  font-weight: 500;\n}\n.subtitle-poster img {\r\n  width: 100%;\r\n  height: 100%;\r\n  object-fit: cover;\n}\n.subtitle-content-tabs {\r\n  display: flex;\r\n  min-height: 48px;\r\n  flex: 0 0 auto;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  gap: 20px;\r\n  padding: 0 18px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\n}\n.subtitle-content-tab-list {\n  --v-tabs-height: 48px;\n  min-width: 0;\n  align-self: stretch;\n}\n.subtitle-content-tab-list .v-slide-group__content {\n  gap: 0;\n}\n.subtitle-content-tab-list .v-tab {\n  min-width: 0;\n  padding-inline: 14px;\n  font-size: 13px;\n}\n.subtitle-tab-action {\r\n  flex: 0 0 auto;\n}\n.subtitle-mobile-search-trigger {\r\n  display: none;\n}\n.subtitle-tab-search-controls {\r\n  display: flex;\r\n  min-width: 0;\r\n  flex: 1 1 auto;\r\n  align-items: center;\r\n  justify-content: flex-end;\r\n  gap: 12px;\n}\n.subtitle-tab-search {\r\n  width: min(360px, 46vw);\r\n  flex: 0 1 360px;\n}\n.subtitle-tab-search .subtitle-search {\r\n  padding-right: 14px;\n}\n.subtitle-tab-search .subtitle-search:disabled {\r\n  cursor: progress;\r\n  opacity: 0.68;\n}\n.subtitle-local-panel {\r\n  display: flex;\r\n  min-height: 0;\r\n  flex: 1 1 auto;\r\n  flex-direction: column;\r\n  padding: 0;\r\n  overflow: hidden;\n}\n.subtitle-local-list {\r\n  display: flex;\r\n  min-height: 0;\r\n  flex: 1 1 auto;\r\n  flex-direction: column;\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-right: 0;\r\n  border-bottom: 0;\r\n  border-left: 0;\r\n  border-radius: 0;\n}\n.subtitle-local-panel .subtitle-files-heading {\r\n  padding-right: 18px;\r\n  padding-left: 18px;\n}\n.subtitle-local-columns,\r\n.subtitle-local-file {\r\n  display: grid;\r\n  grid-template-columns:\r\n    44px minmax(0, 6.2fr) minmax(84px, 1fr) minmax(60px, 0.7fr)\r\n    minmax(68px, 0.8fr) 32px;\r\n  align-items: center;\r\n  column-gap: 8px;\n}\n.subtitle-local-columns {\r\n  min-height: 38px;\r\n  flex: 0 0 auto;\r\n  padding: 0 12px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\r\n  background: var(--app-surface-subtle);\r\n  color: var(--app-text-muted);\r\n  font-size: 11px;\n}\n.subtitle-local-columns::before {\r\n  content: \"\";\n}\n.subtitle-local-file {\r\n  position: relative;\r\n  min-height: 54px;\r\n  padding: 7px 12px;\n}\n.subtitle-local-file .subtitle-file-mark {\r\n  width: 36px;\r\n  height: 28px;\r\n  border: 0;\r\n  border-radius: var(--app-radius-chip, 6px);\r\n  background: rgba(var(--v-theme-primary), 0.1);\r\n  color: rgb(var(--v-theme-primary));\r\n  font-size: 9px;\n}\n.subtitle-local-file .subtitle-file-mark.is-ass,\r\n.subtitle-local-file .subtitle-file-mark.is-ssa {\r\n  background: rgba(var(--v-theme-warning), 0.14);\r\n  color: rgb(var(--v-theme-warning));\n}\n.subtitle-file-meta {\r\n  overflow: hidden;\r\n  color: var(--app-text-secondary);\r\n  font-size: 12px;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\n}\n.subtitle-mobile-meta {\r\n  display: none;\n}\n.subtitle-file-actions {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: flex-end;\r\n  gap: 12px;\n}\n.subtitle-row-actions {\r\n  position: relative;\r\n  display: flex;\r\n  width: 28px;\r\n  align-items: center;\r\n  justify-content: center;\r\n  justify-self: end;\n}\n.subtitle-action-trigger {\r\n  display: grid;\r\n  width: 28px;\r\n  height: 28px;\r\n  padding: 0;\r\n  border: 0;\r\n  border-radius: var(--app-radius-action, 8px);\r\n  place-items: center;\r\n  color: rgb(var(--v-theme-primary));\r\n  background: transparent;\r\n  cursor: pointer;\r\n  font-size: 22px;\r\n  font-weight: 700;\r\n  line-height: 1;\n}\n.subtitle-action-trigger:hover,\r\n.subtitle-action-trigger[aria-expanded=\"true\"] {\r\n  background: rgba(var(--v-theme-primary), 0.08);\n}\n.subtitle-row-action-menu {\r\n  position: absolute;\r\n  z-index: 12;\r\n  top: calc(100% + 4px);\r\n  right: 8px;\r\n  display: grid;\r\n  min-width: 148px;\r\n  padding: 6px;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-radius: var(--app-radius-action, 8px);\r\n  background: var(--app-surface);\r\n  box-shadow: var(--app-shadow-overlay, 0 12px 30px rgba(15, 23, 42, 0.16));\n}\n.subtitle-row-action-menu.is-above {\r\n  top: auto;\r\n  bottom: calc(100% + 4px);\n}\n.subtitle-row-action-menu > :is(button, a) {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 10px;\r\n  min-height: 40px;\r\n  padding: 0 10px;\r\n  border: 0;\r\n  border-radius: var(--app-radius-action, 8px);\r\n  color: var(--app-text);\r\n  background: transparent;\r\n  cursor: pointer;\r\n  font: inherit;\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n  line-height: 40px;\r\n  text-align: left;\r\n  text-decoration: none;\n}\n.subtitle-row-action-menu > :is(button, a):hover {\r\n  background: var(--app-surface-subtle);\n}\r\n/* Match the host card-action-menu. The host SVG renderer strips inline size\r\n   styles, so VIcon's size prop alone falls back to the menu text size. */\n.subtitle-row-action-menu .v-icon {\r\n  flex: 0 0 18px;\r\n  width: 18px;\r\n  height: 18px;\r\n  font-size: 18px !important;\r\n  opacity: 1 !important;\n}\n.subtitle-row-action-menu .v-icon > svg {\r\n  width: 18px;\r\n  height: 18px;\n}\n.subtitle-row-action-menu > button:disabled {\r\n  cursor: not-allowed;\r\n  opacity: 0.42;\n}\n.subtitle-row-action-menu > .is-danger {\r\n  color: rgb(var(--v-theme-error));\n}\n.subtitle-online-results {\r\n  display: flex;\r\n  min-height: 0;\r\n  flex: 1 1 auto;\r\n  flex-direction: column;\r\n  margin-top: 0;\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border-subtle);\r\n  border-right: 0;\r\n  border-bottom: 0;\r\n  border-left: 0;\r\n  border-radius: 0;\n}\n.subtitle-online-columns,\r\n.subtitle-online-file {\r\n  display: grid;\r\n  grid-template-columns:\r\n    44px minmax(0, 6.4fr) minmax(96px, 1.25fr) minmax(72px, 0.8fr)\r\n    minmax(58px, 0.65fr) minmax(68px, 0.75fr) 32px;\r\n  align-items: center;\r\n  column-gap: 8px;\n}\n.subtitle-online-columns {\r\n  min-height: 38px;\r\n  flex: 0 0 auto;\r\n  padding: 0 12px;\r\n  border-bottom: 1px solid var(--app-border-subtle);\r\n  background: var(--app-surface-subtle);\r\n  color: var(--app-text-muted);\r\n  font-size: 11px;\n}\n.subtitle-online-columns::before {\r\n  content: \"\";\n}\n.subtitle-local-columns > span:last-child,\r\n.subtitle-online-columns > span:last-child {\r\n  justify-self: start;\r\n  text-align: left;\n}\n.subtitle-table-columns > span,\r\n.subtitle-table-row > .subtitle-file-copy,\r\n.subtitle-table-row > .subtitle-file-meta {\r\n  justify-self: stretch;\r\n  text-align: left;\n}\n.subtitle-online-file {\r\n  min-height: 54px;\r\n  padding: 7px 12px;\n}\n.subtitle-online-file .subtitle-file-mark {\r\n  width: 36px;\r\n  height: 28px;\r\n  border-radius: var(--app-radius-chip, 6px);\r\n  font-size: 9px;\n}\n.subtitle-online-file .subtitle-file-copy strong {\r\n  font-size: 13px;\n}\n.subtitle-online-panel {\r\n  padding: 0;\n}\n.subtitle-source-progress,\r\n.subtitle-source-filter,\r\n.subtitle-captcha-list,\r\n.subtitle-online-empty,\r\n.subtitle-manual-actions,\r\n.subtitle-preview-list {\r\n  margin-right: 18px;\r\n  margin-left: 18px;\n}\n.subtitle-source-filter {\r\n  width: auto;\n}\n.subtitle-local-empty {\r\n  display: grid;\r\n  min-height: 0;\r\n  flex: 1 1 auto;\r\n  place-content: center;\r\n  justify-items: center;\r\n  gap: 7px;\r\n  color: var(--app-text-muted);\r\n  font-size: 12px;\r\n  text-align: center;\n}\n.subtitle-local-empty strong {\r\n  color: var(--app-text-secondary);\r\n  font-size: 14px;\n}\n.subtitle-table-empty {\r\n  display: grid;\r\n  min-height: 150px;\r\n  flex: 1 1 auto;\r\n  place-content: center;\r\n  justify-items: center;\r\n  gap: 7px;\r\n  padding: 24px;\r\n  color: var(--app-text-muted);\r\n  font-size: 12px;\r\n  text-align: center;\n}\n.subtitle-table-empty strong {\r\n  color: var(--app-text-secondary);\r\n  font-size: 13px;\n}\n@media (min-width: 901px) {\n.subtitle-browser {\r\n    min-height: 0;\n}\n.subtitle-detail-heading {\r\n    min-height: 108px;\r\n    padding: 10px 18px;\n}\n.subtitle-files-section {\r\n    padding: 0;\n}\n.subtitle-files-heading {\r\n    min-height: 54px;\n}\n.subtitle-file-list {\r\n    max-height: none;\r\n    min-height: 0;\r\n    flex: 1 1 auto;\n}\n.subtitle-online-panel {\r\n    padding: 0;\n}\n}\n@media (max-width: 900px) {\n.subtitle-poster {\r\n    width: 52px;\r\n    height: 70px;\r\n    margin-bottom: 10px;\n}\n.subtitle-content-tabs {\r\n    padding: 0 14px;\n}\n.subtitle-content-tab-list .v-slide-group__content {\n    gap: 0;\n}\n.subtitle-tab-search-controls {\r\n    gap: 8px;\n}\n.subtitle-tab-search {\r\n    width: auto;\r\n    min-width: 160px;\r\n    flex: 1 1 260px;\n}\n.subtitle-local-panel {\r\n    padding: 0 14px 12px;\n}\n.subtitle-local-columns {\r\n    display: none;\n}\n.subtitle-local-file {\r\n    grid-template-columns: 40px minmax(0, 1fr) auto;\n}\n.subtitle-local-file .subtitle-file-meta {\r\n    display: none;\n}\n.subtitle-online-columns {\r\n    display: none;\n}\n.subtitle-online-file {\r\n    grid-template-columns: 40px minmax(0, 1fr) auto;\n}\n.subtitle-online-file .subtitle-file-meta {\r\n    display: none;\n}\n}\r\n/* Mobile workspace: horizontal media picker above a compact subtitle workbench. */\n@media (max-width: 680px) {\n.subtitle-workspace,\r\n  .subtitle-browser {\r\n    height: auto;\r\n    min-height: 0;\n}\n.subtitle-browser {\r\n    overflow: hidden;\r\n    border-radius: 12px;\n}\n.subtitle-layout {\r\n    display: flex;\r\n    min-height: 0;\r\n    flex-direction: column;\n}\n.subtitle-sidebar {\r\n    position: static;\r\n    height: auto;\r\n    max-height: none;\r\n    min-height: 0;\r\n    overflow: hidden;\r\n    border-right: 0;\r\n    border-bottom: 1px solid var(--app-border-subtle);\r\n    background: var(--app-surface-subtle);\n}\n.subtitle-sidebar .subtitle-section-heading {\r\n    min-height: 42px;\r\n    padding: 0 12px;\r\n    border-bottom: 0;\r\n    background: var(--app-surface);\n}\n.subtitle-sidebar-tools {\r\n    padding: 8px 12px;\n}\n.subtitle-sidebar-search .subtitle-search {\r\n    height: 36px;\r\n    font-size: 12px;\n}\n.subtitle-sidebar-tools .subtitle-icon-button {\r\n    width: 36px;\r\n    height: 36px;\n}\n.subtitle-list {\r\n    display: flex;\r\n    min-height: 0;\r\n    gap: 8px;\r\n    padding: 0 12px 10px;\r\n    overflow-x: auto;\r\n    overflow-y: hidden;\r\n    scroll-snap-type: x proximity;\r\n    overscroll-behavior-inline: contain;\r\n    scrollbar-width: none;\n}\n.subtitle-list::-webkit-scrollbar {\r\n    display: none;\n}\n.subtitle-media {\r\n    width: min(78vw, 280px);\r\n    min-height: 60px;\r\n    flex: 0 0 min(78vw, 280px);\r\n    grid-template-columns: 20px minmax(0, 1fr) auto;\r\n    gap: 8px;\r\n    padding: 8px 10px;\r\n    scroll-snap-align: start;\r\n    border: 1px solid var(--app-border-subtle);\r\n    border-radius: 10px;\r\n    background: var(--app-surface);\n}\n.subtitle-media.is-active {\r\n    border-color: rgba(var(--v-theme-primary), 0.48);\r\n    box-shadow: 0 0 0 1px rgba(var(--v-theme-primary), 0.08);\n}\n.subtitle-media.is-active .subtitle-rail {\r\n    top: 8px;\r\n    bottom: 8px;\r\n    width: 3px;\r\n    border-radius: 0 3px 3px 0;\n}\n.subtitle-media strong {\r\n    font-size: 12px;\n}\n.subtitle-media small {\r\n    font-size: 10px;\n}\n.subtitle-detail {\r\n    min-height: 0;\r\n    overflow: visible;\n}\n.subtitle-detail-heading {\r\n    display: grid;\r\n    min-height: 0;\r\n    grid-template-columns: 56px minmax(0, 1fr);\r\n    align-items: center;\r\n    gap: 10px 12px;\r\n    padding: 12px;\n}\n.subtitle-poster {\r\n    width: 56px;\r\n    height: 76px;\r\n    grid-row: 1 / span 2;\r\n    margin: 0;\r\n    border-radius: 8px;\n}\n.subtitle-detail-copy {\r\n    min-width: 0;\n}\n.subtitle-detail-heading h2 {\r\n    font-size: 16px;\r\n    font-weight: 600;\n}\n.subtitle-detail-heading .subtitle-detail-copy > p {\r\n    display: none;\n}\n.subtitle-identity {\r\n    gap: 4px 8px;\r\n    margin-top: 7px;\n}\n.subtitle-identity span {\r\n    font-size: 10px;\n}\n.subtitle-identity small,\r\n  .subtitle-identity-warning {\r\n    display: none;\n}\n.subtitle-summary-actions {\r\n    grid-column: 2;\r\n    margin: 0;\n}\n.subtitle-local-stat {\r\n    margin: 0;\r\n    color: var(--app-text-muted);\r\n    font-size: 10px;\n}\n.subtitle-local-stat strong {\r\n    margin-left: 5px;\r\n    color: var(--app-text);\r\n    font-size: 12px;\n}\n.subtitle-content-tabs {\r\n    min-height: 46px;\r\n    padding: 0 12px;\r\n    background: var(--app-surface);\n}\n.subtitle-content-tab-list {\n    --v-tabs-height: 46px;\n    width: 100%;\n    min-height: 46px;\n}\n.subtitle-content-tab-list .v-slide-group__content {\n    gap: 0;\n}\n.subtitle-content-tab-list .v-tab {\n    min-height: 46px;\n    flex: 1 1 50%;\n    justify-content: center;\r\n    font-size: 12px;\n}\n.subtitle-tab-action {\r\n    position: absolute;\r\n    right: 12px;\r\n    height: 32px;\r\n    padding: 0 10px;\r\n    font-size: 11px;\n}\n.subtitle-content-tabs.has-online-tools {\r\n    gap: 8px;\r\n    padding: 0 12px 10px;\n}\n.subtitle-content-tabs.has-online-tools .subtitle-content-tab-list {\n    width: 100%;\n}\n.subtitle-tab-search-controls {\r\n    width: 100%;\r\n    gap: 8px;\n}\n.subtitle-tab-search {\r\n    min-width: 0;\r\n    flex: 1 1 auto;\n}\n.subtitle-tab-search .subtitle-search {\r\n    height: 36px;\r\n    font-size: 12px;\n}\n.subtitle-season-toggle {\r\n    min-height: 36px;\r\n    padding: 0 5px;\r\n    font-size: 11px;\n}\n.subtitle-files-section,\r\n  .subtitle-local-panel {\r\n    min-height: 0;\r\n    padding: 0;\n}\n.subtitle-local-list,\r\n  .subtitle-online-results {\r\n    min-height: 220px;\r\n    max-height: 52vh;\r\n    overflow-y: auto;\r\n    border: 0;\r\n    scrollbar-gutter: stable;\n}\n.subtitle-local-columns,\r\n  .subtitle-online-columns {\r\n    display: none;\n}\n.subtitle-local-file,\r\n  .subtitle-online-file {\r\n    display: grid;\r\n    min-height: 68px;\r\n    grid-template-columns: 36px minmax(0, 1fr) 28px;\r\n    grid-template-rows: auto auto;\r\n    align-content: center;\r\n    gap: 3px 10px;\r\n    padding: 9px 12px;\n}\n.subtitle-local-file .subtitle-file-mark,\r\n  .subtitle-online-file .subtitle-file-mark {\r\n    width: 36px;\r\n    height: 30px;\r\n    grid-column: 1;\r\n    grid-row: 1 / span 2;\r\n    align-self: center;\n}\n.subtitle-local-file .subtitle-file-copy,\r\n  .subtitle-online-file .subtitle-file-copy {\r\n    min-width: 0;\r\n    grid-column: 2;\r\n    grid-row: 1;\n}\n.subtitle-file-copy strong,\r\n  .subtitle-online-file .subtitle-file-copy strong {\r\n    font-size: 12px;\n}\n.subtitle-mobile-meta {\r\n    display: block;\r\n    min-width: 0;\r\n    overflow: hidden;\r\n    grid-column: 2;\r\n    grid-row: 2;\r\n    color: var(--app-text-muted);\r\n    font-size: 10px;\r\n    line-height: 1.4;\r\n    text-overflow: ellipsis;\r\n    white-space: nowrap;\n}\n.subtitle-local-file .subtitle-file-meta,\r\n  .subtitle-online-file .subtitle-file-meta {\r\n    display: none;\n}\n.subtitle-row-actions {\r\n    width: 28px;\r\n    grid-column: 3;\r\n    grid-row: 1 / span 2;\r\n    align-self: center;\n}\n.subtitle-source-filter,\r\n  .subtitle-source-progress,\r\n  .subtitle-captcha-list,\r\n  .subtitle-manual-actions {\r\n    margin-right: 12px;\r\n    margin-left: 12px;\n}\n.subtitle-source-filter {\r\n    display: block;\r\n    padding: 8px 0;\r\n    border: 0;\n}\n.subtitle-source-label {\r\n    display: none;\n}\n.subtitle-source-list {\r\n    display: flex;\r\n    gap: 6px;\r\n    overflow-x: auto;\r\n    scrollbar-width: none;\n}\n.subtitle-source-list::-webkit-scrollbar {\r\n    display: none;\n}\n.subtitle-source {\r\n    min-height: 32px;\r\n    flex: 0 0 auto;\r\n    padding: 0 10px;\r\n    border: 1px solid var(--app-border-subtle);\r\n    border-radius: 9px;\r\n    background: var(--app-surface);\r\n    font-size: 11px;\n}\n.subtitle-source.is-ready,\r\n  .subtitle-source.is-restricted,\r\n  .subtitle-source.is-error {\r\n    border-left-width: 1px;\r\n    border-left-color: var(--app-border-subtle);\n}\n.subtitle-table-empty {\r\n    min-height: 220px;\n}\n.subtitle-manual-actions {\r\n    margin-top: 8px;\r\n    margin-bottom: 10px;\r\n    font-size: 10px;\n}\n.subtitle-row-action-menu {\r\n    right: 0;\r\n    min-width: 136px;\n}\n.subtitle-row-action-menu > :is(button, a) {\r\n    min-height: 38px;\r\n    font-size: 12px;\r\n    line-height: 38px;\n}\n.subtitle-dialog-backdrop {\r\n    align-items: end;\r\n    padding: 10px;\n}\n.subtitle-dialog:not(.subtitle-preview-dialog) {\r\n    width: 100%;\r\n    border-radius: 16px;\n}\n.subtitle-preview-footer {\r\n    min-height: 64px;\r\n    padding: 10px 14px;\n}\n}\n@media (max-width: 680px) {\n.subtitle-toolbar {\r\n    align-items: stretch;\r\n    flex-direction: column;\r\n    gap: 10px;\n}\n.subtitle-heading {\r\n    align-items: flex-start;\r\n    flex-direction: column;\r\n    gap: 2px;\n}\n.subtitle-controls {\r\n    width: 100%;\r\n    min-width: 0;\n}\n.subtitle-upload-section {\r\n    grid-template-columns: 1fr;\n}\n.subtitle-upload-section > .subtitle-action {\r\n    height: var(--app-control-height, 40px);\n}\n.subtitle-files-section,\r\n  .subtitle-detail-heading {\r\n    padding-right: 14px;\r\n    padding-left: 14px;\n}\n.subtitle-content-tabs.has-online-tools {\r\n    min-height: auto;\r\n    align-items: stretch;\r\n    flex-direction: column;\r\n    gap: 8px;\r\n    padding-top: 8px;\r\n    padding-bottom: 8px;\n}\n.subtitle-content-tabs.has-online-tools .subtitle-content-tab-list {\n    min-height: 40px;\n}\n.subtitle-tab-search-controls {\r\n    width: 100%;\n}\n.subtitle-tab-search {\r\n    width: auto;\r\n    flex: 1 1 auto;\n}\n.subtitle-source-list {\r\n    display: flex;\n}\n.subtitle-files-heading {\r\n    align-items: flex-start;\r\n    flex-direction: column;\r\n    padding: 10px 0;\n}\n.subtitle-local-actions {\r\n    width: 100%;\n}\n.subtitle-local-actions .subtitle-action {\r\n    flex: 1;\n}\n.subtitle-preview-action {\r\n    margin-right: -14px;\r\n    margin-left: -14px;\n}\n}\n@media (prefers-reduced-motion: reduce) {\n.subtitle-workspace * {\r\n    scroll-behavior: auto !important;\r\n    transition: none !important;\n}\n}\r\n/* Desktop workbench: the media rail and subtitle results are the only scrollers. */\n@media (min-width: 901px) {\n.subtitle-workspace {\r\n    height: calc(100vh - 102px);\r\n    min-height: 560px;\r\n    overflow: hidden;\n}\n.subtitle-browser {\r\n    height: 100%;\r\n    min-height: 0;\r\n    overflow: hidden;\r\n    border-radius: 12px;\r\n    box-shadow: 0 4px 18px rgba(15, 23, 42, 0.045);\n}\n.subtitle-toolbar {\r\n    min-height: 58px;\r\n    padding: 8px 16px;\n}\n.subtitle-heading {\r\n    flex: 0 1 auto;\n}\n.subtitle-heading::before {\r\n    width: 28px;\r\n    height: 28px;\n}\n.subtitle-heading h1 {\r\n    font-size: 17px;\n}\n.subtitle-controls {\r\n    min-width: 0;\r\n    max-width: 590px;\n}\n.subtitle-search-wrap {\r\n    width: auto;\r\n    min-width: 180px;\r\n    flex: 1 1 320px;\n}\n.subtitle-notice {\r\n    min-height: 30px;\r\n    padding: 6px 16px;\n}\n.subtitle-layout {\r\n    min-height: 0;\r\n    flex: 1 1 auto;\r\n    align-items: stretch;\r\n    grid-template-columns: 300px minmax(0, 1fr);\r\n    overflow: hidden;\n}\n.subtitle-sidebar {\r\n    position: static;\r\n    height: auto;\r\n    max-height: none;\r\n    min-height: 0;\r\n    align-self: stretch;\r\n    overflow: hidden;\r\n    background: var(--app-surface-subtle);\n}\n.subtitle-sidebar .subtitle-section-heading {\r\n    min-height: 44px;\r\n    padding: 0 14px;\r\n    background: var(--app-surface);\n}\n.subtitle-list {\r\n    min-height: 0;\r\n    flex: 1 1 auto;\r\n    overflow: auto;\r\n    overscroll-behavior: contain;\n}\n.subtitle-media {\r\n    min-height: 58px;\r\n    padding: 7px 12px;\n}\n.subtitle-detail {\r\n    min-height: 0;\r\n    overflow: hidden;\n}\n.subtitle-detail-heading {\r\n    display: flex;\r\n    flex: 0 0 auto;\r\n    align-items: center;\r\n    justify-content: space-between;\r\n    gap: 20px;\r\n    padding: 12px 18px 10px;\n}\n.subtitle-detail-copy {\r\n    min-width: 0;\r\n    flex: 1 1 auto;\n}\n.subtitle-detail-heading h2 {\r\n    font-size: 16px;\r\n    font-weight: 600;\n}\n.subtitle-detail-heading p {\r\n    margin-top: 4px;\n}\n.subtitle-identity {\r\n    margin-top: 6px;\n}\n.subtitle-identity small {\r\n    width: auto;\r\n    margin: 0 0 0 8px;\n}\n.subtitle-summary-actions {\r\n    display: flex;\r\n    flex: 0 0 auto;\r\n    align-items: center;\r\n    gap: 8px;\n}\n.subtitle-local-stat {\r\n    min-width: 76px;\r\n    margin-right: 4px;\r\n    padding-right: 16px;\n}\n.subtitle-local-stat span,\r\n  .subtitle-local-stat strong {\r\n    display: block;\r\n    white-space: nowrap;\n}\n.subtitle-local-stat span {\r\n    color: var(--app-text-muted);\r\n    font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-local-stat strong {\r\n    margin-top: 3px;\r\n    color: var(--app-text);\r\n    font-size: 14px;\n}\n.subtitle-files-section {\r\n    display: flex;\r\n    min-height: 0;\r\n    flex: 1 1 auto;\r\n    flex-direction: column;\r\n    padding: 0;\r\n    overflow: hidden;\n}\n.subtitle-files-heading {\r\n    min-height: 48px;\r\n    flex: 0 0 auto;\n}\n.subtitle-empty-files {\r\n    min-height: 150px;\n}\n.subtitle-empty-inline {\r\n    min-height: 34px;\r\n    flex: 0 0 auto;\r\n    padding: 8px 0;\r\n    justify-content: flex-start;\r\n    text-align: left;\n}\n.subtitle-file-list {\r\n    max-height: none;\r\n    min-height: 0;\r\n    flex: 1 1 auto;\r\n    overflow: auto;\r\n    overscroll-behavior: contain;\n}\n.subtitle-upload-section {\r\n    flex: 0 0 auto;\n}\n.subtitle-online-panel {\r\n    display: flex;\r\n    min-height: 0;\r\n    flex: 1 1 auto;\r\n    flex-direction: column;\r\n    margin: 0;\r\n    overflow: hidden;\r\n    border-top: 0;\n}\n.subtitle-source-progress,\r\n  .subtitle-captcha-list,\r\n  .subtitle-manual-actions {\r\n    flex: 0 0 auto;\n}\n.subtitle-source-filter {\r\n    display: block;\r\n    flex: 0 0 auto;\r\n    padding: 8px 0;\r\n    border: 0;\n}\n.subtitle-source-label {\r\n    display: none;\n}\n.subtitle-source-list {\r\n    gap: 7px;\r\n    margin: 0;\r\n    padding: 0;\r\n    overflow-x: auto;\r\n    scrollbar-width: none;\n}\n.subtitle-source-list::-webkit-scrollbar {\r\n    display: none;\n}\n.subtitle-source {\r\n    min-height: 34px;\r\n    padding: 0 11px;\r\n    border: 1px solid var(--app-border-subtle);\r\n    border-radius: 9px;\r\n    background: var(--app-surface);\n}\n.subtitle-source.is-ready,\r\n  .subtitle-source.is-restricted,\r\n  .subtitle-source.is-error {\r\n    border-left-width: 1px;\r\n    border-left-color: var(--app-border-subtle);\n}\n.subtitle-source::after {\r\n    display: none;\n}\n.subtitle-source.is-active {\r\n    border-color: rgba(var(--v-theme-primary), 0.55);\r\n    background: var(--app-surface-selected, rgba(var(--v-theme-primary), 0.07));\r\n    box-shadow: 0 0 0 1px rgba(var(--v-theme-primary), 0.08);\n}\n.subtitle-online-results {\r\n    min-height: 150px;\r\n    flex: 1 1 auto;\r\n    margin-top: 0;\r\n    overflow: auto;\r\n    overscroll-behavior: contain;\n}\n.subtitle-online-empty {\r\n    display: grid;\r\n    min-height: 120px;\r\n    flex: 1 1 auto;\r\n    place-items: center;\r\n    border: 1px dashed var(--app-border-subtle);\r\n    border-radius: var(--app-control-radius, 12px);\r\n    color: var(--app-text-muted);\r\n    font-size: var(--app-font-size-label, 11px);\n}\n.subtitle-online-file {\r\n    min-height: 54px;\r\n    padding: 7px 12px;\n}\n.subtitle-online-file .subtitle-file-mark {\r\n    width: 36px;\r\n    height: 28px;\n}\n.subtitle-preview-action {\r\n    bottom: 0;\n}\n.subtitle-list,\r\n  .subtitle-file-list,\r\n  .subtitle-online-results {\r\n    scrollbar-width: thin;\r\n    scrollbar-color: var(--app-border) transparent;\n}\n.subtitle-list::-webkit-scrollbar,\r\n  .subtitle-file-list::-webkit-scrollbar,\r\n  .subtitle-online-results::-webkit-scrollbar {\r\n    width: 7px;\n}\n.subtitle-list::-webkit-scrollbar-thumb,\r\n  .subtitle-file-list::-webkit-scrollbar-thumb,\r\n  .subtitle-online-results::-webkit-scrollbar-thumb {\r\n    border: 2px solid transparent;\r\n    border-radius: 999px;\r\n    background: var(--app-border);\r\n    background-clip: padding-box;\n}\r\n  /* Keep header and rows in the same scrollport so fractional columns share\r\n     one content width even when the vertical scrollbar is present. */\n.subtitle-local-list,\r\n  .subtitle-online-results {\r\n    overflow-y: auto;\r\n    overscroll-behavior: contain;\r\n    scrollbar-gutter: stable;\n}\n.subtitle-local-list > .subtitle-file-list,\r\n  .subtitle-online-results > .subtitle-file-list {\r\n    display: contents;\n}\n.subtitle-local-columns,\r\n  .subtitle-online-columns {\r\n    position: sticky;\r\n    z-index: 2;\r\n    top: 0;\n}\n}\n@media (max-width: 900px) {\n.subtitle-detail-heading {\r\n    display: block;\n}\n.subtitle-detail-copy {\r\n    min-width: 0;\n}\n.subtitle-summary-actions {\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    align-items: center;\r\n    gap: 8px;\r\n    margin-top: 12px;\n}\n.subtitle-local-stat {\r\n    margin-right: auto;\n}\n.subtitle-local-stat span,\r\n  .subtitle-local-stat strong {\r\n    display: inline;\n}\n.subtitle-local-stat strong {\r\n    margin-left: 6px;\n}\n.subtitle-online-empty {\r\n    padding: 24px 12px;\r\n    color: var(--app-text-muted);\r\n    font-size: var(--app-font-size-label, 11px);\r\n    text-align: center;\n}\n}\r\n\r\n/* Final phone overrides stay last so the tablet fallback cannot flatten the\r\n   compact media header or reintroduce desktop table chrome. */\n@media (max-width: 680px) {\n.subtitle-layout,\r\n  .subtitle-sidebar {\r\n    width: 100%;\r\n    max-width: 100%;\r\n    min-width: 0;\n}\n.subtitle-sidebar-tools {\r\n    width: 100%;\r\n    min-width: 0;\n}\n.subtitle-sidebar-tools .subtitle-sidebar-search {\r\n    flex: 1 1 0;\n}\n.subtitle-sidebar-tools .subtitle-search {\r\n    min-width: 0;\r\n    max-width: 100%;\n}\n.subtitle-list {\r\n    width: 100%;\r\n    max-width: 100%;\r\n    flex-wrap: nowrap;\r\n    overflow-x: scroll !important;\r\n    overflow-y: hidden !important;\r\n    overscroll-behavior-x: contain;\r\n    scroll-behavior: smooth;\r\n    touch-action: pan-x;\r\n    -webkit-overflow-scrolling: touch;\n}\n.subtitle-media {\r\n    width: min(78vw, 280px);\r\n    flex: 0 0 min(78vw, 280px);\r\n    touch-action: pan-x;\n}\n.subtitle-detail-heading {\r\n    display: grid;\r\n    grid-template-columns: 56px minmax(0, 1fr);\r\n    grid-template-rows: auto auto;\r\n    align-items: center;\r\n    gap: 7px 12px;\r\n    padding: 12px;\n}\n.subtitle-poster {\r\n    grid-column: 1;\r\n    grid-row: 1 / span 2;\n}\n.subtitle-detail-copy {\r\n    grid-column: 2;\r\n    grid-row: 1;\n}\n.subtitle-detail-copy .subtitle-identity {\r\n    max-width: 100%;\r\n    flex-wrap: nowrap;\r\n    gap: 4px;\r\n    overflow-x: auto;\r\n    white-space: nowrap;\r\n    scrollbar-width: none;\r\n    -webkit-overflow-scrolling: touch;\n}\n.subtitle-detail-copy .subtitle-identity span {\r\n    flex: 0 0 auto;\r\n    font-size: 10px;\r\n    line-height: 1.5;\n}\n.subtitle-detail-copy .subtitle-identity span + span::before {\r\n    margin: 0 4px 0 0;\n}\n.subtitle-summary-actions {\r\n    grid-column: 2;\r\n    grid-row: 2;\r\n    margin: 0;\n}\n.subtitle-content-tabs:not(.has-online-tools) {\r\n    position: relative;\r\n    gap: 6px;\n}\n.subtitle-online-panel {\r\n    margin-top: 0;\r\n    border-top: 0;\n}\n.subtitle-content-tabs:not(.has-online-tools) .subtitle-content-tab-list {\n    width: calc(100% - 76px);\n}\n.subtitle-tab-action {\r\n    position: static;\r\n    width: 70px;\r\n    height: 34px;\r\n    min-height: 34px;\r\n    flex: 0 0 70px;\r\n    padding: 0 8px;\n}\n.subtitle-content-tabs.has-online-tools {\r\n    position: relative;\r\n    min-height: 46px;\r\n    flex-direction: row;\r\n    align-items: center;\r\n    gap: 6px;\r\n    padding: 0 12px;\r\n    overflow: visible;\n}\n.subtitle-content-tabs.has-online-tools .subtitle-content-tab-list {\n    width: calc(100% - 76px);\r\n    min-height: 46px;\n}\n.subtitle-mobile-search-trigger {\r\n    display: grid;\r\n    width: 70px;\r\n    height: 34px;\r\n    min-height: 34px;\r\n    flex: 0 0 70px;\r\n    padding: 0;\r\n    border: 1px solid var(--app-border-subtle);\r\n    border-radius: 10px;\r\n    background: var(--app-surface);\r\n    cursor: pointer;\r\n    place-items: center;\n}\n.subtitle-mobile-search-trigger[aria-expanded=\"true\"] {\r\n    border-color: rgba(var(--v-theme-primary), 0.5);\r\n    background: rgba(var(--v-theme-primary), 0.07);\n}\n.subtitle-mobile-search-trigger svg {\r\n    display: block;\r\n    width: 20px;\r\n    height: 20px;\r\n    color: var(--app-text-muted);\n}\n.subtitle-tab-search-controls {\r\n    position: absolute;\r\n    z-index: 20;\r\n    top: calc(100% + 8px);\r\n    right: 8px;\r\n    left: 8px;\r\n    display: none;\r\n    width: auto;\r\n    padding: 10px;\r\n    border: 1px solid var(--app-border-subtle);\r\n    border-radius: 12px;\r\n    background: var(--app-surface);\r\n    box-shadow: var(--app-shadow-overlay, 0 14px 34px rgba(15, 23, 42, 0.18));\n}\n.subtitle-tab-search-controls.is-mobile-open {\r\n    display: flex;\n}\n.subtitle-dialog-backdrop {\r\n    align-items: center;\r\n    padding: max(14px, env(safe-area-inset-top)) 10px\r\n      max(14px, env(safe-area-inset-bottom));\n}\n.subtitle-dialog:not(.subtitle-preview-dialog) {\r\n    max-height: min(620px, calc(100dvh - 72px));\n}\n.subtitle-preview-dialog,\r\n  .subtitle-preview-dialog.is-single {\r\n    width: calc(100vw - 28px);\r\n    height: min(620px, calc(100dvh - 112px));\r\n    min-height: 0;\r\n    max-height: 78dvh;\r\n    border-radius: 16px;\n}\n.subtitle-preview-dialog.is-single .subtitle-preview-dialog-body {\r\n    min-height: 0;\n}\n.subtitle-preview-dialog.is-single .subtitle-preview-content {\r\n    min-height: 0;\n}\n.subtitle-preview-dialog.is-single .subtitle-preview-excerpt {\r\n    max-height: none;\n}\n.subtitle-local-columns,\r\n  .subtitle-online-columns {\r\n    display: none;\n}\n}\r\n\r\n/* One mobile scrollport; the card edge stays above the host navigation dock. */\n@media (max-width: 680px) {\n.subtitle-compact-dialog-content {\r\n    width: min(440px, calc(100% - 28px)) !important;\r\n    max-width: 440px !important;\r\n    align-self: center;\r\n    margin: max(14px, env(safe-area-inset-top)) auto max(14px, env(safe-area-inset-bottom)) !important;\n}\n.subtitle-compact-dialog-content > .subtitle-dialog {\r\n    width: 100%;\r\n    max-height: calc(100dvh - 40px);\r\n    border-radius: var(--app-dialog-radius, 16px);\n}\n.subtitle-compact-dialog-content .subtitle-dialog-heading {\r\n    padding: 14px 46px 12px 16px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-close {\r\n    top: 12px;\r\n    right: 14px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-body {\r\n    padding: 12px 16px 7px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-actions {\r\n    padding: 9px 16px 13px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-actions .subtitle-action {\r\n    min-width: 96px;\r\n    flex: 0 0 auto;\n}\n.subtitle-compact-dialog-content .subtitle-adjustment-field {\r\n    grid-template-columns: 68px minmax(0, 1fr);\r\n    gap: 8px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-body > small {\r\n    margin-left: 76px;\n}\n.subtitle-workspace {\r\n    position: fixed;\r\n    top: var(--subtitle-workspace-top, calc(var(--v-layout-top, 64px) + 12px));\r\n    right: max(12px, env(safe-area-inset-right, 0px));\r\n    bottom: var(--subtitle-workspace-bottom, calc(78px + env(safe-area-inset-bottom, 0px)));\r\n    left: max(12px, env(safe-area-inset-left, 0px));\r\n    width: auto;\r\n    height: auto;\r\n    min-height: 0;\r\n    overflow: hidden;\n}\n.subtitle-browser {\r\n    height: 100%;\r\n    min-height: 0;\r\n    overflow: hidden;\n}\n.subtitle-layout,\r\n  .subtitle-detail,\r\n  .subtitle-files-section,\r\n  .subtitle-local-panel,\r\n  .subtitle-online-panel {\r\n    display: flex;\r\n    flex-direction: column;\r\n    flex: 1 1 0;\r\n    min-height: 0;\r\n    overflow: hidden;\n}\n.subtitle-sidebar,\r\n  .subtitle-detail-heading,\r\n  .subtitle-content-tabs,\r\n  .subtitle-source-filter,\r\n  .subtitle-source-progress,\r\n  .subtitle-captcha-list,\r\n  .subtitle-manual-actions {\r\n    flex: 0 0 auto;\n}\n.subtitle-local-list,\r\n  .subtitle-online-results {\r\n    display: block;\r\n    flex: 1 1 0;\r\n    min-height: 0;\r\n    max-height: none;\r\n    overflow-x: hidden;\r\n    overflow-y: auto;\r\n    overscroll-behavior-y: contain;\r\n    -webkit-overflow-scrolling: touch;\n}\n.subtitle-local-list > .subtitle-file-list,\r\n  .subtitle-online-results > .subtitle-file-list {\r\n    display: contents;\n}\n.subtitle-local-file,\r\n  .subtitle-online-file {\r\n    flex: 0 0 auto;\n}\n}\n.subtitle-workspace .subtitle-pagination { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:12px; font-size:12px;\n}\n.subtitle-workspace .subtitle-pagination button:disabled { opacity:.4; cursor:default;\n}\r\n\r\n/* Final source-rail layout overrides responsive legacy rules above. */\n.subtitle-workspace .subtitle-source-filter {\r\n  display: flex;\r\n  min-width: 0;\r\n  align-items: stretch;\r\n  padding: 8px 0;\n}\n.subtitle-workspace .subtitle-source-scroller {\r\n  min-width: 0;\r\n  flex: 1 1 auto;\n}\n.subtitle-workspace .subtitle-source-scroller .subtitle-source-list {\r\n  display: flex;\r\n  width: 100%;\r\n  min-width: 0;\r\n  gap: 7px;\r\n  padding-top: 0;\r\n  padding-bottom: 0;\r\n  overflow-x: auto;\r\n  scrollbar-width: none;\n}\n.subtitle-workspace .subtitle-source-scroller .subtitle-source-list::-webkit-scrollbar {\r\n  display: none;\n}\n.subtitle-workspace .subtitle-source-all {\r\n  margin-right: 7px;\n}\n@media (max-width: 680px) {\n.subtitle-workspace .subtitle-source-filter {\r\n    margin-right: 12px;\r\n    margin-left: 12px;\n}\n.subtitle-workspace .subtitle-source-navigation {\r\n    display: none;\n}\n}\r\n\r\n/* Final source selection and explicit search action. One selected treatment is\r\n   enough: tint, border and dot replace the old underline-inside-a-pill look. */\n.subtitle-workspace .subtitle-source::after {\r\n  display: none;\n}\n.subtitle-workspace .subtitle-source.is-active {\r\n  border-color: rgba(var(--v-theme-primary), 0.42);\r\n  background: rgba(var(--v-theme-primary), 0.09);\r\n  box-shadow: none;\r\n  color: rgb(var(--v-theme-primary));\n}\n.subtitle-workspace .subtitle-source.is-active .subtitle-source-dot {\r\n  background: rgb(var(--v-theme-primary));\r\n  box-shadow: 0 0 0 3px rgba(var(--v-theme-primary), 0.12);\n}\n.subtitle-workspace .subtitle-source.is-active span {\r\n  color: rgba(var(--v-theme-primary), 0.82);\n}\n.subtitle-workspace .subtitle-online-search-submit {\r\n  width: 62px;\r\n  min-width: 62px;\r\n  height: 34px;\r\n  min-height: 34px;\r\n  max-height: 34px;\r\n  flex: 0 0 auto;\r\n  align-self: center;\r\n  padding: 0 12px;\r\n  border: 1px solid rgb(var(--v-theme-primary));\r\n  border-radius: var(--app-radius-action, 8px);\r\n  background: rgb(var(--v-theme-primary));\r\n  box-shadow: 0 2px 6px rgba(var(--v-theme-primary), 0.16);\r\n  color: #fff;\r\n  font: inherit;\r\n  font-size: 12px;\r\n  font-weight: 500;\r\n  cursor: pointer;\r\n  transition: background-color 0.16s ease, box-shadow 0.16s ease, transform 0.16s ease;\n}\n.subtitle-online-search-submit:hover:not(:disabled) {\r\n  box-shadow: 0 6px 14px rgba(var(--v-theme-primary), 0.24);\r\n  transform: translateY(-1px);\n}\n.subtitle-online-search-submit:focus-visible {\r\n  outline: 2px solid rgba(var(--v-theme-primary), 0.35);\r\n  outline-offset: 2px;\n}\n.subtitle-online-search-submit:disabled {\r\n  border-color: var(--app-border-subtle);\r\n  background: var(--app-surface-subtle);\r\n  box-shadow: none;\r\n  color: var(--app-text-muted);\r\n  cursor: default;\n}\n@media (max-width: 680px) {\n.subtitle-workspace .subtitle-tab-search-controls {\r\n    flex-wrap: nowrap;\r\n    gap: 8px;\n}\n.subtitle-workspace .subtitle-tab-search {\r\n    min-width: 0;\r\n    flex: 1 1 auto;\n}\n.subtitle-workspace .subtitle-online-search-submit {\r\n    width: 62px;\r\n    min-width: 62px;\r\n    height: 36px;\r\n    min-height: 36px;\r\n    max-height: 36px;\r\n    padding: 0 10px;\n}\n.subtitle-workspace .subtitle-season-toggle {\r\n    width: auto;\r\n    min-height: 36px;\r\n    flex: 0 0 auto;\r\n    padding: 0 2px;\n}\n}\r\n\r\n/* Approved compact dialogs; share host radius tokens on desktop and mobile. */\n.subtitle-compact-dialog-content .subtitle-compact-close {\r\n  position: absolute;\r\n  top: 20px;\r\n  right: 16px;\r\n  width: 48px;\r\n  height: 48px;\r\n  border-radius: 50%;\r\n  color: var(--app-text);\n}\n.subtitle-compact-dialog-content .subtitle-compact-close .v-icon {\r\n  font-size: 24px;\n}\n@media (max-width: 680px) {\n.subtitle-compact-dialog-content .subtitle-compact-close { top: 16px; right: 8px;\n}\n}\n.subtitle-host-dialog-content.subtitle-compact-dialog-content {\r\n  width: min(480px, calc(100% - 28px)) !important;\n}\n.subtitle-compact-dialog-content > .subtitle-dialog {\r\n  width: min(480px, 100%); max-height: calc(100dvh - 40px); display: flex; flex-direction: column;\r\n  border-radius: var(--app-dialog-radius, 17px);\r\n  font-family: var(--app-font-family, \"Microsoft YaHei UI\", \"Noto Sans CJK SC\", sans-serif);\r\n  font-size: 13px; font-weight: 400;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-heading { flex: 0 0 auto; gap: 14px; padding: 20px 54px 20px 24px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-symbol {\r\n  display: grid; position: relative; flex: 0 0 40px; width: 40px; height: 40px; place-items: center;\r\n  border-radius: var(--app-control-radius, 12px); color: rgb(var(--v-theme-primary)); background: rgba(var(--v-theme-primary), .08);\n}\n.subtitle-compact-dialog-content .subtitle-dialog-symbol.is-danger { color: rgb(var(--v-theme-error)); background: rgba(var(--v-theme-error), .08);\n}\n.subtitle-compact-dialog-content .subtitle-dialog-symbol::before,\r\n.subtitle-compact-dialog-content .subtitle-dialog-symbol::after { content: none;\n}\n.subtitle-dialog-symbol svg { width: 24px; height: 24px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-heading h2 { font-size: 18px; font-weight: 600; line-height: 1.4;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-heading p { margin-top: 4px; font-size: 12px; font-weight: 400; line-height: 1.5;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-close { top: 20px; right: 18px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-body { min-height: 0; overflow-y: auto; padding: 24px;\n}\n.subtitle-compact-dialog-content .subtitle-upload-dialog-body { gap: 0;\n}\n.subtitle-compact-dialog-content .subtitle-field-heading { display: block; margin-bottom: 8px; color: var(--app-text); font-size: 12px; font-weight: 500; line-height: 1.5;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-target {\r\n  min-height: 44px; margin: 0 0 20px; padding: 10px 12px; gap: 12px;\r\n  border: 1px solid var(--app-border-subtle); border-radius: var(--app-control-radius, 12px); background: var(--app-surface-subtle);\n}\n.subtitle-dialog-target svg { width: 22px; height: 22px; flex: 0 0 22px; color: var(--app-text-muted);\n}\n.subtitle-compact-dialog-content .subtitle-dialog-target strong { min-width: 0; font-size: 13px; font-weight: 400; color: var(--app-text);\n}\n.subtitle-compact-dialog-content .subtitle-upload-file { height: 44px; padding: 0 8px; background: var(--app-surface);\n}\n.subtitle-compact-dialog-content .subtitle-upload-file > span { font-size: 13px; font-weight: 500; border-radius: 9px; color: rgb(var(--v-theme-primary));\n}\n.subtitle-compact-dialog-content .subtitle-upload-file > strong { font-size: 13px; font-weight: 400;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-hint,\r\n.subtitle-compact-dialog-content .subtitle-dialog-body > small { margin: 8px 0 0; color: var(--app-text-muted); font-size: 9px; font-weight: 400; line-height: 1.7;\n}\n.subtitle-compact-dialog-content .subtitle-upload-dialog-body > .subtitle-dialog-hint { margin-bottom: 20px;\n}\n.subtitle-compact-dialog-content .v-field {\r\n  border-radius: var(--app-control-radius, 12px); --v-input-control-height: 40px;\r\n  --v-field-input-padding-top: 8px; --v-field-input-padding-bottom: 8px; font-size: 13px; font-weight: 400;\n}\n.subtitle-compact-dialog-content .v-field__input { min-height: 40px !important; padding-block: 8px !important;\n}\n.subtitle-compact-dialog-content .subtitle-adjustment-field { grid-template-columns: minmax(0, 1fr); gap: 0; font-weight: 400; font-size: 13px;\n}\n.subtitle-compact-dialog-content .subtitle-adjustment-input { height: 40px;\n}\n.subtitle-compact-dialog-content .subtitle-adjustment-input:focus-within { box-shadow: none;\n}\n.subtitle-compact-dialog-content .subtitle-adjustment-input > span { font-size: 12px; font-weight: 400;\n}\n.subtitle-compact-dialog-content .subtitle-delete-message { font-size: 13px; font-weight: 400; margin: 0 0 16px;\n}\n.subtitle-compact-dialog-content .subtitle-delete-dialog-body .subtitle-dialog-target { margin-bottom: 0;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-actions { flex: 0 0 auto; padding: 14px 24px; background: var(--app-surface-subtle);\n}\n.subtitle-compact-dialog-content .subtitle-dialog-actions .subtitle-action {\r\n  flex: 0 0 auto; min-width: 88px; height: 36px; min-height: 36px; padding: 0 16px;\r\n  border-radius: var(--app-radius-action, 8px); font-family: inherit; font-size: 13px; font-weight: 500;\n}\n@media (max-width: 680px) {\n.subtitle-compact-dialog-content .subtitle-dialog-heading { padding: 18px 48px 18px 16px; gap: 12px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-body { padding: 20px 16px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-actions { padding: 14px 16px;\n}\n.subtitle-compact-dialog-content .subtitle-dialog-close { top: 18px; right: 12px;\n}\n}\r\n\n.online-source-settings h3[data-v-371a0594]{grid-column:1 / -1;margin:0;color:var(--app-text);font-size:var(--app-font-size-body,14px);font-weight:var(--app-font-weight-heading, 600)}\n\n.plugin-loading-state[data-v-1be133f1]{display:grid;min-height:var(--loading-height);place-content:center;justify-items:center;gap:8px;color:var(--app-text-secondary);font-size:11px;font-weight:400;line-height:1.4}\n.plugin-loading-ring[data-v-1be133f1]{box-sizing:border-box;width:20px;height:20px;border:2px solid rgba(var(--v-theme-primary,36,107,253),.16);border-top-color:var(--app-primary,#246bfd);border-radius:50%;animation:plugin-loading-spin-1be133f1 .9s linear infinite}\n.plugin-loading-state.is-inline[data-v-1be133f1]{display:inline-flex;min-height:0;align-items:center;gap:6px}.is-inline .plugin-loading-ring[data-v-1be133f1]{width:14px;height:14px}\n@keyframes plugin-loading-spin-1be133f1{to{transform:rotate(360deg)}}\n@media(prefers-reduced-motion:reduce){.plugin-loading-ring[data-v-1be133f1]{animation:none;border-right-color:var(--app-primary,#246bfd)}}\r\n\n.subtitle-statistics[data-v-6c9490fa]{display:flex;flex-direction:column;max-height:calc(100dvh - 32px);overflow:hidden;border-radius:var(--app-dialog-radius, 16px)!important;background:var(--app-dialog-surface,#fff);color:var(--app-text,#1a2434);font-family:var(--app-font-family,inherit);font-size:var(--app-font-size-body,14px)}\n.stats-header[data-v-6c9490fa]{display:flex;align-items:center;justify-content:space-between;flex:none;height:var(--app-plugin-dialog-header-height,58px);padding:0 24px;border-bottom:1px solid var(--app-border-subtle,#e0e6ef)}\n.stats-header h2[data-v-6c9490fa]{margin:0;font-size:var(--app-font-size-title,18px)}.stats-body[data-v-6c9490fa]{padding:24px;overflow:auto;min-height:0;display:grid;gap:20px}\n.metrics[data-v-6c9490fa]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.metrics article[data-v-6c9490fa]{border:1px solid var(--app-border-subtle);border-radius:12px;padding:15px 16px;min-width:0;background:var(--app-surface-muted)}\nh3[data-v-6c9490fa]{margin:0;font-size:var(--app-font-size-body,14px);font-weight:var(--app-font-weight-heading, 600)}.metrics h3[data-v-6c9490fa],.secondary[data-v-6c9490fa],.pagination[data-v-6c9490fa]{color:var(--app-text-muted,#73819a)}.metrics h3[data-v-6c9490fa]{font-size:var(--app-font-size-caption,12px);font-weight:400}.metrics strong[data-v-6c9490fa]{display:block;margin:10px 0 0;font-size:24px;font-weight:600;font-variant-numeric:tabular-nums;color:var(--app-text)}\n.pill[data-v-6c9490fa]{display:inline-block;border-radius:var(--app-radius-chip, 6px);padding:4px 10px;font-size:var(--app-font-size-helper,12px)}.saved[data-v-6c9490fa]{background:var(--app-success-soft);color:var(--app-success-text)}.failed[data-v-6c9490fa]{background:var(--app-danger-soft);color:var(--app-danger-text)}.skipped[data-v-6c9490fa]{background:var(--app-surface-muted);color:var(--app-text-secondary)}\n.detail-title[data-v-6c9490fa]{margin-bottom:14px}.table-scroll[data-v-6c9490fa]{overflow-x:auto;border:1px solid var(--app-border-subtle,#e0e6ef);border-radius:var(--app-radius-panel, 12px)}table[data-v-6c9490fa]{width:100%;border-collapse:collapse;text-align:left}th[data-v-6c9490fa],td[data-v-6c9490fa]{padding:12px 16px;border-bottom:1px solid var(--app-border-subtle,#e0e6ef)}th[data-v-6c9490fa]{background:var(--app-surface-subtle,#f5f7fb);white-space:nowrap}td[data-v-6c9490fa]:first-child{max-width:260px;overflow-wrap:anywhere}td[data-v-6c9490fa]:not(:first-child){white-space:nowrap}.reason[data-v-6c9490fa]{white-space:normal!important}.reason-toggle[data-v-6c9490fa]{border:0;background:transparent;color:inherit;margin-left:12px;cursor:pointer}.reason-toggle[data-v-6c9490fa]:focus-visible{outline:2px solid rgb(var(--v-theme-primary,41,104,255))}.empty[data-v-6c9490fa]{text-align:center;color:var(--app-text-muted,#73819a);padding:30px}.pagination[data-v-6c9490fa]{display:flex;align-items:center;justify-content:space-between;margin-top:12px}.pagination>div[data-v-6c9490fa]{display:flex;align-items:center;gap:8px}footer[data-v-6c9490fa]{display:flex;justify-content:flex-end;padding:10px 20px;border-top:1px solid var(--app-border-subtle,#e0e6ef)}\n@media(max-width:760px){.metrics[data-v-6c9490fa]{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.stats-body[data-v-6c9490fa]{padding:16px}.metrics article[data-v-6c9490fa]{padding:14px 16px}.stats-header[data-v-6c9490fa]{padding:0 16px}}\r\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\r\n * Values mirror the host application's standard configuration dialog and\r\n * operational content density. Keep business-specific layouts in each plugin.\r\n */\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .signin-page,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace,\r\n  .signin-stat-dialog,\r\n  .cc-statistics-dialog,\r\n  .douban-dialog,\r\n  .maoyan-dialog,\r\n  .cover-history\r\n) {\r\n  color: var(--app-text, #1a2434);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field) {\r\n  min-height: var(--app-control-height, 52px);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--control-surface, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field__input) {\r\n  min-width: 0;\r\n  min-height: var(--app-control-height, 52px) !important;\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-label.v-field-label) {\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-label, 11px);\r\n}\r\n\r\n/* Custom plugin editors render Vuetify switches directly instead of through\r\n * the host's InlineSwitchRow. Pin their copy to the host's compact form-label\r\n * treatment so Vuetify's larger body label cannot change the visual scale. */\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-switch, .v-checkbox, .v-radio) .v-label {\r\n  color: var(--app-text-secondary, #657087) !important;\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: 12px !important;\r\n  font-weight: 500 !important;\r\n  line-height: 1.35;\r\n  opacity: 1;\r\n}\r\n\r\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .traffic-dialog, .cover-history) {\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border, #dfe4ee) !important;\r\n  border-radius: var(--app-dialog-radius, 16px) !important;\r\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\r\n  color: var(--app-text, #202939);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) {\r\n  min-height: 80px;\r\n  padding: 18px 20px !important;\r\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) h2 {\r\n  margin: 0;\r\n  color: var(--app-text, #202939);\r\n  font-size: 16px !important;\r\n  font-weight: 600 !important;\r\n  line-height: 1.2;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header\r\n) p {\r\n  margin: 3px 0 0;\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: var(--app-font-size-helper, 10px) !important;\r\n  line-height: 1.4;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__content,\r\n  .cc-statistics-content,\r\n  .douban-dialog__content,\r\n  .traffic-dialog-body,\r\n  .maoyan-dialog__content,\r\n  .cover-history > main\r\n) {\r\n  padding: 20px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__actions,\r\n  .cc-statistics-actions,\r\n  .douban-dialog__actions,\r\n  .traffic-dialog-actions,\r\n  .maoyan-dialog__actions,\r\n  .cover-history > footer\r\n) {\r\n  min-height: 64px;\r\n  padding: 13px 18px !important;\r\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface-raised, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) {\r\n  gap: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) > div {\r\n  min-width: 0;\r\n  padding: 15px 16px !important;\r\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  border-radius: 12px !important;\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) dt,\r\n:where(.cover-history .metrics) span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics\r\n) dd,\r\n:where(.cover-history .metrics) strong {\r\n  margin-top: 7px;\r\n  color: var(--app-text, #202939);\r\n  font-family: inherit !important;\r\n  font-size: var(--app-font-size-metric, 24px) !important;\r\n  font-weight: var(--app-font-weight-metric, 600);\r\n  font-variant-numeric: tabular-nums;\r\n  line-height: 1.15;\r\n}\r\n\r\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\r\n.cookie-metric dd > span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 11px !important;\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n.signin-stat-results {\r\n  border-radius: 12px !important;\r\n}\r\n\r\n.signin-stat-results > header {\r\n  min-height: 44px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article {\r\n  min-height: 68px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article strong {\r\n  color: var(--app-text, #202939);\r\n  font-size: 13px;\r\n  font-weight: var(--app-font-weight-medium, 500);\r\n}\r\n\r\n.signin-stat-results article p {\r\n  font-size: 12px !important;\r\n}\r\n\r\n.signin-stat-results :is(article span, time) {\r\n  font-size: 10px !important;\r\n}\r\n\r\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\r\n  min-width: 0;\r\n  color: var(--app-text, #17243a);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  line-height: 1.5;\r\n}\r\n\r\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\r\n  font-size: 27px !important;\r\n  font-weight: 600;\r\n  line-height: 1.15;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\r\n  font-size: 12px !important;\r\n  font-weight: 500;\r\n  line-height: 1.3;\r\n}\r\n\r\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\r\n  min-height: 40px;\r\n  border-radius: var(--app-radius-action) !important;\r\n  font-size: 13px;\r\n  letter-spacing: 0;\r\n  font-weight: 500;\r\n}\r\n\r\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\r\n  min-height: 52px;\r\n  border-radius: var(--app-control-radius, 12px);\r\n  color: var(--app-text-secondary, #657087);\r\n  font: inherit;\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n@media (max-width: 700px) {\r\n  :where(\r\n    .signin-stat-dialog__header,\r\n    .cc-statistics-header,\r\n    .douban-dialog__header,\r\n    .traffic-dialog-heading,\n    .maoyan-dialog__header,\n    .cover-history > header,\r\n    .signin-stat-dialog__content,\r\n    .cc-statistics-content,\r\n    .douban-dialog__content,\r\n    .traffic-dialog-body,\n    .maoyan-dialog__content,\n    .cover-history > main\r\n  ) {\r\n    padding: 16px !important;\r\n  }\r\n}\r\n\r\n/* Legacy-host fallback. On current hosts, the public form owns these tokens. */\r\n:where(.app-form-layout) {\r\n  display: grid;\r\n  grid-template-columns: repeat(var(--app-plugin-config-columns, 2), minmax(0, 1fr));\r\n  row-gap: var(--app-plugin-config-row-gap, 14px);\r\n  column-gap: var(--app-plugin-config-column-gap, 16px);\r\n}\r\n@media (max-width: 760px) {\r\n  :where(.app-form-layout) { grid-template-columns: minmax(0, 1fr); }\r\n}\r\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const isRef = runtime.isRef;
const normalizeClass = runtime.normalizeClass;
const normalizeStyle = runtime.normalizeStyle;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveComponent = runtime.resolveComponent;
const resolveDynamicComponent = runtime.resolveDynamicComponent;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1$9 = { class: "subtitle-local-panel" };
const _hoisted_2$8 = { class: "subtitle-table subtitle-local-list" };
const _hoisted_3$7 = {
  key: 0,
  class: "subtitle-file-list"
};
const _hoisted_4$7 = { class: "subtitle-file-copy" };
const _hoisted_5$7 = ["title", "aria-label"];
const _hoisted_6$7 = { class: "subtitle-mobile-meta" };
const _hoisted_7$7 = { class: "subtitle-file-meta" };
const _hoisted_8$6 = { class: "subtitle-file-meta" };
const _hoisted_9$6 = { class: "subtitle-file-meta" };
const _hoisted_10$5 = ["aria-expanded", "aria-label", "onClick"];
const _hoisted_11$3 = ["onClick"];
const _hoisted_12$2 = ["onClick"];
const _hoisted_13$2 = {
  key: 1,
  class: "subtitle-table-empty"
};
const _hoisted_14$2 = {
  key: 2,
  class: "subtitle-table-empty"
};
const _hoisted_15$2 = {
  key: 3,
  class: "subtitle-table-empty"
};
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  __name: "SubtitleLocalList",
  props: {
    selected: {},
    inventoryLoading: { type: Boolean },
    activeActionMenu: {},
    activeActionMenuAbove: { type: Boolean },
    subtitleFormat: { type: Function },
    subtitleLanguage: { type: Function },
    formatSize: { type: Function },
    closeActionMenu: { type: Function },
    toggleActionMenu: { type: Function },
    loadSelection: { type: Function }
  },
  emits: ["adjust", "delete", "searchOnline"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    return (_ctx, _cache) => {
      const _component_VIcon = resolveComponent("VIcon");
      return openBlock(), createElementBlock("div", _hoisted_1$9, [
        createElementVNode("div", _hoisted_2$8, [
          _cache[8] || (_cache[8] = createElementVNode(
            "div",
            {
              class: "subtitle-table-columns subtitle-local-columns",
              "aria-hidden": "true"
            },
            [
              createElementVNode("span", null, "文件名"),
              createElementVNode("span", null, "语言"),
              createElementVNode("span", null, "格式"),
              createElementVNode("span", null, "大小")
            ],
            -1
            /* CACHED */
          )),
          __props.selected.subtitles?.length ? (openBlock(), createElementBlock("div", _hoisted_3$7, [
            (openBlock(true), createElementBlock(
              Fragment,
              null,
              renderList(__props.selected.subtitles, (subtitle) => {
                return openBlock(), createElementBlock("div", {
                  key: subtitle.name,
                  class: "subtitle-file subtitle-table-row subtitle-local-file"
                }, [
                  createElementVNode(
                    "span",
                    {
                      class: normalizeClass(["subtitle-file-mark", `is-${__props.subtitleFormat(subtitle.name).toLowerCase()}`]),
                      "aria-hidden": "true"
                    },
                    toDisplayString(__props.subtitleFormat(subtitle.name)),
                    3
                    /* TEXT, CLASS */
                  ),
                  createElementVNode("span", _hoisted_4$7, [
                    createElementVNode("strong", {
                      title: subtitle.name,
                      "aria-label": subtitle.name,
                      tabindex: "0"
                    }, toDisplayString(subtitle.name), 9, _hoisted_5$7)
                  ]),
                  createElementVNode(
                    "span",
                    _hoisted_6$7,
                    toDisplayString(__props.subtitleLanguage(subtitle.name)) + " · " + toDisplayString(__props.subtitleFormat(subtitle.name)) + " · " + toDisplayString(__props.formatSize(subtitle.size)),
                    1
                    /* TEXT */
                  ),
                  createElementVNode(
                    "span",
                    _hoisted_7$7,
                    toDisplayString(__props.subtitleLanguage(subtitle.name)),
                    1
                    /* TEXT */
                  ),
                  createElementVNode(
                    "span",
                    _hoisted_8$6,
                    toDisplayString(__props.subtitleFormat(subtitle.name)),
                    1
                    /* TEXT */
                  ),
                  createElementVNode(
                    "span",
                    _hoisted_9$6,
                    toDisplayString(__props.formatSize(subtitle.size)),
                    1
                    /* TEXT */
                  ),
                  createElementVNode(
                    "span",
                    {
                      class: "subtitle-row-actions",
                      onFocusout: _cache[0] || (_cache[0] = //@ts-ignore
                      (...args) => __props.closeActionMenu && __props.closeActionMenu(...args))
                    },
                    [
                      createElementVNode("button", {
                        type: "button",
                        class: "subtitle-action-trigger",
                        "aria-expanded": __props.activeActionMenu === `local:${subtitle.name}`,
                        "aria-haspopup": "menu",
                        "aria-label": `操作 ${subtitle.name}`,
                        title: "更多操作",
                        onClick: ($event) => __props.toggleActionMenu(`local:${subtitle.name}`, $event)
                      }, "⋮", 8, _hoisted_10$5),
                      __props.activeActionMenu === `local:${subtitle.name}` ? (openBlock(), createElementBlock(
                        "span",
                        {
                          key: 0,
                          class: normalizeClass(["subtitle-row-action-menu", { "is-above": __props.activeActionMenuAbove }]),
                          role: "menu"
                        },
                        [
                          createElementVNode("button", {
                            type: "button",
                            role: "menuitem",
                            onClick: ($event) => emit("adjust", subtitle)
                          }, [
                            createVNode(_component_VIcon, {
                              icon: "mdi-clock-outline",
                              size: "18",
                              "aria-hidden": "true"
                            }),
                            _cache[3] || (_cache[3] = createTextVNode(
                              "调轴",
                              -1
                              /* CACHED */
                            ))
                          ], 8, _hoisted_11$3),
                          createElementVNode("button", {
                            type: "button",
                            role: "menuitem",
                            class: "is-danger",
                            onClick: ($event) => emit("delete", subtitle)
                          }, [
                            createVNode(_component_VIcon, {
                              icon: "mdi-trash-can-outline",
                              size: "18",
                              "aria-hidden": "true"
                            }),
                            _cache[4] || (_cache[4] = createTextVNode(
                              "删除",
                              -1
                              /* CACHED */
                            ))
                          ], 8, _hoisted_12$2)
                        ],
                        2
                        /* CLASS */
                      )) : createCommentVNode("v-if", true)
                    ],
                    32
                    /* NEED_HYDRATION */
                  )
                ]);
              }),
              128
              /* KEYED_FRAGMENT */
            ))
          ])) : __props.inventoryLoading ? (openBlock(), createElementBlock("div", _hoisted_13$2, "正在读取字幕…")) : __props.selected.subtitles === void 0 ? (openBlock(), createElementBlock("div", _hoisted_14$2, [
            _cache[5] || (_cache[5] = createElementVNode(
              "strong",
              null,
              "字幕尚未读取成功",
              -1
              /* CACHED */
            )),
            createElementVNode("button", {
              type: "button",
              class: "subtitle-text-button",
              onClick: _cache[1] || (_cache[1] = ($event) => __props.loadSelection(__props.selected))
            }, "重试")
          ])) : (openBlock(), createElementBlock("div", _hoisted_15$2, [
            _cache[6] || (_cache[6] = createElementVNode(
              "strong",
              null,
              "暂无本地字幕",
              -1
              /* CACHED */
            )),
            _cache[7] || (_cache[7] = createElementVNode(
              "span",
              null,
              "上传字幕文件，或切换到在线字幕进行搜索",
              -1
              /* CACHED */
            )),
            createElementVNode("button", {
              type: "button",
              class: "subtitle-text-button",
              onClick: _cache[2] || (_cache[2] = ($event) => emit("searchOnline"))
            }, "去在线搜索")
          ]))
        ])
      ]);
    };
  }
});
const _hoisted_1$8 = { class: "subtitle-detail-heading" };
const _hoisted_2$7 = {
  class: "subtitle-poster",
  "aria-hidden": "true"
};
const _hoisted_3$6 = ["src"];
const _hoisted_4$6 = { key: 1 };
const _hoisted_5$6 = { class: "subtitle-detail-copy" };
const _hoisted_6$6 = {
  class: "subtitle-identity",
  "aria-label": "结构化媒体身份"
};
const _hoisted_7$6 = { key: 0 };
const _hoisted_8$5 = { class: "subtitle-summary-actions" };
const _hoisted_9$5 = { class: "subtitle-local-stat" };
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "SubtitleMediaSummary",
  props: {
    selected: {},
    posterFailed: { type: Boolean },
    mediaName: { type: Function }
  },
  emits: ["posterError"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    function identityParts(item) {
      const value = item.identity || {};
      return [
        value.media_type === "tv" ? "剧集" : value.media_type === "movie" ? "电影" : "类型未知",
        value.year,
        value.season != null && value.episode != null ? `S${String(value.season).padStart(2, "0")}E${String(value.episode).padStart(2, "0")}` : "",
        value.tmdb_id ? `TMDB ${value.tmdb_id}` : "",
        value.imdb_id ? `IMDb ${value.imdb_id}` : ""
      ].filter(Boolean);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("header", _hoisted_1$8, [
        createElementVNode("div", _hoisted_2$7, [
          __props.selected.poster_url && !__props.posterFailed ? (openBlock(), createElementBlock("img", {
            key: 0,
            src: __props.selected.poster_url,
            alt: "",
            onError: _cache[0] || (_cache[0] = ($event) => emit("posterError"))
          }, null, 40, _hoisted_3$6)) : (openBlock(), createElementBlock("span", _hoisted_4$6, "影视"))
        ]),
        createElementVNode("div", _hoisted_5$6, [
          createElementVNode(
            "h2",
            null,
            toDisplayString(__props.selected.title || __props.mediaName(__props.selected) || "字幕详情"),
            1
            /* TEXT */
          ),
          createElementVNode(
            "p",
            null,
            toDisplayString(__props.selected.path),
            1
            /* TEXT */
          ),
          createElementVNode("div", _hoisted_6$6, [
            (openBlock(true), createElementBlock(
              Fragment,
              null,
              renderList(identityParts(__props.selected), (part) => {
                return openBlock(), createElementBlock(
                  "span",
                  {
                    key: String(part)
                  },
                  toDisplayString(part),
                  1
                  /* TEXT */
                );
              }),
              128
              /* KEYED_FRAGMENT */
            )),
            __props.selected.identity?.aliases?.length ? (openBlock(), createElementBlock(
              "small",
              _hoisted_7$6,
              "别名：" + toDisplayString(__props.selected.identity.aliases.join(" / ")),
              1
              /* TEXT */
            )) : createCommentVNode("v-if", true)
          ]),
          (openBlock(true), createElementBlock(
            Fragment,
            null,
            renderList(__props.selected.identity?.warnings || [], (warning) => {
              return openBlock(), createElementBlock(
                "p",
                {
                  key: warning,
                  class: "subtitle-identity-warning"
                },
                toDisplayString(warning),
                1
                /* TEXT */
              );
            }),
            128
            /* KEYED_FRAGMENT */
          ))
        ]),
        createElementVNode("div", _hoisted_8$5, [
          createElementVNode("div", _hoisted_9$5, [
            _cache[1] || (_cache[1] = createElementVNode(
              "span",
              null,
              "本地字幕",
              -1
              /* CACHED */
            )),
            createElementVNode(
              "strong",
              null,
              toDisplayString(__props.selected.subtitles === void 0 ? "—" : `${__props.selected.subtitles.length} 条`),
              1
              /* TEXT */
            )
          ])
        ])
      ]);
    };
  }
});
const _hoisted_1$7 = { class: "subtitle-dialog-heading" };
const _hoisted_2$6 = { class: "subtitle-dialog-body subtitle-delete-dialog-body" };
const _hoisted_3$5 = { class: "subtitle-dialog-target" };
const _hoisted_4$5 = ["title"];
const _hoisted_5$5 = {
  key: 0,
  class: "subtitle-dialog-error",
  role: "alert"
};
const _hoisted_6$5 = { class: "subtitle-dialog-actions" };
const _hoisted_7$5 = ["disabled"];
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "SubtitleDeleteDialog",
  props: {
    dialogComponent: {},
    deletingSubtitle: {},
    deleting: { type: Boolean },
    deleteError: {},
    closeDeleteDialog: { type: Function },
    removeSubtitle: { type: Function }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _cache) => {
      const _component_VBtn = resolveComponent("VBtn");
      return __props.deletingSubtitle ? (openBlock(), createBlock(resolveDynamicComponent(props.dialogComponent), {
        key: 0,
        "model-value": true,
        persistent: __props.deleting,
        "z-index": 2200,
        class: "subtitle-host-overlay",
        "content-class": "subtitle-host-dialog-content subtitle-compact-dialog-content",
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => !$event && __props.closeDeleteDialog())
      }, {
        default: withCtx(() => [
          createElementVNode(
            "form",
            {
              class: "subtitle-dialog subtitle-delete-dialog",
              role: "dialog",
              "aria-modal": "true",
              "aria-labelledby": "subtitle-delete-title",
              onSubmit: _cache[0] || (_cache[0] = //@ts-ignore
              (...args) => __props.removeSubtitle && __props.removeSubtitle(...args))
            },
            [
              createElementVNode("header", _hoisted_1$7, [
                _cache[2] || (_cache[2] = createElementVNode(
                  "span",
                  {
                    class: "subtitle-dialog-symbol is-danger",
                    "aria-hidden": "true"
                  },
                  [
                    createElementVNode("svg", {
                      viewBox: "0 0 24 24",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "1.7",
                      "stroke-linecap": "round",
                      "stroke-linejoin": "round"
                    }, [
                      createElementVNode("path", { d: "M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7" })
                    ])
                  ],
                  -1
                  /* CACHED */
                )),
                _cache[3] || (_cache[3] = createElementVNode(
                  "div",
                  null,
                  [
                    createElementVNode("h2", { id: "subtitle-delete-title" }, "删除字幕"),
                    createElementVNode("p", null, "删除后无法恢复")
                  ],
                  -1
                  /* CACHED */
                )),
                createVNode(_component_VBtn, {
                  icon: "mdi-close",
                  variant: "text",
                  title: "关闭",
                  class: "app-dialog-close subtitle-compact-close",
                  "aria-label": "关闭删除字幕窗口",
                  disabled: __props.deleting,
                  onClick: __props.closeDeleteDialog
                }, null, 8, ["disabled", "onClick"])
              ]),
              createElementVNode("div", _hoisted_2$6, [
                _cache[5] || (_cache[5] = createElementVNode(
                  "p",
                  { class: "subtitle-delete-message" },
                  "确定要删除这个字幕文件吗？",
                  -1
                  /* CACHED */
                )),
                createElementVNode("div", _hoisted_3$5, [
                  _cache[4] || (_cache[4] = createElementVNode(
                    "svg",
                    {
                      viewBox: "0 0 24 24",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "1.5",
                      "stroke-linejoin": "round",
                      "aria-hidden": "true"
                    },
                    [
                      createElementVNode("path", { d: "M14 3H5v18h14V8zM14 3v5h5" })
                    ],
                    -1
                    /* CACHED */
                  )),
                  createElementVNode("strong", {
                    title: __props.deletingSubtitle.name
                  }, toDisplayString(__props.deletingSubtitle.name), 9, _hoisted_4$5)
                ]),
                _cache[6] || (_cache[6] = createElementVNode(
                  "p",
                  { class: "subtitle-dialog-hint" },
                  "仅删除字幕文件，不影响视频文件",
                  -1
                  /* CACHED */
                )),
                __props.deleteError ? (openBlock(), createElementBlock(
                  "p",
                  _hoisted_5$5,
                  toDisplayString(__props.deleteError),
                  1
                  /* TEXT */
                )) : createCommentVNode("v-if", true)
              ]),
              createElementVNode("footer", _hoisted_6$5, [
                createElementVNode("button", {
                  type: "submit",
                  class: "subtitle-action is-danger",
                  disabled: __props.deleting
                }, toDisplayString(__props.deleting ? "删除中…" : "删除字幕"), 9, _hoisted_7$5)
              ])
            ],
            32
            /* NEED_HYDRATION */
          )
        ]),
        _: 1
        /* STABLE */
      }, 8, ["persistent"])) : createCommentVNode("v-if", true);
    };
  }
});
const _hoisted_1$6 = { class: "subtitle-dialog-heading" };
const _hoisted_2$5 = { class: "subtitle-dialog-body" };
const _hoisted_3$4 = { class: "subtitle-dialog-target" };
const _hoisted_4$4 = ["title"];
const _hoisted_5$4 = { class: "subtitle-adjustment-field" };
const _hoisted_6$4 = { class: "subtitle-adjustment-input" };
const _hoisted_7$4 = ["value", "disabled"];
const _hoisted_8$4 = {
  key: 0,
  class: "subtitle-dialog-error",
  role: "alert"
};
const _hoisted_9$4 = { class: "subtitle-dialog-actions" };
const _hoisted_10$4 = ["disabled"];
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "SubtitleAdjustmentDialog",
  props: {
    adjustmentSeconds: {},
    dialogComponent: {},
    adjustingSubtitle: {},
    adjusting: { type: Boolean },
    adjustmentError: {},
    closeAdjustment: { type: Function },
    submitAdjustment: { type: Function }
  },
  emits: ["update:adjustmentSeconds"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const adjustmentSeconds = computed({
      get: () => props.adjustmentSeconds,
      set: (value) => emit("update:adjustmentSeconds", value)
    });
    return (_ctx, _cache) => {
      const _component_VBtn = resolveComponent("VBtn");
      return __props.adjustingSubtitle ? (openBlock(), createBlock(resolveDynamicComponent(props.dialogComponent), {
        key: 0,
        "model-value": true,
        persistent: __props.adjusting,
        "z-index": 2200,
        class: "subtitle-host-overlay",
        "content-class": "subtitle-host-dialog-content subtitle-compact-dialog-content",
        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => !$event && __props.closeAdjustment())
      }, {
        default: withCtx(() => [
          createElementVNode(
            "form",
            {
              class: "subtitle-dialog subtitle-adjustment-dialog",
              role: "dialog",
              "aria-modal": "true",
              "aria-labelledby": "subtitle-adjustment-title",
              onSubmit: _cache[1] || (_cache[1] = //@ts-ignore
              (...args) => __props.submitAdjustment && __props.submitAdjustment(...args))
            },
            [
              createElementVNode("header", _hoisted_1$6, [
                _cache[3] || (_cache[3] = createElementVNode(
                  "span",
                  {
                    class: "subtitle-dialog-symbol is-timeline",
                    "aria-hidden": "true"
                  },
                  [
                    createElementVNode("svg", {
                      viewBox: "0 0 24 24",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "1.7",
                      "stroke-linecap": "round"
                    }, [
                      createElementVNode("circle", {
                        cx: "12",
                        cy: "12",
                        r: "9"
                      }),
                      createElementVNode("path", { d: "M12 6v6h5" })
                    ])
                  ],
                  -1
                  /* CACHED */
                )),
                _cache[4] || (_cache[4] = createElementVNode(
                  "div",
                  null,
                  [
                    createElementVNode("h2", { id: "subtitle-adjustment-title" }, "调整字幕时间轴"),
                    createElementVNode("p", null, "正数延后字幕，负数提前字幕")
                  ],
                  -1
                  /* CACHED */
                )),
                createVNode(_component_VBtn, {
                  icon: "mdi-close",
                  variant: "text",
                  title: "关闭",
                  class: "app-dialog-close subtitle-compact-close",
                  "aria-label": "关闭调轴窗口",
                  disabled: __props.adjusting,
                  onClick: __props.closeAdjustment
                }, null, 8, ["disabled", "onClick"])
              ]),
              createElementVNode("div", _hoisted_2$5, [
                _cache[8] || (_cache[8] = createElementVNode(
                  "span",
                  { class: "subtitle-field-heading" },
                  "当前字幕",
                  -1
                  /* CACHED */
                )),
                createElementVNode("div", _hoisted_3$4, [
                  _cache[5] || (_cache[5] = createElementVNode(
                    "svg",
                    {
                      viewBox: "0 0 24 24",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "1.5",
                      "stroke-linejoin": "round",
                      "aria-hidden": "true"
                    },
                    [
                      createElementVNode("path", { d: "M14 3H5v18h14V8zM14 3v5h5" })
                    ],
                    -1
                    /* CACHED */
                  )),
                  createElementVNode("strong", {
                    title: __props.adjustingSubtitle.name
                  }, toDisplayString(__props.adjustingSubtitle.name), 9, _hoisted_4$4)
                ]),
                createElementVNode("label", _hoisted_5$4, [
                  _cache[7] || (_cache[7] = createElementVNode(
                    "span",
                    { class: "subtitle-field-heading" },
                    "偏移时间",
                    -1
                    /* CACHED */
                  )),
                  createElementVNode("span", _hoisted_6$4, [
                    createElementVNode("input", {
                      value: adjustmentSeconds.value,
                      autofocus: "",
                      type: "number",
                      step: "0.1",
                      min: "-300",
                      max: "300",
                      inputmode: "decimal",
                      "aria-describedby": "subtitle-adjustment-help",
                      disabled: __props.adjusting,
                      onInput: _cache[0] || (_cache[0] = ($event) => adjustmentSeconds.value = $event.currentTarget.value)
                    }, null, 40, _hoisted_7$4),
                    _cache[6] || (_cache[6] = createElementVNode(
                      "span",
                      { "aria-hidden": "true" },
                      "秒",
                      -1
                      /* CACHED */
                    ))
                  ])
                ]),
                _cache[9] || (_cache[9] = createElementVNode(
                  "small",
                  { id: "subtitle-adjustment-help" },
                  [
                    createTextVNode("例如 +1.5 延后 1.5 秒；−2 提前 2 秒"),
                    createElementVNode("br"),
                    createTextVNode("可输入 −300 至 300 秒")
                  ],
                  -1
                  /* CACHED */
                )),
                __props.adjustmentError ? (openBlock(), createElementBlock(
                  "p",
                  _hoisted_8$4,
                  toDisplayString(__props.adjustmentError),
                  1
                  /* TEXT */
                )) : createCommentVNode("v-if", true)
              ]),
              createElementVNode("footer", _hoisted_9$4, [
                createElementVNode("button", {
                  type: "submit",
                  class: "subtitle-action is-primary",
                  disabled: __props.adjusting || !adjustmentSeconds.value.trim()
                }, toDisplayString(__props.adjusting ? "调整中…" : "确认调整"), 9, _hoisted_10$4)
              ])
            ],
            32
            /* NEED_HYDRATION */
          )
        ]),
        _: 1
        /* STABLE */
      }, 8, ["persistent"])) : createCommentVNode("v-if", true);
    };
  }
});
const _hoisted_1$5 = { class: "subtitle-dialog-heading" };
const _hoisted_2$4 = ["disabled"];
const _hoisted_3$3 = { class: "subtitle-preview-dialog-body" };
const _hoisted_4$3 = {
  key: 0,
  class: "subtitle-preview-files",
  "aria-label": "字幕文件"
};
const _hoisted_5$3 = { class: "subtitle-preview-files-heading" };
const _hoisted_6$3 = { class: "subtitle-preview-select-all" };
const _hoisted_7$3 = ["checked", "indeterminate"];
const _hoisted_8$3 = { class: "subtitle-preview-file-list" };
const _hoisted_9$3 = ["checked", "aria-label", "onChange"];
const _hoisted_10$3 = ["onClick"];
const _hoisted_11$2 = { class: "subtitle-preview-file-copy" };
const _hoisted_12$1 = ["title"];
const _hoisted_13$1 = {
  key: 1,
  class: "subtitle-preview-content"
};
const _hoisted_14$1 = { class: "subtitle-preview-current" };
const _hoisted_15$1 = { class: "subtitle-preview-current-copy" };
const _hoisted_16$1 = ["title"];
const _hoisted_17$1 = { class: "subtitle-preview-excerpt" };
const _hoisted_18$1 = { class: "subtitle-preview-footer" };
const _hoisted_19$1 = ["disabled"];
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "SubtitlePreviewDialog",
  props: {
    activePreviewIndex: {},
    dialogComponent: {},
    previewItems: {},
    savingPreview: { type: Boolean },
    previewSelected: {},
    previewProvider: {},
    closePreviewDialog: { type: Function },
    toggleAllPreviews: { type: Function },
    togglePreview: { type: Function },
    confirmPreview: { type: Function }
  },
  emits: ["update:activePreviewIndex"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const activePreviewIndex = computed({
      get: () => props.activePreviewIndex,
      set: (value) => emit("update:activePreviewIndex", value)
    });
    const activePreviewItem = computed(
      () => props.previewItems.find((item) => item.index === activePreviewIndex.value) || props.previewItems[0] || null
    );
    const allPreviewSelected = computed(
      () => props.previewItems.length > 0 && props.previewSelected.length === props.previewItems.length
    );
    const somePreviewSelected = computed(
      () => props.previewSelected.length > 0 && !allPreviewSelected.value
    );
    function previewLanguage(value) {
      const normalized = value.trim().toLowerCase();
      if (["zh-cn", "zh-hans", "chs"].includes(normalized)) return "简体中文";
      if (["zh-tw", "zh-hant", "cht"].includes(normalized)) return "繁体中文";
      if (normalized === "zh") return "中文";
      if (normalized === "en") return "英语";
      if (normalized === "ja") return "日语";
      if (normalized === "ko") return "韩语";
      return value || "自动识别";
    }
    return (_ctx, _cache) => {
      return __props.previewItems.length ? (openBlock(), createBlock(resolveDynamicComponent(props.dialogComponent), {
        key: 0,
        "model-value": true,
        persistent: __props.savingPreview,
        "z-index": 2200,
        class: "subtitle-host-overlay",
        "content-class": "subtitle-host-dialog-content",
        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => !$event && __props.closePreviewDialog())
      }, {
        default: withCtx(() => [
          createElementVNode(
            "section",
            {
              class: normalizeClass([
                "subtitle-dialog",
                "subtitle-preview-dialog",
                { "is-single": __props.previewItems.length === 1 }
              ]),
              role: "dialog",
              "aria-modal": "true",
              "aria-labelledby": "subtitle-preview-title"
            },
            [
              createElementVNode("header", _hoisted_1$5, [
                _cache[4] || (_cache[4] = createElementVNode(
                  "div",
                  null,
                  [
                    createElementVNode("h2", { id: "subtitle-preview-title" }, "字幕预览"),
                    createElementVNode("p", null, "保存前请确认字幕内容")
                  ],
                  -1
                  /* CACHED */
                )),
                createElementVNode("button", {
                  type: "button",
                  class: "app-dialog-close subtitle-dialog-close",
                  "aria-label": "关闭字幕预览窗口",
                  disabled: __props.savingPreview,
                  onClick: _cache[0] || (_cache[0] = //@ts-ignore
                  (...args) => __props.closePreviewDialog && __props.closePreviewDialog(...args))
                }, "×", 8, _hoisted_2$4)
              ]),
              createElementVNode("div", _hoisted_3$3, [
                __props.previewItems.length > 1 ? (openBlock(), createElementBlock("aside", _hoisted_4$3, [
                  createElementVNode("label", _hoisted_5$3, [
                    createElementVNode("span", null, [
                      _cache[5] || (_cache[5] = createTextVNode(
                        "字幕文件 ",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "small",
                        null,
                        toDisplayString(__props.previewItems.length),
                        1
                        /* TEXT */
                      )
                    ]),
                    createElementVNode("span", _hoisted_6$3, [
                      createElementVNode("input", {
                        type: "checkbox",
                        checked: allPreviewSelected.value,
                        indeterminate: somePreviewSelected.value,
                        onChange: _cache[1] || (_cache[1] = ($event) => __props.toggleAllPreviews($event.currentTarget.checked))
                      }, null, 40, _hoisted_7$3),
                      _cache[6] || (_cache[6] = createTextVNode(
                        " 全选 ",
                        -1
                        /* CACHED */
                      ))
                    ])
                  ]),
                  createElementVNode("div", _hoisted_8$3, [
                    (openBlock(true), createElementBlock(
                      Fragment,
                      null,
                      renderList(__props.previewItems, (item) => {
                        return openBlock(), createElementBlock(
                          "div",
                          {
                            key: item.index,
                            class: normalizeClass([
                              "subtitle-preview-file",
                              { "is-active": activePreviewItem.value?.index === item.index }
                            ])
                          },
                          [
                            createElementVNode("input", {
                              type: "checkbox",
                              checked: __props.previewSelected.includes(item.index),
                              "aria-label": `选择 ${item.name}`,
                              onChange: ($event) => __props.togglePreview(item.index, $event.currentTarget.checked)
                            }, null, 40, _hoisted_9$3),
                            createElementVNode("button", {
                              type: "button",
                              class: "subtitle-preview-file-open",
                              onClick: ($event) => activePreviewIndex.value = item.index
                            }, [
                              createElementVNode(
                                "span",
                                {
                                  class: normalizeClass(["subtitle-preview-format", `is-${item.format.toLowerCase()}`]),
                                  "aria-hidden": "true"
                                },
                                toDisplayString(item.format),
                                3
                                /* TEXT, CLASS */
                              ),
                              createElementVNode("span", _hoisted_11$2, [
                                createElementVNode("strong", {
                                  title: item.name
                                }, toDisplayString(item.name), 9, _hoisted_12$1),
                                createElementVNode(
                                  "small",
                                  null,
                                  toDisplayString(previewLanguage(item.language)) + " · " + toDisplayString(item.format),
                                  1
                                  /* TEXT */
                                )
                              ])
                            ], 8, _hoisted_10$3),
                            _cache[7] || (_cache[7] = createElementVNode(
                              "span",
                              {
                                class: "subtitle-preview-valid",
                                title: "校验通过",
                                "aria-label": "校验通过"
                              },
                              null,
                              -1
                              /* CACHED */
                            ))
                          ],
                          2
                          /* CLASS */
                        );
                      }),
                      128
                      /* KEYED_FRAGMENT */
                    ))
                  ])
                ])) : createCommentVNode("v-if", true),
                activePreviewItem.value ? (openBlock(), createElementBlock("main", _hoisted_13$1, [
                  createElementVNode("div", _hoisted_14$1, [
                    createElementVNode(
                      "span",
                      {
                        class: normalizeClass(["subtitle-preview-format", `is-${activePreviewItem.value.format.toLowerCase()}`]),
                        "aria-hidden": "true"
                      },
                      toDisplayString(activePreviewItem.value.format),
                      3
                      /* TEXT, CLASS */
                    ),
                    createElementVNode("span", _hoisted_15$1, [
                      createElementVNode("strong", {
                        title: activePreviewItem.value.name
                      }, toDisplayString(activePreviewItem.value.name), 9, _hoisted_16$1),
                      createElementVNode(
                        "small",
                        null,
                        toDisplayString(previewLanguage(activePreviewItem.value.language)) + " · " + toDisplayString(activePreviewItem.value.format) + " · " + toDisplayString(__props.previewProvider),
                        1
                        /* TEXT */
                      )
                    ]),
                    _cache[8] || (_cache[8] = createElementVNode(
                      "span",
                      { class: "subtitle-preview-check" },
                      [
                        createElementVNode("i"),
                        createTextVNode("校验通过")
                      ],
                      -1
                      /* CACHED */
                    ))
                  ]),
                  createElementVNode(
                    "pre",
                    _hoisted_17$1,
                    toDisplayString(activePreviewItem.value.excerpt),
                    1
                    /* TEXT */
                  )
                ])) : createCommentVNode("v-if", true)
              ]),
              createElementVNode("footer", _hoisted_18$1, [
                createElementVNode(
                  "span",
                  null,
                  "已选择 " + toDisplayString(__props.previewSelected.length) + " / " + toDisplayString(__props.previewItems.length) + " 个字幕文件",
                  1
                  /* TEXT */
                ),
                createElementVNode("button", {
                  type: "button",
                  class: "subtitle-action is-primary",
                  disabled: !__props.previewSelected.length || __props.savingPreview,
                  onClick: _cache[2] || (_cache[2] = //@ts-ignore
                  (...args) => __props.confirmPreview && __props.confirmPreview(...args))
                }, toDisplayString(__props.savingPreview ? "保存中…" : "保存所选"), 9, _hoisted_19$1)
              ])
            ],
            2
            /* CLASS */
          )
        ]),
        _: 1
        /* STABLE */
      }, 8, ["persistent"])) : createCommentVNode("v-if", true);
    };
  }
});
const _hoisted_1$4 = { class: "subtitle-dialog-heading" };
const _hoisted_2$3 = { class: "subtitle-dialog-body subtitle-upload-dialog-body" };
const _hoisted_3$2 = {
  key: 0,
  class: "subtitle-field-heading"
};
const _hoisted_4$2 = {
  key: 1,
  class: "subtitle-dialog-target"
};
const _hoisted_5$2 = ["title"];
const _hoisted_6$2 = { class: "subtitle-upload-file" };
const _hoisted_7$2 = ["title"];
const _hoisted_8$2 = {
  key: 2,
  class: "subtitle-dialog-error",
  role: "alert"
};
const _hoisted_9$2 = { class: "subtitle-dialog-actions" };
const _hoisted_10$2 = ["disabled"];
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "SubtitleUploadDialog",
  props: {
    language: {},
    dialogComponent: {},
    uploadPanelOpen: { type: Boolean },
    uploading: { type: Boolean },
    selected: {},
    file: {},
    error: {},
    languages: {},
    mediaName: { type: Function },
    closeUploadDialog: { type: Function },
    upload: { type: Function },
    chooseFile: { type: Function }
  },
  emits: ["update:language"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const fileInput = ref(null);
    function resetInput() {
      if (fileInput.value) fileInput.value.value = "";
    }
    __expose({ resetInput });
    const props = __props;
    const emit = __emit;
    const language = computed({
      get: () => props.language,
      set: (value) => emit("update:language", value)
    });
    return (_ctx, _cache) => {
      const _component_VBtn = resolveComponent("VBtn");
      const _component_VSelect = resolveComponent("VSelect");
      return __props.uploadPanelOpen ? (openBlock(), createBlock(resolveDynamicComponent(props.dialogComponent), {
        key: 0,
        "model-value": true,
        persistent: __props.uploading,
        "z-index": 2200,
        class: "subtitle-host-overlay",
        "content-class": "subtitle-host-dialog-content subtitle-compact-dialog-content",
        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => !$event && __props.closeUploadDialog())
      }, {
        default: withCtx(() => [
          createElementVNode(
            "form",
            {
              class: "subtitle-dialog subtitle-upload-dialog",
              role: "dialog",
              "aria-modal": "true",
              "aria-labelledby": "subtitle-upload-title",
              onSubmit: _cache[2] || (_cache[2] = //@ts-ignore
              (...args) => __props.upload && __props.upload(...args))
            },
            [
              createElementVNode("header", _hoisted_1$4, [
                _cache[4] || (_cache[4] = createElementVNode(
                  "span",
                  {
                    class: "subtitle-dialog-symbol is-upload",
                    "aria-hidden": "true"
                  },
                  [
                    createElementVNode("svg", {
                      viewBox: "0 0 24 24",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "1.7",
                      "stroke-linecap": "round",
                      "stroke-linejoin": "round"
                    }, [
                      createElementVNode("path", { d: "M12 16V3m-5 5 5-5 5 5M4 15v6h16v-6" })
                    ])
                  ],
                  -1
                  /* CACHED */
                )),
                _cache[5] || (_cache[5] = createElementVNode(
                  "div",
                  null,
                  [
                    createElementVNode("h2", { id: "subtitle-upload-title" }, "上传字幕"),
                    createElementVNode("p", null, "为当前媒体添加外挂字幕")
                  ],
                  -1
                  /* CACHED */
                )),
                createVNode(_component_VBtn, {
                  icon: "mdi-close",
                  variant: "text",
                  title: "关闭",
                  class: "app-dialog-close subtitle-compact-close",
                  "aria-label": "关闭上传字幕窗口",
                  disabled: __props.uploading,
                  onClick: __props.closeUploadDialog
                }, null, 8, ["disabled", "onClick"])
              ]),
              createElementVNode("div", _hoisted_2$3, [
                __props.selected ? (openBlock(), createElementBlock("span", _hoisted_3$2, "当前媒体")) : createCommentVNode("v-if", true),
                __props.selected ? (openBlock(), createElementBlock("div", _hoisted_4$2, [
                  _cache[6] || (_cache[6] = createElementVNode(
                    "svg",
                    {
                      viewBox: "0 0 24 24",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "1.5",
                      "aria-hidden": "true"
                    },
                    [
                      createElementVNode("rect", {
                        x: "3",
                        y: "3",
                        width: "18",
                        height: "18",
                        rx: "2"
                      }),
                      createElementVNode("path", { d: "M7 3v18M17 3v18M3 8h4m-4 8h4M17 8h4m-4 8h4" })
                    ],
                    -1
                    /* CACHED */
                  )),
                  createElementVNode("strong", {
                    title: __props.mediaName(__props.selected)
                  }, toDisplayString(__props.mediaName(__props.selected)), 9, _hoisted_5$2)
                ])) : createCommentVNode("v-if", true),
                _cache[8] || (_cache[8] = createElementVNode(
                  "span",
                  { class: "subtitle-field-heading" },
                  "字幕文件",
                  -1
                  /* CACHED */
                )),
                createElementVNode("label", _hoisted_6$2, [
                  _cache[7] || (_cache[7] = createElementVNode(
                    "span",
                    null,
                    "选择文件",
                    -1
                    /* CACHED */
                  )),
                  createElementVNode("strong", {
                    title: __props.file?.name
                  }, toDisplayString(__props.file?.name || "未选择文件"), 9, _hoisted_7$2),
                  createElementVNode(
                    "input",
                    {
                      ref_key: "fileInput",
                      ref: fileInput,
                      type: "file",
                      accept: ".srt,.ass,.ssa,.sbv,.sub,.vtt,.webvtt",
                      onChange: _cache[0] || (_cache[0] = //@ts-ignore
                      (...args) => __props.chooseFile && __props.chooseFile(...args))
                    },
                    null,
                    544
                    /* NEED_HYDRATION, NEED_PATCH */
                  )
                ]),
                _cache[9] || (_cache[9] = createElementVNode(
                  "p",
                  { class: "subtitle-dialog-hint" },
                  "支持 SRT、ASS、SSA、VTT、SUB",
                  -1
                  /* CACHED */
                )),
                _cache[10] || (_cache[10] = createElementVNode(
                  "span",
                  {
                    id: "subtitle-language-label",
                    class: "subtitle-field-heading"
                  },
                  "字幕语言",
                  -1
                  /* CACHED */
                )),
                createVNode(_component_VSelect, {
                  "aria-labelledby": "subtitle-language-label",
                  "model-value": language.value,
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => language.value = $event),
                  items: __props.languages.map((option) => ({ value: option[0], title: option[1] })),
                  "menu-props": { location: "bottom", offset: 6, maxHeight: 280, zIndex: 2300 },
                  variant: "outlined",
                  density: "compact",
                  "hide-details": ""
                }, null, 8, ["model-value", "items"]),
                __props.error ? (openBlock(), createElementBlock(
                  "p",
                  _hoisted_8$2,
                  toDisplayString(__props.error),
                  1
                  /* TEXT */
                )) : createCommentVNode("v-if", true)
              ]),
              createElementVNode("footer", _hoisted_9$2, [
                createElementVNode("button", {
                  type: "submit",
                  class: "subtitle-action is-primary",
                  disabled: !__props.file || __props.uploading
                }, toDisplayString(__props.uploading ? "上传中…" : "上传字幕"), 9, _hoisted_10$2)
              ])
            ],
            32
            /* NEED_HYDRATION */
          )
        ]),
        _: 1
        /* STABLE */
      }, 8, ["persistent"])) : createCommentVNode("v-if", true);
    };
  }
});
function preserveDialogDocumentHeight(initialHeight) {
  if (!initialHeight || !window.matchMedia?.("(max-width: 959px)").matches || !(/iP(?:hone|ad|od)/.test(navigator.userAgent) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)) return () => {
  };
  const targets = [document.documentElement, document.body].map((element) => ({
    element,
    value: element.style.getPropertyValue("min-height"),
    priority: element.style.getPropertyPriority("min-height")
  }));
  let applied = "";
  let width = window.innerWidth;
  function restore() {
    for (const { element, value, priority } of targets) {
      if (element.style.getPropertyValue("min-height") !== applied || element.style.getPropertyPriority("min-height") !== "important") continue;
      if (value) element.style.setProperty("min-height", value, priority);
      else element.style.removeProperty("min-height");
    }
  }
  function apply(height) {
    applied = `${Math.ceil(height)}px`;
    targets.forEach(({ element }) => element.style.setProperty("min-height", applied, "important"));
  }
  function resize() {
    if (width === window.innerWidth) return;
    width = window.innerWidth;
    restore();
    if (window.matchMedia("(max-width: 959px)").matches) {
      apply(Math.max(window.innerHeight, document.body.scrollHeight, document.documentElement.clientHeight));
    }
  }
  apply(initialHeight);
  window.addEventListener("resize", resize, { passive: true });
  return () => {
    window.removeEventListener("resize", resize);
    restore();
  };
}
function createInlineSearchViewport() {
  let release;
  let restingHeight = 0;
  let focused = false;
  let timer;
  function restore() {
    if (focused || !release) return;
    if (window.visualViewport && window.visualViewport.height < restingHeight - 120) return;
    release();
    release = void 0;
    window.visualViewport?.removeEventListener("resize", restore);
    window.removeEventListener("resize", restore);
  }
  return {
    focus() {
      focused = true;
      clearTimeout(timer);
      if (release) return;
      restingHeight = window.innerHeight;
      release = preserveDialogDocumentHeight(Math.max(restingHeight, document.body.scrollHeight, document.documentElement.clientHeight));
      window.visualViewport?.addEventListener("resize", restore, { passive: true });
      window.addEventListener("resize", restore, { passive: true });
    },
    blur() {
      focused = false;
      timer = setTimeout(restore, 250);
    },
    dispose() {
      clearTimeout(timer);
      release?.();
      release = void 0;
      window.visualViewport?.removeEventListener("resize", restore);
      window.removeEventListener("resize", restore);
    }
  };
}
function trackWorkspaceBounds(root) {
  let frame = 0;
  const observed = /* @__PURE__ */ new Set();
  const observer = new ResizeObserver(schedule);
  function update() {
    frame = 0;
    for (const [selector, property, edge] of [
      [".mobile-shell-bar", "--subtitle-workspace-top", "top"],
      [".mobile-shell-dock", "--subtitle-workspace-bottom", "bottom"]
    ]) {
      const element = document.querySelector(selector);
      if (!element || !element.getClientRects().length) {
        root.style.removeProperty(property);
        continue;
      }
      if (!observed.has(element)) {
        observed.add(element);
        observer.observe(element);
      }
      const rect = element.getBoundingClientRect();
      const inset = edge === "top" ? rect.bottom + 12 : window.innerHeight - rect.top + 6;
      root.style.setProperty(property, `${Math.max(0, inset)}px`);
    }
  }
  function schedule() {
    if (!frame) frame = requestAnimationFrame(update);
  }
  const additions = new MutationObserver(schedule);
  additions.observe(document.body, { childList: true, subtree: true });
  window.addEventListener("resize", schedule, { passive: true });
  window.visualViewport?.addEventListener("resize", schedule, { passive: true });
  update();
  return () => {
    cancelAnimationFrame(frame);
    observer.disconnect();
    additions.disconnect();
    window.removeEventListener("resize", schedule);
    window.visualViewport?.removeEventListener("resize", schedule);
  };
}
const list = (value) => Array.isArray(value) ? value : [];
class SubtitleOnlineSession {
  constructor(request, selected, error, status) {
    this.request = request;
    this.selected = selected;
    this.error = error;
    this.status = status;
  }
  request;
  selected;
  error;
  status;
  online = ref([]);
  onlineQuery = ref("");
  sourceStatuses = ref([]);
  activeSource = ref("");
  manualActions = ref([]);
  captchaChallenges = ref([]);
  selectedCandidate = ref("");
  previewToken = ref("");
  previewItems = ref([]);
  previewSelected = ref([]);
  activePreviewIndex = ref(null);
  previewing = ref(false);
  previewCaptcha = ref(null);
  captchaInput = ref("");
  solvingCaptcha = ref(false);
  seasonPack = ref(false);
  searching = ref(false);
  searchSequence = 0;
  previewSequence = 0;
  resetPreview() {
    this.previewToken.value = "";
    this.previewItems.value = [];
    this.previewSelected.value = [];
    this.activePreviewIndex.value = null;
    this.previewCaptcha.value = null;
    this.captchaInput.value = "";
  }
  resetResults() {
    this.online.value = [];
    this.selectedCandidate.value = "";
    this.sourceStatuses.value = [];
    this.activeSource.value = "";
    this.manualActions.value = [];
    this.captchaChallenges.value = [];
    this.resetPreview();
  }
  reset() {
    this.searchSequence += 1;
    this.previewSequence += 1;
    this.searching.value = false;
    this.previewing.value = false;
    this.solvingCaptcha.value = false;
    this.resetResults();
  }
  isSearchCurrent(id, path) {
    return id === this.searchSequence && this.selected.value?.path === path;
  }
  isPreviewCurrent(id, path) {
    return id === this.previewSequence && this.selected.value?.path === path;
  }
  applySearch(result, emptyMessage = "在线字幕源暂无匹配结果") {
    this.online.value = list(result?.items);
    this.sourceStatuses.value = list(result?.sources);
    this.manualActions.value = list(result?.manual_actions);
    this.captchaChallenges.value = list(result?.captcha_challenges);
    this.selectedCandidate.value = "";
    this.status.value = this.online.value.length ? `找到 ${this.online.value.length} 条在线字幕` : emptyMessage;
  }
  applyPreview(result) {
    if (result.captcha_required && result.captcha) {
      this.previewCaptcha.value = result.captcha;
      this.status.value = "该字幕下载前需要验证码，请完成后继续预览";
      return;
    }
    this.previewToken.value = result.preview_handle;
    this.previewItems.value = Array.isArray(result.items) ? result.items : [];
    this.previewSelected.value = this.previewItems.value.map((item) => item.index);
    this.activePreviewIndex.value = this.previewItems.value[0]?.index ?? null;
    this.previewCaptcha.value = null;
    this.captchaInput.value = "";
    this.status.value = `已下载并校验 ${this.previewItems.value.length} 个字幕文件，请确认后保存`;
  }
  async search() {
    if (!this.selected.value || this.searching.value) return;
    this.reset();
    const requestId = ++this.searchSequence;
    const mediaPath = this.selected.value.path;
    const query = this.onlineQuery.value;
    const seasonPack = this.seasonPack.value;
    this.searching.value = true;
    this.error.value = "";
    try {
      const result = await this.request("/plugins/subtitle-manager/api/online-search", {
        method: "POST",
        body: JSON.stringify({ media_path: mediaPath, query, season_pack: seasonPack })
      });
      if (this.isSearchCurrent(requestId, mediaPath)) this.applySearch(result);
    } catch (reason) {
      if (this.isSearchCurrent(requestId, mediaPath))
        this.error.value = reason instanceof Error ? reason.message : "在线字幕搜索失败";
    } finally {
      if (requestId === this.searchSequence) this.searching.value = false;
    }
  }
  async preview(candidateToken) {
    if (!this.selected.value || !candidateToken || this.previewing.value) return;
    const requestId = ++this.previewSequence;
    this.solvingCaptcha.value = false;
    const mediaPath = this.selected.value.path;
    this.selectedCandidate.value = candidateToken;
    this.previewing.value = true;
    this.error.value = "";
    this.status.value = "";
    this.resetPreview();
    try {
      const result = await this.request("/plugins/subtitle-manager/api/online-preview", {
        method: "POST",
        body: JSON.stringify({ media_path: mediaPath, candidate_handle: candidateToken })
      });
      if (this.isPreviewCurrent(requestId, mediaPath) && this.selectedCandidate.value === candidateToken) this.applyPreview(result);
    } catch (reason) {
      if (this.isPreviewCurrent(requestId, mediaPath))
        this.error.value = reason instanceof Error ? reason.message : "字幕下载预览失败";
    } finally {
      if (requestId === this.previewSequence) this.previewing.value = false;
    }
  }
  applyCaptcha(result) {
    if ("captcha_required" in result && result.captcha_required && result.captcha) {
      if (this.previewCaptcha.value) this.previewCaptcha.value = result.captcha;
      else this.captchaChallenges.value = [result.captcha];
      this.captchaInput.value = "";
      return;
    }
    if ("preview_handle" in result && result.preview_handle) {
      this.applyPreview(result);
      return;
    }
    this.applySearch(result, "验证码已提交，仍在等待字幕源结果");
    this.activeSource.value = "";
    this.captchaInput.value = "";
  }
  async submitCaptcha(challenge) {
    if (!challenge || this.solvingCaptcha.value || !this.captchaInput.value.trim()) return;
    const code = this.captchaInput.value.trim();
    const generation = this.searchSequence;
    const preview = this.previewSequence;
    const current = () => generation === this.searchSequence && preview === this.previewSequence;
    this.solvingCaptcha.value = true;
    this.error.value = "";
    try {
      const result = await this.request("/plugins/subtitle-manager/api/online-captcha", {
        method: "POST",
        body: JSON.stringify({ captcha_handle: challenge.handle, code })
      });
      if (current()) this.applyCaptcha(result);
    } catch (reason) {
      if (current()) this.error.value = reason instanceof Error ? reason.message : "验证码提交失败";
    } finally {
      if (current()) this.solvingCaptcha.value = false;
    }
  }
}
const _hoisted_1$3 = { class: "subtitle-browser app-surface-boundary" };
const _hoisted_2$2 = { class: "subtitle-layout" };
const _hoisted_3$1 = { class: "subtitle-sidebar" };
const _hoisted_4$1 = { class: "subtitle-section-heading" };
const _hoisted_5$1 = { class: "subtitle-sidebar-tools" };
const _hoisted_6$1 = { class: "subtitle-sidebar-search" };
const _hoisted_7$1 = ["value"];
const _hoisted_8$1 = ["disabled"];
const _hoisted_9$1 = { class: "subtitle-list" };
const _hoisted_10$1 = ["aria-pressed", "onClick"];
const _hoisted_11$1 = { class: "subtitle-media-copy" };
const _hoisted_12 = { class: "subtitle-count" };
const _hoisted_13 = {
  key: 0,
  class: "subtitle-empty subtitle-empty-list"
};
const _hoisted_14 = {
  class: "subtitle-pagination",
  "aria-label": "媒体分页"
};
const _hoisted_15 = ["disabled"];
const _hoisted_16 = ["disabled"];
const _hoisted_17 = {
  key: 0,
  class: "subtitle-detail"
};
const _hoisted_18 = ["aria-expanded"];
const _hoisted_19 = { class: "subtitle-sidebar-search subtitle-tab-search" };
const _hoisted_20 = ["value", "disabled"];
const _hoisted_21 = {
  key: 0,
  class: "subtitle-season-toggle"
};
const _hoisted_22 = ["checked"];
const _hoisted_23 = ["disabled"];
const _hoisted_24 = { class: "subtitle-files-section" };
const _hoisted_25 = {
  key: 1,
  class: "subtitle-online-panel"
};
const _hoisted_26 = {
  key: 0,
  class: "subtitle-source-progress"
};
const _hoisted_27 = {
  key: 1,
  class: "subtitle-source-filter"
};
const _hoisted_28 = ["aria-pressed"];
const _hoisted_29 = ["aria-pressed", "title", "onClick"];
const _hoisted_30 = { key: 0 };
const _hoisted_31 = {
  key: 0,
  class: "subtitle-source-navigation",
  "aria-label": "字幕源导航"
};
const _hoisted_32 = ["disabled"];
const _hoisted_33 = ["disabled"];
const _hoisted_34 = {
  key: 2,
  class: "subtitle-captcha-list"
};
const _hoisted_35 = ["src"];
const _hoisted_36 = { class: "subtitle-captcha-copy" };
const _hoisted_37 = { class: "subtitle-captcha-controls" };
const _hoisted_38 = ["value"];
const _hoisted_39 = ["disabled", "onClick"];
const _hoisted_40 = { class: "subtitle-table subtitle-online-results" };
const _hoisted_41 = {
  key: 0,
  class: "subtitle-table-empty"
};
const _hoisted_42 = {
  key: 1,
  class: "subtitle-file-list"
};
const _hoisted_43 = { class: "subtitle-file-copy" };
const _hoisted_44 = ["title", "aria-label"];
const _hoisted_45 = { class: "subtitle-mobile-meta" };
const _hoisted_46 = { class: "subtitle-file-meta" };
const _hoisted_47 = { class: "subtitle-file-meta" };
const _hoisted_48 = { class: "subtitle-file-meta" };
const _hoisted_49 = { class: "subtitle-file-meta" };
const _hoisted_50 = ["aria-expanded", "aria-label", "onClick"];
const _hoisted_51 = ["disabled", "onClick"];
const _hoisted_52 = ["href"];
const _hoisted_53 = {
  key: 2,
  class: "subtitle-table-empty"
};
const _hoisted_54 = {
  key: 3,
  class: "subtitle-captcha-list"
};
const _hoisted_55 = { class: "subtitle-captcha-card" };
const _hoisted_56 = ["src"];
const _hoisted_57 = { class: "subtitle-captcha-copy" };
const _hoisted_58 = { class: "subtitle-captcha-controls" };
const _hoisted_59 = ["value"];
const _hoisted_60 = ["disabled"];
const _hoisted_61 = {
  key: 4,
  class: "subtitle-manual-actions"
};
const _hoisted_62 = ["href"];
const _hoisted_63 = {
  key: 1,
  class: "subtitle-detail"
};
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "SubtitleWorkspacePage",
  props: {
    request: { type: Function },
    alertComponent: {},
    dialogComponent: {}
  },
  setup(__props) {
    const searchViewport = createInlineSearchViewport();
    const workspaceRoot = ref(null);
    let releaseWorkspaceBounds;
    let sourceResizeObserver;
    function disposeWorkspace() {
      catalogRequest++;
      selectionRequest++;
      onlineSession.reset();
      searchViewport.dispose();
      sourceResizeObserver?.disconnect();
      releaseWorkspaceBounds?.();
    }
    const props = __props;
    const items = ref([]);
    const selected = ref(null);
    const query = ref("");
    const loading = ref(false);
    const offset = ref(0);
    const hasMore = ref(false);
    let loadedQuery = "";
    const inventoryLoading = ref(false);
    let catalogRequest = 0;
    let selectionRequest = 0;
    const uploading = ref(false);
    const status = ref("");
    const error = ref("");
    const onlineSession = new SubtitleOnlineSession((path, init) => props.request(path, init), selected, error, status);
    const { online, onlineQuery, sourceStatuses, activeSource, manualActions, captchaChallenges, selectedCandidate, previewToken, previewItems, previewSelected, activePreviewIndex, previewing, previewCaptcha, captchaInput, solvingCaptcha, seasonPack, searching } = onlineSession;
    const language = ref("auto");
    const file = ref(null);
    const uploadDialog = ref(null);
    const savingPreview = ref(false);
    const adjustingSubtitle = ref(null);
    const adjustmentSeconds = ref("0");
    const adjustmentError = ref("");
    const adjusting = ref(false);
    const deletingSubtitle = ref(null);
    const deleteError = ref("");
    const deleting = ref(false);
    const uploadPanelOpen = ref(false);
    const activePanel = ref("local");
    const posterFailed = ref(false);
    const activeActionMenu = ref("");
    const activeActionMenuAbove = ref(false);
    const mobileSearchOpen = ref(false);
    const sourceScroller = ref(null);
    const sourceCanScrollLeft = ref(false);
    const sourceCanScrollRight = ref(false);
    const onlineSearchInput = ref(null);
    const noticeText = computed(() => error.value || status.value);
    const showNotice = computed(
      () => Boolean(error.value || status.value && !status.value.startsWith("已读取 "))
    );
    const notificationOnly = computed(() => !error.value && /^(?:找到 |在线字幕源)/.test(status.value));
    const noticeTitle = computed(() => {
      if (error.value) return "操作失败";
      if (status.value.startsWith("找到 ") || status.value.startsWith("在线字幕源"))
        return "搜索完成";
      if (status.value.startsWith("已写入 ")) return "上传完成";
      if (status.value.startsWith("已保存 ")) return "保存完成";
      if (status.value.startsWith("已删除 ")) return "删除完成";
      if (status.value.startsWith("已调整 ")) return "调整完成";
      if (status.value.includes("验证码")) return "需要验证码";
      if (status.value.startsWith("已下载并校验 ")) return "预览就绪";
      return "提示";
    });
    const visibleOnline = computed(
      () => activeSource.value ? online.value.filter((item) => item.provider === activeSource.value) : online.value
    );
    const previewProvider = computed(
      () => online.value.find(
        (item) => item.candidate_handle === selectedCandidate.value
      )?.provider || "在线字幕"
    );
    const providerClasses = {
      ASSRT: "is-assrt",
      OpenSubtitles: "is-opensubtitles",
      SubHD: "is-subhd",
      字幕库: "is-zimuku"
    };
    const providerMarks = {
      ASSRT: "A",
      OpenSubtitles: "O",
      SubHD: "S",
      字幕库: "字"
    };
    const languages = [
      ["auto", "自动识别"],
      ["zh-CN", "简体中文"],
      ["zh-TW", "繁体中文"],
      ["zh", "中文（未区分简繁）"],
      ["en", "英语"],
      ["ja", "日语"],
      ["ko", "韩语"]
    ];
    function toggleActionMenu(key, event) {
      if (activeActionMenu.value === key) {
        activeActionMenu.value = "";
        activeActionMenuAbove.value = false;
        return;
      }
      const trigger = event.currentTarget;
      const scrollport = trigger?.closest(
        ".subtitle-local-list, .subtitle-online-results"
      );
      const triggerBox = trigger?.getBoundingClientRect();
      const boundaryBox = scrollport?.getBoundingClientRect();
      activeActionMenuAbove.value = Boolean(
        triggerBox && boundaryBox && triggerBox.bottom + 108 > boundaryBox.bottom
      );
      activeActionMenu.value = key;
    }
    function handleWorkspacePointerDown(event) {
      const target = event.target;
      if (!target?.closest(".subtitle-row-actions")) activeActionMenu.value = "";
      if (!target?.closest(
        ".subtitle-mobile-search-trigger, .subtitle-tab-search-controls"
      ))
        mobileSearchOpen.value = false;
    }
    function toggleMobileSearch() {
      mobileSearchOpen.value = !mobileSearchOpen.value;
      if (mobileSearchOpen.value) {
        requestAnimationFrame(() => onlineSearchInput.value?.focus());
      }
    }
    function closeActionMenu(event) {
      const current = event?.currentTarget;
      const next = event?.relatedTarget;
      if (!current || !next || !current.contains(next)) activeActionMenu.value = "";
    }
    function restoreSelection() {
      const next = items.value.find((item) => item.path === selected.value?.path) || items.value[0] || null;
      if (next && next.path !== selected.value?.path) selectMedia(next);
      else {
        selected.value = next;
        if (next) void loadSelection(next);
        else {
          selectionRequest++;
          inventoryLoading.value = false;
        }
      }
    }
    function applyCatalogPage(result, nextOffset, keyword) {
      loadedQuery = keyword;
      offset.value = nextOffset;
      hasMore.value = Boolean(result?.has_more);
      items.value = Array.isArray(result?.items) ? result.items : [];
      restoreSelection();
      status.value = items.value.length ? `已读取 ${items.value.length} 个本地媒体文件` : "没有找到可访问的同步或整理媒体";
    }
    async function load(nextOffset = 0) {
      const requestId = ++catalogRequest;
      const keyword = query.value;
      if (keyword !== loadedQuery) nextOffset = 0;
      loading.value = true;
      error.value = "";
      try {
        const result = await props.request(
          `/plugins/subtitle-manager/api/catalog?query=${encodeURIComponent(keyword)}&limit=100&offset=${nextOffset}`
        );
        if (requestId !== catalogRequest) return;
        applyCatalogPage(result, nextOffset, keyword);
      } catch (reason) {
        if (requestId === catalogRequest) error.value = reason instanceof Error ? reason.message : "媒体记录读取失败";
      } finally {
        if (requestId === catalogRequest) loading.value = false;
      }
    }
    async function upload(event) {
      event?.preventDefault();
      if (!selected.value || !file.value || uploading.value) return;
      uploading.value = true;
      error.value = "";
      try {
        const params = new URLSearchParams({
          media_path: selected.value.path,
          language: language.value
        });
        await props.request(`/plugins/subtitle-manager/api/upload?${params}`, {
          method: "POST",
          headers: {
            "Content-Type": file.value.type || "application/octet-stream",
            "X-Plugin-Filename": encodeURIComponent(file.value.name)
          },
          body: file.value
        });
        status.value = `已写入 ${file.value.name}`;
        file.value = null;
        uploadDialog.value?.resetInput();
        await load(offset.value);
        uploadPanelOpen.value = false;
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "字幕上传失败";
      } finally {
        uploading.value = false;
      }
    }
    function openUploadDialog() {
      error.value = "";
      uploadPanelOpen.value = true;
    }
    function closeUploadDialog() {
      if (uploading.value) return;
      uploadPanelOpen.value = false;
      file.value = null;
      uploadDialog.value?.resetInput();
    }
    async function searchOnline(event) {
      event?.preventDefault();
      if (!selected.value || searching.value) return;
      activePanel.value = "online";
      await onlineSession.search();
      scheduleSourceOverflow();
    }
    const previewOnline = (candidateToken) => onlineSession.preview(candidateToken);
    async function submitCaptcha(challenge) {
      await onlineSession.submitCaptcha(challenge);
      scheduleSourceOverflow();
    }
    async function confirmPreview() {
      if (!selected.value || !previewToken.value || !previewSelected.value.length || savingPreview.value)
        return;
      savingPreview.value = true;
      error.value = "";
      try {
        const result = await props.request("/plugins/subtitle-manager/api/online-confirm", {
          method: "POST",
          body: JSON.stringify({
            media_path: selected.value.path,
            preview_handle: previewToken.value,
            selected: previewSelected.value
          })
        });
        status.value = `已保存 ${result.saved?.length || 0} 个字幕文件`;
        previewToken.value = "";
        previewItems.value = [];
        previewSelected.value = [];
        activePreviewIndex.value = null;
        await load(offset.value);
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "字幕保存失败";
      } finally {
        savingPreview.value = false;
      }
    }
    function openDeleteDialog(subtitle) {
      deletingSubtitle.value = subtitle;
      deleteError.value = "";
    }
    function closeDeleteDialog() {
      if (deleting.value) return;
      deletingSubtitle.value = null;
      deleteError.value = "";
    }
    async function removeSubtitle(event) {
      event?.preventDefault();
      if (!selected.value || !deletingSubtitle.value || deleting.value) return;
      const subtitle = deletingSubtitle.value;
      deleting.value = true;
      deleteError.value = "";
      try {
        await props.request("/plugins/subtitle-manager/api/delete", {
          method: "POST",
          body: JSON.stringify({
            media_path: selected.value.path,
            subtitle_name: subtitle.name
          })
        });
        status.value = `已删除 ${subtitle.name}`;
        deletingSubtitle.value = null;
        await load(offset.value);
      } catch (reason) {
        deleteError.value = reason instanceof Error ? reason.message : "字幕删除失败";
      } finally {
        deleting.value = false;
      }
    }
    function openAdjustment(subtitle) {
      adjustingSubtitle.value = subtitle;
      adjustmentSeconds.value = "0";
      adjustmentError.value = "";
    }
    function closeAdjustment() {
      if (adjusting.value) return;
      adjustingSubtitle.value = null;
      adjustmentError.value = "";
    }
    async function submitAdjustment(event) {
      event?.preventDefault();
      if (!selected.value || !adjustingSubtitle.value || adjusting.value) return;
      const seconds = Number(adjustmentSeconds.value);
      if (!Number.isFinite(seconds)) {
        adjustmentError.value = "请输入有效的时间偏移秒数";
        return;
      }
      adjusting.value = true;
      adjustmentError.value = "";
      try {
        const result = await props.request(
          "/plugins/subtitle-manager/api/adjust",
          {
            method: "POST",
            body: JSON.stringify({
              media_path: selected.value.path,
              subtitle_name: adjustingSubtitle.value.name,
              offset_seconds: seconds
            })
          }
        );
        status.value = `已调整 ${result.adjusted_count || 0} 条字幕时间轴`;
        adjustingSubtitle.value = null;
        await load(offset.value);
      } catch (reason) {
        adjustmentError.value = reason instanceof Error ? reason.message : "字幕调轴失败";
      } finally {
        adjusting.value = false;
      }
    }
    function mediaName(item) {
      return item.title || item.path.split(/[\\/]/).pop();
    }
    function identityQuery(item) {
      const identity = item.identity || {};
      const title = identity.title || item.title || mediaName(item) || "";
      if (identity.season != null && identity.episode != null)
        return `${title} S${String(identity.season).padStart(2, "0")}E${String(identity.episode).padStart(2, "0")}`;
      return `${title}${identity.year ? ` ${identity.year}` : ""}`;
    }
    function selectMedia(item) {
      onlineSession.reset();
      selected.value = item;
      adjustingSubtitle.value = null;
      adjustmentError.value = "";
      deletingSubtitle.value = null;
      deleteError.value = "";
      seasonPack.value = false;
      activePanel.value = "local";
      mobileSearchOpen.value = false;
      uploadPanelOpen.value = false;
      posterFailed.value = false;
      onlineQuery.value = identityQuery(item);
      error.value = "";
      void loadSelection(item);
      if (!item.poster_url) void loadPoster(item);
    }
    async function loadSelection(item) {
      const requestId = ++selectionRequest;
      inventoryLoading.value = item.subtitles === void 0;
      const params = `media_path=${encodeURIComponent(item.path)}`;
      const current = () => requestId === selectionRequest && selected.value?.path === item.path;
      await Promise.all([
        item.subtitles !== void 0 ? Promise.resolve() : props.request(
          `/plugins/subtitle-manager/api/inventory?${params}`
        ).then((result) => {
          if (current()) item.subtitles = Array.isArray(result?.items) ? result.items : [];
        }).catch((reason) => {
          if (current()) error.value = reason instanceof Error ? reason.message : "字幕读取失败";
        }).finally(() => {
          if (current()) inventoryLoading.value = false;
        }),
        props.request(`/plugins/subtitle-manager/api/detail?${params}`).then((result) => {
          if (!current()) return;
          const previousQuery = identityQuery(item);
          if (result?.identity) item.identity = result.identity;
          if (result?.title) item.title = result.title;
          if (onlineQuery.value === previousQuery) onlineQuery.value = identityQuery(item);
        }).catch((reason) => {
          if (current()) error.value = reason instanceof Error ? reason.message : "媒体详情读取失败";
        })
      ]);
    }
    async function loadPoster(item) {
      try {
        const result = await props.request(
          `/plugins/subtitle-manager/api/poster?media_path=${encodeURIComponent(item.path)}`
        );
        if (selected.value?.path === item.path && result?.data_url) {
          item.poster_url = result.data_url;
          posterFailed.value = false;
        }
      } catch {
      }
    }
    function updateSourceOverflow() {
      const element = sourceScroller.value;
      if (!element) return;
      sourceCanScrollLeft.value = element.scrollLeft > 2;
      sourceCanScrollRight.value = element.scrollLeft + element.clientWidth < element.scrollWidth - 2;
    }
    function observeSourceScroller() {
      const element = sourceScroller.value;
      if (!element || typeof ResizeObserver === "undefined") return;
      sourceResizeObserver?.disconnect();
      sourceResizeObserver = new ResizeObserver(updateSourceOverflow);
      sourceResizeObserver.observe(element);
    }
    function scheduleSourceOverflow() {
      requestAnimationFrame(() => {
        observeSourceScroller();
        updateSourceOverflow();
      });
    }
    function scrollSources(direction) {
      const element = sourceScroller.value;
      if (!element) return;
      const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
      element.scrollBy({
        left: direction * Math.max(180, element.clientWidth * 0.66),
        behavior: reducedMotion ? "auto" : "smooth"
      });
    }
    function selectSource(provider, event) {
      activeSource.value = activeSource.value === provider ? "" : provider;
      const button = event?.currentTarget;
      if (button && typeof button.scrollIntoView === "function") {
        button.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
      }
    }
    function providerClass(provider) {
      return providerClasses[provider] || "is-other";
    }
    function providerMark(provider) {
      return providerMarks[provider] || provider.slice(0, 1).toUpperCase();
    }
    function togglePreview(index, checked) {
      previewSelected.value = checked ? [.../* @__PURE__ */ new Set([...previewSelected.value, index])] : previewSelected.value.filter((value) => value !== index);
    }
    function toggleAllPreviews(checked) {
      previewSelected.value = checked ? previewItems.value.map((item) => item.index) : [];
    }
    function closePreviewDialog() {
      if (savingPreview.value) return;
      previewToken.value = "";
      previewItems.value = [];
      previewSelected.value = [];
      activePreviewIndex.value = null;
    }
    function sourceState(value) {
      if (value.state === "ready") {
        const rawCount = value.raw_candidate_count ?? value.candidate_count;
        return rawCount > value.candidate_count ? `${value.candidate_count}/${rawCount}` : `${value.candidate_count}`;
      }
      if (value.state === "restricted") return "";
      return value.state === "disabled" ? "未启用" : "失败";
    }
    function sourceTitle(value) {
      const rawCount = value.raw_candidate_count ?? value.candidate_count;
      const count = rawCount > value.candidate_count ? `${value.candidate_count} 条匹配，源站返回 ${rawCount} 条` : `${value.candidate_count} 条结果`;
      const issue = value.errors?.[0]?.message;
      if (value.state === "ready") return `${value.provider}：${count}`;
      const state = sourceState(value);
      return `${value.provider}${state ? `：${state}` : ""}${issue ? `${state ? "；" : "："}${issue}` : ""}`;
    }
    function formatSize(size = 0) {
      if (size < 1024) return `${size} B`;
      if (size < 1024 * 1024) return `${Math.max(1, Math.round(size / 1024))} KB`;
      return `${(size / 1024 / 1024).toFixed(1)} MB`;
    }
    function subtitleFormat(name) {
      return name.split(".").pop()?.toUpperCase() || "字幕";
    }
    function subtitleLanguage(name) {
      const value = name.toLowerCase();
      if (/zh[-_.]?(tw|hant)|cht/.test(value)) return "繁体中文";
      if (/zh[-_.]?(cn|hans)|chs/.test(value)) return "简体中文";
      if (/(^|[._-])en(g)?([._-]|$)/.test(value)) return "英语";
      return "自动识别";
    }
    function chooseFile(event) {
      file.value = event.currentTarget.files?.[0] || null;
    }
    function searchOnEnter(event) {
      if (event.key === "Enter") load();
    }
    onMounted(() => {
      if (workspaceRoot.value) releaseWorkspaceBounds = trackWorkspaceBounds(workspaceRoot.value);
      load();
    });
    return (_ctx, _cache) => {
      const _component_VTab = resolveComponent("VTab");
      const _component_VTabs = resolveComponent("VTabs");
      return openBlock(), createElementBlock(
        "section",
        {
          ref_key: "workspaceRoot",
          ref: workspaceRoot,
          class: "subtitle-workspace",
          onVnodeBeforeUnmount: disposeWorkspace,
          onPointerdown: handleWorkspacePointerDown
        },
        [
          createElementVNode("div", _hoisted_1$3, [
            showNotice.value ? (openBlock(), createBlock(resolveDynamicComponent(__props.alertComponent || "div"), {
              key: 0,
              type: error.value ? "error" : "info",
              variant: "tonal",
              class: normalizeClass(["subtitle-host-notice", { "subtitle-host-notice--notification-only": notificationOnly.value }]),
              role: "alert"
            }, {
              default: withCtx(() => [
                createElementVNode(
                  "strong",
                  null,
                  toDisplayString(noticeTitle.value),
                  1
                  /* TEXT */
                ),
                createElementVNode(
                  "span",
                  null,
                  toDisplayString(noticeText.value),
                  1
                  /* TEXT */
                )
              ]),
              _: 1
              /* STABLE */
            }, 8, ["type", "class"])) : createCommentVNode("v-if", true),
            createElementVNode("div", _hoisted_2$2, [
              createElementVNode("aside", _hoisted_3$1, [
                createElementVNode("div", _hoisted_4$1, [
                  _cache[27] || (_cache[27] = createElementVNode(
                    "h2",
                    null,
                    "媒体文件",
                    -1
                    /* CACHED */
                  )),
                  createElementVNode(
                    "span",
                    null,
                    toDisplayString(items.value.length) + " 个",
                    1
                    /* TEXT */
                  )
                ]),
                createElementVNode("div", _hoisted_5$1, [
                  createElementVNode("label", _hoisted_6$1, [
                    _cache[28] || (_cache[28] = createElementVNode(
                      "span",
                      {
                        class: "subtitle-search-icon",
                        "aria-hidden": "true"
                      },
                      null,
                      -1
                      /* CACHED */
                    )),
                    createElementVNode("input", {
                      class: "subtitle-search",
                      value: query.value,
                      "aria-label": "搜索本地媒体名称或路径",
                      placeholder: "搜索媒体",
                      onInput: _cache[0] || (_cache[0] = ($event) => query.value = $event.currentTarget.value),
                      onKeyup: searchOnEnter,
                      onFocus: _cache[1] || (_cache[1] = //@ts-ignore
                      (...args) => unref(searchViewport).focus && unref(searchViewport).focus(...args)),
                      onBlur: _cache[2] || (_cache[2] = //@ts-ignore
                      (...args) => unref(searchViewport).blur && unref(searchViewport).blur(...args))
                    }, null, 40, _hoisted_7$1),
                    query.value ? (openBlock(), createElementBlock("button", {
                      key: 0,
                      type: "button",
                      "aria-label": "清除媒体搜索",
                      title: "清除媒体搜索",
                      onClick: _cache[3] || (_cache[3] = ($event) => {
                        query.value = "";
                        load();
                      })
                    }, " × ")) : createCommentVNode("v-if", true)
                  ]),
                  createElementVNode("button", {
                    class: "subtitle-icon-button subtitle-sidebar-refresh",
                    type: "button",
                    disabled: loading.value,
                    "aria-label": "刷新媒体目录",
                    title: "刷新媒体目录",
                    onClick: _cache[4] || (_cache[4] = ($event) => load())
                  }, " ↻ ", 8, _hoisted_8$1)
                ]),
                createElementVNode("div", _hoisted_9$1, [
                  (openBlock(true), createElementBlock(
                    Fragment,
                    null,
                    renderList(items.value, (item) => {
                      return openBlock(), createElementBlock("button", {
                        key: item.path,
                        class: normalizeClass([
                          "subtitle-media",
                          selected.value?.path === item.path && "is-active"
                        ]),
                        "aria-pressed": selected.value?.path === item.path,
                        onClick: ($event) => selectMedia(item)
                      }, [
                        _cache[29] || (_cache[29] = createElementVNode(
                          "span",
                          {
                            class: "subtitle-rail",
                            "aria-hidden": "true"
                          },
                          null,
                          -1
                          /* CACHED */
                        )),
                        _cache[30] || (_cache[30] = createElementVNode(
                          "span",
                          {
                            class: "subtitle-media-icon",
                            "aria-hidden": "true"
                          },
                          "▶",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("span", _hoisted_11$1, [
                          createElementVNode(
                            "strong",
                            null,
                            toDisplayString(mediaName(item)),
                            1
                            /* TEXT */
                          ),
                          createElementVNode(
                            "small",
                            null,
                            toDisplayString(item.path),
                            1
                            /* TEXT */
                          )
                        ]),
                        createElementVNode(
                          "span",
                          _hoisted_12,
                          toDisplayString(item.subtitles === void 0 ? "—" : `${item.subtitles.length} 条`),
                          1
                          /* TEXT */
                        )
                      ], 10, _hoisted_10$1);
                    }),
                    128
                    /* KEYED_FRAGMENT */
                  )),
                  !items.value.length ? (openBlock(), createElementBlock(
                    "div",
                    _hoisted_13,
                    toDisplayString(loading.value ? "正在读取媒体记录…" : "暂无可管理媒体"),
                    1
                    /* TEXT */
                  )) : createCommentVNode("v-if", true)
                ]),
                createElementVNode("nav", _hoisted_14, [
                  createElementVNode("button", {
                    type: "button",
                    disabled: loading.value || offset.value === 0,
                    onClick: _cache[5] || (_cache[5] = ($event) => load(Math.max(0, offset.value - 100)))
                  }, "上一页", 8, _hoisted_15),
                  createElementVNode(
                    "span",
                    null,
                    "第 " + toDisplayString(Math.floor(offset.value / 100) + 1) + " 页",
                    1
                    /* TEXT */
                  ),
                  createElementVNode("button", {
                    type: "button",
                    disabled: loading.value || !hasMore.value,
                    onClick: _cache[6] || (_cache[6] = ($event) => load(offset.value + 100))
                  }, "下一页", 8, _hoisted_16)
                ])
              ]),
              selected.value ? (openBlock(), createElementBlock("main", _hoisted_17, [
                createVNode(_sfc_main$9, {
                  selected: selected.value,
                  "poster-failed": posterFailed.value,
                  "media-name": mediaName,
                  onPosterError: _cache[7] || (_cache[7] = ($event) => posterFailed.value = true)
                }, null, 8, ["selected", "poster-failed"]),
                createElementVNode(
                  "div",
                  {
                    class: normalizeClass([
                      "subtitle-content-tabs",
                      { "has-online-tools": activePanel.value === "online" }
                    ])
                  },
                  [
                    createVNode(_component_VTabs, {
                      modelValue: activePanel.value,
                      "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => activePanel.value = $event),
                      class: "subtitle-content-tab-list app-section-tabs app-section-tabs--line",
                      color: "primary",
                      "align-tabs": "start",
                      mandatory: "",
                      "aria-label": "字幕类型"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_VTab, { value: "local" }, {
                          default: withCtx(() => [..._cache[31] || (_cache[31] = [
                            createTextVNode(
                              "本地字幕",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }),
                        createVNode(_component_VTab, { value: "online" }, {
                          default: withCtx(() => [..._cache[32] || (_cache[32] = [
                            createTextVNode(
                              "在线字幕",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        })
                      ]),
                      _: 1
                      /* STABLE */
                    }, 8, ["modelValue"]),
                    activePanel.value === "local" ? (openBlock(), createElementBlock("button", {
                      key: 0,
                      type: "button",
                      class: "subtitle-action is-secondary is-compact subtitle-tab-action",
                      "aria-haspopup": "dialog",
                      onClick: openUploadDialog
                    }, " 上传字幕 ")) : (openBlock(), createElementBlock("button", {
                      key: 1,
                      type: "button",
                      class: "subtitle-mobile-search-trigger",
                      "aria-expanded": mobileSearchOpen.value,
                      "aria-label": "打开在线字幕搜索",
                      onClick: toggleMobileSearch
                    }, [..._cache[33] || (_cache[33] = [
                      createElementVNode(
                        "svg",
                        {
                          viewBox: "0 0 24 24",
                          fill: "none",
                          stroke: "currentColor",
                          "stroke-width": "2",
                          "stroke-linecap": "round",
                          "aria-hidden": "true"
                        },
                        [
                          createElementVNode("circle", {
                            cx: "11",
                            cy: "11",
                            r: "8"
                          }),
                          createElementVNode("path", { d: "m21 21-4.35-4.35" })
                        ],
                        -1
                        /* CACHED */
                      )
                    ])], 8, _hoisted_18)),
                    activePanel.value === "online" ? (openBlock(), createElementBlock(
                      "form",
                      {
                        key: 2,
                        class: normalizeClass(["subtitle-tab-search-controls", { "is-mobile-open": mobileSearchOpen.value }]),
                        role: "search",
                        onSubmit: _cache[13] || (_cache[13] = ($event) => {
                          mobileSearchOpen.value = false;
                          searchOnline($event);
                        })
                      },
                      [
                        createElementVNode("label", _hoisted_19, [
                          _cache[34] || (_cache[34] = createElementVNode(
                            "span",
                            {
                              class: "subtitle-search-icon",
                              "aria-hidden": "true"
                            },
                            null,
                            -1
                            /* CACHED */
                          )),
                          createElementVNode("input", {
                            value: unref(onlineQuery),
                            ref_key: "onlineSearchInput",
                            ref: onlineSearchInput,
                            onFocus: _cache[9] || (_cache[9] = //@ts-ignore
                            (...args) => unref(searchViewport).focus && unref(searchViewport).focus(...args)),
                            onBlur: _cache[10] || (_cache[10] = //@ts-ignore
                            (...args) => unref(searchViewport).blur && unref(searchViewport).blur(...args)),
                            class: "subtitle-search subtitle-online-query",
                            "aria-label": "在线字幕查询词",
                            placeholder: "搜索在线字幕",
                            disabled: unref(searching),
                            onInput: _cache[11] || (_cache[11] = ($event) => onlineQuery.value = $event.currentTarget.value)
                          }, null, 40, _hoisted_20)
                        ]),
                        selected.value.identity?.media_type === "tv" ? (openBlock(), createElementBlock("label", _hoisted_21, [
                          createElementVNode("input", {
                            checked: unref(seasonPack),
                            type: "checkbox",
                            "aria-label": "搜索整季字幕包",
                            onChange: _cache[12] || (_cache[12] = ($event) => seasonPack.value = $event.currentTarget.checked)
                          }, null, 40, _hoisted_22),
                          _cache[35] || (_cache[35] = createTextVNode(
                            " 整季 ",
                            -1
                            /* CACHED */
                          ))
                        ])) : createCommentVNode("v-if", true),
                        createElementVNode("button", {
                          type: "submit",
                          class: "subtitle-online-search-submit",
                          disabled: unref(searching) || !unref(onlineQuery).trim()
                        }, toDisplayString(unref(searching) ? "搜索中" : "搜索"), 9, _hoisted_23)
                      ],
                      34
                      /* CLASS, NEED_HYDRATION */
                    )) : createCommentVNode("v-if", true)
                  ],
                  2
                  /* CLASS */
                ),
                createElementVNode("section", _hoisted_24, [
                  activePanel.value === "local" ? (openBlock(), createBlock(_sfc_main$a, {
                    key: 0,
                    selected: selected.value,
                    "inventory-loading": inventoryLoading.value,
                    "active-action-menu": activeActionMenu.value,
                    "active-action-menu-above": activeActionMenuAbove.value,
                    "subtitle-format": subtitleFormat,
                    "subtitle-language": subtitleLanguage,
                    "format-size": formatSize,
                    "close-action-menu": closeActionMenu,
                    "toggle-action-menu": toggleActionMenu,
                    "load-selection": loadSelection,
                    onAdjust: _cache[14] || (_cache[14] = ($event) => {
                      activeActionMenu.value = "";
                      openAdjustment($event);
                    }),
                    onDelete: _cache[15] || (_cache[15] = ($event) => {
                      activeActionMenu.value = "";
                      openDeleteDialog($event);
                    }),
                    onSearchOnline: _cache[16] || (_cache[16] = ($event) => activePanel.value = "online")
                  }, null, 8, ["selected", "inventory-loading", "active-action-menu", "active-action-menu-above"])) : (openBlock(), createElementBlock("div", _hoisted_25, [
                    unref(searching) ? (openBlock(), createElementBlock("div", _hoisted_26, " 已启用字幕源正在独立搜索，单个来源失败不会影响其他来源。 ")) : createCommentVNode("v-if", true),
                    unref(sourceStatuses).length ? (openBlock(), createElementBlock("div", _hoisted_27, [
                      createElementVNode("button", {
                        type: "button",
                        class: normalizeClass(["subtitle-source", "subtitle-source-all", { "is-active": !unref(activeSource) }]),
                        "aria-pressed": !unref(activeSource),
                        title: "显示全部字幕源",
                        onClick: _cache[17] || (_cache[17] = ($event) => activeSource.value = "")
                      }, [
                        _cache[36] || (_cache[36] = createElementVNode(
                          "strong",
                          null,
                          "全部",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode(
                          "span",
                          null,
                          toDisplayString(unref(online).length),
                          1
                          /* TEXT */
                        )
                      ], 10, _hoisted_28),
                      createElementVNode(
                        "div",
                        {
                          class: normalizeClass([
                            "subtitle-source-scroller",
                            { "can-scroll-left": sourceCanScrollLeft.value, "can-scroll-right": sourceCanScrollRight.value }
                          ])
                        },
                        [
                          createElementVNode(
                            "div",
                            {
                              ref_key: "sourceScroller",
                              ref: sourceScroller,
                              class: "subtitle-source-list",
                              onScroll: updateSourceOverflow
                            },
                            [
                              (openBlock(true), createElementBlock(
                                Fragment,
                                null,
                                renderList(unref(sourceStatuses), (source) => {
                                  return openBlock(), createElementBlock("button", {
                                    key: source.provider,
                                    type: "button",
                                    class: normalizeClass([
                                      "subtitle-source",
                                      `is-${source.state}`,
                                      { "is-active": unref(activeSource) === source.provider }
                                    ]),
                                    "aria-pressed": unref(activeSource) === source.provider,
                                    title: sourceTitle(source),
                                    onClick: ($event) => selectSource(source.provider, $event)
                                  }, [
                                    _cache[37] || (_cache[37] = createElementVNode(
                                      "i",
                                      {
                                        class: "subtitle-source-dot",
                                        "aria-hidden": "true"
                                      },
                                      null,
                                      -1
                                      /* CACHED */
                                    )),
                                    createElementVNode(
                                      "strong",
                                      null,
                                      toDisplayString(source.provider),
                                      1
                                      /* TEXT */
                                    ),
                                    sourceState(source) ? (openBlock(), createElementBlock(
                                      "span",
                                      _hoisted_30,
                                      toDisplayString(sourceState(source)),
                                      1
                                      /* TEXT */
                                    )) : createCommentVNode("v-if", true)
                                  ], 10, _hoisted_29);
                                }),
                                128
                                /* KEYED_FRAGMENT */
                              ))
                            ],
                            544
                            /* NEED_HYDRATION, NEED_PATCH */
                          )
                        ],
                        2
                        /* CLASS */
                      ),
                      sourceCanScrollLeft.value || sourceCanScrollRight.value ? (openBlock(), createElementBlock("div", _hoisted_31, [
                        createElementVNode("button", {
                          type: "button",
                          class: "subtitle-source-arrow is-left",
                          "aria-label": "查看左侧字幕源",
                          disabled: !sourceCanScrollLeft.value,
                          onClick: _cache[18] || (_cache[18] = ($event) => scrollSources(-1))
                        }, [..._cache[38] || (_cache[38] = [
                          createElementVNode(
                            "span",
                            { "aria-hidden": "true" },
                            null,
                            -1
                            /* CACHED */
                          )
                        ])], 8, _hoisted_32),
                        createElementVNode("button", {
                          type: "button",
                          class: "subtitle-source-arrow is-right",
                          "aria-label": "查看右侧字幕源",
                          disabled: !sourceCanScrollRight.value,
                          onClick: _cache[19] || (_cache[19] = ($event) => scrollSources(1))
                        }, [..._cache[39] || (_cache[39] = [
                          createElementVNode(
                            "span",
                            { "aria-hidden": "true" },
                            null,
                            -1
                            /* CACHED */
                          )
                        ])], 8, _hoisted_33)
                      ])) : createCommentVNode("v-if", true)
                    ])) : createCommentVNode("v-if", true),
                    unref(captchaChallenges).length ? (openBlock(), createElementBlock("div", _hoisted_34, [
                      (openBlock(true), createElementBlock(
                        Fragment,
                        null,
                        renderList(unref(captchaChallenges), (challenge) => {
                          return openBlock(), createElementBlock("div", {
                            key: challenge.handle,
                            class: "subtitle-captcha-card"
                          }, [
                            challenge.image ? (openBlock(), createElementBlock("img", {
                              key: 0,
                              src: challenge.image,
                              class: "subtitle-captcha-image",
                              alt: "验证码"
                            }, null, 8, _hoisted_35)) : createCommentVNode("v-if", true),
                            createElementVNode(
                              "span",
                              _hoisted_36,
                              toDisplayString(challenge.provider) + "：" + toDisplayString(challenge.instruction),
                              1
                              /* TEXT */
                            ),
                            createElementVNode("div", _hoisted_37, [
                              createElementVNode("input", {
                                value: unref(captchaInput),
                                class: "subtitle-captcha-input",
                                maxlength: "64",
                                autocomplete: "off",
                                "aria-label": "验证码",
                                placeholder: "输入验证码",
                                onInput: _cache[20] || (_cache[20] = ($event) => captchaInput.value = $event.currentTarget.value)
                              }, null, 40, _hoisted_38),
                              createElementVNode("button", {
                                class: "subtitle-action is-primary",
                                disabled: unref(solvingCaptcha) || !unref(captchaInput).trim(),
                                onClick: ($event) => submitCaptcha(challenge)
                              }, toDisplayString(unref(solvingCaptcha) ? "提交中…" : "提交并继续搜索"), 9, _hoisted_39)
                            ])
                          ]);
                        }),
                        128
                        /* KEYED_FRAGMENT */
                      ))
                    ])) : createCommentVNode("v-if", true),
                    createElementVNode("div", _hoisted_40, [
                      _cache[40] || (_cache[40] = createElementVNode(
                        "div",
                        {
                          class: "subtitle-table-columns subtitle-online-columns",
                          "aria-hidden": "true"
                        },
                        [
                          createElementVNode("span", null, "字幕名称"),
                          createElementVNode("span", null, "来源"),
                          createElementVNode("span", null, "语言"),
                          createElementVNode("span", null, "格式"),
                          createElementVNode("span", null, "匹配")
                        ],
                        -1
                        /* CACHED */
                      )),
                      unref(online).length && !visibleOnline.value.length ? (openBlock(), createElementBlock(
                        "div",
                        _hoisted_41,
                        toDisplayString(unref(activeSource)) + " 暂无匹配字幕，再次点击来源卡可显示全部结果 ",
                        1
                        /* TEXT */
                      )) : visibleOnline.value.length ? (openBlock(), createElementBlock("div", _hoisted_42, [
                        (openBlock(true), createElementBlock(
                          Fragment,
                          null,
                          renderList(visibleOnline.value.slice(0, 20), (item) => {
                            return openBlock(), createElementBlock("div", {
                              key: item.candidate_handle,
                              class: "subtitle-file subtitle-table-row subtitle-online-file"
                            }, [
                              createElementVNode(
                                "span",
                                {
                                  class: normalizeClass([
                                    "subtitle-file-mark",
                                    "subtitle-provider-mark",
                                    providerClass(item.provider)
                                  ]),
                                  "aria-hidden": "true"
                                },
                                toDisplayString(providerMark(item.provider)),
                                3
                                /* TEXT, CLASS */
                              ),
                              createElementVNode("span", _hoisted_43, [
                                createElementVNode("strong", {
                                  title: item.title,
                                  "aria-label": item.title,
                                  tabindex: "0"
                                }, toDisplayString(item.title), 9, _hoisted_44)
                              ]),
                              createElementVNode(
                                "span",
                                _hoisted_45,
                                toDisplayString(item.provider) + " · " + toDisplayString(item.language || "未知") + " · " + toDisplayString(item.format?.toUpperCase() || "—") + " · " + toDisplayString(item.score || 0) + " 分 ",
                                1
                                /* TEXT */
                              ),
                              createElementVNode(
                                "span",
                                _hoisted_46,
                                toDisplayString(item.provider),
                                1
                                /* TEXT */
                              ),
                              createElementVNode(
                                "span",
                                _hoisted_47,
                                toDisplayString(item.language || "未知"),
                                1
                                /* TEXT */
                              ),
                              createElementVNode(
                                "span",
                                _hoisted_48,
                                toDisplayString(item.format?.toUpperCase() || "—"),
                                1
                                /* TEXT */
                              ),
                              createElementVNode(
                                "span",
                                _hoisted_49,
                                toDisplayString(item.score || 0) + " 分",
                                1
                                /* TEXT */
                              ),
                              createElementVNode(
                                "span",
                                {
                                  class: "subtitle-row-actions",
                                  onFocusout: closeActionMenu
                                },
                                [
                                  createElementVNode("button", {
                                    type: "button",
                                    class: "subtitle-action-trigger",
                                    "aria-expanded": activeActionMenu.value === `online:${item.candidate_handle}`,
                                    "aria-haspopup": "menu",
                                    "aria-label": `操作 ${item.title}`,
                                    title: "更多操作",
                                    onClick: ($event) => toggleActionMenu(`online:${item.candidate_handle}`, $event)
                                  }, "⋮", 8, _hoisted_50),
                                  activeActionMenu.value === `online:${item.candidate_handle}` ? (openBlock(), createElementBlock(
                                    "span",
                                    {
                                      key: 0,
                                      class: normalizeClass(["subtitle-row-action-menu", { "is-above": activeActionMenuAbove.value }]),
                                      role: "menu"
                                    },
                                    [
                                      createElementVNode("button", {
                                        type: "button",
                                        role: "menuitem",
                                        class: "subtitle-download-action",
                                        disabled: !item.downloadable || unref(previewing),
                                        onClick: ($event) => {
                                          activeActionMenu.value = "";
                                          previewOnline(item.candidate_handle);
                                        }
                                      }, toDisplayString(unref(previewing) && unref(selectedCandidate) === item.candidate_handle ? "下载中…" : "下载并预览"), 9, _hoisted_51),
                                      item.url ? (openBlock(), createElementBlock("a", {
                                        key: 0,
                                        href: item.url,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        role: "menuitem",
                                        onClick: _cache[21] || (_cache[21] = ($event) => activeActionMenu.value = "")
                                      }, "查看来源", 8, _hoisted_52)) : createCommentVNode("v-if", true)
                                    ],
                                    2
                                    /* CLASS */
                                  )) : createCommentVNode("v-if", true)
                                ],
                                32
                                /* NEED_HYDRATION */
                              )
                            ]);
                          }),
                          128
                          /* KEYED_FRAGMENT */
                        ))
                      ])) : (openBlock(), createElementBlock("div", _hoisted_53, [
                        createElementVNode(
                          "strong",
                          null,
                          toDisplayString(unref(searching) ? "正在搜索在线字幕" : "暂无在线字幕"),
                          1
                          /* TEXT */
                        ),
                        createElementVNode(
                          "span",
                          null,
                          toDisplayString(unref(searching) ? "正在等待各字幕源返回结果" : "输入关键词后搜索，结果会显示在这里"),
                          1
                          /* TEXT */
                        )
                      ]))
                    ]),
                    unref(previewCaptcha) ? (openBlock(), createElementBlock("div", _hoisted_54, [
                      createElementVNode("div", _hoisted_55, [
                        unref(previewCaptcha).image ? (openBlock(), createElementBlock("img", {
                          key: 0,
                          src: unref(previewCaptcha).image,
                          class: "subtitle-captcha-image",
                          alt: "下载验证码"
                        }, null, 8, _hoisted_56)) : createCommentVNode("v-if", true),
                        createElementVNode(
                          "span",
                          _hoisted_57,
                          toDisplayString(unref(previewCaptcha).provider) + "：" + toDisplayString(unref(previewCaptcha).instruction),
                          1
                          /* TEXT */
                        ),
                        createElementVNode("div", _hoisted_58, [
                          createElementVNode("input", {
                            value: unref(captchaInput),
                            class: "subtitle-captcha-input",
                            maxlength: "64",
                            autocomplete: "off",
                            "aria-label": "下载验证码",
                            placeholder: "输入验证码",
                            onInput: _cache[22] || (_cache[22] = ($event) => captchaInput.value = $event.currentTarget.value)
                          }, null, 40, _hoisted_59),
                          createElementVNode("button", {
                            class: "subtitle-action is-primary",
                            disabled: unref(solvingCaptcha) || !unref(captchaInput).trim(),
                            onClick: _cache[23] || (_cache[23] = ($event) => submitCaptcha(unref(previewCaptcha)))
                          }, toDisplayString(unref(solvingCaptcha) ? "提交中…" : "提交并继续预览"), 9, _hoisted_60)
                        ])
                      ])
                    ])) : createCommentVNode("v-if", true),
                    unref(manualActions).length ? (openBlock(), createElementBlock("div", _hoisted_61, [
                      _cache[41] || (_cache[41] = createElementVNode(
                        "span",
                        null,
                        "该来源需手动处理：",
                        -1
                        /* CACHED */
                      )),
                      (openBlock(true), createElementBlock(
                        Fragment,
                        null,
                        renderList(unref(manualActions), (action) => {
                          return openBlock(), createElementBlock("a", {
                            key: `${action.provider}:${action.url}`,
                            href: action.url,
                            target: "_blank",
                            rel: "noopener noreferrer"
                          }, toDisplayString(action.provider) + " · " + toDisplayString(action.reason), 9, _hoisted_62);
                        }),
                        128
                        /* KEYED_FRAGMENT */
                      ))
                    ])) : createCommentVNode("v-if", true)
                  ]))
                ])
              ])) : (openBlock(), createElementBlock("main", _hoisted_63, [..._cache[42] || (_cache[42] = [
                createElementVNode(
                  "div",
                  { class: "subtitle-empty subtitle-empty-files" },
                  [
                    createElementVNode("strong", null, "请选择媒体文件"),
                    createElementVNode("small", null, "从左侧列表选择需要管理字幕的媒体")
                  ],
                  -1
                  /* CACHED */
                )
              ])]))
            ])
          ]),
          createVNode(_sfc_main$5, {
            ref_key: "uploadDialog",
            ref: uploadDialog,
            "dialog-component": props.dialogComponent,
            "upload-panel-open": uploadPanelOpen.value,
            uploading: uploading.value,
            selected: selected.value,
            file: file.value,
            error: error.value,
            languages,
            "media-name": mediaName,
            "close-upload-dialog": closeUploadDialog,
            upload,
            "choose-file": chooseFile,
            language: language.value,
            "onUpdate:language": _cache[24] || (_cache[24] = ($event) => language.value = $event)
          }, null, 8, ["dialog-component", "upload-panel-open", "uploading", "selected", "file", "error", "language"]),
          createVNode(_sfc_main$6, {
            "dialog-component": props.dialogComponent,
            "preview-items": unref(previewItems),
            "saving-preview": savingPreview.value,
            "preview-selected": unref(previewSelected),
            "preview-provider": previewProvider.value,
            "close-preview-dialog": closePreviewDialog,
            "toggle-all-previews": toggleAllPreviews,
            "toggle-preview": togglePreview,
            "confirm-preview": confirmPreview,
            "active-preview-index": unref(activePreviewIndex),
            "onUpdate:activePreviewIndex": _cache[25] || (_cache[25] = ($event) => isRef(activePreviewIndex) ? activePreviewIndex.value = $event : null)
          }, null, 8, ["dialog-component", "preview-items", "saving-preview", "preview-selected", "preview-provider", "active-preview-index"]),
          createVNode(_sfc_main$7, {
            "dialog-component": props.dialogComponent,
            "adjusting-subtitle": adjustingSubtitle.value,
            adjusting: adjusting.value,
            "adjustment-error": adjustmentError.value,
            "close-adjustment": closeAdjustment,
            "submit-adjustment": submitAdjustment,
            "adjustment-seconds": adjustmentSeconds.value,
            "onUpdate:adjustmentSeconds": _cache[26] || (_cache[26] = ($event) => adjustmentSeconds.value = $event)
          }, null, 8, ["dialog-component", "adjusting-subtitle", "adjusting", "adjustment-error", "adjustment-seconds"]),
          createVNode(_sfc_main$8, {
            "dialog-component": props.dialogComponent,
            "deleting-subtitle": deletingSubtitle.value,
            deleting: deleting.value,
            "delete-error": deleteError.value,
            "close-delete-dialog": closeDeleteDialog,
            "remove-subtitle": removeSubtitle
          }, null, 8, ["dialog-component", "deleting-subtitle", "deleting", "delete-error"])
        ],
        544
        /* NEED_HYDRATION, NEED_PATCH */
      );
    };
  }
});
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "SavedSecretField",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    label: {},
    endpoint: {},
    request: { type: Function }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const restored = ref("");
    const edited = ref(false);
    const visible = ref(false);
    const error = ref("");
    const value = computed(() => edited.value ? String(props.modelValue || "") : String(props.modelValue || restored.value));
    let pending = null;
    async function load() {
      if (edited.value || value.value) return;
      pending ||= props.request(props.endpoint).then((result) => {
        if (!edited.value) restored.value = result.value || "";
      }).finally(() => {
        pending = null;
      });
      await pending;
    }
    async function restore() {
      error.value = "";
      try {
        await load();
        return true;
      } catch {
        error.value = "密钥读取失败，请点击眼睛重试";
        return false;
      }
    }
    async function toggle() {
      if (props.disabled) return;
      if (visible.value) {
        visible.value = false;
        return;
      }
      if (await restore()) visible.value = true;
    }
    function update(next) {
      edited.value = true;
      restored.value = "";
      emit("update:modelValue", next || "");
    }
    onMounted(restore);
    return (_ctx, _cache) => {
      const _component_VTextField = resolveComponent("VTextField");
      return openBlock(), createBlock(_component_VTextField, {
        "model-value": value.value,
        disabled: __props.disabled,
        label: __props.label,
        type: visible.value ? "text" : "password",
        "prepend-inner-icon": "mdi-lock-outline",
        "append-inner-icon": visible.value ? "mdi-eye-off-outline" : "mdi-eye-outline",
        autocomplete: "off",
        "hide-details": !error.value,
        "error-messages": error.value,
        "onClick:appendInner": toggle,
        "onUpdate:modelValue": update
      }, null, 8, ["model-value", "disabled", "label", "type", "append-inner-icon", "hide-details", "error-messages"]);
    };
  }
});
function orderedFields(fields, order) {
  return order.flatMap((key) => {
    const field = fields.find((candidate) => candidate.key === key);
    return field ? [{ ...field }] : [];
  });
}
const _hoisted_1$2 = { class: "online-source-settings plugin-config-grid app-form-layout" };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "OnlineSourcesEditor",
  props: {
    modelValue: {},
    fields: {},
    disabled: { type: Boolean },
    schemaFieldsComponent: {},
    request: { type: Function }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const top = computed(() => orderedFields(props.fields || [], ["online_providers", "online_use_proxy"]));
    const selected = computed(() => {
      const value = props.modelValue.online_providers ?? props.fields?.find((field) => field.key === "online_providers")?.default ?? ["subhd", "zimuku"];
      return Array.isArray(value) ? value.map(String) : [];
    });
    const groups = [
      { key: "subhd", title: "SubHD", fields: ["subhd_url"] },
      { key: "zimuku", title: "字幕库", fields: ["zimuku_url"] },
      { key: "assrt", title: "ASSRT", fields: ["assrt_api_url", "assrt_api_key", "assrt_search_url"] },
      { key: "opensubtitles", title: "OpenSubtitles", fields: ["opensubtitles_api_url", "opensubtitles_api_key", "opensubtitles_username", "opensubtitles_password"] },
      { key: "subdl", title: "SubDL", fields: ["subdl_api_url", "subdl_api_key"] },
      { key: "shooter", title: "射手影音", fields: ["shooter_api_url"] },
      { key: "xunlei", title: "迅雷看看", fields: ["xunlei_api_url"] }
    ];
    const visibleGroups = computed(() => groups.filter((group) => selected.value.includes(group.key)));
    function fieldsFor(keys) {
      return orderedFields(props.fields || [], keys);
    }
    function update(next) {
      emit("update:modelValue", { ...props.modelValue, ...next });
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        (openBlock(true), createElementBlock(
          Fragment,
          null,
          renderList(top.value, (field) => {
            return openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
              key: field.key,
              fields: [field],
              "model-value": __props.modelValue,
              disabled: __props.disabled,
              compact: "",
              "onUpdate:modelValue": update
            }, null, 8, ["fields", "model-value", "disabled"]);
          }),
          128
          /* KEYED_FRAGMENT */
        )),
        (openBlock(true), createElementBlock(
          Fragment,
          null,
          renderList(visibleGroups.value, (group) => {
            return openBlock(), createElementBlock(
              Fragment,
              {
                key: group.key
              },
              [
                createElementVNode(
                  "h3",
                  null,
                  toDisplayString(group.title),
                  1
                  /* TEXT */
                ),
                (openBlock(true), createElementBlock(
                  Fragment,
                  null,
                  renderList(fieldsFor(group.fields), (field) => {
                    return openBlock(), createElementBlock(
                      Fragment,
                      {
                        key: field.key
                      },
                      [
                        field.secret ? (openBlock(), createBlock(_sfc_main$3, {
                          key: 0,
                          "model-value": __props.modelValue[field.key],
                          disabled: __props.disabled,
                          label: field.label || field.key,
                          request: __props.request,
                          endpoint: `/plugins/subtitle-manager/config/secret/${field.key}`,
                          "onUpdate:modelValue": ($event) => update({ [field.key]: $event, [field.key + "_clear"]: false })
                        }, null, 8, ["model-value", "disabled", "label", "request", "endpoint", "onUpdate:modelValue"])) : (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
                          key: 1,
                          fields: [field],
                          "model-value": __props.modelValue,
                          disabled: __props.disabled,
                          compact: "",
                          "onUpdate:modelValue": update
                        }, null, 8, ["fields", "model-value", "disabled"]))
                      ],
                      64
                      /* STABLE_FRAGMENT */
                    );
                  }),
                  128
                  /* KEYED_FRAGMENT */
                ))
              ],
              64
              /* STABLE_FRAGMENT */
            );
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ]);
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const OnlineSourcesEditor = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-371a0594"]]);
const _hoisted_1$1 = ["aria-label"];
const _hoisted_2$1 = { key: 0 };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "LoadingState",
  props: {
    label: { default: "正在加载" },
    inline: { type: Boolean },
    minHeight: { default: 54 }
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["plugin-loading-state", { "is-inline": __props.inline }]),
        style: normalizeStyle({ "--loading-height": `${__props.minHeight}px` }),
        role: "status",
        "aria-live": "polite",
        "aria-label": __props.label
      }, [
        _cache[0] || (_cache[0] = createElementVNode(
          "span",
          {
            class: "plugin-loading-ring",
            "aria-hidden": "true"
          },
          null,
          -1
          /* CACHED */
        )),
        __props.label ? (openBlock(), createElementBlock(
          "span",
          _hoisted_2$1,
          toDisplayString(__props.label),
          1
          /* TEXT */
        )) : createCommentVNode("v-if", true)
      ], 14, _hoisted_1$1);
    };
  }
});
const LoadingState = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-1be133f1"]]);
const _hoisted_1 = { class: "stats-header" };
const _hoisted_2 = { class: "stats-body" };
const _hoisted_3 = {
  key: 0,
  role: "alert"
};
const _hoisted_4 = {
  class: "metrics",
  "aria-label": "处理指标"
};
const _hoisted_5 = { "aria-label": "字幕明细" };
const _hoisted_6 = { class: "table-scroll" };
const _hoisted_7 = ["aria-expanded", "onClick"];
const _hoisted_8 = { key: 0 };
const _hoisted_9 = { key: 0 };
const _hoisted_10 = { class: "pagination" };
const _hoisted_11 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: { type: Function },
    dialogComponent: {},
    cardComponent: {},
    buttonComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiDialog = props.dialogComponent, UiCard = props.cardComponent, UiButton = props.buttonComponent;
    const loading = ref(false), error = ref("");
    const latest = ref(null);
    const page = ref(1);
    const expanded = ref({});
    const stats = computed(() => latest.value?.result?.statistics);
    const rows = computed(() => stats.value?.rows || []);
    const pages = computed(() => Math.max(1, Math.ceil(rows.value.length / 8)));
    const visibleRows = computed(() => rows.value.slice((page.value - 1) * 8, page.value * 8));
    const number = (value) => typeof value === "number" && Number.isFinite(value) ? value : 0;
    const legacyResult = computed(() => latest.value?.result);
    const checkedMedia = computed(() => number(stats.value?.media ?? legacyResult.value?.media_count));
    const savedSubtitles = computed(() => number(stats.value?.saved ?? legacyResult.value?.saved_count));
    const metrics = computed(() => [
      { label: "检查媒体", value: checkedMedia.value },
      { label: "保存字幕", value: savedSubtitles.value },
      { label: "已跳过", value: number(stats.value?.skipped) },
      { label: "处理失败", value: number(stats.value?.failed) }
    ]);
    function language(value) {
      return { "zh-CN-en": "简体中英双语", "zh-TW-en": "繁体中英双语", "zh-CN": "简体中文", "zh-TW": "繁体中文", zh: "中文（未区分简繁）", en: "英语", ja: "日语", ko: "韩语" }[value || ""] || "—";
    }
    function rowStatus(value) {
      return { saved: "已保存", skipped: "已跳过", failed: "失败" }[value || ""] || "—";
    }
    async function load() {
      if (loading.value) return;
      loading.value = true;
      error.value = "";
      try {
        const data = await props.request("/plugins/subtitle-manager/runs?limit=1");
        latest.value = data.items?.[0] || null;
        page.value = 1;
        expanded.value = {};
      } catch {
        error.value = "统计数据加载失败，请刷新重试";
      } finally {
        loading.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(UiDialog), {
        "model-value": true,
        "max-width": 1e3,
        width: "calc(100vw - 32px)",
        "onUpdate:modelValue": _cache[2] || (_cache[2] = (open) => {
          if (!open) __props.context.close();
        })
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "subtitle-statistics" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1, [
                _cache[3] || (_cache[3] = createElementVNode(
                  "h2",
                  null,
                  "字幕管理助手 · 数据统计",
                  -1
                  /* CACHED */
                )),
                createVNode(unref(UiButton), {
                  class: "app-dialog-close",
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: __props.context.close
                }, null, 8, ["onClick"])
              ]),
              createElementVNode("main", _hoisted_2, [
                error.value ? (openBlock(), createElementBlock(
                  "p",
                  _hoisted_3,
                  toDisplayString(error.value),
                  1
                  /* TEXT */
                )) : loading.value && !latest.value ? (openBlock(), createBlock(LoadingState, {
                  key: 1,
                  label: "正在加载统计数据"
                })) : (openBlock(), createElementBlock(
                  Fragment,
                  { key: 2 },
                  [
                    createElementVNode("section", _hoisted_4, [
                      (openBlock(true), createElementBlock(
                        Fragment,
                        null,
                        renderList(metrics.value, (metric) => {
                          return openBlock(), createElementBlock("article", {
                            key: metric.label
                          }, [
                            createElementVNode(
                              "h3",
                              null,
                              toDisplayString(metric.label),
                              1
                              /* TEXT */
                            ),
                            createElementVNode(
                              "strong",
                              null,
                              toDisplayString(metric.value),
                              1
                              /* TEXT */
                            )
                          ]);
                        }),
                        128
                        /* KEYED_FRAGMENT */
                      ))
                    ]),
                    createElementVNode("section", _hoisted_5, [
                      _cache[8] || (_cache[8] = createElementVNode(
                        "h3",
                        { class: "detail-title" },
                        "字幕明细",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("div", _hoisted_6, [
                        createElementVNode("table", null, [
                          _cache[5] || (_cache[5] = createElementVNode(
                            "thead",
                            null,
                            [
                              createElementVNode("tr", null, [
                                createElementVNode("th", null, "媒体名称"),
                                createElementVNode("th", null, "字幕源"),
                                createElementVNode("th", null, "语言"),
                                createElementVNode("th", null, "格式"),
                                createElementVNode("th", null, "处理结果")
                              ])
                            ],
                            -1
                            /* CACHED */
                          )),
                          createElementVNode("tbody", null, [
                            (openBlock(true), createElementBlock(
                              Fragment,
                              null,
                              renderList(visibleRows.value, (row, index) => {
                                return openBlock(), createElementBlock(
                                  Fragment,
                                  {
                                    key: `${page.value}-${index}`
                                  },
                                  [
                                    createElementVNode("tr", null, [
                                      createElementVNode(
                                        "td",
                                        null,
                                        toDisplayString(row.media || "—"),
                                        1
                                        /* TEXT */
                                      ),
                                      createElementVNode(
                                        "td",
                                        null,
                                        toDisplayString(row.provider || "—"),
                                        1
                                        /* TEXT */
                                      ),
                                      createElementVNode(
                                        "td",
                                        null,
                                        toDisplayString(language(row.language)),
                                        1
                                        /* TEXT */
                                      ),
                                      createElementVNode(
                                        "td",
                                        null,
                                        toDisplayString(row.format || "—"),
                                        1
                                        /* TEXT */
                                      ),
                                      createElementVNode("td", null, [
                                        createElementVNode(
                                          "span",
                                          {
                                            class: normalizeClass(["pill", row.status])
                                          },
                                          toDisplayString(rowStatus(row.status)),
                                          3
                                          /* TEXT, CLASS */
                                        ),
                                        row.reason ? (openBlock(), createElementBlock("button", {
                                          key: 0,
                                          class: "reason-toggle",
                                          "aria-expanded": !!expanded.value[index],
                                          "aria-label": "查看处理原因",
                                          onClick: ($event) => expanded.value[index] = !expanded.value[index]
                                        }, toDisplayString(expanded.value[index] ? "⌃" : "⌄"), 9, _hoisted_7)) : createCommentVNode("v-if", true)
                                      ])
                                    ]),
                                    row.reason && expanded.value[index] ? (openBlock(), createElementBlock("tr", _hoisted_8, [
                                      createElementVNode(
                                        "td",
                                        {
                                          colspan: "5",
                                          class: normalizeClass(["reason", row.status])
                                        },
                                        toDisplayString(row.reason),
                                        3
                                        /* TEXT, CLASS */
                                      )
                                    ])) : createCommentVNode("v-if", true)
                                  ],
                                  64
                                  /* STABLE_FRAGMENT */
                                );
                              }),
                              128
                              /* KEYED_FRAGMENT */
                            )),
                            !rows.value.length ? (openBlock(), createElementBlock("tr", _hoisted_9, [..._cache[4] || (_cache[4] = [
                              createElementVNode(
                                "td",
                                {
                                  colspan: "5",
                                  class: "empty"
                                },
                                "暂无字幕处理明细",
                                -1
                                /* CACHED */
                              )
                            ])])) : createCommentVNode("v-if", true)
                          ])
                        ])
                      ]),
                      createElementVNode("div", _hoisted_10, [
                        createElementVNode("span", null, [
                          createTextVNode(
                            "共 " + toDisplayString(rows.value.length) + " 条",
                            1
                            /* TEXT */
                          ),
                          (stats.value?.total_rows || 0) > rows.value.length ? (openBlock(), createElementBlock(
                            "span",
                            _hoisted_11,
                            "（仅展示前 " + toDisplayString(rows.value.length) + " 条）",
                            1
                            /* TEXT */
                          )) : createCommentVNode("v-if", true)
                        ]),
                        createElementVNode("div", null, [
                          createVNode(unref(UiButton), {
                            variant: "text",
                            disabled: page.value <= 1,
                            "aria-label": "上一页",
                            onClick: _cache[0] || (_cache[0] = ($event) => {
                              page.value--;
                              expanded.value = {};
                            })
                          }, {
                            default: withCtx(() => [..._cache[6] || (_cache[6] = [
                              createTextVNode(
                                "‹",
                                -1
                                /* CACHED */
                              )
                            ])]),
                            _: 1
                            /* STABLE */
                          }, 8, ["disabled"]),
                          createElementVNode(
                            "span",
                            null,
                            toDisplayString(page.value) + " / " + toDisplayString(pages.value),
                            1
                            /* TEXT */
                          ),
                          createVNode(unref(UiButton), {
                            variant: "text",
                            disabled: page.value >= pages.value,
                            "aria-label": "下一页",
                            onClick: _cache[1] || (_cache[1] = ($event) => {
                              page.value++;
                              expanded.value = {};
                            })
                          }, {
                            default: withCtx(() => [..._cache[7] || (_cache[7] = [
                              createTextVNode(
                                "›",
                                -1
                                /* CACHED */
                              )
                            ])]),
                            _: 1
                            /* STABLE */
                          }, 8, ["disabled"])
                        ])
                      ])
                    ])
                  ],
                  64
                  /* STABLE_FRAGMENT */
                ))
              ]),
              createElementVNode("footer", null, [
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: loading.value,
                  onClick: load
                }, {
                  default: withCtx(() => [..._cache[9] || (_cache[9] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-6c9490fa"]]);
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  sdk.registerContribution?.({ pluginId: "subtitle-manager", slot: "plugin.statistics", key: "overview", component: defineComponent2({
    props: { context: { type: Object, required: true } },
    setup(props) {
      return () => h(StatisticsView, {
        context: props.context,
        request: sdk.request,
        dialogComponent: sdk.ui.components.Dialog,
        cardComponent: sdk.ui.components.Card,
        buttonComponent: sdk.ui.components.Button
      });
    }
  }) });
  const SchemaFields = sdk.ui?.components?.SchemaFields;
  if (SchemaFields) {
    sdk.registerEditor({ domain: "plugin", key: "subtitle-manager:online", component: defineComponent2({
      inheritAttrs: false,
      props: { modelValue: { type: Object, required: true }, disabled: Boolean },
      emits: ["update:modelValue"],
      setup(props, { attrs, emit }) {
        return () => h(OnlineSourcesEditor, {
          ...attrs,
          modelValue: props.modelValue,
          disabled: props.disabled,
          request: sdk.request,
          schemaFieldsComponent: SchemaFields,
          "onUpdate:modelValue": (value) => emit("update:modelValue", value)
        });
      }
    }) });
  }
  const Page = defineComponent2({
    name: "SubtitleWorkspacePage",
    inheritAttrs: false,
    setup() {
      return () => h(_sfc_main$4, {
        request: (path, init) => sdk.request(path, init),
        alertComponent: sdk.ui?.components?.Alert,
        dialogComponent: sdk.ui.components.Dialog
      });
    }
  });
  sdk.registerPage({ pluginId: "subtitle-manager", route: "plugin-subtitle-manager", title: "字幕管理", icon: "mdi-subtitles-outline", section: "tools", order: 65, component: Page });
}
export {
  install
};
