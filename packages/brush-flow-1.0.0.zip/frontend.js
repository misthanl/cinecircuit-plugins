if (typeof document !== "undefined") { const id = "brush_flow"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.brush[data-v-74820f41]{display:grid;gap:18px;color:var(--app-text,#17243a)}.brush[data-v-74820f41] *{box-sizing:border-box}.brush-head[data-v-74820f41],.brush-panel[data-v-74820f41]{border:1px solid var(--app-border,#dfe6f0);border-radius:22px;background:var(--app-surface,#fff);box-shadow:0 14px 36px rgba(38,60,94,.06)}.brush-head[data-v-74820f41]{display:flex;justify-content:space-between;align-items:center;gap:18px;padding:22px 24px}.brush h1[data-v-74820f41],.brush h2[data-v-74820f41]{margin:0}.brush p[data-v-74820f41]{margin:5px 0 0;color:var(--app-text-muted,#71809a)}.brush-actions[data-v-74820f41]{display:flex;gap:9px}.brush button[data-v-74820f41]{min-height:40px;padding:0 15px;border:0;border-radius:12px;background:#2f74f6;color:#fff;font-weight:750;cursor:pointer}.brush button.ghost[data-v-74820f41]{background:#edf3ff;color:#245fc4}.brush button.warn[data-v-74820f41]{background:#fff1dc;color:#a86100}.brush button[data-v-74820f41]:disabled{opacity:.5}.brush-layout[data-v-74820f41]{display:grid;grid-template-columns:minmax(240px,.65fr) minmax(0,1.45fr);gap:16px}.brush-panel[data-v-74820f41]{padding:20px}.brush-list[data-v-74820f41]{display:grid;gap:9px;margin-top:15px}.brush-task[data-v-74820f41]{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;padding:13px;border:1px solid var(--app-border,#dfe6f0);border-radius:14px;background:#f8fafc;cursor:pointer}.brush-task.on[data-v-74820f41]{border-color:#82adff;background:#f1f6ff}.brush-task strong[data-v-74820f41],.brush-task small[data-v-74820f41]{display:block}.brush-task small[data-v-74820f41]{margin-top:4px;color:#7c899d}.brush-form[data-v-74820f41]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}.brush-field[data-v-74820f41]{display:grid;gap:6px}.brush-field.full[data-v-74820f41]{grid-column:1/-1}.brush-field span[data-v-74820f41]{font-size:13px;font-weight:700;color:#5e6d84}.brush-field input[data-v-74820f41],.brush-field select[data-v-74820f41]{width:100%;min-height:42px;padding:0 12px;border:1px solid #d6deea;border-radius:11px;background:#fff}.brush-check[data-v-74820f41]{display:flex;gap:8px;align-items:center;min-height:42px}.brush-preview[data-v-74820f41]{grid-column:1/-1;display:grid;gap:7px;padding-top:13px;border-top:1px solid #e3e8f1}.brush-preview div[data-v-74820f41]{padding:9px 11px;border-radius:10px;background:#f5f8fc;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.brush-empty[data-v-74820f41]{padding:30px;text-align:center;color:#8290a5}@media(max-width:800px){.brush-layout[data-v-74820f41]{grid-template-columns:1fr}.brush-form[data-v-74820f41]{grid-template-columns:1fr}.brush-field.full[data-v-74820f41]{grid-column:auto}.brush-head[data-v-74820f41]{align-items:stretch;flex-direction:column}.brush-actions[data-v-74820f41]{display:grid}}\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\n * Values mirror the host application's standard configuration dialog and\n * operational content density. Keep business-specific layouts in each plugin.\n */\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .signin-page,\n  .brush,\n  .cover,\n  .subtitle-workspace,\n  .signin-stat-dialog,\n  .cc-statistics-dialog,\n  .douban-dialog,\n  .maoyan-dialog,\n  .cover-history\n) {\n  color: var(--app-text, #1a2434);\n  font-family: var(--app-font-family, inherit) !important;\n  font-size: var(--app-font-size-body, 14px);\n  font-weight: var(--app-font-weight-regular, 400);\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-field) {\n  min-height: var(--app-control-height, 52px);\n  border-radius: 11px;\n  background: var(--control-surface, var(--app-surface, #fff));\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-field__input) {\n  min-width: 0;\n  min-height: var(--app-control-height, 52px) !important;\n  color: var(--app-text-secondary, #657087);\n  font-size: var(--app-font-size-control, 14px);\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-label.v-field-label) {\n  color: var(--app-text-secondary, #657087);\n  font-size: var(--app-font-size-label, 11px);\n}\n\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .cover-history) {\n  overflow: hidden;\n  border: 1px solid var(--app-border, #dfe4ee) !important;\n  border-radius: 18px !important;\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\n  color: var(--app-text, #202939);\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header,\n  .cover-history > header\n) {\n  min-height: 80px;\n  padding: 18px 20px !important;\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\n  background: var(--app-surface, #fff);\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header,\n  .cover-history > header\n) h2 {\n  margin: 0;\n  color: var(--app-text, #202939);\n  font-size: var(--app-font-size-section-title, 18px) !important;\n  font-weight: var(--app-font-weight-heading, 750) !important;\n  line-height: 1.2;\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header\n) p {\n  margin: 3px 0 0;\n  color: var(--app-text-muted, #7a869d);\n  font-size: var(--app-font-size-helper, 10px) !important;\n  line-height: 1.4;\n}\n\n:where(\n  .signin-stat-dialog__content,\n  .cc-statistics-content,\n  .douban-dialog__content,\n  .maoyan-dialog__content,\n  .cover-history > main\n) {\n  padding: 20px !important;\n}\n\n:where(\n  .signin-stat-dialog__actions,\n  .cc-statistics-actions,\n  .douban-dialog__actions,\n  .maoyan-dialog__actions,\n  .cover-history > footer\n) {\n  min-height: 64px;\n  padding: 13px 18px !important;\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\n  background: var(--app-surface-raised, var(--app-surface, #fff));\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) {\n  gap: 12px !important;\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) > div {\n  min-width: 0;\n  padding: 15px 16px !important;\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\n  border-radius: 12px !important;\n  background: var(--app-surface, #fff);\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) dt,\n:where(.cover-history .metrics) span {\n  color: var(--app-text-muted, #7a869d);\n  font-size: 12px !important;\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics\n) dd,\n:where(.cover-history .metrics) strong {\n  margin-top: 7px;\n  color: var(--app-text, #202939);\n  font-family: inherit !important;\n  font-size: var(--app-font-size-metric, 24px) !important;\n  font-weight: var(--app-font-weight-metric, 700);\n  font-variant-numeric: tabular-nums;\n  line-height: 1.15;\n}\n\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\n.cookie-metric dd > span {\n  color: var(--app-text-muted, #7a869d);\n  font-size: 11px !important;\n  font-weight: var(--app-font-weight-regular, 400);\n}\n\n.signin-stat-results {\n  border-radius: 12px !important;\n}\n\n.signin-stat-results > header {\n  min-height: 44px;\n  padding: 10px 12px !important;\n}\n\n.signin-stat-results article {\n  min-height: 68px;\n  padding: 10px 12px !important;\n}\n\n.signin-stat-results article strong {\n  color: var(--app-text, #202939);\n  font-size: 13px;\n  font-weight: var(--app-font-weight-medium, 650);\n}\n\n.signin-stat-results article p {\n  font-size: 12px !important;\n}\n\n.signin-stat-results :is(article span, time) {\n  font-size: 10px !important;\n}\n\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\n  min-width: 0;\n  color: var(--app-text, #17243a);\n  font-family: var(--app-font-family, inherit) !important;\n  font-size: var(--app-font-size-body, 14px);\n  line-height: 1.5;\n}\n\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\n  font-size: 27px !important;\n  font-weight: 750;\n  line-height: 1.15;\n  letter-spacing: 0;\n}\n\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\n  font-size: var(--app-font-size-section-title, 18px) !important;\n  font-weight: var(--app-font-weight-metric, 700);\n  line-height: 1.3;\n}\n\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\n  min-height: 40px;\n  border-radius: 9px !important;\n  font-size: 13px;\n  letter-spacing: 0;\n}\n\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\n  min-height: 52px;\n  border-radius: 11px;\n  color: var(--app-text-secondary, #657087);\n  font: inherit;\n  font-size: var(--app-font-size-control, 14px);\n}\n\n@media (max-width: 700px) {\n  :where(\n    .signin-stat-dialog__header,\n    .cc-statistics-header,\n    .douban-dialog__header,\n    .maoyan-dialog__header,\n    .cover-history > header,\n    .signin-stat-dialog__content,\n    .cc-statistics-content,\n    .douban-dialog__content,\n    .maoyan-dialog__content,\n    .cover-history > main\n  ) {\n    padding: 16px !important;\n  }\n}\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveComponent = runtime.resolveComponent;
const toDisplayString = runtime.toDisplayString;
const _hoisted_1 = { class: "brush" };
const _hoisted_2 = { class: "brush-head" };
const _hoisted_3 = { class: "brush-actions" };
const _hoisted_4 = ["disabled"];
const _hoisted_5 = ["disabled"];
const _hoisted_6 = { class: "brush-layout" };
const _hoisted_7 = { class: "brush-panel" };
const _hoisted_8 = { class: "brush-list" };
const _hoisted_9 = ["onClick"];
const _hoisted_10 = {
  key: 1,
  class: "brush-empty"
};
const _hoisted_11 = { class: "brush-panel" };
const _hoisted_12 = {
  key: 0,
  class: "brush-form"
};
const _hoisted_13 = { class: "brush-field full" };
const _hoisted_14 = ["value"];
const _hoisted_15 = { class: "brush-field" };
const _hoisted_16 = { class: "brush-field" };
const _hoisted_17 = { class: "brush-field" };
const _hoisted_18 = ["value"];
const _hoisted_19 = { class: "brush-field" };
const _hoisted_20 = ["value"];
const _hoisted_21 = { class: "brush-field" };
const _hoisted_22 = ["value"];
const _hoisted_23 = { class: "brush-field" };
const _hoisted_24 = ["value"];
const _hoisted_25 = { class: "brush-field" };
const _hoisted_26 = ["value"];
const _hoisted_27 = { class: "brush-field" };
const _hoisted_28 = ["value"];
const _hoisted_29 = { class: "brush-field" };
const _hoisted_30 = ["value"];
const _hoisted_31 = { class: "brush-field" };
const _hoisted_32 = ["value"];
const _hoisted_33 = { class: "brush-check" };
const _hoisted_34 = ["checked"];
const _hoisted_35 = { class: "brush-check" };
const _hoisted_36 = ["checked"];
const _hoisted_37 = { class: "brush-actions brush-field full" };
const _hoisted_38 = ["disabled"];
const _hoisted_39 = ["disabled"];
const _hoisted_40 = {
  key: 0,
  class: "brush-preview"
};
const _hoisted_41 = { class: "brush-field full" };
const _hoisted_42 = {
  key: 1,
  class: "brush-empty"
};
const PLUGIN_ID$1 = "brush-flow";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SiteTrafficView",
  props: {
    request: { type: Function }
  },
  setup(__props) {
    const props = __props;
    const sites = ref([]);
    const downloaders = ref([]);
    const tasks = ref([]);
    const config = ref({});
    const selected = ref(null);
    const preview = ref([]);
    const message = ref("");
    const busy = ref(false);
    function errorMessage(error, fallback) {
      return error instanceof Error ? error.message : fallback;
    }
    async function load() {
      busy.value = true;
      try {
        const data = await props.request(`/plugins/${PLUGIN_ID$1}/api/inventory`);
        sites.value = data.sites || [];
        downloaders.value = data.downloaders || [];
        config.value = data.config || {};
        tasks.value = data.tasks || [];
        selected.value = tasks.value.find((task) => task.id === selected.value?.id) || tasks.value[0] || null;
      } catch (error) {
        message.value = errorMessage(error, "读取失败");
      } finally {
        busy.value = false;
      }
    }
    function add() {
      const task = {
        id: `task-${Date.now()}`,
        name: "新刷流任务",
        enabled: true,
        site_id: sites.value[0]?.id || "",
        downloader_id: downloaders.value[0]?.id || "",
        include: "",
        exclude: "",
        min_size: 0,
        max_size: 0,
        max_add: 3,
        save_path: "",
        delete_ratio: 0,
        delete_seed_hours: 0,
        delete_task: false
      };
      tasks.value = [...tasks.value, task];
      selected.value = task;
    }
    function field(key, value) {
      if (!selected.value) return;
      const updated = { ...selected.value, [key]: value };
      selected.value = updated;
      tasks.value = tasks.value.map((task) => task.id === updated.id ? updated : task);
    }
    function inputField(key, event, numeric = false) {
      const value = event.target.value;
      field(key, numeric ? Number(value) : value);
    }
    async function save() {
      busy.value = true;
      try {
        await props.request(`/plugins/${PLUGIN_ID$1}`, { method: "PATCH", body: JSON.stringify({ config: { ...config.value, tasks: tasks.value } }) });
        config.value = { ...config.value, tasks: tasks.value };
        message.value = "刷流任务已保存";
      } catch (error) {
        message.value = errorMessage(error, "保存失败");
      } finally {
        busy.value = false;
      }
    }
    async function run(action = "run") {
      if (!selected.value) return;
      busy.value = true;
      try {
        const data = await props.request(`/plugins/${PLUGIN_ID$1}/api/${action}`, { method: "POST", body: JSON.stringify({ task_id: selected.value.id, ...selected.value }) });
        if (action === "preview") preview.value = data.items || [];
        message.value = action === "preview" ? `匹配 ${data.count || 0} 个候选` : `已添加 ${data.added || 0} 个任务`;
      } catch (error) {
        message.value = errorMessage(error, "执行失败");
      } finally {
        busy.value = false;
      }
    }
    function siteName(task) {
      return sites.value.find((site) => site.id === task.site_id)?.name || "未选择站点";
    }
    onMounted(load);
    return (_ctx, _cache) => {
      const _component_VSelect = resolveComponent("VSelect");
      return openBlock(), createElementBlock("section", _hoisted_1, [
        createElementVNode("header", _hoisted_2, [
          _cache[15] || (_cache[15] = createElementVNode(
            "div",
            null,
            [
              createElementVNode("h1", null, "站点刷流"),
              createElementVNode("p", null, "任务、选种、下载和删种规则集中在同一个工作台。")
            ],
            -1
            /* CACHED */
          )),
          createElementVNode("div", _hoisted_3, [
            createElementVNode("button", {
              class: "ghost",
              disabled: busy.value,
              onClick: load
            }, "刷新", 8, _hoisted_4),
            createElementVNode("button", {
              disabled: busy.value,
              onClick: save
            }, "保存全部", 8, _hoisted_5)
          ])
        ]),
        createElementVNode("div", _hoisted_6, [
          createElementVNode("aside", _hoisted_7, [
            createElementVNode("div", { class: "brush-actions" }, [
              _cache[16] || (_cache[16] = createElementVNode(
                "h2",
                null,
                "流量任务",
                -1
                /* CACHED */
              )),
              createElementVNode("button", {
                class: "ghost",
                onClick: add
              }, "新增")
            ]),
            createElementVNode("div", _hoisted_8, [
              tasks.value.length ? (openBlock(true), createElementBlock(
                Fragment,
                { key: 0 },
                renderList(tasks.value, (task) => {
                  return openBlock(), createElementBlock("article", {
                    key: task.id,
                    class: normalizeClass(["brush-task", { on: selected.value?.id === task.id }]),
                    onClick: ($event) => selected.value = task
                  }, [
                    createElementVNode("div", null, [
                      createElementVNode(
                        "strong",
                        null,
                        toDisplayString(task.name),
                        1
                        /* TEXT */
                      ),
                      createElementVNode(
                        "small",
                        null,
                        toDisplayString(siteName(task)),
                        1
                        /* TEXT */
                      )
                    ]),
                    createElementVNode(
                      "span",
                      null,
                      toDisplayString(task.enabled ? "启用" : "停用"),
                      1
                      /* TEXT */
                    )
                  ], 10, _hoisted_9);
                }),
                128
                /* KEYED_FRAGMENT */
              )) : (openBlock(), createElementBlock("div", _hoisted_10, "还没有流量任务"))
            ])
          ]),
          createElementVNode("main", _hoisted_11, [
            selected.value ? (openBlock(), createElementBlock("div", _hoisted_12, [
              createElementVNode("label", _hoisted_13, [
                _cache[17] || (_cache[17] = createElementVNode(
                  "span",
                  null,
                  "任务名称",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  value: selected.value.name,
                  onInput: _cache[0] || (_cache[0] = ($event) => inputField("name", $event))
                }, null, 40, _hoisted_14)
              ]),
              createElementVNode("div", _hoisted_15, [
                createVNode(_component_VSelect, {
                  label: "PT 站点",
                  "model-value": selected.value.site_id,
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => field("site_id", $event)),
                  items: sites.value.map((item) => ({ value: item.id, title: item.name })),
                  variant: "outlined",
                  density: "comfortable",
                  "hide-details": ""
                }, null, 8, ["model-value", "items"])
              ]),
              createElementVNode("div", _hoisted_16, [
                createVNode(_component_VSelect, {
                  label: "下载器",
                  "model-value": selected.value.downloader_id,
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => field("downloader_id", $event)),
                  items: downloaders.value.map((item) => ({ value: item.id, title: item.name })),
                  variant: "outlined",
                  density: "comfortable",
                  "hide-details": ""
                }, null, 8, ["model-value", "items"])
              ]),
              createElementVNode("label", _hoisted_17, [
                _cache[18] || (_cache[18] = createElementVNode(
                  "span",
                  null,
                  "包含规则（正则）",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  value: selected.value.include,
                  onInput: _cache[3] || (_cache[3] = ($event) => inputField("include", $event))
                }, null, 40, _hoisted_18)
              ]),
              createElementVNode("label", _hoisted_19, [
                _cache[19] || (_cache[19] = createElementVNode(
                  "span",
                  null,
                  "排除规则（正则）",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  value: selected.value.exclude,
                  onInput: _cache[4] || (_cache[4] = ($event) => inputField("exclude", $event))
                }, null, 40, _hoisted_20)
              ]),
              createElementVNode("label", _hoisted_21, [
                _cache[20] || (_cache[20] = createElementVNode(
                  "span",
                  null,
                  "最小体积 GiB",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  type: "number",
                  value: selected.value.min_size,
                  onInput: _cache[5] || (_cache[5] = ($event) => inputField("min_size", $event, true))
                }, null, 40, _hoisted_22)
              ]),
              createElementVNode("label", _hoisted_23, [
                _cache[21] || (_cache[21] = createElementVNode(
                  "span",
                  null,
                  "最大体积 GiB",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  type: "number",
                  value: selected.value.max_size,
                  onInput: _cache[6] || (_cache[6] = ($event) => inputField("max_size", $event, true))
                }, null, 40, _hoisted_24)
              ]),
              createElementVNode("label", _hoisted_25, [
                _cache[22] || (_cache[22] = createElementVNode(
                  "span",
                  null,
                  "单次最多添加",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  type: "number",
                  value: selected.value.max_add,
                  onInput: _cache[7] || (_cache[7] = ($event) => inputField("max_add", $event, true))
                }, null, 40, _hoisted_26)
              ]),
              createElementVNode("label", _hoisted_27, [
                _cache[23] || (_cache[23] = createElementVNode(
                  "span",
                  null,
                  "保存目录",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  value: selected.value.save_path,
                  onInput: _cache[8] || (_cache[8] = ($event) => inputField("save_path", $event))
                }, null, 40, _hoisted_28)
              ]),
              createElementVNode("label", _hoisted_29, [
                _cache[24] || (_cache[24] = createElementVNode(
                  "span",
                  null,
                  "分享率达到后处理",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  type: "number",
                  value: selected.value.delete_ratio,
                  onInput: _cache[9] || (_cache[9] = ($event) => inputField("delete_ratio", $event, true))
                }, null, 40, _hoisted_30)
              ]),
              createElementVNode("label", _hoisted_31, [
                _cache[25] || (_cache[25] = createElementVNode(
                  "span",
                  null,
                  "做种小时达到后处理",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  type: "number",
                  value: selected.value.delete_seed_hours,
                  onInput: _cache[10] || (_cache[10] = ($event) => inputField("delete_seed_hours", $event, true))
                }, null, 40, _hoisted_32)
              ]),
              createElementVNode("label", _hoisted_33, [
                createElementVNode("input", {
                  type: "checkbox",
                  checked: selected.value.enabled,
                  onChange: _cache[11] || (_cache[11] = ($event) => field("enabled", $event.target.checked))
                }, null, 40, _hoisted_34),
                _cache[26] || (_cache[26] = createTextVNode(
                  "启用任务",
                  -1
                  /* CACHED */
                ))
              ]),
              createElementVNode("label", _hoisted_35, [
                createElementVNode("input", {
                  type: "checkbox",
                  checked: selected.value.delete_task,
                  onChange: _cache[12] || (_cache[12] = ($event) => field("delete_task", $event.target.checked))
                }, null, 40, _hoisted_36),
                _cache[27] || (_cache[27] = createTextVNode(
                  "条件满足时删种（否则暂停）",
                  -1
                  /* CACHED */
                ))
              ]),
              createElementVNode("div", _hoisted_37, [
                createElementVNode("button", {
                  class: "ghost",
                  disabled: busy.value,
                  onClick: _cache[13] || (_cache[13] = ($event) => run("preview"))
                }, "预览选种", 8, _hoisted_38),
                createElementVNode("button", {
                  disabled: busy.value,
                  onClick: _cache[14] || (_cache[14] = ($event) => run("run"))
                }, "立即执行", 8, _hoisted_39)
              ]),
              preview.value.length ? (openBlock(), createElementBlock("div", _hoisted_40, [
                (openBlock(true), createElementBlock(
                  Fragment,
                  null,
                  renderList(preview.value.slice(0, 10), (item) => {
                    return openBlock(), createElementBlock(
                      "div",
                      {
                        key: item.title
                      },
                      toDisplayString(item.title),
                      1
                      /* TEXT */
                    );
                  }),
                  128
                  /* KEYED_FRAGMENT */
                ))
              ])) : createCommentVNode("v-if", true),
              createElementVNode(
                "p",
                _hoisted_41,
                toDisplayString(message.value),
                1
                /* TEXT */
              )
            ])) : (openBlock(), createElementBlock("div", _hoisted_42, "选择或新建一个任务"))
          ])
        ])
      ]);
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const SiteTrafficView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-74820f41"]]);
const PLUGIN_ID = "brush-flow";
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const Page = defineComponent2({
    name: "SiteTrafficPage",
    setup() {
      return () => h(SiteTrafficView, {
        request: (path, init) => sdk.request(path, init)
      });
    }
  });
  sdk.registerPage({ pluginId: PLUGIN_ID, route: `plugin-${PLUGIN_ID}`, title: "站点刷流", icon: "mdi-water-sync", section: "tools", order: 74, component: Page });
}
export {
  install
};
