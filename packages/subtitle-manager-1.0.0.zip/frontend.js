if (typeof document !== "undefined") { const id = "subtitle_manager"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.subtitle-workspace{width:100%;min-width:0;color:#17243a}.subtitle-workspace *{box-sizing:border-box}.subtitle-hero{display:flex;justify-content:space-between;gap:20px;align-items:center;padding:24px 26px;border:1px solid rgba(137,156,185,.22);border-radius:24px;background:linear-gradient(135deg,rgba(47,116,246,.1),rgba(255,255,255,.94) 58%);box-shadow:0 18px 42px rgba(37,61,99,.07)}.subtitle-hero h1{margin:3px 0 6px;font-size:clamp(25px,3vw,36px)}.subtitle-hero p{margin:0;color:#71809a}.subtitle-kicker{font-size:12px;font-weight:800;letter-spacing:.12em;color:#2f74f6}.subtitle-controls{display:flex;gap:10px;align-items:center}.subtitle-search{width:min(390px,48vw);min-height:42px;padding:0 14px;border:1px solid #d7dfec;border-radius:13px;background:#fff;color:#22324b;outline:none}.subtitle-search:focus{border-color:#2f74f6;box-shadow:0 0 0 3px rgba(47,116,246,.12)}.subtitle-layout{display:grid;grid-template-columns:minmax(300px,.85fr) minmax(0,1.55fr);gap:18px;margin-top:18px}.subtitle-panel{min-width:0;padding:20px;border:1px solid rgba(137,156,185,.22);border-radius:22px;background:rgba(255,255,255,.9);box-shadow:0 16px 38px rgba(37,61,99,.06)}.subtitle-panel h2{margin:0 0 4px;font-size:18px}.subtitle-panel-note{margin:0 0 16px;color:#7a879c;font-size:13px}.subtitle-list{display:grid;gap:9px;max-height:620px;overflow:auto}.subtitle-media{width:100%;display:grid;grid-template-columns:5px minmax(0,1fr) auto;gap:12px;align-items:center;padding:12px;border:1px solid transparent;border-radius:15px;background:#f7f9fc;text-align:left;cursor:pointer}.subtitle-media:hover,.subtitle-media.is-active{border-color:rgba(47,116,246,.25);background:#f1f6ff}.subtitle-rail{align-self:stretch;border-radius:8px;background:#cfd8e7}.subtitle-media.is-active .subtitle-rail{background:#2f74f6}.subtitle-media strong,.subtitle-media small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.subtitle-media small{margin-top:4px;color:#8591a5}.subtitle-count{padding:4px 8px;border-radius:999px;background:#e8eef8;color:#60708a;font-size:12px}.subtitle-detail{display:grid;gap:16px}.subtitle-path{padding:13px 15px;border-radius:14px;background:#f4f7fb;color:#66758d;word-break:break-all}.subtitle-timeline{position:relative;display:grid;gap:12px;padding-left:20px}.subtitle-timeline:before{content:\"\";position:absolute;left:5px;top:5px;bottom:5px;width:2px;background:#dce5f2}.subtitle-file{position:relative;display:flex;justify-content:space-between;gap:16px;padding:12px 14px;border-radius:14px;background:#f8fafc}.subtitle-file:before{content:\"\";position:absolute;left:-19px;top:18px;width:10px;height:10px;border:2px solid #fff;border-radius:50%;background:#2f74f6;box-shadow:0 0 0 2px rgba(47,116,246,.18)}.subtitle-file small{color:#8692a6}.subtitle-empty{display:grid;place-items:center;min-height:190px;color:#8995a8;text-align:center}.subtitle-upload{display:grid;grid-template-columns:minmax(0,1fr) 160px auto;gap:10px;padding-top:16px;border-top:1px solid #e5eaf2}.subtitle-upload input,.subtitle-upload select{min-width:0;min-height:42px;padding:0 12px;border:1px solid #d7dfec;border-radius:12px;background:#fff}.subtitle-button{min-height:42px;padding:0 16px;border:0;border-radius:12px;background:#2f74f6;color:#fff;font-weight:750;cursor:pointer}.subtitle-button:disabled{cursor:not-allowed;opacity:.45}.subtitle-status{min-height:22px;margin:0;color:#63728a}.subtitle-status.is-error{color:#d04444}@media(max-width:900px){.subtitle-layout{grid-template-columns:1fr}.subtitle-list{max-height:340px}}@media(max-width:620px){.subtitle-hero{align-items:stretch;flex-direction:column}.subtitle-controls{align-items:stretch;flex-direction:column}.subtitle-search{width:100%}.subtitle-upload{grid-template-columns:1fr}.subtitle-panel{padding:16px}.subtitle-file{flex-wrap:wrap;gap:8px}.subtitle-file strong{flex-basis:100%}}\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const toDisplayString = runtime.toDisplayString;
const _hoisted_1 = { class: "subtitle-workspace" };
const _hoisted_2 = { class: "subtitle-hero" };
const _hoisted_3 = { class: "subtitle-controls" };
const _hoisted_4 = ["value"];
const _hoisted_5 = ["disabled"];
const _hoisted_6 = { class: "subtitle-layout" };
const _hoisted_7 = { class: "subtitle-panel" };
const _hoisted_8 = { class: "subtitle-list" };
const _hoisted_9 = ["onClick"];
const _hoisted_10 = { class: "subtitle-count" };
const _hoisted_11 = {
  key: 0,
  class: "subtitle-empty"
};
const _hoisted_12 = {
  key: 0,
  class: "subtitle-panel subtitle-detail"
};
const _hoisted_13 = { class: "subtitle-path" };
const _hoisted_14 = { class: "subtitle-timeline" };
const _hoisted_15 = ["onClick"];
const _hoisted_16 = ["onClick"];
const _hoisted_17 = {
  key: 0,
  class: "subtitle-file"
};
const _hoisted_18 = ["disabled"];
const _hoisted_19 = {
  key: 0,
  class: "subtitle-timeline"
};
const _hoisted_20 = ["href"];
const _hoisted_21 = { class: "subtitle-upload" };
const _hoisted_22 = ["value"];
const _hoisted_23 = ["value"];
const _hoisted_24 = ["disabled"];
const _hoisted_25 = {
  key: 1,
  class: "subtitle-panel subtitle-detail"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SubtitleWorkspacePage",
  props: {
    request: { type: Function }
  },
  setup(__props) {
    const props = __props;
    const items = ref([]);
    const selected = ref(null);
    const query = ref("");
    const loading = ref(false);
    const uploading = ref(false);
    const status = ref("");
    const error = ref("");
    const language = ref("zh-CN");
    const file = ref(null);
    const online = ref([]);
    const searching = ref(false);
    const languages = [["zh-CN", "简体中文"], ["zh-TW", "繁体中文"], ["zh", "中文"], ["en", "英语"], ["ja", "日语"], ["ko", "韩语"]];
    async function load() {
      loading.value = true;
      error.value = "";
      try {
        const result = await props.request(`/plugins/subtitle-manager/api/catalog?query=${encodeURIComponent(query.value)}&limit=100`);
        items.value = Array.isArray(result?.items) ? result.items : [];
        selected.value = items.value.find((item) => item.path === selected.value?.path) || items.value[0] || null;
        status.value = items.value.length ? `已读取 ${items.value.length} 个本地媒体文件` : "没有找到可访问的本地整理记录";
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "字幕目录读取失败";
      } finally {
        loading.value = false;
      }
    }
    async function upload() {
      if (!selected.value || !file.value || uploading.value) return;
      uploading.value = true;
      error.value = "";
      try {
        const params = new URLSearchParams({ media_path: selected.value.path, language: language.value });
        await props.request(`/plugins/subtitle-manager/api/upload?${params}`, {
          method: "POST",
          headers: { "Content-Type": file.value.type || "application/octet-stream", "X-Plugin-Filename": encodeURIComponent(file.value.name) },
          body: file.value
        });
        status.value = `已写入 ${file.value.name}`;
        file.value = null;
        await load();
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "字幕上传失败";
      } finally {
        uploading.value = false;
      }
    }
    async function searchOnline() {
      if (!selected.value || searching.value) return;
      searching.value = true;
      error.value = "";
      try {
        const keyword = selected.value.title || selected.value.path.split(/[\\/]/).pop()?.replace(/\.[^.]+$/, "") || "";
        const result = await props.request(`/plugins/subtitle-manager/api/online?query=${encodeURIComponent(keyword)}`);
        online.value = Array.isArray(result?.items) ? result.items : [];
        status.value = online.value.length ? `找到 ${online.value.length} 条在线字幕` : "在线字幕源暂无匹配结果";
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "在线字幕搜索失败";
      } finally {
        searching.value = false;
      }
    }
    async function removeSubtitle(subtitle) {
      if (!selected.value || !window.confirm(`确定删除字幕 ${subtitle.name}？`)) return;
      try {
        await props.request("/plugins/subtitle-manager/api/delete", { method: "POST", body: JSON.stringify({ media_path: selected.value.path, subtitle_name: subtitle.name }) });
        status.value = `已删除 ${subtitle.name}`;
        await load();
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "字幕删除失败";
      }
    }
    async function adjustSubtitle(subtitle) {
      if (!selected.value) return;
      const value = window.prompt("输入字幕偏移秒数：正数延后，负数提前", "0");
      if (value === null || !value.trim()) return;
      const offset = Number(value);
      if (!Number.isFinite(offset)) {
        error.value = "请输入有效的时间偏移秒数";
        return;
      }
      try {
        const result = await props.request("/plugins/subtitle-manager/api/adjust", {
          method: "POST",
          body: JSON.stringify({ media_path: selected.value.path, subtitle_name: subtitle.name, offset_seconds: offset })
        });
        status.value = `已调整 ${result.adjusted_count || 0} 条字幕时间轴`;
        await load();
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "字幕调轴失败";
      }
    }
    function mediaName(item) {
      return item.title || item.path.split(/[\\/]/).pop();
    }
    function chooseFile(event) {
      file.value = event.currentTarget.files?.[0] || null;
    }
    function chooseLanguage(event) {
      language.value = event.currentTarget.value;
    }
    function searchOnEnter(event) {
      if (event.key === "Enter") load();
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("section", _hoisted_1, [
        createElementVNode("header", _hoisted_2, [
          _cache[1] || (_cache[1] = createElementVNode(
            "div",
            null,
            [
              createElementVNode("div", { class: "subtitle-kicker" }, "SUBTITLE WORKSPACE"),
              createElementVNode("h1", null, "字幕管理助手"),
              createElementVNode("p", null, "在线搜索、手动上传、同名匹配与外挂字幕管理。")
            ],
            -1
            /* CACHED */
          )),
          createElementVNode("div", _hoisted_3, [
            createElementVNode("input", {
              class: "subtitle-search",
              value: query.value,
              placeholder: "搜索媒体名称或路径",
              onInput: _cache[0] || (_cache[0] = ($event) => query.value = $event.currentTarget.value),
              onKeyup: searchOnEnter
            }, null, 40, _hoisted_4),
            createElementVNode("button", {
              class: "subtitle-button",
              disabled: loading.value,
              onClick: load
            }, toDisplayString(loading.value ? "读取中…" : "搜索"), 9, _hoisted_5)
          ])
        ]),
        createElementVNode("div", _hoisted_6, [
          createElementVNode("aside", _hoisted_7, [
            _cache[3] || (_cache[3] = createElementVNode(
              "h2",
              null,
              "媒体目录",
              -1
              /* CACHED */
            )),
            _cache[4] || (_cache[4] = createElementVNode(
              "p",
              { class: "subtitle-panel-note" },
              "仅显示整理成功且当前可访问的本地媒体文件。",
              -1
              /* CACHED */
            )),
            createElementVNode("div", _hoisted_8, [
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(items.value, (item) => {
                  return openBlock(), createElementBlock("button", {
                    key: item.path,
                    class: normalizeClass(["subtitle-media", selected.value?.path === item.path && "is-active"]),
                    onClick: ($event) => selected.value = item
                  }, [
                    _cache[2] || (_cache[2] = createElementVNode(
                      "span",
                      { class: "subtitle-rail" },
                      null,
                      -1
                      /* CACHED */
                    )),
                    createElementVNode("span", null, [
                      createElementVNode(
                        "strong",
                        null,
                        toDisplayString(mediaName(item)),
                        1
                        /* TEXT */
                      ),
                      createElementVNode(
                        "small",
                        null,
                        toDisplayString(item.path),
                        1
                        /* TEXT */
                      )
                    ]),
                    createElementVNode(
                      "span",
                      _hoisted_10,
                      toDisplayString(item.subtitles?.length || 0) + " 条",
                      1
                      /* TEXT */
                    )
                  ], 10, _hoisted_9);
                }),
                128
                /* KEYED_FRAGMENT */
              )),
              !items.value.length ? (openBlock(), createElementBlock(
                "div",
                _hoisted_11,
                toDisplayString(loading.value ? "正在读取媒体目录…" : "暂无可管理媒体"),
                1
                /* TEXT */
              )) : createCommentVNode("v-if", true)
            ])
          ]),
          selected.value ? (openBlock(), createElementBlock("main", _hoisted_12, [
            createElementVNode("div", null, [
              createElementVNode(
                "h2",
                null,
                toDisplayString(selected.value.title || "字幕详情"),
                1
                /* TEXT */
              ),
              createElementVNode(
                "p",
                _hoisted_13,
                toDisplayString(selected.value.path),
                1
                /* TEXT */
              )
            ]),
            createElementVNode("div", _hoisted_14, [
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(selected.value.subtitles, (subtitle) => {
                  return openBlock(), createElementBlock("div", {
                    key: subtitle.name,
                    class: "subtitle-file"
                  }, [
                    createElementVNode(
                      "strong",
                      null,
                      toDisplayString(subtitle.name),
                      1
                      /* TEXT */
                    ),
                    createElementVNode(
                      "small",
                      null,
                      toDisplayString(Math.max(1, Math.round((subtitle.size || 0) / 1024))) + " KB",
                      1
                      /* TEXT */
                    ),
                    createElementVNode("button", {
                      class: "subtitle-button",
                      onClick: ($event) => adjustSubtitle(subtitle)
                    }, "调轴", 8, _hoisted_15),
                    createElementVNode("button", {
                      class: "subtitle-button",
                      onClick: ($event) => removeSubtitle(subtitle)
                    }, "删除", 8, _hoisted_16)
                  ]);
                }),
                128
                /* KEYED_FRAGMENT */
              )),
              !selected.value.subtitles?.length ? (openBlock(), createElementBlock("div", _hoisted_17, [..._cache[5] || (_cache[5] = [
                createElementVNode(
                  "span",
                  null,
                  "尚未发现外挂字幕",
                  -1
                  /* CACHED */
                ),
                createElementVNode(
                  "small",
                  null,
                  "可在线搜索或手动上传",
                  -1
                  /* CACHED */
                )
              ])])) : createCommentVNode("v-if", true)
            ]),
            createElementVNode("div", null, [
              createElementVNode("button", {
                class: "subtitle-button",
                disabled: searching.value,
                onClick: searchOnline
              }, toDisplayString(searching.value ? "搜索中…" : "在线搜索字幕"), 9, _hoisted_18)
            ]),
            online.value.length ? (openBlock(), createElementBlock("div", _hoisted_19, [
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(online.value.slice(0, 20), (item) => {
                  return openBlock(), createElementBlock("div", {
                    key: `${item.provider}:${item.title}:${item.url || ""}`,
                    class: "subtitle-file"
                  }, [
                    createElementVNode("a", {
                      href: item.url || "#",
                      target: "_blank",
                      rel: "noopener noreferrer"
                    }, toDisplayString(item.title), 9, _hoisted_20),
                    createElementVNode(
                      "small",
                      null,
                      toDisplayString(item.provider) + toDisplayString(item.language ? ` · ${item.language}` : ""),
                      1
                      /* TEXT */
                    )
                  ]);
                }),
                128
                /* KEYED_FRAGMENT */
              ))
            ])) : createCommentVNode("v-if", true),
            createElementVNode(
              "p",
              {
                class: normalizeClass(["subtitle-status", error.value && "is-error"])
              },
              toDisplayString(error.value || status.value),
              3
              /* TEXT, CLASS */
            ),
            createElementVNode("div", _hoisted_21, [
              createElementVNode(
                "input",
                {
                  type: "file",
                  accept: ".srt,.ass,.ssa,.sub,.vtt,.webvtt",
                  onChange: chooseFile
                },
                null,
                32
                /* NEED_HYDRATION */
              ),
              createElementVNode("select", {
                value: language.value,
                onChange: chooseLanguage
              }, [
                (openBlock(), createElementBlock(
                  Fragment,
                  null,
                  renderList(languages, (option) => {
                    return createElementVNode("option", {
                      key: option[0],
                      value: option[0]
                    }, toDisplayString(option[1]), 9, _hoisted_23);
                  }),
                  64
                  /* STABLE_FRAGMENT */
                ))
              ], 40, _hoisted_22),
              createElementVNode("button", {
                class: "subtitle-button",
                disabled: !file.value || uploading.value,
                onClick: upload
              }, toDisplayString(uploading.value ? "上传中…" : "上传字幕"), 9, _hoisted_24)
            ])
          ])) : (openBlock(), createElementBlock("main", _hoisted_25, [..._cache[6] || (_cache[6] = [
            createElementVNode(
              "div",
              { class: "subtitle-empty" },
              "请先从左侧选择媒体",
              -1
              /* CACHED */
            )
          ])]))
        ])
      ]);
    };
  }
});
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const Page = defineComponent2({
    name: "SubtitleWorkspacePage",
    inheritAttrs: false,
    setup() {
      return () => h(_sfc_main, {
        request: (path, init) => sdk.request(path, init)
      });
    }
  });
  sdk.registerPage({ pluginId: "subtitle-manager", route: "plugin-subtitle-manager", title: "字幕大师", icon: "mdi-subtitles-outline", section: "tools", order: 65, component: Page });
}
export {
  install
};
