if (typeof document !== "undefined") { const id = "cloud_copy"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.copy-statistics[data-v-965eae6d]{display:flex;flex-direction:column;max-height:calc(100dvh - 32px);overflow:hidden;border-radius:18px!important;background:var(--app-dialog-surface,#fff);color:var(--app-text,#1a2434);font-family:var(--app-font-family,inherit);font-size:var(--app-font-size-body,14px)}header[data-v-965eae6d]{display:flex;align-items:center;justify-content:space-between;flex:none;height:var(--app-plugin-dialog-header-height,58px);padding:0 24px;border-bottom:1px solid var(--app-border-subtle,#e0e6ef)}h2[data-v-965eae6d]{margin:0;font-size:var(--app-font-size-title,18px)}main[data-v-965eae6d]{padding:24px;overflow:auto;min-height:0}.metrics[data-v-965eae6d]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.metrics article[data-v-965eae6d]{border:1px solid var(--app-border-subtle);border-radius:12px;padding:15px 16px;background:var(--app-surface-muted)}.metrics span[data-v-965eae6d],.muted[data-v-965eae6d],.pagination[data-v-965eae6d]{font-size:12px;color:var(--app-text-muted,#73819a)}.metrics strong[data-v-965eae6d]{display:block;margin-top:10px;font-size:24px;font-weight:600;font-variant-numeric:tabular-nums}.heading[data-v-965eae6d]{display:flex;align-items:center;gap:12px;margin:22px 0 16px}h3[data-v-965eae6d]{margin:0;font-size:14px}.push[data-v-965eae6d]{margin-left:auto}.filters[data-v-965eae6d]{display:grid;grid-template-columns:2fr 1fr 1fr;gap:12px;margin-bottom:16px}.table-scroll[data-v-965eae6d]{overflow-x:auto;border:1px solid var(--app-border-subtle,#e0e6ef);border-radius:10px}table[data-v-965eae6d]{width:100%;min-width:820px;border-collapse:collapse;table-layout:fixed;text-align:left}td[data-v-965eae6d],th[data-v-965eae6d]{padding:12px 14px;border-bottom:1px solid var(--app-border-subtle,#e0e6ef);font-size:12px}th[data-v-965eae6d]{background:var(--app-surface-subtle,#f5f7fb);white-space:nowrap}td[data-v-965eae6d]{height:68px}tbody tr:last-child td[data-v-965eae6d]{border-bottom:0}.file[data-v-965eae6d],.path[data-v-965eae6d],.cell-name[data-v-965eae6d]{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.file[data-v-965eae6d]{font-weight:500;font-size:13px}.path[data-v-965eae6d]{margin-top:7px;color:var(--app-text-muted);font-size:11px}.pill[data-v-965eae6d]{display:inline-block;border-radius:20px;padding:4px 9px;font-size:11px;white-space:nowrap}.saved[data-v-965eae6d]{background:var(--app-success-soft);color:var(--app-success-text)}.attention[data-v-965eae6d]{background:var(--app-warning-soft,#fff4df);color:var(--app-warning-text,#a87821)}.waiting[data-v-965eae6d]{background:var(--app-primary-soft,#edf3ff);color:rgb(var(--v-theme-primary,41,104,255))}.skipped[data-v-965eae6d]{background:var(--app-surface-muted);color:var(--app-text-secondary)}.detail[data-v-965eae6d]{white-space:normal;overflow-wrap:anywhere}.detail span[data-v-965eae6d]{margin-right:16px}.empty[data-v-965eae6d]{text-align:center;padding:45px 16px;color:var(--app-text-muted,#73819a)}.empty h3[data-v-965eae6d]{margin-top:14px}.empty p[data-v-965eae6d]{margin:12px 0}.pagination[data-v-965eae6d]{display:flex;align-items:center;justify-content:space-between;margin-top:12px}.pagination>div[data-v-965eae6d]{display:flex;align-items:center;gap:8px}footer[data-v-965eae6d]{display:flex;align-items:center;justify-content:space-between;flex:none;padding:10px 20px;border-top:1px solid var(--app-border-subtle,#e0e6ef)}.error[data-v-965eae6d]{color:var(--app-danger-text,#c62828);margin:0 0 16px}@media(max-width:760px){.metrics[data-v-965eae6d]{grid-template-columns:repeat(2,minmax(0,1fr))}main[data-v-965eae6d]{padding:16px}header[data-v-965eae6d]{padding:0 16px}.heading[data-v-965eae6d]{gap:5px;flex-wrap:wrap}.heading .muted[data-v-965eae6d]{display:none}.filters[data-v-965eae6d]{grid-template-columns:1fr 1fr}.filters[data-v-965eae6d]>:first-child{grid-column:1/-1}}\r\n\n.copy-path-tooltip{color:var(--app-text)!important;background:var(--app-dialog-surface,var(--app-surface))!important}\n.copy-browser[data-v-788e96a3]{min-height:0;overflow:hidden;min-width:0;display:flex;flex-direction:column;background:var(--app-surface,#fff)}\n.browser-select[data-v-788e96a3]{flex-shrink:0;padding:18px}.browser-path[data-v-788e96a3],.browser-search[data-v-788e96a3]{flex-shrink:0;display:flex;gap:10px;align-items:center;padding:10px 18px;border-bottom:1px solid var(--app-border,#e2e8f0)}\n.browser-crumbs[data-v-788e96a3]{min-width:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:13px;color:var(--app-text-secondary,#738198)}\n.browser-crumbs button[data-v-788e96a3]{font:inherit}.browser-crumbs button[aria-current=page][data-v-788e96a3]{opacity:1;color:var(--app-text-secondary)}.crumb-divider[data-v-788e96a3]{color:var(--app-text-secondary)}\nbutton[data-v-788e96a3]{color:var(--app-text);cursor:pointer}button[data-v-788e96a3]:disabled{opacity:.4;cursor:default}button[data-v-788e96a3]:focus-visible,input[data-v-788e96a3]:focus-visible{outline:2px solid #2b6dff;outline-offset:2px}\n.browser-search input[data-v-788e96a3]{color:var(--app-text);min-width:0;flex:1;outline:none;font-size:13px}.browser-search button[data-v-788e96a3]{font-size:13px}.browser-search input[data-v-788e96a3]::placeholder{color:var(--app-text-secondary)!important;opacity:1!important}.browser-file>.v-icon[data-v-788e96a3]{color:var(--app-text-secondary)}\n.browser-files[data-v-788e96a3]{flex:1;min-height:0;overflow:auto;padding:8px}.browser-file[data-v-788e96a3]{display:flex;align-items:center;gap:10px;padding:11px 10px;border-radius:8px}.browser-file.selected[data-v-788e96a3]{background:var(--app-surface-selected,#edf3ff);color:var(--app-text)}.browser-file input[type=checkbox][data-v-788e96a3]{appearance:none;-webkit-appearance:none;width:18px;height:18px;flex-shrink:0;margin:0;border:2px solid var(--app-text-secondary);border-radius:5px;background:transparent;cursor:pointer}.browser-file input[type=checkbox][data-v-788e96a3]:checked{border-color:var(--blue);background-color:var(--blue);background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath d='m3 8 3 3 7-7' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E\");background-size:100% 100%}.browser-file input[type=checkbox][data-v-788e96a3]:disabled{opacity:.5;cursor:default}.file-name[data-v-788e96a3]{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left;font-size:14px}.browser-file small[data-v-788e96a3]{color:var(--app-text-secondary,#738198);font-size:11px;white-space:nowrap}.browser-empty[data-v-788e96a3]{padding:60px 18px;text-align:center;color:var(--app-text-secondary,#738198);font-size:13px}.browser-more[data-v-788e96a3]{width:100%;padding:12px;font-size:13px}footer[data-v-788e96a3]{flex-shrink:0;padding:12px 18px;border-top:1px solid var(--app-border,#e2e8f0);font-size:12px;color:var(--app-text-secondary,#738198)}p[role=alert][data-v-788e96a3]{color:var(--app-danger-text,#bd3333);padding:8px 18px;font-size:13px}\n@media(max-width:700px){footer[data-v-788e96a3]{display:none}.browser-select[data-v-788e96a3]{padding:14px 12px}.browser-path[data-v-788e96a3],.browser-search[data-v-788e96a3]{padding:4px 10px}.browser-empty[data-v-788e96a3]{padding:12px 10px}footer[data-v-788e96a3]{padding:4px 10px}}\r\n\n.app-workspace:has(.copy-workspace){min-height:0}\n.copy-workspace[data-v-564fb17e]{display:flex;flex-direction:column;min-height:0;overflow:hidden;color:var(--app-text,#1d2939);max-width:1600px;margin:auto}.copy-workspace>header[data-v-564fb17e]{flex-shrink:0;display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}.copy-workspace h2[data-v-564fb17e]{color:var(--blue,#2b6dff);font-size:22px;font-weight:700}.copy-workspace header span[data-v-564fb17e]{font-size:13px;color:var(--app-text-secondary,#738198)}.copy-workbench[data-v-564fb17e],.copy-batches[data-v-564fb17e]{border:1px solid var(--app-border,#e2e8f0);border-radius:14px;background:var(--app-surface,#fff);overflow:hidden}.copy-workbench[data-v-564fb17e]{display:flex;flex-direction:column;flex:1;min-height:0}.copy-browsers[data-v-564fb17e]{flex:1;min-height:0;overflow:hidden;display:grid;grid-template-columns:1fr 1fr}.copy-browsers[data-v-564fb17e]>:first-child{border-right:1px solid var(--app-border,#e2e8f0)}.copy-controls[data-v-564fb17e]{flex-shrink:0;display:grid;grid-template-columns:1.5fr 1fr 1fr auto;align-items:center;gap:14px;padding:20px;border-top:1px solid var(--app-border,#e2e8f0)}.workspace-actions[data-v-564fb17e]{display:flex;align-items:center;gap:6px}.copy-batches[data-v-564fb17e]{margin:0;color:var(--app-text,#1d2939)}.records-header[data-v-564fb17e]{display:flex;align-items:center;justify-content:space-between;padding:18px 24px;border-bottom:1px solid var(--app-border,#e2e8f0)}.records-header h2[data-v-564fb17e]{font-size:20px;font-weight:700}.records-body[data-v-564fb17e]{max-height:70vh;overflow:auto}.records-body table[data-v-564fb17e]{min-width:720px}.copy-batches>h3[data-v-564fb17e]{padding:18px 20px;border-bottom:1px solid var(--app-border,#e2e8f0);font-size:16px}.batch-empty[data-v-564fb17e]{padding:36px;text-align:center;color:var(--app-text-secondary,#738198)}.batch-table[data-v-564fb17e]{overflow:auto}table[data-v-564fb17e]{table-layout:fixed;width:100%;border-collapse:collapse;text-align:left;font-size:13px}th[data-v-564fb17e],td[data-v-564fb17e]{overflow:hidden;text-overflow:ellipsis;padding:12px 20px;border-bottom:1px solid var(--app-border,#e2e8f0)}th[data-v-564fb17e]{font-weight:500;color:var(--app-text-secondary,#738198)}.batch-name[data-v-564fb17e]{display:block;max-width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}td small[data-v-564fb17e]{display:block;color:var(--app-text-secondary,#738198)}.workspace-error[data-v-564fb17e]{color:var(--app-danger-text,#bd3333);margin-bottom:14px}.workspace-message[data-v-564fb17e]{color:var(--app-success-text,#148754);margin-bottom:14px}.batch-detail[data-v-564fb17e]{padding:18px 20px}.batch-detail>div[data-v-564fb17e]:first-child{display:flex;justify-content:space-between;align-items:center}.batch-record[data-v-564fb17e]{display:flex;gap:20px;padding:10px 0;border-bottom:1px solid var(--app-border,#e2e8f0);font-size:13px}.batch-record>span[data-v-564fb17e]:first-child{flex:1;overflow-wrap:anywhere}\n.workspace-actions[data-v-564fb17e] .v-btn{color:var(--app-text)}\n.copy-workspace[data-v-564fb17e] .v-field-label{color:var(--app-text-secondary)!important}\n.copy-workspace[data-v-564fb17e] .v-field__input{color:var(--app-text)}\n.copy-workspace[data-v-564fb17e] .v-field__append-inner{color:var(--app-text-secondary);opacity:1}\n.copy-submit[data-v-564fb17e]{border-radius:var(--app-control-radius,11px)!important}\n@media(max-width:1000px){.copy-controls[data-v-564fb17e]{grid-template-columns:1fr 1fr}}@media(max-width:700px){.copy-browsers[data-v-564fb17e]{grid-template-columns:1fr;grid-template-rows:repeat(2,minmax(0,1fr))}.copy-browsers[data-v-564fb17e]>:first-child{border-right:0;border-bottom:1px solid var(--app-border,#e2e8f0)}.copy-controls[data-v-564fb17e]{grid-template-columns:1fr 1fr;padding:10px;gap:10px}.copy-workspace>header[data-v-564fb17e]{align-items:flex-start;flex-wrap:wrap;gap:10px}.workspace-actions[data-v-564fb17e]{margin-left:auto}th[data-v-564fb17e],td[data-v-564fb17e]{padding:10px;white-space:nowrap}}\r\n\n.mobile-copy-tabs[data-v-564fb17e],.mobile-copy-footer[data-v-564fb17e]{display:none}.mobile-settings-fields[data-v-564fb17e]{display:grid;gap:20px;padding:24px 20px}.mobile-copy-settings>footer[data-v-564fb17e]{display:flex;justify-content:flex-end;padding:12px 20px;border-top:1px solid var(--app-border)}\n@media(max-width:700px){\n.copy-workspace>header>div[data-v-564fb17e]:first-child{display:none}.copy-workspace>header[data-v-564fb17e]{margin-bottom:10px;justify-content:flex-end}.workspace-actions[data-v-564fb17e]{gap:0}\n.copy-browsers[data-v-564fb17e]{grid-template-rows:minmax(0,1fr)}.copy-browsers>.is-mobile-hidden[data-v-564fb17e]{display:none}.copy-browsers[data-v-564fb17e]>:first-child{border:0}.copy-controls[data-v-564fb17e]{display:none}\n.mobile-copy-tabs[data-v-564fb17e]{display:flex;flex-shrink:0;border-bottom:1px solid var(--app-border);padding:0 12px;gap:20px}.mobile-copy-tabs button[data-v-564fb17e]{position:relative;flex:1;padding:13px 4px;color:var(--app-text-secondary);font-size:14px;font-weight:600}.mobile-copy-tabs button[aria-selected=true][data-v-564fb17e]{color:var(--blue);box-shadow:inset 0 -2px var(--blue)}.mobile-copy-tabs span[data-v-564fb17e]{margin-left:8px;font-size:12px}\n.mobile-copy-footer[data-v-564fb17e]{display:block;flex-shrink:0;border-top:1px solid var(--app-border);padding:10px 12px}.mobile-copy-summary[data-v-564fb17e]{display:flex;align-items:center;gap:12px;margin-bottom:10px;font-size:12px;color:var(--app-text-secondary)}.mobile-copy-summary>span[data-v-564fb17e]{flex-shrink:0}.mobile-copy-summary button[data-v-564fb17e]{display:flex;align-items:center;justify-content:flex-end;gap:3px;min-width:0;flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;text-align:right;color:var(--app-text)}.mobile-copy-actions[data-v-564fb17e]{display:grid;grid-template-columns:1fr 1.3fr;gap:12px}.mobile-copy-actions .copy-submit[data-v-564fb17e]{min-height:42px}\n}\r\n\n@media(max-width:700px){\n.mobile-copy-footer[data-v-564fb17e]{padding:0}.mobile-target-row[data-v-564fb17e]{display:flex;align-items:center;gap:12px;width:100%;min-height:42px;padding:10px 14px;border-bottom:1px solid var(--app-border);color:var(--app-text);text-align:left;font-size:12px}.mobile-target-row>span[data-v-564fb17e]{flex-shrink:0;color:var(--app-text-secondary)}.mobile-target-row strong[data-v-564fb17e]{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:400}.mobile-target-row>.v-icon[data-v-564fb17e]{flex-shrink:0;color:var(--app-text-secondary)}\n.mobile-copy-actions[data-v-564fb17e]{grid-template-columns:36px minmax(0,1fr) 124px;align-items:center;gap:10px;padding:10px 12px}.mobile-settings-trigger[data-v-564fb17e]{width:36px!important;height:36px!important;color:var(--app-text)!important}.mobile-selected-count[data-v-564fb17e]{color:var(--app-text-secondary);font-size:12px}.mobile-copy-actions .copy-submit[data-v-564fb17e]{font-size:14px}\n}\r\n\n.copy-config[data-v-d8a6eaaa]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px 16px}\n.copy-config-sidebar[data-v-d8a6eaaa],.copy-config>p[data-v-d8a6eaaa]{grid-column:1/-1}\n.copy-config-trigger[data-v-d8a6eaaa]{display:contents}\n.copy-config>p[data-v-d8a6eaaa]{color:var(--app-danger-text)}\n@media(max-width:600px){.copy-config[data-v-d8a6eaaa]{grid-template-columns:1fr}}\r\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\r\n * Values mirror the host application's standard configuration dialog and\r\n * operational content density. Keep business-specific layouts in each plugin.\r\n */\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .signin-page,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace,\r\n  .signin-stat-dialog,\r\n  .cc-statistics-dialog,\r\n  .douban-dialog,\r\n  .maoyan-dialog,\r\n  .cover-history\r\n) {\r\n  color: var(--app-text, #1a2434);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field) {\r\n  min-height: var(--app-control-height, 52px);\r\n  border-radius: var(--app-control-radius, 11px);\r\n  background: var(--control-surface, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field__input) {\r\n  min-width: 0;\r\n  min-height: var(--app-control-height, 52px) !important;\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-label.v-field-label) {\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-label, 11px);\r\n}\r\n\r\n/* Custom plugin editors render Vuetify switches directly instead of through\r\n * the host's InlineSwitchRow. Pin their copy to the host's compact form-label\r\n * treatment so Vuetify's larger body label cannot change the visual scale. */\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-switch, .v-checkbox, .v-radio) .v-label {\r\n  color: var(--app-text-secondary, #657087) !important;\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-label, 13px) !important;\r\n  font-weight: var(--app-font-weight-regular, 400) !important;\r\n  line-height: 1.35;\r\n  opacity: 1;\r\n}\r\n\r\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .traffic-dialog, .cover-history) {\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border, #dfe4ee) !important;\r\n  border-radius: 18px !important;\r\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\r\n  color: var(--app-text, #202939);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) {\r\n  min-height: 80px;\r\n  padding: 18px 20px !important;\r\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) h2 {\r\n  margin: 0;\r\n  color: var(--app-text, #202939);\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-heading, 750) !important;\r\n  line-height: 1.2;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header\r\n) p {\r\n  margin: 3px 0 0;\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: var(--app-font-size-helper, 10px) !important;\r\n  line-height: 1.4;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__content,\r\n  .cc-statistics-content,\r\n  .douban-dialog__content,\r\n  .traffic-dialog-body,\r\n  .maoyan-dialog__content,\r\n  .cover-history > main\r\n) {\r\n  padding: 20px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__actions,\r\n  .cc-statistics-actions,\r\n  .douban-dialog__actions,\r\n  .traffic-dialog-actions,\r\n  .maoyan-dialog__actions,\r\n  .cover-history > footer\r\n) {\r\n  min-height: 64px;\r\n  padding: 13px 18px !important;\r\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface-raised, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) {\r\n  gap: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) > div {\r\n  min-width: 0;\r\n  padding: 15px 16px !important;\r\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  border-radius: 12px !important;\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) dt,\r\n:where(.cover-history .metrics) span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics\r\n) dd,\r\n:where(.cover-history .metrics) strong {\r\n  margin-top: 7px;\r\n  color: var(--app-text, #202939);\r\n  font-family: inherit !important;\r\n  font-size: var(--app-font-size-metric, 24px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  font-variant-numeric: tabular-nums;\r\n  line-height: 1.15;\r\n}\r\n\r\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\r\n.cookie-metric dd > span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 11px !important;\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n.signin-stat-results {\r\n  border-radius: 12px !important;\r\n}\r\n\r\n.signin-stat-results > header {\r\n  min-height: 44px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article {\r\n  min-height: 68px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article strong {\r\n  color: var(--app-text, #202939);\r\n  font-size: 13px;\r\n  font-weight: var(--app-font-weight-medium, 650);\r\n}\r\n\r\n.signin-stat-results article p {\r\n  font-size: 12px !important;\r\n}\r\n\r\n.signin-stat-results :is(article span, time) {\r\n  font-size: 10px !important;\r\n}\r\n\r\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\r\n  min-width: 0;\r\n  color: var(--app-text, #17243a);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  line-height: 1.5;\r\n}\r\n\r\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\r\n  font-size: 27px !important;\r\n  font-weight: 750;\r\n  line-height: 1.15;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  line-height: 1.3;\r\n}\r\n\r\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\r\n  min-height: 40px;\r\n  border-radius: 9px !important;\r\n  font-size: 13px;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\r\n  min-height: 52px;\r\n  border-radius: 11px;\r\n  color: var(--app-text-secondary, #657087);\r\n  font: inherit;\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n@media (max-width: 700px) {\r\n  :where(\r\n    .signin-stat-dialog__header,\r\n    .cc-statistics-header,\r\n    .douban-dialog__header,\r\n    .traffic-dialog-heading,\n    .maoyan-dialog__header,\n    .cover-history > header,\r\n    .signin-stat-dialog__content,\r\n    .cc-statistics-content,\r\n    .douban-dialog__content,\r\n    .traffic-dialog-body,\n    .maoyan-dialog__content,\n    .cover-history > main\r\n  ) {\r\n    padding: 16px !important;\r\n  }\r\n}\r\n\r\n/* Legacy-host fallback. On current hosts, the public form owns these tokens. */\r\n:where(.app-form-layout) {\r\n  display: grid;\r\n  grid-template-columns: repeat(var(--app-plugin-config-columns, 2), minmax(0, 1fr));\r\n  row-gap: var(--app-plugin-config-row-gap, 14px);\r\n  column-gap: var(--app-plugin-config-column-gap, 16px);\r\n}\r\n@media (max-width: 760px) {\r\n  :where(.app-form-layout) { grid-template-columns: minmax(0, 1fr); }\r\n}\r\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveComponent = runtime.resolveComponent;
const resolveDynamicComponent = runtime.resolveDynamicComponent;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1$3 = {
  key: 0,
  class: "error",
  role: "alert"
};
const _hoisted_2$3 = { class: "metrics" };
const _hoisted_3$3 = { class: "heading" };
const _hoisted_4$3 = {
  key: 0,
  class: "muted"
};
const _hoisted_5$2 = { class: "filters" };
const _hoisted_6$2 = { class: "table-scroll" };
const _hoisted_7$2 = { class: "file" };
const _hoisted_8$2 = { class: "path" };
const _hoisted_9$2 = { class: "cell-name" };
const _hoisted_10$2 = { class: "cell-name" };
const _hoisted_11$2 = { key: 0 };
const _hoisted_12$2 = {
  colspan: "6",
  class: "detail"
};
const _hoisted_13$2 = { key: 0 };
const _hoisted_14$2 = {
  colspan: "6",
  class: "empty"
};
const _hoisted_15$2 = { class: "pagination" };
const _hoisted_16$2 = {
  key: 2,
  class: "empty"
};
const _hoisted_17$2 = { class: "muted" };
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    page: { type: Boolean },
    request: { type: Function },
    dialogComponent: {},
    cardComponent: {},
    buttonComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiDialog = props.dialogComponent, UiCard = props.cardComponent, UiButton = props.buttonComponent;
    const data = ref(null), busy = ref(false), error = ref("");
    const search = ref(""), status = ref(""), method = ref(""), pageNumber = ref(1), expanded = ref("");
    let generation = 0;
    const labels = { completed: "复制完成", copied: "等待交接", uncertain: "结果待确认", conflict: "同名冲突", skipped: "未命中秒传", retry: "等待重试", failed: "复制失败" };
    const methods = { rapid: "秒传", relay: "中转", existing: "已存在" };
    const metrics = computed(() => [{ key: "completed", label: "已复制" }, { key: "skipped", label: "已跳过" }, { key: "attention", label: "待核对" }, { key: "pending", label: "待处理" }]);
    const statusOptions = [{ title: "全部处理结果", value: "" }, ...Object.entries(labels).map(([value, title]) => ({ value, title }))];
    const methodOptions = [{ title: "全部复制方式", value: "" }, ...Object.entries(methods).map(([value, title]) => ({ value, title }))];
    const updated = computed(() => data.value?.updated_at ? new Date(data.value.updated_at * 1e3).toLocaleTimeString("zh-CN", { hour12: false }) : "");
    async function load(reset = false) {
      if (reset) pageNumber.value = 1;
      const current = ++generation;
      busy.value = true;
      error.value = "";
      const query = new URLSearchParams({ page: String(pageNumber.value), search: search.value, status: status.value, method: method.value });
      try {
        const result = await props.request(`/plugins/cloud-copy/api/status?${query}`);
        if (current !== generation) return;
        data.value = result;
        pageNumber.value = result.page;
        expanded.value = "";
      } catch {
        if (current === generation) error.value = "统计数据加载失败，请刷新重试";
      } finally {
        if (current === generation) busy.value = false;
      }
    }
    async function action(name, identity) {
      if (busy.value) return;
      busy.value = true;
      error.value = "";
      try {
        await props.request(`/plugins/cloud-copy/api/${name}`, { method: "POST", body: JSON.stringify({ identity }) });
        await load();
      } catch {
        error.value = "操作未完成，请重试";
      } finally {
        busy.value = false;
      }
    }
    function paginate(offset) {
      pageNumber.value += offset;
      void load();
    }
    function tone(value) {
      return value === "completed" ? "saved" : value === "copied" ? "waiting" : ["conflict", "uncertain", "failed", "retry"].includes(value) ? "attention" : "skipped";
    }
    onMounted(() => load());
    return (_ctx, _cache) => {
      const _component_VTextField = resolveComponent("VTextField");
      const _component_VSelect = resolveComponent("VSelect");
      const _component_VTooltip = resolveComponent("VTooltip");
      const _component_VIcon = resolveComponent("VIcon");
      return openBlock(), createBlock(resolveDynamicComponent(__props.page ? "div" : unref(UiDialog)), {
        "model-value": true,
        "max-width": 1060,
        width: "calc(100vw - 32px)",
        "onUpdate:modelValue": _cache[14] || (_cache[14] = (open) => {
          if (!open) __props.context?.close();
        })
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "copy-statistics cc-statistics-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", null, [
                _cache[15] || (_cache[15] = createElementVNode(
                  "h2",
                  null,
                  "跨网盘复制 · 数据统计",
                  -1
                  /* CACHED */
                )),
                !__props.page ? (openBlock(), createBlock(unref(UiButton), {
                  key: 0,
                  class: "app-dialog-close",
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: _cache[0] || (_cache[0] = ($event) => __props.context?.close())
                })) : createCommentVNode("v-if", true)
              ]),
              createElementVNode("main", null, [
                error.value ? (openBlock(), createElementBlock(
                  "p",
                  _hoisted_1$3,
                  toDisplayString(error.value),
                  1
                  /* TEXT */
                )) : createCommentVNode("v-if", true),
                createElementVNode("section", _hoisted_2$3, [
                  (openBlock(true), createElementBlock(
                    Fragment,
                    null,
                    renderList(metrics.value, (metric) => {
                      return openBlock(), createElementBlock("article", {
                        key: metric.key
                      }, [
                        createElementVNode(
                          "span",
                          null,
                          toDisplayString(metric.label),
                          1
                          /* TEXT */
                        ),
                        createElementVNode(
                          "strong",
                          null,
                          toDisplayString(data.value ? data.value.counts[metric.key] || 0 : "—"),
                          1
                          /* TEXT */
                        )
                      ]);
                    }),
                    128
                    /* KEYED_FRAGMENT */
                  ))
                ]),
                createElementVNode("div", _hoisted_3$3, [
                  _cache[17] || (_cache[17] = createElementVNode(
                    "h3",
                    null,
                    "复制明细",
                    -1
                    /* CACHED */
                  )),
                  data.value?.configured ? (openBlock(), createElementBlock(
                    "span",
                    _hoisted_4$3,
                    "剩余 " + toDisplayString(data.value.directories) + " 个目录",
                    1
                    /* TEXT */
                  )) : createCommentVNode("v-if", true),
                  createVNode(unref(UiButton), {
                    color: "primary",
                    class: "push",
                    "prepend-icon": "mdi-folder-search-outline",
                    variant: "text",
                    disabled: busy.value || !data.value?.configured,
                    onClick: _cache[1] || (_cache[1] = ($event) => action("rescan"))
                  }, {
                    default: withCtx(() => [..._cache[16] || (_cache[16] = [
                      createTextVNode(
                        "重新扫描",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  }, 8, ["disabled"]),
                  createVNode(unref(UiButton), {
                    "prepend-icon": data.value?.paused ? "mdi-play-outline" : "mdi-pause",
                    variant: "text",
                    disabled: busy.value || !data.value?.configured,
                    onClick: _cache[2] || (_cache[2] = ($event) => action(data.value?.paused ? "resume" : "pause"))
                  }, {
                    default: withCtx(() => [
                      createTextVNode(
                        toDisplayString(data.value?.paused ? "继续" : "暂停"),
                        1
                        /* TEXT */
                      )
                    ]),
                    _: 1
                    /* STABLE */
                  }, 8, ["prepend-icon", "disabled"])
                ]),
                data.value?.configured ? (openBlock(), createElementBlock(
                  Fragment,
                  { key: 1 },
                  [
                    createElementVNode("div", _hoisted_5$2, [
                      createVNode(_component_VTextField, {
                        modelValue: search.value,
                        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => search.value = $event),
                        placeholder: "搜索文件名或路径",
                        "aria-label": "搜索文件名或路径",
                        "prepend-inner-icon": "mdi-magnify",
                        variant: "outlined",
                        "hide-details": "",
                        clearable: "",
                        onKeyup: _cache[4] || (_cache[4] = (event) => {
                          if (event.key === "Enter") load(true);
                        }),
                        "onClick:clear": _cache[5] || (_cache[5] = ($event) => {
                          search.value = "";
                          load(true);
                        }),
                        onBlur: _cache[6] || (_cache[6] = ($event) => load(true))
                      }, null, 8, ["modelValue"]),
                      createVNode(_component_VSelect, {
                        modelValue: status.value,
                        "onUpdate:modelValue": [
                          _cache[7] || (_cache[7] = ($event) => status.value = $event),
                          _cache[8] || (_cache[8] = ($event) => load(true))
                        ],
                        items: statusOptions,
                        "aria-label": "处理结果",
                        variant: "outlined",
                        "hide-details": ""
                      }, null, 8, ["modelValue"]),
                      createVNode(_component_VSelect, {
                        modelValue: method.value,
                        "onUpdate:modelValue": [
                          _cache[9] || (_cache[9] = ($event) => method.value = $event),
                          _cache[10] || (_cache[10] = ($event) => load(true))
                        ],
                        items: methodOptions,
                        "aria-label": "复制方式",
                        variant: "outlined",
                        "hide-details": ""
                      }, null, 8, ["modelValue"])
                    ]),
                    createElementVNode("div", _hoisted_6$2, [
                      createElementVNode("table", null, [
                        _cache[19] || (_cache[19] = createElementVNode(
                          "colgroup",
                          null,
                          [
                            createElementVNode("col", { style: { "width": "33%" } }),
                            createElementVNode("col", { style: { "width": "14%" } }),
                            createElementVNode("col", { style: { "width": "14%" } }),
                            createElementVNode("col", { style: { "width": "11%" } }),
                            createElementVNode("col", { style: { "width": "15%" } }),
                            createElementVNode("col", { style: { "width": "13%" } })
                          ],
                          -1
                          /* CACHED */
                        )),
                        _cache[20] || (_cache[20] = createElementVNode(
                          "thead",
                          null,
                          [
                            createElementVNode("tr", null, [
                              createElementVNode("th", null, "文件名称"),
                              createElementVNode("th", null, "源网盘"),
                              createElementVNode("th", null, "目的网盘"),
                              createElementVNode("th", null, "复制方式"),
                              createElementVNode("th", null, "处理结果"),
                              createElementVNode("th", null, "操作")
                            ])
                          ],
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("tbody", null, [
                          (openBlock(true), createElementBlock(
                            Fragment,
                            null,
                            renderList(data.value.records, (row) => {
                              return openBlock(), createElementBlock(
                                Fragment,
                                {
                                  key: row.identity
                                },
                                [
                                  createElementVNode("tr", null, [
                                    createElementVNode("td", null, [
                                      createElementVNode("div", null, [
                                        createVNode(_component_VTooltip, {
                                          text: row.path,
                                          location: "top",
                                          activator: "parent"
                                        }, null, 8, ["text"]),
                                        createElementVNode(
                                          "strong",
                                          _hoisted_7$2,
                                          toDisplayString(row.name || row.path),
                                          1
                                          /* TEXT */
                                        ),
                                        createElementVNode(
                                          "small",
                                          _hoisted_8$2,
                                          toDisplayString(row.path),
                                          1
                                          /* TEXT */
                                        )
                                      ])
                                    ]),
                                    createElementVNode("td", null, [
                                      createElementVNode(
                                        "span",
                                        _hoisted_9$2,
                                        toDisplayString(row.source_name),
                                        1
                                        /* TEXT */
                                      )
                                    ]),
                                    createElementVNode("td", null, [
                                      createElementVNode(
                                        "span",
                                        _hoisted_10$2,
                                        toDisplayString(row.target_storage_name),
                                        1
                                        /* TEXT */
                                      )
                                    ]),
                                    createElementVNode(
                                      "td",
                                      null,
                                      toDisplayString(methods[row.method || ""] || "—"),
                                      1
                                      /* TEXT */
                                    ),
                                    createElementVNode("td", null, [
                                      createElementVNode(
                                        "span",
                                        {
                                          class: normalizeClass(["pill", tone(row.status)])
                                        },
                                        toDisplayString(labels[row.status] || row.status),
                                        3
                                        /* TEXT, CLASS */
                                      )
                                    ]),
                                    createElementVNode("td", null, [
                                      createVNode(unref(UiButton), {
                                        color: "primary",
                                        variant: "text",
                                        size: "small",
                                        onClick: ($event) => expanded.value = expanded.value === row.identity ? "" : row.identity
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(
                                            toDisplayString(expanded.value === row.identity ? "收起详情" : "查看详情"),
                                            1
                                            /* TEXT */
                                          )
                                        ]),
                                        _: 2
                                        /* DYNAMIC */
                                      }, 1032, ["onClick"])
                                    ])
                                  ]),
                                  expanded.value === row.identity ? (openBlock(), createElementBlock("tr", _hoisted_11$2, [
                                    createElementVNode("td", _hoisted_12$2, [
                                      createElementVNode(
                                        "span",
                                        null,
                                        toDisplayString(row.reason || (row.handoff ? `后续处理：${row.handoff}` : `目标文件：${row.target_name || row.name}`)),
                                        1
                                        /* TEXT */
                                      ),
                                      !["completed", "copied"].includes(row.status) ? (openBlock(), createBlock(unref(UiButton), {
                                        key: 0,
                                        variant: "text",
                                        size: "small",
                                        disabled: busy.value,
                                        onClick: ($event) => action("retry", row.identity)
                                      }, {
                                        default: withCtx(() => [..._cache[18] || (_cache[18] = [
                                          createTextVNode(
                                            "核对并重试",
                                            -1
                                            /* CACHED */
                                          )
                                        ])]),
                                        _: 1
                                        /* STABLE */
                                      }, 8, ["disabled", "onClick"])) : createCommentVNode("v-if", true)
                                    ])
                                  ])) : createCommentVNode("v-if", true)
                                ],
                                64
                                /* STABLE_FRAGMENT */
                              );
                            }),
                            128
                            /* KEYED_FRAGMENT */
                          )),
                          !data.value.records.length ? (openBlock(), createElementBlock("tr", _hoisted_13$2, [
                            createElementVNode(
                              "td",
                              _hoisted_14$2,
                              toDisplayString(search.value || status.value || method.value ? "没有符合条件的复制记录" : "暂无复制记录"),
                              1
                              /* TEXT */
                            )
                          ])) : createCommentVNode("v-if", true)
                        ])
                      ])
                    ]),
                    createElementVNode("div", _hoisted_15$2, [
                      createElementVNode(
                        "span",
                        null,
                        "共 " + toDisplayString(data.value.total) + " 条记录",
                        1
                        /* TEXT */
                      ),
                      createElementVNode("div", null, [
                        createVNode(unref(UiButton), {
                          variant: "text",
                          icon: "mdi-chevron-left",
                          "aria-label": "上一页",
                          disabled: busy.value || pageNumber.value <= 1,
                          onClick: _cache[11] || (_cache[11] = ($event) => paginate(-1))
                        }, null, 8, ["disabled"]),
                        createElementVNode(
                          "span",
                          null,
                          toDisplayString(pageNumber.value) + " / " + toDisplayString(data.value.pages),
                          1
                          /* TEXT */
                        ),
                        createVNode(unref(UiButton), {
                          variant: "text",
                          icon: "mdi-chevron-right",
                          "aria-label": "下一页",
                          disabled: busy.value || pageNumber.value >= data.value.pages,
                          onClick: _cache[12] || (_cache[12] = ($event) => paginate(1))
                        }, null, 8, ["disabled"])
                      ])
                    ])
                  ],
                  64
                  /* STABLE_FRAGMENT */
                )) : data.value ? (openBlock(), createElementBlock("div", _hoisted_16$2, [
                  createVNode(_component_VIcon, {
                    icon: "mdi-folder-outline",
                    size: "42"
                  }),
                  _cache[21] || (_cache[21] = createElementVNode(
                    "h3",
                    null,
                    "暂无复制记录",
                    -1
                    /* CACHED */
                  )),
                  createElementVNode(
                    "p",
                    null,
                    toDisplayString(data.value.configuration_message || "请先在插件配置中选择源网盘与目标网盘"),
                    1
                    /* TEXT */
                  )
                ])) : createCommentVNode("v-if", true)
              ]),
              createElementVNode("footer", null, [
                createElementVNode(
                  "span",
                  _hoisted_17$2,
                  toDisplayString(updated.value ? `最近更新 ${updated.value}` : ""),
                  1
                  /* TEXT */
                ),
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: busy.value,
                  disabled: busy.value,
                  onClick: _cache[13] || (_cache[13] = ($event) => load())
                }, {
                  default: withCtx(() => [..._cache[22] || (_cache[22] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading", "disabled"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-965eae6d"]]);
const _hoisted_1$2 = ["aria-label"];
const _hoisted_2$2 = { class: "browser-select" };
const _hoisted_3$2 = { class: "browser-path" };
const _hoisted_4$2 = ["disabled"];
const _hoisted_5$1 = {
  key: 0,
  class: "crumb-divider",
  "aria-hidden": "true"
};
const _hoisted_6$1 = ["aria-current", "disabled", "onClick"];
const _hoisted_7$1 = ["disabled"];
const _hoisted_8$1 = { class: "browser-search" };
const _hoisted_9$1 = ["value", "disabled"];
const _hoisted_10$1 = ["disabled"];
const _hoisted_11$1 = {
  key: 0,
  role: "alert"
};
const _hoisted_12$1 = ["aria-busy"];
const _hoisted_13$1 = ["checked", "aria-label", "disabled", "onChange"];
const _hoisted_14$1 = ["disabled", "onClick"];
const _hoisted_15$1 = {
  key: 2,
  class: "file-name"
};
const _hoisted_16$1 = {
  key: 0,
  class: "browser-empty"
};
const _hoisted_17$1 = ["disabled"];
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "FileBrowser",
  props: {
    request: { type: Function },
    storages: {},
    target: { type: Boolean },
    disabled: { type: Boolean }
  },
  emits: ["change"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const storage = ref(""), items = ref([]), selected = ref([]), loading = ref(false), error = ref("");
    const folders = ref([{ id: "0", name: "根目录" }]), cursor = ref(null), search = ref("");
    let generation = 0;
    const pathTipOpen = ref(false);
    function showPathTip(event) {
      const element = event.currentTarget;
      pathTipOpen.value = element.scrollWidth > element.clientWidth;
    }
    const visible = computed(() => items.value.filter((item) => (!props.target || item.directory) && item.name.toLocaleLowerCase().includes(search.value.toLocaleLowerCase())));
    function publish() {
      emit("change", { storage: storage.value, parent: folders.value.at(-1).id, selected: [...selected.value], path: folders.value.map((row) => row.name).join(" / ") });
    }
    async function load(more = false) {
      const current = ++generation;
      loading.value = true;
      error.value = "";
      if (!more) {
        items.value = [];
        selected.value = [];
        cursor.value = null;
        publish();
      }
      if (!storage.value) {
        loading.value = false;
        return;
      }
      try {
        const query = new URLSearchParams({ storage: storage.value, parent: folders.value.at(-1).id });
        if (more) query.set("cursor", cursor.value);
        const data = await props.request(`/plugins/cloud-copy/api/browse?${query}`);
        if (current !== generation) return;
        if (!more) items.value = [];
        items.value.push(...data.items);
        cursor.value = data.cursor;
      } catch {
        if (current === generation) error.value = "目录读取失败，请刷新重试";
      } finally {
        if (current === generation) loading.value = false;
      }
    }
    function changeStorage(value) {
      storage.value = value;
      folders.value = [{ id: "0", name: "根目录" }];
      search.value = "";
      void load();
    }
    function enter(item) {
      if (loading.value || props.disabled) return;
      folders.value.push({ id: String(item.file_id), name: item.name });
      search.value = "";
      void load();
    }
    function navigate(index) {
      if (loading.value || props.disabled || index === folders.value.length - 1) return;
      pathTipOpen.value = false;
      folders.value = folders.value.slice(0, index + 1);
      search.value = "";
      void load();
    }
    function back() {
      navigate(folders.value.length - 2);
    }
    function toggle(item) {
      const id = String(item.file_id);
      selected.value = selected.value.includes(id) ? selected.value.filter((value) => value !== id) : [...selected.value, id];
      publish();
    }
    function selectAll() {
      selected.value = visible.value.every((item) => selected.value.includes(String(item.file_id))) ? [] : visible.value.map((item) => String(item.file_id));
      publish();
    }
    function size(value) {
      return value === void 0 ? "—" : value >= 1073741824 ? `${(value / 1073741824).toFixed(1)} GB` : value >= 1048576 ? `${(value / 1048576).toFixed(1)} MB` : `${value} B`;
    }
    return (_ctx, _cache) => {
      const _component_VSelect = resolveComponent("VSelect");
      const _component_VIcon = resolveComponent("VIcon");
      const _component_VTooltip = resolveComponent("VTooltip");
      return openBlock(), createElementBlock("section", {
        class: "copy-browser",
        "aria-label": __props.target ? "目标目录浏览器" : "源文件浏览器"
      }, [
        createElementVNode("div", _hoisted_2$2, [
          createVNode(_component_VSelect, {
            "model-value": storage.value || null,
            items: __props.storages,
            "item-title": "name",
            "item-value": "id",
            label: __props.target ? "目标网盘" : "源网盘",
            variant: "outlined",
            "hide-details": "",
            disabled: __props.disabled,
            "onUpdate:modelValue": changeStorage
          }, null, 8, ["model-value", "items", "label", "disabled"])
        ]),
        createElementVNode("div", _hoisted_3$2, [
          createElementVNode("button", {
            type: "button",
            disabled: folders.value.length === 1 || loading.value || __props.disabled,
            "aria-label": "返回上级目录",
            onClick: back
          }, [
            createVNode(_component_VIcon, { icon: "mdi-arrow-up" })
          ], 8, _hoisted_4$2),
          createElementVNode(
            "nav",
            {
              class: "browser-crumbs",
              "aria-label": "目录路径",
              onMouseenter: showPathTip,
              onMouseleave: _cache[0] || (_cache[0] = ($event) => pathTipOpen.value = false)
            },
            [
              createVNode(_component_VTooltip, {
                "model-value": pathTipOpen.value,
                "open-on-hover": false,
                "open-on-focus": false,
                location: "bottom start",
                "content-class": "copy-path-tooltip",
                text: folders.value.map((row) => row.name).join(" / "),
                activator: "parent"
              }, null, 8, ["model-value", "text"]),
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(folders.value, (folder, index) => {
                  return openBlock(), createElementBlock(
                    Fragment,
                    {
                      key: folder.id
                    },
                    [
                      index ? (openBlock(), createElementBlock("span", _hoisted_5$1, " / ")) : createCommentVNode("v-if", true),
                      createElementVNode("button", {
                        type: "button",
                        "aria-current": index === folders.value.length - 1 ? "page" : void 0,
                        disabled: loading.value || __props.disabled || index === folders.value.length - 1,
                        onClick: ($event) => navigate(index)
                      }, toDisplayString(folder.name), 9, _hoisted_6$1)
                    ],
                    64
                    /* STABLE_FRAGMENT */
                  );
                }),
                128
                /* KEYED_FRAGMENT */
              ))
            ],
            32
            /* NEED_HYDRATION */
          ),
          createElementVNode("button", {
            type: "button",
            disabled: !storage.value || loading.value || __props.disabled,
            "aria-label": "刷新目录",
            onClick: _cache[1] || (_cache[1] = ($event) => load())
          }, [
            createVNode(_component_VIcon, { icon: "mdi-refresh" })
          ], 8, _hoisted_7$1)
        ]),
        createElementVNode("div", _hoisted_8$1, [
          createElementVNode("input", {
            value: search.value,
            onInput: _cache[2] || (_cache[2] = ($event) => search.value = $event.target.value),
            disabled: __props.disabled,
            "aria-label": "筛选当前目录",
            placeholder: "筛选当前目录"
          }, null, 40, _hoisted_9$1),
          !__props.target ? (openBlock(), createElementBlock("button", {
            key: 0,
            type: "button",
            disabled: !visible.value.length || loading.value || __props.disabled,
            onClick: selectAll
          }, "全选", 8, _hoisted_10$1)) : createCommentVNode("v-if", true)
        ]),
        error.value ? (openBlock(), createElementBlock(
          "p",
          _hoisted_11$1,
          toDisplayString(error.value),
          1
          /* TEXT */
        )) : createCommentVNode("v-if", true),
        createElementVNode("div", {
          class: "browser-files",
          "aria-busy": loading.value
        }, [
          (openBlock(true), createElementBlock(
            Fragment,
            null,
            renderList(visible.value, (item) => {
              return openBlock(), createElementBlock(
                "div",
                {
                  key: item.file_id,
                  class: normalizeClass(["browser-file", { selected: selected.value.includes(String(item.file_id)) }])
                },
                [
                  !__props.target ? (openBlock(), createElementBlock("input", {
                    key: 0,
                    type: "checkbox",
                    checked: selected.value.includes(String(item.file_id)),
                    "aria-label": `选择 ${item.name}`,
                    disabled: __props.disabled || loading.value,
                    onChange: ($event) => toggle(item)
                  }, null, 40, _hoisted_13$1)) : createCommentVNode("v-if", true),
                  createVNode(_component_VIcon, {
                    icon: item.directory ? "mdi-folder-outline" : "mdi-file-outline"
                  }, null, 8, ["icon"]),
                  item.directory ? (openBlock(), createElementBlock("button", {
                    key: 1,
                    type: "button",
                    class: "file-name",
                    disabled: loading.value || __props.disabled,
                    onClick: ($event) => enter(item)
                  }, [
                    createVNode(_component_VTooltip, {
                      text: item.name,
                      activator: "parent",
                      location: "bottom start",
                      "content-class": "copy-path-tooltip"
                    }, null, 8, ["text"]),
                    createTextVNode(
                      toDisplayString(item.name),
                      1
                      /* TEXT */
                    )
                  ], 8, _hoisted_14$1)) : (openBlock(), createElementBlock("span", _hoisted_15$1, [
                    createVNode(_component_VTooltip, {
                      text: item.name,
                      activator: "parent",
                      location: "bottom start",
                      "content-class": "copy-path-tooltip"
                    }, null, 8, ["text"]),
                    createTextVNode(
                      toDisplayString(item.name),
                      1
                      /* TEXT */
                    )
                  ])),
                  createElementVNode(
                    "small",
                    null,
                    toDisplayString(item.directory ? "文件夹" : size(item.size)),
                    1
                    /* TEXT */
                  )
                ],
                2
                /* CLASS */
              );
            }),
            128
            /* KEYED_FRAGMENT */
          )),
          !visible.value.length ? (openBlock(), createElementBlock(
            "div",
            _hoisted_16$1,
            toDisplayString(loading.value ? "正在读取目录…" : !storage.value ? __props.target ? "选择目标网盘和目录" : "选择源网盘，勾选要复制的文件或文件夹" : "当前目录暂无可显示的内容"),
            1
            /* TEXT */
          )) : createCommentVNode("v-if", true),
          cursor.value ? (openBlock(), createElementBlock("button", {
            key: 1,
            type: "button",
            class: "browser-more",
            disabled: loading.value || __props.disabled,
            onClick: _cache[3] || (_cache[3] = ($event) => load(true))
          }, toDisplayString(loading.value ? "正在读取…" : "加载更多"), 9, _hoisted_17$1)) : createCommentVNode("v-if", true)
        ], 8, _hoisted_12$1),
        createElementVNode(
          "footer",
          null,
          toDisplayString(__props.target ? "复制到当前目录" : `已选择 ${selected.value.length} 项`),
          1
          /* TEXT */
        )
      ], 8, _hoisted_1$2);
    };
  }
});
const FileBrowser = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-788e96a3"]]);
const _hoisted_1$1 = { class: "workspace-actions" };
const _hoisted_2$1 = {
  key: 0,
  class: "workspace-error",
  role: "alert"
};
const _hoisted_3$1 = {
  key: 1,
  class: "workspace-message",
  role: "status"
};
const _hoisted_4$1 = { class: "copy-workbench app-surface-boundary" };
const _hoisted_5 = {
  class: "mobile-copy-tabs",
  role: "tablist",
  "aria-label": "复制位置"
};
const _hoisted_6 = ["aria-selected"];
const _hoisted_7 = { key: 0 };
const _hoisted_8 = ["aria-selected"];
const _hoisted_9 = { class: "copy-browsers" };
const _hoisted_10 = { class: "copy-controls" };
const _hoisted_11 = { class: "mobile-copy-footer" };
const _hoisted_12 = { class: "mobile-copy-actions" };
const _hoisted_13 = { class: "mobile-selected-count" };
const _hoisted_14 = { class: "records-header" };
const _hoisted_15 = { class: "mobile-settings-fields" };
const _hoisted_16 = { class: "records-header" };
const _hoisted_17 = { class: "records-body" };
const _hoisted_18 = {
  key: 0,
  class: "batch-empty"
};
const _hoisted_19 = {
  key: 1,
  class: "batch-table"
};
const _hoisted_20 = { class: "batch-name" };
const _hoisted_21 = { key: 0 };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "CopyWorkspace",
  props: {
    request: { type: Function },
    buttonComponent: {},
    dialogComponent: {},
    cardComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiButton = props.buttonComponent, UiDialog = props.dialogComponent, UiCard = props.cardComponent;
    const workspaceRoot = ref(null);
    let releaseBounds;
    function fitWorkspace() {
      const root = workspaceRoot.value;
      if (!root) return;
      const update = () => {
        const top = root.getBoundingClientRect().top;
        const dock = document.querySelector(".mobile-shell-dock")?.getBoundingClientRect();
        const shell2 = root.closest(".app-workspace");
        const padding = shell2 ? parseFloat(getComputedStyle(shell2).paddingBottom) : 24;
        const bottom = Math.min(window.innerHeight - padding - 2, dock && dock.height ? dock.top - 8 : window.innerHeight);
        root.style.height = `${Math.max(0, bottom - top)}px`;
      };
      const observer = new ResizeObserver(update);
      if (root.parentElement) observer.observe(root.parentElement);
      const shell = root.closest(".app-workspace");
      if (shell) observer.observe(shell);
      if (shell?.parentElement) observer.observe(shell.parentElement);
      window.addEventListener("resize", update);
      window.visualViewport?.addEventListener("resize", update);
      update();
      releaseBounds = () => {
        observer.disconnect();
        window.removeEventListener("resize", update);
        window.visualViewport?.removeEventListener("resize", update);
      };
    }
    const recordsOpen = ref(false), settingsOpen = ref(false), activePane = ref("source");
    function openRecords() {
      recordsOpen.value = true;
      void load();
    }
    const storages = ref([]);
    const sources = computed(() => storages.value.filter((row) => row.enabled !== false && row.capabilities.includes("file_copy_source")));
    const targets = computed(() => storages.value.filter((row) => row.enabled !== false && row.capabilities.includes("file_copy_target")));
    const source = ref({ storage: "", parent: "0", selected: [], path: "" }), target = ref({ storage: "", parent: "0", selected: [], path: "" });
    const policy = ref("metadata"), followup = ref("none"), maxGib = ref(10), busy = ref(false), loading = ref(false), error = ref(""), message = ref(""), batches = ref([]);
    let submissionId = "", submittedPayload = "";
    let refreshTimer;
    let disposed = false;
    function dispose() {
      releaseBounds?.();
      disposed = true;
      clearTimeout(refreshTimer);
    }
    const policies = [{ title: "仅使用已有校验信息", value: "metadata" }, { title: "允许读取源文件验证秒传", value: "verify" }, { title: "允许服务器中转上传", value: "relay" }];
    const followups = [{ title: "仅复制", value: "none" }, { title: "交接整理", value: "organize" }, { title: "同步本批文件", value: "sync" }];
    const states = { queued: "等待执行", running: "正在复制", completed: "处理完成", failed: "执行失败", skipped: "已跳过", uncertain: "结果待确认", conflict: "同名冲突", copied: "等待交接" };
    const name = (id) => storages.value.find((row) => row.id === id)?.name || id;
    async function load() {
      clearTimeout(refreshTimer);
      loading.value = true;
      try {
        batches.value = (await props.request("/plugins/cloud-copy/api/batches")).items;
      } catch {
        error.value = "批次记录读取失败，请刷新重试";
      } finally {
        loading.value = false;
        if (!disposed && batches.value.some((row) => ["queued", "running"].includes(row.status))) refreshTimer = setTimeout(() => void load(), 5e3);
      }
    }
    async function submit() {
      if (busy.value || !source.value.selected.length || !target.value.storage) return;
      busy.value = true;
      error.value = "";
      message.value = "";
      const data = { source: source.value.storage, source_root: source.value.parent, target: target.value.storage, target_root: target.value.parent, selected: source.value.selected, policy: policy.value, followup: followup.value, max_gib: maxGib.value };
      const encoded = JSON.stringify(data);
      if (encoded !== submittedPayload) {
        submissionId = crypto.randomUUID();
        submittedPayload = encoded;
      }
      try {
        await props.request("/plugins/cloud-copy/api/submit", { method: "POST", body: JSON.stringify({ ...data, id: submissionId }) });
        message.value = `已提交 ${source.value.selected.length} 项，后台将处理本批文件`;
        await load();
      } catch (e) {
        error.value = e instanceof Error ? e.message : "复制提交失败，请重试";
      } finally {
        busy.value = false;
      }
    }
    onMounted(async () => {
      fitWorkspace();
      try {
        storages.value = (await props.request("/plugins/cloud-copy/api/options")).items;
        await load();
      } catch {
        error.value = "网盘列表读取失败，请刷新页面";
      }
    });
    return (_ctx, _cache) => {
      const _component_VSelect = resolveComponent("VSelect");
      const _component_VTextField = resolveComponent("VTextField");
      const _component_VIcon = resolveComponent("VIcon");
      const _component_VTooltip = resolveComponent("VTooltip");
      return openBlock(), createElementBlock(
        "section",
        {
          ref_key: "workspaceRoot",
          ref: workspaceRoot,
          class: "copy-workspace",
          onVnodeBeforeUnmount: dispose
        },
        [
          createElementVNode("header", null, [
            _cache[19] || (_cache[19] = createElementVNode(
              "div",
              null,
              [
                createElementVNode("h2", null, "跨网盘复制")
              ],
              -1
              /* CACHED */
            )),
            createElementVNode("div", _hoisted_1$1, [
              createVNode(unref(UiButton), {
                variant: "text",
                "prepend-icon": "mdi-history",
                onClick: openRecords
              }, {
                default: withCtx(() => [..._cache[17] || (_cache[17] = [
                  createTextVNode(
                    "复制记录",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }),
              createVNode(unref(UiButton), {
                "prepend-icon": "mdi-refresh",
                variant: "text",
                loading: loading.value,
                onClick: load
              }, {
                default: withCtx(() => [..._cache[18] || (_cache[18] = [
                  createTextVNode(
                    "刷新记录",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["loading"])
            ])
          ]),
          error.value ? (openBlock(), createElementBlock(
            "p",
            _hoisted_2$1,
            toDisplayString(error.value),
            1
            /* TEXT */
          )) : message.value ? (openBlock(), createElementBlock(
            "p",
            _hoisted_3$1,
            toDisplayString(message.value),
            1
            /* TEXT */
          )) : createCommentVNode("v-if", true),
          createElementVNode("div", _hoisted_4$1, [
            createElementVNode("div", _hoisted_5, [
              createElementVNode("button", {
                role: "tab",
                "aria-selected": activePane.value === "source",
                onClick: _cache[0] || (_cache[0] = ($event) => activePane.value = "source")
              }, [
                _cache[20] || (_cache[20] = createTextVNode(
                  "源文件",
                  -1
                  /* CACHED */
                )),
                source.value.selected.length ? (openBlock(), createElementBlock(
                  "span",
                  _hoisted_7,
                  toDisplayString(source.value.selected.length),
                  1
                  /* TEXT */
                )) : createCommentVNode("v-if", true)
              ], 8, _hoisted_6),
              createElementVNode("button", {
                role: "tab",
                "aria-selected": activePane.value === "target",
                onClick: _cache[1] || (_cache[1] = ($event) => activePane.value = "target")
              }, "目标目录", 8, _hoisted_8)
            ]),
            createElementVNode("div", _hoisted_9, [
              createVNode(FileBrowser, {
                class: normalizeClass({ "is-mobile-hidden": activePane.value !== "source" }),
                request: __props.request,
                storages: sources.value,
                disabled: busy.value,
                onChange: _cache[2] || (_cache[2] = ($event) => source.value = $event)
              }, null, 8, ["class", "request", "storages", "disabled"]),
              createVNode(FileBrowser, {
                class: normalizeClass({ "is-mobile-hidden": activePane.value !== "target" }),
                request: __props.request,
                storages: targets.value,
                disabled: busy.value,
                target: "",
                onChange: _cache[3] || (_cache[3] = ($event) => target.value = $event)
              }, null, 8, ["class", "request", "storages", "disabled"])
            ]),
            createElementVNode("div", _hoisted_10, [
              createVNode(_component_VSelect, {
                modelValue: policy.value,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => policy.value = $event),
                items: policies,
                label: "复制策略",
                variant: "outlined",
                "hide-details": "",
                disabled: busy.value
              }, null, 8, ["modelValue", "disabled"]),
              createVNode(_component_VTextField, {
                modelValue: maxGib.value,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => maxGib.value = $event),
                type: "number",
                min: "1",
                label: "临时空间上限（GiB）",
                variant: "outlined",
                "hide-details": "",
                disabled: busy.value
              }, null, 8, ["modelValue", "disabled"]),
              createVNode(_component_VSelect, {
                modelValue: followup.value,
                "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => followup.value = $event),
                items: followups,
                label: "复制完成后",
                variant: "outlined",
                "hide-details": "",
                disabled: busy.value
              }, null, 8, ["modelValue", "disabled"]),
              createVNode(unref(UiButton), {
                class: "copy-submit",
                color: "primary",
                "prepend-icon": "mdi-content-copy",
                disabled: busy.value || !source.value.selected.length || !target.value.storage || Number(maxGib.value) <= 0,
                loading: busy.value,
                onClick: submit
              }, {
                default: withCtx(() => [
                  createTextVNode(
                    "复制所选 " + toDisplayString(source.value.selected.length) + " 项",
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }, 8, ["disabled", "loading"])
            ]),
            createElementVNode("div", _hoisted_11, [
              createElementVNode("button", {
                class: "mobile-target-row",
                onClick: _cache[7] || (_cache[7] = ($event) => activePane.value = "target")
              }, [
                _cache[21] || (_cache[21] = createElementVNode(
                  "span",
                  null,
                  "目标目录",
                  -1
                  /* CACHED */
                )),
                createElementVNode(
                  "strong",
                  null,
                  toDisplayString(target.value.storage ? `${name(target.value.storage)} · ${target.value.path}` : "请选择"),
                  1
                  /* TEXT */
                ),
                createVNode(_component_VIcon, {
                  icon: "mdi-chevron-right",
                  size: "16"
                })
              ]),
              createElementVNode("div", _hoisted_12, [
                createVNode(unref(UiButton), {
                  class: "mobile-settings-trigger",
                  variant: "text",
                  icon: "mdi-cog-outline",
                  "aria-label": "复制设置",
                  onClick: _cache[8] || (_cache[8] = ($event) => settingsOpen.value = true)
                }),
                createElementVNode(
                  "span",
                  _hoisted_13,
                  "已选 " + toDisplayString(source.value.selected.length) + " 项",
                  1
                  /* TEXT */
                ),
                createVNode(unref(UiButton), {
                  class: "copy-submit",
                  color: "primary",
                  disabled: busy.value || !source.value.selected.length || !target.value.storage || Number(maxGib.value) <= 0,
                  loading: busy.value,
                  onClick: submit
                }, {
                  default: withCtx(() => [..._cache[22] || (_cache[22] = [
                    createTextVNode(
                      "开始复制",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["disabled", "loading"])
              ])
            ])
          ]),
          settingsOpen.value ? (openBlock(), createBlock(unref(UiDialog), {
            key: 2,
            modelValue: settingsOpen.value,
            "onUpdate:modelValue": _cache[14] || (_cache[14] = ($event) => settingsOpen.value = $event),
            "max-width": 480,
            width: "calc(100vw - 24px)"
          }, {
            default: withCtx(() => [
              createVNode(unref(UiCard), { class: "mobile-copy-settings cc-statistics-dialog" }, {
                default: withCtx(() => [
                  createElementVNode("header", _hoisted_14, [
                    _cache[23] || (_cache[23] = createElementVNode(
                      "h2",
                      null,
                      "复制设置",
                      -1
                      /* CACHED */
                    )),
                    createVNode(unref(UiButton), {
                      icon: "mdi-close",
                      variant: "text",
                      "aria-label": "关闭复制设置",
                      onClick: _cache[9] || (_cache[9] = ($event) => settingsOpen.value = false)
                    })
                  ]),
                  createElementVNode("div", _hoisted_15, [
                    createVNode(_component_VSelect, {
                      modelValue: policy.value,
                      "onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => policy.value = $event),
                      items: policies,
                      label: "复制策略",
                      variant: "outlined",
                      "hide-details": "",
                      disabled: busy.value
                    }, null, 8, ["modelValue", "disabled"]),
                    createVNode(_component_VTextField, {
                      modelValue: maxGib.value,
                      "onUpdate:modelValue": _cache[11] || (_cache[11] = ($event) => maxGib.value = $event),
                      type: "number",
                      min: "1",
                      label: "临时空间上限（GiB）",
                      variant: "outlined",
                      "hide-details": "",
                      disabled: busy.value
                    }, null, 8, ["modelValue", "disabled"]),
                    createVNode(_component_VSelect, {
                      modelValue: followup.value,
                      "onUpdate:modelValue": _cache[12] || (_cache[12] = ($event) => followup.value = $event),
                      items: followups,
                      label: "复制完成后",
                      variant: "outlined",
                      "hide-details": "",
                      disabled: busy.value
                    }, null, 8, ["modelValue", "disabled"])
                  ]),
                  createElementVNode("footer", null, [
                    createVNode(unref(UiButton), {
                      color: "primary",
                      onClick: _cache[13] || (_cache[13] = ($event) => settingsOpen.value = false)
                    }, {
                      default: withCtx(() => [..._cache[24] || (_cache[24] = [
                        createTextVNode(
                          "完成",
                          -1
                          /* CACHED */
                        )
                      ])]),
                      _: 1
                      /* STABLE */
                    })
                  ])
                ]),
                _: 1
                /* STABLE */
              })
            ]),
            _: 1
            /* STABLE */
          }, 8, ["modelValue"])) : createCommentVNode("v-if", true),
          recordsOpen.value ? (openBlock(), createBlock(unref(UiDialog), {
            key: 3,
            modelValue: recordsOpen.value,
            "onUpdate:modelValue": _cache[16] || (_cache[16] = ($event) => recordsOpen.value = $event),
            "max-width": 1060,
            width: "calc(100vw - 32px)"
          }, {
            default: withCtx(() => [
              createVNode(unref(UiCard), { class: "copy-batches cc-statistics-dialog" }, {
                default: withCtx(() => [
                  createElementVNode("header", _hoisted_16, [
                    _cache[25] || (_cache[25] = createElementVNode(
                      "h2",
                      null,
                      "复制记录",
                      -1
                      /* CACHED */
                    )),
                    createVNode(unref(UiButton), {
                      icon: "mdi-close",
                      class: "app-dialog-close",
                      variant: "text",
                      "aria-label": "关闭复制记录",
                      onClick: _cache[15] || (_cache[15] = ($event) => recordsOpen.value = false)
                    })
                  ]),
                  createElementVNode("main", _hoisted_17, [
                    !batches.value.length ? (openBlock(), createElementBlock("div", _hoisted_18, "暂无手动复制批次")) : (openBlock(), createElementBlock("div", _hoisted_19, [
                      createElementVNode("table", null, [
                        _cache[26] || (_cache[26] = createElementVNode(
                          "colgroup",
                          null,
                          [
                            createElementVNode("col", { style: { "width": "40%" } }),
                            createElementVNode("col", { style: { "width": "18%" } }),
                            createElementVNode("col", { style: { "width": "18%" } }),
                            createElementVNode("col", { style: { "width": "12%" } }),
                            createElementVNode("col", { style: { "width": "12%" } })
                          ],
                          -1
                          /* CACHED */
                        )),
                        _cache[27] || (_cache[27] = createElementVNode(
                          "thead",
                          null,
                          [
                            createElementVNode("tr", null, [
                              createElementVNode("th", null, "所选内容"),
                              createElementVNode("th", null, "源网盘"),
                              createElementVNode("th", null, "目标网盘"),
                              createElementVNode("th", null, "进度"),
                              createElementVNode("th", null, "状态")
                            ])
                          ],
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("tbody", null, [
                          (openBlock(true), createElementBlock(
                            Fragment,
                            null,
                            renderList(batches.value, (batch) => {
                              return openBlock(), createElementBlock("tr", {
                                key: batch.id
                              }, [
                                createElementVNode("td", null, [
                                  createElementVNode("span", _hoisted_20, [
                                    createVNode(_component_VTooltip, {
                                      text: batch.names.join("、"),
                                      activator: "parent"
                                    }, null, 8, ["text"]),
                                    createTextVNode(
                                      toDisplayString(batch.names.join("、")),
                                      1
                                      /* TEXT */
                                    )
                                  ]),
                                  createElementVNode(
                                    "small",
                                    null,
                                    toDisplayString(batch.selected) + " 项",
                                    1
                                    /* TEXT */
                                  )
                                ]),
                                createElementVNode(
                                  "td",
                                  null,
                                  toDisplayString(name(batch.config.source)),
                                  1
                                  /* TEXT */
                                ),
                                createElementVNode(
                                  "td",
                                  null,
                                  toDisplayString(name(batch.config.target)),
                                  1
                                  /* TEXT */
                                ),
                                createElementVNode("td", null, [
                                  createTextVNode(
                                    "已复制 " + toDisplayString(batch.completed || 0),
                                    1
                                    /* TEXT */
                                  ),
                                  batch.attention ? (openBlock(), createElementBlock(
                                    "small",
                                    _hoisted_21,
                                    "待核对 " + toDisplayString(batch.attention),
                                    1
                                    /* TEXT */
                                  )) : createCommentVNode("v-if", true)
                                ]),
                                createElementVNode(
                                  "td",
                                  null,
                                  toDisplayString(states[batch.status] || batch.status),
                                  1
                                  /* TEXT */
                                )
                              ]);
                            }),
                            128
                            /* KEYED_FRAGMENT */
                          ))
                        ])
                      ])
                    ]))
                  ])
                ]),
                _: 1
                /* STABLE */
              })
            ]),
            _: 1
            /* STABLE */
          }, 8, ["modelValue"])) : createCommentVNode("v-if", true)
        ],
        512
        /* NEED_PATCH */
      );
    };
  }
});
const CopyWorkspace = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-564fb17e"]]);
const _hoisted_1 = { class: "copy-config plugin-config-grid app-form-layout" };
const _hoisted_2 = {
  key: 0,
  role: "alert"
};
const _hoisted_3 = { class: "copy-config-sidebar" };
const _hoisted_4 = { class: "copy-config-trigger" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ConfigEditor",
  props: {
    modelValue: {},
    fields: {},
    disabled: { type: Boolean },
    schemaFieldsComponent: {},
    request: { type: Function }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const sources = ref([]);
    const error = ref("");
    const supportsEvents = computed(() => sources.value.some((item) => item.id === props.modelValue.source && item.capabilities.includes("change_feed")));
    const trigger = computed(() => props.modelValue.full_scan_enabled ? "full" : supportsEvents.value && props.modelValue.life_events_enabled ? "events" : "manual");
    const triggerItems = computed(() => [
      { title: "手动全量", value: "manual" },
      { title: "定时全量", value: "full" },
      ...supportsEvents.value ? [{ title: "生活事件", value: "events" }] : []
    ]);
    const fieldModel = computed(() => ({ ...props.modelValue, source: props.modelValue.source || null, target: props.modelValue.target || null }));
    const field = (key) => props.fields.filter((item) => item.key === key);
    function updateTrigger(value) {
      update({ full_scan_enabled: value === "full", life_events_enabled: value === "events" });
    }
    function update(next) {
      const merged = { ...props.modelValue, ...next };
      const sourceChanged = merged.source !== props.modelValue.source;
      if (sourceChanged) merged.source_root = "0";
      if (merged.target !== props.modelValue.target) merged.target_root = "0";
      const supported = sources.value.some((item) => item.id === merged.source && item.capabilities.includes("change_feed"));
      if (merged.full_scan_enabled || !supported || sourceChanged) {
        merged.life_events_enabled = false;
        merged.life_events_since = 0;
      }
      if (merged.life_events_enabled && !props.modelValue.life_events_enabled) merged.life_events_since = Math.floor(Date.now() / 1e3);
      emit("update:modelValue", merged);
    }
    onMounted(async () => {
      try {
        sources.value = (await props.request("/plugins/cloud-copy/sdk/resources/storage?capability=file_copy_source&limit=500")).items;
      } catch {
        error.value = "读取源网盘能力失败，请重新打开配置";
      }
    });
    return (_ctx, _cache) => {
      const _component_VSelect = resolveComponent("VSelect");
      const _component_VTextField = resolveComponent("VTextField");
      return openBlock(), createElementBlock("div", _hoisted_1, [
        error.value ? (openBlock(), createElementBlock(
          "p",
          _hoisted_2,
          toDisplayString(error.value),
          1
          /* TEXT */
        )) : createCommentVNode("v-if", true),
        createElementVNode("div", _hoisted_3, [
          (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
            fields: field("show_sidebar_nav"),
            "model-value": fieldModel.value,
            disabled: __props.disabled,
            "plugin-id": "cloud-copy",
            compact: "",
            "onUpdate:modelValue": update
          }, null, 8, ["fields", "model-value", "disabled"]))
        ]),
        (openBlock(), createElementBlock(
          Fragment,
          null,
          renderList(["source", "source_root", "target", "target_root"], (key) => {
            return createVNode(resolveDynamicComponent(__props.schemaFieldsComponent), {
              key,
              fields: field(key),
              "model-value": fieldModel.value,
              disabled: __props.disabled,
              "plugin-id": "cloud-copy",
              compact: "",
              "onUpdate:modelValue": update
            }, null, 8, ["fields", "model-value", "disabled"]);
          }),
          64
          /* STABLE_FRAGMENT */
        )),
        createElementVNode("div", _hoisted_4, [
          createVNode(_component_VSelect, {
            "model-value": trigger.value,
            items: triggerItems.value,
            label: "触发方式",
            variant: "outlined",
            disabled: __props.disabled,
            "onUpdate:modelValue": updateTrigger
          }, null, 8, ["model-value", "items", "disabled"]),
          __props.modelValue.full_scan_enabled ? (openBlock(), createBlock(_component_VTextField, {
            key: 0,
            "model-value": __props.modelValue.full_scan_interval_minutes ?? 60,
            label: "全量执行间隔（分钟）",
            type: "number",
            min: "1",
            step: "1",
            variant: "outlined",
            disabled: __props.disabled,
            rules: [(value) => Number.isInteger(Number(value)) && Number(value) > 0 || "请输入大于 0 的整数分钟"],
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => update({ full_scan_interval_minutes: $event === "" ? "" : Number($event) }))
          }, null, 8, ["model-value", "disabled", "rules"])) : createCommentVNode("v-if", true)
        ]),
        (openBlock(), createElementBlock(
          Fragment,
          null,
          renderList(["policy", "max_gib", "followup"], (key) => {
            return createVNode(resolveDynamicComponent(__props.schemaFieldsComponent), {
              key,
              fields: field(key),
              "model-value": fieldModel.value,
              disabled: __props.disabled,
              "plugin-id": "cloud-copy",
              compact: "",
              "onUpdate:modelValue": update
            }, null, 8, ["fields", "model-value", "disabled"]);
          }),
          64
          /* STABLE_FRAGMENT */
        ))
      ]);
    };
  }
});
const ConfigEditor = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d8a6eaaa"]]);
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const Workspace = defineComponent2({
    props: { context: { type: Object }, page: Boolean },
    setup: (props) => () => h(StatisticsView, {
      context: props.context,
      page: props.page,
      request: sdk.request,
      dialogComponent: sdk.ui.components.Dialog,
      cardComponent: sdk.ui.components.Card,
      buttonComponent: sdk.ui.components.Button
    })
  });
  sdk.registerContribution({ pluginId: "cloud-copy", slot: "plugin.statistics", key: "copies", component: Workspace });
  sdk.registerPage({
    pluginId: "cloud-copy",
    route: "plugin-cloud-copy",
    title: "跨网盘复制",
    icon: "mdi-content-copy",
    section: "tools",
    order: 66,
    component: defineComponent2({ setup: () => () => h(CopyWorkspace, { request: sdk.request, buttonComponent: sdk.ui.components.Button, dialogComponent: sdk.ui.components.Dialog, cardComponent: sdk.ui.components.Card }) })
  });
  const SchemaFields = sdk.ui.components.SchemaFields;
  if (SchemaFields) sdk.registerEditor({ domain: "plugin", key: "cloud-copy", component: defineComponent2({
    inheritAttrs: false,
    props: { modelValue: { type: Object, required: true }, fields: { type: Array, default: () => [] }, disabled: Boolean },
    emits: ["update:modelValue"],
    setup: (props, { emit }) => () => h(ConfigEditor, {
      modelValue: props.modelValue,
      fields: props.fields,
      disabled: props.disabled,
      schemaFieldsComponent: SchemaFields,
      request: sdk.request,
      "onUpdate:modelValue": (value) => emit("update:modelValue", value)
    })
  }) });
}
export {
  install
};
