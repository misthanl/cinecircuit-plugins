if (typeof document !== "undefined") { const id = "maoyan_rank"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.maoyan-statistics[data-v-3ea12395] { display: grid; gap: 22px; min-width: 0;\n}\n.maoyan-statistics__metrics[data-v-3ea12395] { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; margin: 0 0 6px;\n}\n.maoyan-statistics__metrics > div[data-v-3ea12395] { padding: 15px 16px; border: 1px solid var(--app-border-subtle); border-radius: 12px; background: var(--app-surface-muted);\n}\n.maoyan-statistics__metrics > div[data-v-3ea12395]:first-child { background: var(--app-violet-soft);\n}\n.maoyan-statistics__metrics dt[data-v-3ea12395] { color: var(--app-text-muted); font-size: 12px;\n}\n.maoyan-statistics__metrics > div:first-child dt[data-v-3ea12395] { color: var(--app-violet-text);\n}\n.maoyan-statistics__metrics dd[data-v-3ea12395] { margin: 10px 0 0; color: var(--app-text); font-size: 24px; font-weight: 600; font-variant-numeric: tabular-nums;\n}\n.maoyan-statistics__metrics dd span[data-v-3ea12395] { font-size: 11px; font-weight: 400;\n}\n.maoyan-statistics__page-info[data-v-3ea12395] { display: flex; justify-content: space-between; color: var(--app-text-muted); font-size: 13px;\n}\n.maoyan-statistics__grid[data-v-3ea12395] { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; margin-top: -10px;\n}\n.maoyan-subscription[data-v-3ea12395] { display: grid; grid-template-columns: 96px minmax(0, 1fr); align-items: start; gap: 14px; padding: 14px; min-width: 0; border: 1px solid var(--app-border-subtle); border-radius: 14px; background: var(--app-surface);\n}\n.maoyan-subscription__poster[data-v-3ea12395] { display: grid; place-items: center; width: 100%; aspect-ratio: 2 / 3; overflow: hidden; border-radius: 8px; background: var(--app-surface-muted); color: var(--app-text-muted); font-size: 12px;\n}\n.maoyan-subscription__poster img[data-v-3ea12395] { width: 100%; height: 100%; object-fit: cover;\n}\n.maoyan-subscription__body[data-v-3ea12395] { min-width: 0; padding-top: 2px;\n}\n.maoyan-subscription h3[data-v-3ea12395] { margin: 0 0 10px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--app-text); font-size: 15px; font-weight: 600;\n}\n.maoyan-subscription__tags[data-v-3ea12395] { display: flex; flex-wrap: wrap; gap: 5px;\n}\n.maoyan-subscription__tags span[data-v-3ea12395] { max-width: 100%; padding: 3px 8px; border-radius: 16px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; background: var(--app-surface-muted); color: var(--app-text-secondary); font-size: 10px;\n}\n.maoyan-subscription__release[data-v-3ea12395] { margin: 11px 0 6px; color: var(--app-text-secondary); font-size: 14px; overflow-wrap: anywhere;\n}\n.maoyan-subscription__time[data-v-3ea12395] { margin: 0; color: var(--app-text-muted); font-size: 12px; line-height: 1.8; overflow-wrap: anywhere; font-variant-numeric: tabular-nums;\n}\n.maoyan-statistics__pagination[data-v-3ea12395] { display: flex; align-items: center; justify-content: center; gap: 14px; color: var(--app-text-muted); font-size: 12px;\n}\n.maoyan-dialog[data-v-3ea12395] { display: flex; flex-direction: column; max-height: calc(100dvh - 32px); border: 1px solid var(--app-border); border-radius: 18px !important; background: var(--app-dialog-surface) !important; color: var(--app-text);\n}\n.maoyan-dialog__header[data-v-3ea12395] { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 20px 24px;\n}\n.maoyan-dialog__header h2[data-v-3ea12395] { margin: 0; font-size: 18px; font-weight: 750;\n}.maoyan-dialog__header p[data-v-3ea12395]{margin:3px 0 0;color:var(--app-text-muted);font-size:10px}\n.maoyan-dialog__content[data-v-3ea12395] { min-height: 0; overflow: auto; padding: 20px 24px; background: var(--app-surface-subtle);\n}\n.maoyan-dialog__actions[data-v-3ea12395] { display: flex; align-items: center; justify-content: flex-end; gap: 12px; padding: 12px 24px; border-top: 1px solid var(--app-border-subtle);\n}\n.maoyan-dialog__config[data-v-3ea12395] { color: var(--app-on-accent) !important; background: var(--app-violet-text) !important;\n}\n.maoyan-dialog__message[data-v-3ea12395] { padding: 40px 12px; text-align: center; color: var(--app-text-muted);\n}\n.maoyan-statistics__pagination button[data-v-3ea12395]:focus-visible { outline: 2px solid var(--app-violet-text); outline-offset: 2px;\n}\n@media (max-width: 1250px) {\n.maoyan-statistics__grid[data-v-3ea12395] { grid-template-columns: repeat(2, minmax(0, 1fr));\n}\n}\n@media (max-width: 600px) {\n.maoyan-statistics__metrics[data-v-3ea12395] { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px;\n}\n.maoyan-statistics__metrics > div[data-v-3ea12395] { padding: 14px 16px;\n}\n.maoyan-statistics__grid[data-v-3ea12395] { grid-template-columns: minmax(0, 1fr);\n}\n.maoyan-dialog__content[data-v-3ea12395], .maoyan-dialog__header[data-v-3ea12395] { padding: 16px;\n}\n.maoyan-dialog__header h2[data-v-3ea12395] { font-size: 18px;\n}\n}\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\n * Values mirror the host application's standard configuration dialog and\n * operational content density. Keep business-specific layouts in each plugin.\n */\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-field) {\n  min-height: var(--app-control-height, 52px);\n  border-radius: 11px;\n  background: var(--control-surface, var(--app-surface, #fff));\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-field__input) {\n  min-width: 0;\n  min-height: var(--app-control-height, 52px) !important;\n  color: var(--app-text-secondary, #657087);\n  font-size: 14px;\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-label.v-field-label) {\n  color: var(--app-text-secondary, #657087);\n  font-size: 11px;\n}\n\n:where(.cookiecloud-config-fields, .cover-run-settings) .v-switch .v-label {\n  color: var(--app-text, #202939);\n  font-size: 13px !important;\n  font-weight: 400;\n  opacity: 1;\n}\n\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .cover-history) {\n  overflow: hidden;\n  border: 1px solid var(--app-border, #dfe4ee) !important;\n  border-radius: 18px !important;\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\n  color: var(--app-text, #202939);\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header,\n  .cover-history > header\n) {\n  min-height: 80px;\n  padding: 18px 20px !important;\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\n  background: var(--app-surface, #fff);\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header,\n  .cover-history > header\n) h2 {\n  margin: 0;\n  color: var(--app-text, #202939);\n  font-size: 18px !important;\n  font-weight: 750 !important;\n  line-height: 1.2;\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header\n) p {\n  margin: 3px 0 0;\n  color: var(--app-text-muted, #7a869d);\n  font-size: 10px !important;\n  line-height: 1.4;\n}\n\n:where(\n  .signin-stat-dialog__content,\n  .cc-statistics-content,\n  .douban-dialog__content,\n  .maoyan-dialog__content,\n  .cover-history > main\n) {\n  padding: 20px !important;\n}\n\n:where(\n  .signin-stat-dialog__actions,\n  .cc-statistics-actions,\n  .douban-dialog__actions,\n  .maoyan-dialog__actions,\n  .cover-history > footer\n) {\n  min-height: 64px;\n  padding: 13px 18px !important;\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\n  background: var(--app-surface-raised, var(--app-surface, #fff));\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) {\n  gap: 12px !important;\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) > div {\n  min-width: 0;\n  padding: 15px 16px !important;\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\n  border-radius: 12px !important;\n  background: var(--app-surface, #fff);\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) dt,\n:where(.cover-history .metrics) span {\n  color: var(--app-text-muted, #7a869d);\n  font-size: 12px !important;\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics\n) dd,\n:where(.cover-history .metrics) strong {\n  margin-top: 7px;\n  color: var(--app-text, #202939);\n  font-family: inherit !important;\n  font-size: 24px !important;\n  font-weight: 700;\n  font-variant-numeric: tabular-nums;\n  line-height: 1.15;\n}\n\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\n.cookie-metric dd > span {\n  color: var(--app-text-muted, #7a869d);\n  font-size: 11px !important;\n  font-weight: 400;\n}\n\n.signin-stat-results {\n  border-radius: 12px !important;\n}\n\n.signin-stat-results > header {\n  min-height: 44px;\n  padding: 10px 12px !important;\n}\n\n.signin-stat-results article {\n  min-height: 68px;\n  padding: 10px 12px !important;\n}\n\n.signin-stat-results article strong {\n  color: var(--app-text, #202939);\n  font-size: 13px;\n  font-weight: 650;\n}\n\n.signin-stat-results article p {\n  font-size: 12px !important;\n}\n\n.signin-stat-results :is(article span, time) {\n  font-size: 10px !important;\n}\n\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\n  min-width: 0;\n  color: var(--app-text, #17243a);\n  font-family: inherit !important;\n  font-size: 14px;\n  line-height: 1.5;\n}\n\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\n  font-size: 27px !important;\n  font-weight: 750;\n  line-height: 1.15;\n  letter-spacing: 0;\n}\n\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\n  font-size: 18px !important;\n  font-weight: 700;\n  line-height: 1.3;\n}\n\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\n  min-height: 40px;\n  border-radius: 9px !important;\n  font-size: 13px;\n  letter-spacing: 0;\n}\n\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\n  min-height: 52px;\n  border-radius: 11px;\n  color: var(--app-text-secondary, #657087);\n  font: inherit;\n  font-size: 13px;\n}\n\n@media (max-width: 700px) {\n  :where(\n    .signin-stat-dialog__header,\n    .cc-statistics-header,\n    .douban-dialog__header,\n    .maoyan-dialog__header,\n    .cover-history > header,\n    .signin-stat-dialog__content,\n    .cc-statistics-content,\n    .douban-dialog__content,\n    .maoyan-dialog__content,\n    .cover-history > main\n  ) {\n    padding: 16px !important;\n  }\n}\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1 = { class: "maoyan-dialog__header" };
const _hoisted_2 = { class: "maoyan-dialog__content" };
const _hoisted_3 = {
  key: 0,
  class: "maoyan-dialog__message",
  role: "status"
};
const _hoisted_4 = {
  key: 2,
  class: "maoyan-statistics",
  "aria-label": "猫眼榜单订阅统计"
};
const _hoisted_5 = { class: "maoyan-statistics__metrics" };
const _hoisted_6 = {
  class: "maoyan-statistics__page-info",
  "aria-live": "polite"
};
const _hoisted_7 = { class: "maoyan-statistics__grid" };
const _hoisted_8 = { class: "maoyan-subscription__poster" };
const _hoisted_9 = ["src", "alt", "onError"];
const _hoisted_10 = { key: 1 };
const _hoisted_11 = { class: "maoyan-subscription__body" };
const _hoisted_12 = ["title"];
const _hoisted_13 = { class: "maoyan-subscription__tags" };
const _hoisted_14 = ["title"];
const _hoisted_15 = { class: "maoyan-subscription__release" };
const _hoisted_16 = { class: "maoyan-subscription__time" };
const _hoisted_17 = ["datetime"];
const _hoisted_18 = {
  key: 0,
  class: "maoyan-statistics__pagination",
  "aria-label": "订阅记录分页"
};
const _hoisted_19 = {
  key: 1,
  class: "maoyan-dialog__message"
};
const _hoisted_20 = { class: "maoyan-dialog__actions" };
const ID$1 = "maoyan-rank";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: {},
    buttonComponent: {},
    cardComponent: {},
    dialogComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiButton = props.buttonComponent;
    const UiCard = props.cardComponent;
    const UiDialog = props.dialogComponent;
    const UiAlert = props.alertComponent;
    const history = ref({ items: [], total: 0, movie_count: 0, tv_count: 0, platform_count: 0, page: 1, pages: 1 });
    const loading = ref(false);
    const error = ref("");
    const failedPosters = ref(/* @__PURE__ */ new Set());
    let requestedPage = 1;
    function failureMessage(reason, fallback) {
      if (reason && typeof reason === "object" && "message" in reason) return String(reason.message || fallback);
      return fallback;
    }
    function posterUrl(value) {
      const raw = String(value || "");
      if (!raw) return "";
      if (raw.startsWith("/explore/image-proxy?")) return raw;
      try {
        const url = new URL(raw);
        if (!["https:", "http:"].includes(url.protocol)) return "";
        if (url.hostname === "image.tmdb.org") return `/explore/image-proxy?source_key=tmdb&url=${encodeURIComponent(raw)}`;
        return raw;
      } catch {
        return "";
      }
    }
    function subscriptionTime(value) {
      const text = String(value || "");
      const date = new Date(/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(text) ? `${text.replace(" ", "T")}Z` : text);
      return Number.isFinite(date.getTime()) ? date.toLocaleString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).replaceAll("/", "-") : "未知时间";
    }
    function markPosterFailed(id) {
      failedPosters.value = /* @__PURE__ */ new Set([...failedPosters.value, id]);
    }
    async function load(page = requestedPage) {
      if (loading.value) return;
      requestedPage = page;
      loading.value = true;
      error.value = "";
      try {
        history.value = await props.request(`/plugins/${ID$1}/api/statistics?page=${page}`);
        requestedPage = history.value.page;
        failedPosters.value = /* @__PURE__ */ new Set();
      } catch (reason) {
        error.value = failureMessage(reason, "订阅统计加载失败");
      } finally {
        loading.value = false;
      }
    }
    onMounted(() => load());
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(UiDialog), {
        "model-value": true,
        "max-width": 1480,
        width: "calc(100vw - 32px)",
        "onUpdate:modelValue": _cache[3] || (_cache[3] = (open) => {
          if (!open) __props.context.close();
        })
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "maoyan-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1, [
                _cache[4] || (_cache[4] = createElementVNode(
                  "div",
                  null,
                  [
                    createElementVNode("h2", null, "猫眼榜单订阅"),
                    createElementVNode("p", null, "只统计已被插件成功加入订阅的作品，可按来源平台核对自动订阅结果。")
                  ],
                  -1
                  /* CACHED */
                )),
                createVNode(unref(UiButton), {
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: __props.context.close
                }, null, 8, ["onClick"])
              ]),
              createElementVNode("div", _hoisted_2, [
                loading.value ? (openBlock(), createElementBlock("p", _hoisted_3, "正在读取订阅统计…")) : error.value ? (openBlock(), createBlock(unref(UiAlert), {
                  key: 1,
                  type: "error",
                  variant: "tonal"
                }, {
                  default: withCtx(() => [
                    createTextVNode(
                      toDisplayString(error.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  _: 1
                  /* STABLE */
                })) : (openBlock(), createElementBlock("section", _hoisted_4, [
                  createElementVNode("dl", _hoisted_5, [
                    createElementVNode("div", null, [
                      _cache[6] || (_cache[6] = createElementVNode(
                        "dt",
                        null,
                        "订阅记录",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("dd", null, [
                        createTextVNode(
                          toDisplayString(history.value.total) + " ",
                          1
                          /* TEXT */
                        ),
                        _cache[5] || (_cache[5] = createElementVNode(
                          "span",
                          null,
                          "条",
                          -1
                          /* CACHED */
                        ))
                      ])
                    ]),
                    createElementVNode("div", null, [
                      _cache[8] || (_cache[8] = createElementVNode(
                        "dt",
                        null,
                        "电影",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("dd", null, [
                        createTextVNode(
                          toDisplayString(history.value.movie_count) + " ",
                          1
                          /* TEXT */
                        ),
                        _cache[7] || (_cache[7] = createElementVNode(
                          "span",
                          null,
                          "条",
                          -1
                          /* CACHED */
                        ))
                      ])
                    ]),
                    createElementVNode("div", null, [
                      _cache[10] || (_cache[10] = createElementVNode(
                        "dt",
                        null,
                        "剧集／综艺",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("dd", null, [
                        createTextVNode(
                          toDisplayString(history.value.tv_count) + " ",
                          1
                          /* TEXT */
                        ),
                        _cache[9] || (_cache[9] = createElementVNode(
                          "span",
                          null,
                          "条",
                          -1
                          /* CACHED */
                        ))
                      ])
                    ]),
                    createElementVNode("div", null, [
                      _cache[12] || (_cache[12] = createElementVNode(
                        "dt",
                        null,
                        "来源平台",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("dd", null, [
                        createTextVNode(
                          toDisplayString(history.value.platform_count) + " ",
                          1
                          /* TEXT */
                        ),
                        _cache[11] || (_cache[11] = createElementVNode(
                          "span",
                          null,
                          "个",
                          -1
                          /* CACHED */
                        ))
                      ])
                    ])
                  ]),
                  history.value.total ? (openBlock(), createElementBlock(
                    Fragment,
                    { key: 0 },
                    [
                      createElementVNode("div", _hoisted_6, [
                        createElementVNode(
                          "span",
                          null,
                          "第 " + toDisplayString(history.value.page) + " / " + toDisplayString(history.value.pages) + " 页",
                          1
                          /* TEXT */
                        ),
                        createElementVNode(
                          "span",
                          null,
                          "本页 " + toDisplayString(history.value.items.length) + " 条",
                          1
                          /* TEXT */
                        )
                      ]),
                      createElementVNode("div", _hoisted_7, [
                        (openBlock(true), createElementBlock(
                          Fragment,
                          null,
                          renderList(history.value.items, (item) => {
                            return openBlock(), createElementBlock("article", {
                              key: item.id,
                              class: "maoyan-subscription"
                            }, [
                              createElementVNode("div", _hoisted_8, [
                                posterUrl(item.poster) && !failedPosters.value.has(item.id) ? (openBlock(), createElementBlock("img", {
                                  key: 0,
                                  src: posterUrl(item.poster),
                                  alt: `${item.title}海报`,
                                  loading: "lazy",
                                  onError: ($event) => markPosterFailed(item.id)
                                }, null, 40, _hoisted_9)) : (openBlock(), createElementBlock("span", _hoisted_10, "无海报"))
                              ]),
                              createElementVNode("div", _hoisted_11, [
                                createElementVNode("h3", {
                                  title: item.title
                                }, toDisplayString(item.title), 9, _hoisted_12),
                                createElementVNode("div", _hoisted_13, [
                                  createElementVNode(
                                    "span",
                                    null,
                                    toDisplayString(item.media_label),
                                    1
                                    /* TEXT */
                                  ),
                                  createElementVNode("span", {
                                    title: item.platform
                                  }, toDisplayString(item.platform), 9, _hoisted_14)
                                ]),
                                createElementVNode(
                                  "p",
                                  _hoisted_15,
                                  toDisplayString(item.release_info || "暂无上线信息"),
                                  1
                                  /* TEXT */
                                ),
                                createElementVNode("p", _hoisted_16, [
                                  _cache[13] || (_cache[13] = createTextVNode(
                                    "订阅时间：",
                                    -1
                                    /* CACHED */
                                  )),
                                  createElementVNode("time", {
                                    datetime: item.subscribed_at
                                  }, toDisplayString(subscriptionTime(item.subscribed_at)), 9, _hoisted_17)
                                ])
                              ])
                            ]);
                          }),
                          128
                          /* KEYED_FRAGMENT */
                        ))
                      ]),
                      history.value.pages > 1 ? (openBlock(), createElementBlock("nav", _hoisted_18, [
                        createVNode(unref(UiButton), {
                          variant: "text",
                          size: "small",
                          "prepend-icon": "mdi-chevron-left",
                          disabled: history.value.page <= 1 || loading.value,
                          onClick: _cache[0] || (_cache[0] = ($event) => load(history.value.page - 1))
                        }, {
                          default: withCtx(() => [..._cache[14] || (_cache[14] = [
                            createTextVNode(
                              "上一页",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["disabled"]),
                        createElementVNode(
                          "span",
                          null,
                          toDisplayString(history.value.page) + " / " + toDisplayString(history.value.pages),
                          1
                          /* TEXT */
                        ),
                        createVNode(unref(UiButton), {
                          variant: "text",
                          size: "small",
                          "append-icon": "mdi-chevron-right",
                          disabled: history.value.page >= history.value.pages || loading.value,
                          onClick: _cache[1] || (_cache[1] = ($event) => load(history.value.page + 1))
                        }, {
                          default: withCtx(() => [..._cache[15] || (_cache[15] = [
                            createTextVNode(
                              "下一页",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["disabled"])
                      ])) : createCommentVNode("v-if", true)
                    ],
                    64
                    /* STABLE_FRAGMENT */
                  )) : (openBlock(), createElementBlock("div", _hoisted_19, [..._cache[16] || (_cache[16] = [
                    createElementVNode(
                      "h3",
                      null,
                      "暂无订阅记录",
                      -1
                      /* CACHED */
                    ),
                    createElementVNode(
                      "p",
                      null,
                      "猫眼榜单中的作品成功加入订阅后，会显示在这里。",
                      -1
                      /* CACHED */
                    )
                  ])]))
                ]))
              ]),
              createElementVNode("footer", _hoisted_20, [
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: loading.value,
                  onClick: _cache[2] || (_cache[2] = ($event) => load())
                }, {
                  default: withCtx(() => [..._cache[17] || (_cache[17] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading"]),
                createVNode(unref(UiButton), {
                  class: "maoyan-dialog__config",
                  "prepend-icon": "mdi-cog-outline",
                  variant: "flat",
                  "aria-label": "配置猫眼榜单",
                  onClick: __props.context.configure
                }, {
                  default: withCtx(() => [..._cache[18] || (_cache[18] = [
                    createTextVNode(
                      "调整榜单设置",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["onClick"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-3ea12395"]]);
const ID = "maoyan-rank";
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const { Button, Card, Dialog, Alert } = sdk.ui.components;
  const Statistics = defineComponent2({
    name: "MaoyanStatistics",
    inheritAttrs: false,
    props: { context: { type: Object, required: true } },
    setup(props, { attrs }) {
      return () => h(StatisticsView, {
        ...attrs,
        context: props.context,
        request: sdk.request,
        buttonComponent: Button,
        cardComponent: Card,
        dialogComponent: Dialog,
        alertComponent: Alert
      });
    }
  });
  sdk.registerContribution({ pluginId: ID, slot: "plugin.statistics", key: "subscriptions", component: Statistics });
}
export {
  install
};
