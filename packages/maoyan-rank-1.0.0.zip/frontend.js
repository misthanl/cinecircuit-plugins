if (typeof document !== "undefined") { const id = "maoyan_rank"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.maoyan-statistics[data-v-6321182d] { display: grid; gap: 22px; min-width: 0;\n}\n.maoyan-statistics__metrics[data-v-6321182d] { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 24px; margin: 0 0 6px;\n}\n.maoyan-statistics__metrics > div[data-v-6321182d] { padding: 18px 24px; border-radius: 16px; background: var(--app-surface-muted);\n}\n.maoyan-statistics__metrics > div[data-v-6321182d]:first-child { background: var(--app-violet-soft);\n}\n.maoyan-statistics__metrics dt[data-v-6321182d] { color: var(--app-text-muted); font-size: 14px;\n}\n.maoyan-statistics__metrics > div:first-child dt[data-v-6321182d] { color: var(--app-violet-text);\n}\n.maoyan-statistics__metrics dd[data-v-6321182d] { margin: 10px 0 0; color: var(--app-text); font-size: 24px; font-weight: 600; font-variant-numeric: tabular-nums;\n}\n.maoyan-statistics__metrics dd span[data-v-6321182d] { font-size: 18px; font-weight: 500;\n}\n.maoyan-statistics__page-info[data-v-6321182d] { display: flex; justify-content: space-between; color: var(--app-text-muted); font-size: 13px;\n}\n.maoyan-statistics__grid[data-v-6321182d] { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; margin-top: -10px;\n}\n.maoyan-subscription[data-v-6321182d] { display: grid; grid-template-columns: 96px minmax(0, 1fr); align-items: start; gap: 14px; padding: 14px; min-width: 0; border: 1px solid var(--app-border-subtle); border-radius: 14px; background: var(--app-surface);\n}\n.maoyan-subscription__poster[data-v-6321182d] { display: grid; place-items: center; width: 100%; aspect-ratio: 2 / 3; overflow: hidden; border-radius: 8px; background: var(--app-surface-muted); color: var(--app-text-muted); font-size: 12px;\n}\n.maoyan-subscription__poster img[data-v-6321182d] { width: 100%; height: 100%; object-fit: cover;\n}\n.maoyan-subscription__body[data-v-6321182d] { min-width: 0; padding-top: 2px;\n}\n.maoyan-subscription h3[data-v-6321182d] { margin: 0 0 10px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--app-text); font-size: 15px; font-weight: 600;\n}\n.maoyan-subscription__tags[data-v-6321182d] { display: flex; flex-wrap: wrap; gap: 5px;\n}\n.maoyan-subscription__tags span[data-v-6321182d] { max-width: 100%; padding: 3px 8px; border-radius: 16px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; background: var(--app-surface-muted); color: var(--app-text-secondary); font-size: 10px;\n}\n.maoyan-subscription__release[data-v-6321182d] { margin: 11px 0 6px; color: var(--app-text-secondary); font-size: 14px; overflow-wrap: anywhere;\n}\n.maoyan-subscription__time[data-v-6321182d] { margin: 0; color: var(--app-text-muted); font-size: 12px; line-height: 1.8; overflow-wrap: anywhere; font-variant-numeric: tabular-nums;\n}\n.maoyan-statistics__pagination[data-v-6321182d] { display: flex; align-items: center; justify-content: center; gap: 14px; color: var(--app-text-muted); font-size: 12px;\n}\n.maoyan-dialog[data-v-6321182d] { display: flex; flex-direction: column; max-height: calc(100dvh - 32px); border: 1px solid var(--app-border); border-radius: 18px !important; background: var(--app-dialog-surface) !important; color: var(--app-text);\n}\n.maoyan-dialog__header[data-v-6321182d] { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 20px 24px;\n}\n.maoyan-dialog__header h2[data-v-6321182d] { margin: 0; font-size: 22px; font-weight: 600;\n}.maoyan-dialog__header p[data-v-6321182d]{margin:3px 0 0;color:var(--app-text-muted);font-size:11px}\n.maoyan-dialog__content[data-v-6321182d] { min-height: 0; overflow: auto; padding: 20px 24px; background: var(--app-surface-subtle);\n}\n.maoyan-dialog__actions[data-v-6321182d] { display: flex; align-items: center; justify-content: flex-end; gap: 12px; padding: 12px 24px; border-top: 1px solid var(--app-border-subtle);\n}\n.maoyan-dialog__config[data-v-6321182d] { color: var(--app-on-accent) !important; background: var(--app-violet-text) !important;\n}\n.maoyan-dialog__message[data-v-6321182d] { padding: 40px 12px; text-align: center; color: var(--app-text-muted);\n}\n.maoyan-statistics__pagination button[data-v-6321182d]:focus-visible { outline: 2px solid var(--app-violet-text); outline-offset: 2px;\n}\n@media (max-width: 1250px) {\n.maoyan-statistics__grid[data-v-6321182d] { grid-template-columns: repeat(2, minmax(0, 1fr));\n}\n}\n@media (max-width: 600px) {\n.maoyan-statistics__metrics[data-v-6321182d] { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px;\n}\n.maoyan-statistics__metrics > div[data-v-6321182d] { padding: 14px 16px;\n}\n.maoyan-statistics__grid[data-v-6321182d] { grid-template-columns: minmax(0, 1fr);\n}\n.maoyan-dialog__content[data-v-6321182d], .maoyan-dialog__header[data-v-6321182d] { padding: 16px;\n}\n.maoyan-dialog__header h2[data-v-6321182d] { font-size: 18px;\n}\n}\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1 = { class: "maoyan-dialog__header" };
const _hoisted_2 = { class: "maoyan-dialog__content" };
const _hoisted_3 = {
  key: 0,
  class: "maoyan-dialog__message",
  role: "status"
};
const _hoisted_4 = {
  key: 2,
  class: "maoyan-statistics",
  "aria-label": "猫眼榜单订阅统计"
};
const _hoisted_5 = { class: "maoyan-statistics__metrics" };
const _hoisted_6 = {
  class: "maoyan-statistics__page-info",
  "aria-live": "polite"
};
const _hoisted_7 = { class: "maoyan-statistics__grid" };
const _hoisted_8 = { class: "maoyan-subscription__poster" };
const _hoisted_9 = ["src", "alt", "onError"];
const _hoisted_10 = { key: 1 };
const _hoisted_11 = { class: "maoyan-subscription__body" };
const _hoisted_12 = ["title"];
const _hoisted_13 = { class: "maoyan-subscription__tags" };
const _hoisted_14 = ["title"];
const _hoisted_15 = { class: "maoyan-subscription__release" };
const _hoisted_16 = { class: "maoyan-subscription__time" };
const _hoisted_17 = ["datetime"];
const _hoisted_18 = {
  key: 0,
  class: "maoyan-statistics__pagination",
  "aria-label": "订阅记录分页"
};
const _hoisted_19 = {
  key: 1,
  class: "maoyan-dialog__message"
};
const _hoisted_20 = { class: "maoyan-dialog__actions" };
const ID$1 = "maoyan-rank";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: {},
    buttonComponent: {},
    cardComponent: {},
    dialogComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiButton = props.buttonComponent;
    const UiCard = props.cardComponent;
    const UiDialog = props.dialogComponent;
    const UiAlert = props.alertComponent;
    const history = ref({ items: [], total: 0, movie_count: 0, tv_count: 0, platform_count: 0, page: 1, pages: 1 });
    const loading = ref(false);
    const error = ref("");
    const failedPosters = ref(/* @__PURE__ */ new Set());
    let requestedPage = 1;
    function failureMessage(reason, fallback) {
      if (reason && typeof reason === "object" && "message" in reason) return String(reason.message || fallback);
      return fallback;
    }
    function posterUrl(value) {
      const raw = String(value || "");
      if (!raw) return "";
      if (raw.startsWith("/explore/image-proxy?")) return raw;
      try {
        const url = new URL(raw);
        if (!["https:", "http:"].includes(url.protocol)) return "";
        if (url.hostname === "image.tmdb.org") return `/explore/image-proxy?source_key=tmdb&url=${encodeURIComponent(raw)}`;
        return raw;
      } catch {
        return "";
      }
    }
    function subscriptionTime(value) {
      const text = String(value || "");
      const date = new Date(/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(text) ? `${text.replace(" ", "T")}Z` : text);
      return Number.isFinite(date.getTime()) ? date.toLocaleString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).replaceAll("/", "-") : "未知时间";
    }
    function markPosterFailed(id) {
      failedPosters.value = /* @__PURE__ */ new Set([...failedPosters.value, id]);
    }
    async function load(page = requestedPage) {
      if (loading.value) return;
      requestedPage = page;
      loading.value = true;
      error.value = "";
      try {
        history.value = await props.request(`/plugins/${ID$1}/api/statistics?page=${page}`);
        requestedPage = history.value.page;
        failedPosters.value = /* @__PURE__ */ new Set();
      } catch (reason) {
        error.value = failureMessage(reason, "订阅统计加载失败");
      } finally {
        loading.value = false;
      }
    }
    onMounted(() => load());
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(UiDialog), {
        "model-value": true,
        "max-width": 1480,
        width: "calc(100vw - 32px)",
        "onUpdate:modelValue": _cache[3] || (_cache[3] = (open) => {
          if (!open) __props.context.close();
        })
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "maoyan-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1, [
                _cache[4] || (_cache[4] = createElementVNode(
                  "div",
                  null,
                  [
                    createElementVNode("h2", null, "猫眼榜单订阅"),
                    createElementVNode("p", null, "只统计已被插件成功加入订阅的作品，可按来源平台核对自动订阅结果。")
                  ],
                  -1
                  /* CACHED */
                )),
                createVNode(unref(UiButton), {
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: __props.context.close
                }, null, 8, ["onClick"])
              ]),
              createElementVNode("div", _hoisted_2, [
                loading.value ? (openBlock(), createElementBlock("p", _hoisted_3, "正在读取订阅统计…")) : error.value ? (openBlock(), createBlock(unref(UiAlert), {
                  key: 1,
                  type: "error",
                  variant: "tonal"
                }, {
                  default: withCtx(() => [
                    createTextVNode(
                      toDisplayString(error.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  _: 1
                  /* STABLE */
                })) : (openBlock(), createElementBlock("section", _hoisted_4, [
                  createElementVNode("dl", _hoisted_5, [
                    createElementVNode("div", null, [
                      _cache[6] || (_cache[6] = createElementVNode(
                        "dt",
                        null,
                        "订阅记录",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("dd", null, [
                        createTextVNode(
                          toDisplayString(history.value.total) + " ",
                          1
                          /* TEXT */
                        ),
                        _cache[5] || (_cache[5] = createElementVNode(
                          "span",
                          null,
                          "条",
                          -1
                          /* CACHED */
                        ))
                      ])
                    ]),
                    createElementVNode("div", null, [
                      _cache[8] || (_cache[8] = createElementVNode(
                        "dt",
                        null,
                        "电影",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("dd", null, [
                        createTextVNode(
                          toDisplayString(history.value.movie_count) + " ",
                          1
                          /* TEXT */
                        ),
                        _cache[7] || (_cache[7] = createElementVNode(
                          "span",
                          null,
                          "条",
                          -1
                          /* CACHED */
                        ))
                      ])
                    ]),
                    createElementVNode("div", null, [
                      _cache[10] || (_cache[10] = createElementVNode(
                        "dt",
                        null,
                        "剧集／综艺",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("dd", null, [
                        createTextVNode(
                          toDisplayString(history.value.tv_count) + " ",
                          1
                          /* TEXT */
                        ),
                        _cache[9] || (_cache[9] = createElementVNode(
                          "span",
                          null,
                          "条",
                          -1
                          /* CACHED */
                        ))
                      ])
                    ]),
                    createElementVNode("div", null, [
                      _cache[12] || (_cache[12] = createElementVNode(
                        "dt",
                        null,
                        "来源平台",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("dd", null, [
                        createTextVNode(
                          toDisplayString(history.value.platform_count) + " ",
                          1
                          /* TEXT */
                        ),
                        _cache[11] || (_cache[11] = createElementVNode(
                          "span",
                          null,
                          "个",
                          -1
                          /* CACHED */
                        ))
                      ])
                    ])
                  ]),
                  history.value.total ? (openBlock(), createElementBlock(
                    Fragment,
                    { key: 0 },
                    [
                      createElementVNode("div", _hoisted_6, [
                        createElementVNode(
                          "span",
                          null,
                          "第 " + toDisplayString(history.value.page) + " / " + toDisplayString(history.value.pages) + " 页",
                          1
                          /* TEXT */
                        ),
                        createElementVNode(
                          "span",
                          null,
                          "本页 " + toDisplayString(history.value.items.length) + " 条",
                          1
                          /* TEXT */
                        )
                      ]),
                      createElementVNode("div", _hoisted_7, [
                        (openBlock(true), createElementBlock(
                          Fragment,
                          null,
                          renderList(history.value.items, (item) => {
                            return openBlock(), createElementBlock("article", {
                              key: item.id,
                              class: "maoyan-subscription"
                            }, [
                              createElementVNode("div", _hoisted_8, [
                                posterUrl(item.poster) && !failedPosters.value.has(item.id) ? (openBlock(), createElementBlock("img", {
                                  key: 0,
                                  src: posterUrl(item.poster),
                                  alt: `${item.title}海报`,
                                  loading: "lazy",
                                  onError: ($event) => markPosterFailed(item.id)
                                }, null, 40, _hoisted_9)) : (openBlock(), createElementBlock("span", _hoisted_10, "无海报"))
                              ]),
                              createElementVNode("div", _hoisted_11, [
                                createElementVNode("h3", {
                                  title: item.title
                                }, toDisplayString(item.title), 9, _hoisted_12),
                                createElementVNode("div", _hoisted_13, [
                                  createElementVNode(
                                    "span",
                                    null,
                                    toDisplayString(item.media_label),
                                    1
                                    /* TEXT */
                                  ),
                                  createElementVNode("span", {
                                    title: item.platform
                                  }, toDisplayString(item.platform), 9, _hoisted_14)
                                ]),
                                createElementVNode(
                                  "p",
                                  _hoisted_15,
                                  toDisplayString(item.release_info || "暂无上线信息"),
                                  1
                                  /* TEXT */
                                ),
                                createElementVNode("p", _hoisted_16, [
                                  _cache[13] || (_cache[13] = createTextVNode(
                                    "订阅时间：",
                                    -1
                                    /* CACHED */
                                  )),
                                  createElementVNode("time", {
                                    datetime: item.subscribed_at
                                  }, toDisplayString(subscriptionTime(item.subscribed_at)), 9, _hoisted_17)
                                ])
                              ])
                            ]);
                          }),
                          128
                          /* KEYED_FRAGMENT */
                        ))
                      ]),
                      history.value.pages > 1 ? (openBlock(), createElementBlock("nav", _hoisted_18, [
                        createVNode(unref(UiButton), {
                          variant: "text",
                          size: "small",
                          "prepend-icon": "mdi-chevron-left",
                          disabled: history.value.page <= 1 || loading.value,
                          onClick: _cache[0] || (_cache[0] = ($event) => load(history.value.page - 1))
                        }, {
                          default: withCtx(() => [..._cache[14] || (_cache[14] = [
                            createTextVNode(
                              "上一页",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["disabled"]),
                        createElementVNode(
                          "span",
                          null,
                          toDisplayString(history.value.page) + " / " + toDisplayString(history.value.pages),
                          1
                          /* TEXT */
                        ),
                        createVNode(unref(UiButton), {
                          variant: "text",
                          size: "small",
                          "append-icon": "mdi-chevron-right",
                          disabled: history.value.page >= history.value.pages || loading.value,
                          onClick: _cache[1] || (_cache[1] = ($event) => load(history.value.page + 1))
                        }, {
                          default: withCtx(() => [..._cache[15] || (_cache[15] = [
                            createTextVNode(
                              "下一页",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["disabled"])
                      ])) : createCommentVNode("v-if", true)
                    ],
                    64
                    /* STABLE_FRAGMENT */
                  )) : (openBlock(), createElementBlock("div", _hoisted_19, [..._cache[16] || (_cache[16] = [
                    createElementVNode(
                      "h3",
                      null,
                      "暂无订阅记录",
                      -1
                      /* CACHED */
                    ),
                    createElementVNode(
                      "p",
                      null,
                      "猫眼榜单中的作品成功加入订阅后，会显示在这里。",
                      -1
                      /* CACHED */
                    )
                  ])]))
                ]))
              ]),
              createElementVNode("footer", _hoisted_20, [
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: loading.value,
                  onClick: _cache[2] || (_cache[2] = ($event) => load())
                }, {
                  default: withCtx(() => [..._cache[17] || (_cache[17] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading"]),
                createVNode(unref(UiButton), {
                  class: "maoyan-dialog__config",
                  "prepend-icon": "mdi-cog-outline",
                  variant: "flat",
                  "aria-label": "配置猫眼榜单",
                  onClick: __props.context.configure
                }, {
                  default: withCtx(() => [..._cache[18] || (_cache[18] = [
                    createTextVNode(
                      "调整榜单设置",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["onClick"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-6321182d"]]);
const ID = "maoyan-rank";
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const { Button, Card, Dialog, Alert } = sdk.ui.components;
  const Statistics = defineComponent2({
    name: "MaoyanStatistics",
    inheritAttrs: false,
    props: { context: { type: Object, required: true } },
    setup(props, { attrs }) {
      return () => h(StatisticsView, {
        ...attrs,
        context: props.context,
        request: sdk.request,
        buttonComponent: Button,
        cardComponent: Card,
        dialogComponent: Dialog,
        alertComponent: Alert
      });
    }
  });
  sdk.registerContribution({ pluginId: ID, slot: "plugin.statistics", key: "subscriptions", component: Statistics });
}
export {
  install
};
