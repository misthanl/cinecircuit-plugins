if (typeof document !== "undefined") { const id = "cookiecloud"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.cookiecloud-config-fields[data-v-012f5b08] {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 18px 14px;\n}\n.cookiecloud-config-hint[data-v-012f5b08] {\n  grid-column: 1 / -1;\n  margin: 0;\n  color: var(--app-text-muted);\n  font-size: 12px;\n}\n@media (max-width: 600px) {\n.cookiecloud-config-fields[data-v-012f5b08] {\n    grid-template-columns: 1fr;\n}\n}\n\n.cc-statistics-dialog[data-v-24ea080e]{display:flex;flex-direction:column;max-height:calc(100dvh - 32px);border:1px solid var(--app-border);border-radius:18px!important;background:var(--app-dialog-surface)!important;color:var(--app-text)}\n.cc-statistics-header[data-v-24ea080e]{display:flex;align-items:center;gap:12px;padding:20px;border-bottom:1px solid var(--app-border-subtle)}\n.cc-statistics-header>div[data-v-24ea080e]{flex:1;min-width:0}.cc-statistics-header h2[data-v-24ea080e]{font-size:18px;margin:0;line-height:1.2}.cc-statistics-header p[data-v-24ea080e]{font-size:10px;color:var(--app-text-muted);margin:2px 0 0}\n.cc-statistics-logo[data-v-24ea080e]{display:grid;place-items:center;width:44px;height:44px;flex-shrink:0;border-radius:13px;background:var(--app-info-soft);color:rgb(var(--v-theme-primary))}\n.cc-statistics-content[data-v-24ea080e]{min-height:0;overflow:auto;padding:20px}.cc-statistics-actions[data-v-24ea080e]{display:flex;justify-content:flex-end;padding:12px 20px;border-top:1px solid var(--app-border-subtle)}.cc-statistics-message[data-v-24ea080e]{padding:40px 12px;text-align:center;color:var(--app-text-muted)}\n.cookie-overview[data-v-24ea080e]{display:grid;gap:18px;min-width:0;color:var(--app-text)}.cookie-tone--neutral[data-v-24ea080e]{--cookie-tone:var(--app-text-secondary)}.cookie-tone--primary[data-v-24ea080e]{--cookie-tone:rgb(var(--v-theme-primary))}.cookie-tone--success[data-v-24ea080e]{--cookie-tone:rgb(var(--v-theme-success))}.cookie-tone--error[data-v-24ea080e]{--cookie-tone:rgb(var(--v-theme-error))}.cookie-tone--muted[data-v-24ea080e]{--cookie-tone:var(--app-text-muted)}\n.cookie-overview__heading[data-v-24ea080e]{display:flex;align-items:baseline;justify-content:space-between;gap:12px;margin-top:6px}.cookie-overview__heading h3[data-v-24ea080e]{margin:0;font-size:15px;font-weight:650}.cookie-overview__heading>span[data-v-24ea080e]{color:var(--app-text-muted);font-size:12px}\n.cookie-metrics[data-v-24ea080e]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:0}.cookie-metric[data-v-24ea080e]{padding:15px 16px;border:1px solid color-mix(in srgb,var(--cookie-tone) 15%,transparent);border-radius:12px;background:color-mix(in srgb,var(--cookie-tone) 5%,transparent)}.cookie-metric dt[data-v-24ea080e]{display:flex;align-items:center;justify-content:space-between;gap:8px;color:var(--app-text-secondary);font-size:12px}.cookie-metric dt .v-icon[data-v-24ea080e]{color:var(--cookie-tone)}.cookie-metric dd[data-v-24ea080e]{display:flex;align-items:baseline;gap:6px;margin:7px 0 0;color:var(--cookie-tone);font-family:inherit;font-size:24px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1.15}.cookie-metric dd>span[data-v-24ea080e]{color:var(--app-text-muted);font-size:11px;font-weight:400}\n.cookie-results[data-v-24ea080e]{display:grid;gap:12px}.cookie-results__bar[data-v-24ea080e]{display:flex;gap:4px;height:6px;overflow:hidden;border-radius:4px}.cookie-results__bar>span[data-v-24ea080e]{min-width:2px;background:var(--cookie-tone)}.cookie-results__legend[data-v-24ea080e]{display:flex;flex-wrap:wrap;gap:10px 20px;padding:0;margin:0;list-style:none}.cookie-results__legend li[data-v-24ea080e]{display:flex;align-items:center;gap:7px;color:var(--app-text-secondary);font-size:12px}.cookie-results__legend i[data-v-24ea080e]{width:6px;height:6px;border-radius:50%;background:var(--cookie-tone)}.cookie-results__legend strong[data-v-24ea080e]{color:var(--app-text);font-variant-numeric:tabular-nums}.cookie-results p[data-v-24ea080e]{margin:0;color:var(--app-text-muted);font-size:11px}.cookie-results .cookie-results__empty[data-v-24ea080e]{padding:8px 0;font-size:13px}\n.cookie-schedule[data-v-24ea080e]{display:flex;align-items:center;gap:12px;padding:18px 0 2px;border-top:1px solid var(--app-border-subtle)}.cookie-schedule__icon[data-v-24ea080e]{display:grid;place-items:center;width:42px;height:42px;flex:0 0 auto;border-radius:12px;color:rgb(var(--v-theme-primary));background:rgba(var(--v-theme-primary),.08)}.cookie-schedule__time[data-v-24ea080e]{display:grid;flex:1;gap:5px;min-width:0}.cookie-schedule__time>span[data-v-24ea080e]{color:var(--app-text-muted);font-size:12px}.cookie-schedule__time strong[data-v-24ea080e]{font-size:14px;font-weight:600;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}\n@media(max-width:600px){.cc-statistics-header h2[data-v-24ea080e]{font-size:16px}.cookie-metrics[data-v-24ea080e]{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.cookie-schedule[data-v-24ea080e]{flex-wrap:wrap}}\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\n * Values mirror the host application's standard configuration dialog and\n * operational content density. Keep business-specific layouts in each plugin.\n */\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .signin-page,\n  .brush,\n  .cover,\n  .subtitle-workspace,\n  .signin-stat-dialog,\n  .cc-statistics-dialog,\n  .douban-dialog,\n  .maoyan-dialog,\n  .cover-history\n) {\n  color: var(--app-text, #1a2434);\n  font-family: var(--app-font-family, inherit) !important;\n  font-size: var(--app-font-size-body, 14px);\n  font-weight: var(--app-font-weight-regular, 400);\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-field) {\n  min-height: var(--app-control-height, 52px);\n  border-radius: 11px;\n  background: var(--control-surface, var(--app-surface, #fff));\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-field__input) {\n  min-width: 0;\n  min-height: var(--app-control-height, 52px) !important;\n  color: var(--app-text-secondary, #657087);\n  font-size: var(--app-font-size-control, 14px);\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-label.v-field-label) {\n  color: var(--app-text-secondary, #657087);\n  font-size: var(--app-font-size-label, 11px);\n}\n\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .cover-history) {\n  overflow: hidden;\n  border: 1px solid var(--app-border, #dfe4ee) !important;\n  border-radius: 18px !important;\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\n  color: var(--app-text, #202939);\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header,\n  .cover-history > header\n) {\n  min-height: 80px;\n  padding: 18px 20px !important;\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\n  background: var(--app-surface, #fff);\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header,\n  .cover-history > header\n) h2 {\n  margin: 0;\n  color: var(--app-text, #202939);\n  font-size: var(--app-font-size-section-title, 18px) !important;\n  font-weight: var(--app-font-weight-heading, 750) !important;\n  line-height: 1.2;\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header\n) p {\n  margin: 3px 0 0;\n  color: var(--app-text-muted, #7a869d);\n  font-size: var(--app-font-size-helper, 10px) !important;\n  line-height: 1.4;\n}\n\n:where(\n  .signin-stat-dialog__content,\n  .cc-statistics-content,\n  .douban-dialog__content,\n  .maoyan-dialog__content,\n  .cover-history > main\n) {\n  padding: 20px !important;\n}\n\n:where(\n  .signin-stat-dialog__actions,\n  .cc-statistics-actions,\n  .douban-dialog__actions,\n  .maoyan-dialog__actions,\n  .cover-history > footer\n) {\n  min-height: 64px;\n  padding: 13px 18px !important;\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\n  background: var(--app-surface-raised, var(--app-surface, #fff));\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) {\n  gap: 12px !important;\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) > div {\n  min-width: 0;\n  padding: 15px 16px !important;\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\n  border-radius: 12px !important;\n  background: var(--app-surface, #fff);\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) dt,\n:where(.cover-history .metrics) span {\n  color: var(--app-text-muted, #7a869d);\n  font-size: 12px !important;\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics\n) dd,\n:where(.cover-history .metrics) strong {\n  margin-top: 7px;\n  color: var(--app-text, #202939);\n  font-family: inherit !important;\n  font-size: var(--app-font-size-metric, 24px) !important;\n  font-weight: var(--app-font-weight-metric, 700);\n  font-variant-numeric: tabular-nums;\n  line-height: 1.15;\n}\n\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\n.cookie-metric dd > span {\n  color: var(--app-text-muted, #7a869d);\n  font-size: 11px !important;\n  font-weight: var(--app-font-weight-regular, 400);\n}\n\n.signin-stat-results {\n  border-radius: 12px !important;\n}\n\n.signin-stat-results > header {\n  min-height: 44px;\n  padding: 10px 12px !important;\n}\n\n.signin-stat-results article {\n  min-height: 68px;\n  padding: 10px 12px !important;\n}\n\n.signin-stat-results article strong {\n  color: var(--app-text, #202939);\n  font-size: 13px;\n  font-weight: var(--app-font-weight-medium, 650);\n}\n\n.signin-stat-results article p {\n  font-size: 12px !important;\n}\n\n.signin-stat-results :is(article span, time) {\n  font-size: 10px !important;\n}\n\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\n  min-width: 0;\n  color: var(--app-text, #17243a);\n  font-family: var(--app-font-family, inherit) !important;\n  font-size: var(--app-font-size-body, 14px);\n  line-height: 1.5;\n}\n\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\n  font-size: 27px !important;\n  font-weight: 750;\n  line-height: 1.15;\n  letter-spacing: 0;\n}\n\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\n  font-size: var(--app-font-size-section-title, 18px) !important;\n  font-weight: var(--app-font-weight-metric, 700);\n  line-height: 1.3;\n}\n\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\n  min-height: 40px;\n  border-radius: 9px !important;\n  font-size: 13px;\n  letter-spacing: 0;\n}\n\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\n  min-height: 52px;\n  border-radius: 11px;\n  color: var(--app-text-secondary, #657087);\n  font: inherit;\n  font-size: var(--app-font-size-control, 14px);\n}\n\n@media (max-width: 700px) {\n  :where(\n    .signin-stat-dialog__header,\n    .cc-statistics-header,\n    .douban-dialog__header,\n    .maoyan-dialog__header,\n    .cover-history > header,\n    .signin-stat-dialog__content,\n    .cc-statistics-content,\n    .douban-dialog__content,\n    .maoyan-dialog__content,\n    .cover-history > main\n  ) {\n    padding: 16px !important;\n  }\n}\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const normalizeStyle = runtime.normalizeStyle;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveComponent = runtime.resolveComponent;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1$1 = { class: "cookiecloud-config-fields" };
const _hoisted_2$1 = {
  key: 0,
  class: "cookiecloud-config-hint",
  role: "alert"
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ConnectionEditor",
  props: {
    disabled: { type: Boolean, default: false },
    modelValue: {},
    request: {}
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const passwordVisible = ref(false);
    const restoredPassword = ref("");
    const restoredUserKey = ref("");
    const revealError = ref("");
    let passwordLoad = null;
    const periods = [
      { value: "0 */6 * * *", title: "每 6 小时" },
      { value: "0 */12 * * *", title: "每 12 小时" },
      { value: "", title: "每天" },
      { value: "0 0 * * 1", title: "每周" },
      { value: "0 0 1 * *", title: "每月" }
    ];
    function update(key, value) {
      emit("update:modelValue", { ...props.modelValue, [key]: value });
    }
    async function loadPassword() {
      if (props.modelValue.password || restoredPassword.value) return;
      passwordLoad ||= props.request("/plugins/cookiecloud/config/secret/password").then((response) => {
        restoredPassword.value = response.value || "";
      });
      try {
        await passwordLoad;
      } catch (reason) {
        passwordLoad = null;
        throw reason;
      }
    }
    async function togglePassword() {
      if (passwordVisible.value) {
        passwordVisible.value = false;
        return;
      }
      revealError.value = "";
      try {
        await loadPassword();
        passwordVisible.value = true;
      } catch {
        revealError.value = "密码读取失败，请重试";
      }
    }
    onMounted(async () => {
      const failures = [];
      try {
        if (!props.modelValue.user_key) {
          const response = await props.request("/plugins/cookiecloud/config/secret/user_key");
          restoredUserKey.value = response.value || "";
        }
      } catch {
        failures.push("KEY");
      }
      try {
        await loadPassword();
      } catch {
        failures.push("密码");
      }
      if (failures.length) revealError.value = `${failures.join("和")}读取失败，请重试`;
    });
    return (_ctx, _cache) => {
      const _component_VSwitch = resolveComponent("VSwitch");
      const _component_VTextField = resolveComponent("VTextField");
      const _component_VSelect = resolveComponent("VSelect");
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        revealError.value ? (openBlock(), createElementBlock(
          "p",
          _hoisted_2$1,
          toDisplayString(revealError.value),
          1
          /* TEXT */
        )) : createCommentVNode("v-if", true),
        createVNode(_component_VSwitch, {
          "model-value": Boolean(__props.modelValue.enabled),
          disabled: __props.disabled,
          label: "启用站点 Cookie 同步",
          color: "primary",
          "hide-details": "",
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => update("enabled", $event))
        }, null, 8, ["model-value", "disabled"]),
        createVNode(_component_VSwitch, {
          "model-value": Boolean(__props.modelValue.run_once),
          disabled: __props.disabled,
          label: "保存后立即运行一次",
          color: "primary",
          "hide-details": "",
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => update("run_once", $event))
        }, null, 8, ["model-value", "disabled"]),
        createVNode(_component_VTextField, {
          "model-value": __props.modelValue.user_key || restoredUserKey.value,
          disabled: __props.disabled,
          label: "用户 KEY",
          "prepend-inner-icon": "mdi-key-outline",
          autocomplete: "off",
          "hide-details": "",
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => {
            restoredUserKey.value = "";
            update("user_key", $event);
          })
        }, null, 8, ["model-value", "disabled"]),
        createVNode(_component_VTextField, {
          "model-value": __props.modelValue.password || restoredPassword.value,
          disabled: __props.disabled,
          label: "端对端加密密码",
          type: passwordVisible.value ? "text" : "password",
          "prepend-inner-icon": "mdi-lock-outline",
          "append-inner-icon": passwordVisible.value ? "mdi-eye-off-outline" : "mdi-eye-outline",
          autocomplete: "off",
          "hide-details": "",
          "onClick:appendInner": togglePassword,
          "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => {
            restoredPassword.value = "";
            update("password", $event);
          })
        }, null, 8, ["model-value", "disabled", "type", "append-inner-icon"]),
        createVNode(_component_VSelect, {
          "model-value": __props.modelValue.cron || "",
          disabled: __props.disabled,
          label: "定时检查周期",
          "prepend-inner-icon": "mdi-calendar-clock",
          items: periods,
          "hide-details": "",
          "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => update("cron", $event))
        }, null, 8, ["model-value", "disabled"]),
        createVNode(_component_VSwitch, {
          "model-value": Boolean(__props.modelValue.notification_enabled),
          disabled: __props.disabled,
          label: "发送通知",
          color: "primary",
          "hide-details": "",
          "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => update("notification_enabled", $event))
        }, null, 8, ["model-value", "disabled"])
      ]);
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const ConnectionEditorView = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-012f5b08"]]);
const _hoisted_1 = { class: "cc-statistics-header" };
const _hoisted_2 = { class: "cc-statistics-logo" };
const _hoisted_3 = { class: "cc-statistics-content" };
const _hoisted_4 = {
  key: 0,
  class: "cc-statistics-message",
  role: "status"
};
const _hoisted_5 = {
  key: 2,
  class: "cookie-overview",
  "aria-label": "CookieCloud 同步概览"
};
const _hoisted_6 = { class: "cookie-metrics" };
const _hoisted_7 = { class: "cookie-results" };
const _hoisted_8 = {
  class: "cookie-results__bar",
  "aria-hidden": "true"
};
const _hoisted_9 = {
  class: "cookie-results__legend",
  "aria-label": "运行结果分布"
};
const _hoisted_10 = {
  key: 1,
  class: "cookie-results__empty"
};
const _hoisted_11 = { class: "cookie-schedule" };
const _hoisted_12 = { class: "cookie-schedule__icon" };
const _hoisted_13 = { class: "cookie-schedule__time" };
const _hoisted_14 = { class: "cc-statistics-actions" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: {},
    buttonComponent: {},
    cardComponent: {},
    dialogComponent: {},
    chipComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiButton = props.buttonComponent;
    const UiCard = props.cardComponent;
    const UiDialog = props.dialogComponent;
    const UiChip = props.chipComponent;
    const UiAlert = props.alertComponent;
    const runs = ref([]);
    const loading = ref(false);
    const error = ref("");
    const groups = computed(() => {
      const definitions = [
        { label: "成功", tone: "success", icon: "mdi-check-circle-outline", states: ["completed"] },
        { label: "异常", tone: "error", icon: "mdi-alert-circle-outline", states: ["failed", "partial"] },
        { label: "进行中", tone: "primary", icon: "mdi-refresh", states: ["running", "pending"] },
        { label: "已跳过", tone: "muted", icon: "", states: ["skipped"] },
        { label: "其他", tone: "muted", icon: "", states: [] }
      ];
      const known = definitions.flatMap((group) => group.states);
      return definitions.map((group) => ({ ...group, count: runs.value.filter((run) => {
        const state = run.display_status || run.status || "";
        return group.states.includes(state) || group.label === "其他" && !known.includes(state);
      }).length }));
    });
    const visibleGroups = computed(() => groups.value.filter((group) => group.count > 0));
    const metrics = computed(() => [
      { label: "运行次数", tone: "neutral", icon: "mdi-cloud-sync-outline", count: runs.value.length },
      ...groups.value.slice(0, 3)
    ]);
    function localTime(value, fallback) {
      if (!value) return fallback;
      const text = String(value);
      const date = new Date(/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(text) ? `${text.replace(" ", "T")}Z` : text);
      return Number.isFinite(date.getTime()) ? date.toLocaleString("zh-CN", { hour12: false }) : fallback;
    }
    async function load() {
      if (loading.value) return;
      loading.value = true;
      error.value = "";
      try {
        runs.value = (await props.request("/plugins/cookiecloud/runs?limit=100")).items || [];
      } catch (reason) {
        error.value = reason && typeof reason === "object" && "message" in reason ? String(reason.message || "插件统计加载失败") : "插件统计加载失败";
      } finally {
        loading.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      const _component_VIcon = resolveComponent("VIcon");
      return openBlock(), createBlock(unref(UiDialog), {
        "model-value": true,
        "max-width": 780,
        width: "calc(100vw - 32px)",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = (open) => {
          if (!open) __props.context.close();
        })
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "cc-statistics-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1, [
                createElementVNode("span", _hoisted_2, [
                  createVNode(_component_VIcon, {
                    icon: "mdi-cloud-sync-outline",
                    size: 22
                  })
                ]),
                _cache[1] || (_cache[1] = createElementVNode(
                  "div",
                  null,
                  [
                    createElementVNode("h2", null, "CookieCloud 站点同步 · 数据统计"),
                    createElementVNode("p", null, "浏览器 Cookie 同步与站点更新概览")
                  ],
                  -1
                  /* CACHED */
                )),
                createVNode(unref(UiButton), {
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: __props.context.close
                }, null, 8, ["onClick"])
              ]),
              createElementVNode("div", _hoisted_3, [
                loading.value ? (openBlock(), createElementBlock("p", _hoisted_4, "正在读取插件统计…")) : error.value ? (openBlock(), createBlock(unref(UiAlert), {
                  key: 1,
                  type: "error",
                  variant: "tonal"
                }, {
                  default: withCtx(() => [
                    createTextVNode(
                      toDisplayString(error.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  _: 1
                  /* STABLE */
                })) : (openBlock(), createElementBlock("section", _hoisted_5, [
                  _cache[6] || (_cache[6] = createElementVNode(
                    "div",
                    { class: "cookie-overview__heading" },
                    [
                      createElementVNode("h3", null, "运行概览"),
                      createElementVNode("span", null, "最近 100 次运行")
                    ],
                    -1
                    /* CACHED */
                  )),
                  createElementVNode("dl", _hoisted_6, [
                    (openBlock(true), createElementBlock(
                      Fragment,
                      null,
                      renderList(metrics.value, (metric) => {
                        return openBlock(), createElementBlock(
                          "div",
                          {
                            key: metric.label,
                            class: normalizeClass(["cookie-metric", `cookie-tone--${metric.tone}`])
                          },
                          [
                            createElementVNode("dt", null, [
                              createElementVNode(
                                "span",
                                null,
                                toDisplayString(metric.label),
                                1
                                /* TEXT */
                              ),
                              metric.icon ? (openBlock(), createBlock(_component_VIcon, {
                                key: 0,
                                icon: metric.icon,
                                size: 18
                              }, null, 8, ["icon"])) : createCommentVNode("v-if", true)
                            ]),
                            createElementVNode("dd", null, [
                              createTextVNode(
                                toDisplayString(metric.count),
                                1
                                /* TEXT */
                              ),
                              _cache[2] || (_cache[2] = createElementVNode(
                                "span",
                                null,
                                "次",
                                -1
                                /* CACHED */
                              ))
                            ])
                          ],
                          2
                          /* CLASS */
                        );
                      }),
                      128
                      /* KEYED_FRAGMENT */
                    ))
                  ]),
                  createElementVNode("div", _hoisted_7, [
                    runs.value.length ? (openBlock(), createElementBlock(
                      Fragment,
                      { key: 0 },
                      [
                        createElementVNode("div", _hoisted_8, [
                          (openBlock(true), createElementBlock(
                            Fragment,
                            null,
                            renderList(visibleGroups.value, (group) => {
                              return openBlock(), createElementBlock(
                                "span",
                                {
                                  key: group.label,
                                  class: normalizeClass(`cookie-tone--${group.tone}`),
                                  style: normalizeStyle({ flex: group.count })
                                },
                                null,
                                6
                                /* CLASS, STYLE */
                              );
                            }),
                            128
                            /* KEYED_FRAGMENT */
                          ))
                        ]),
                        createElementVNode("ul", _hoisted_9, [
                          (openBlock(true), createElementBlock(
                            Fragment,
                            null,
                            renderList(visibleGroups.value, (group) => {
                              return openBlock(), createElementBlock(
                                "li",
                                {
                                  key: group.label,
                                  class: normalizeClass(`cookie-tone--${group.tone}`)
                                },
                                [
                                  _cache[3] || (_cache[3] = createElementVNode(
                                    "i",
                                    { "aria-hidden": "true" },
                                    null,
                                    -1
                                    /* CACHED */
                                  )),
                                  createTextVNode(
                                    toDisplayString(group.label),
                                    1
                                    /* TEXT */
                                  ),
                                  createElementVNode(
                                    "strong",
                                    null,
                                    toDisplayString(group.count),
                                    1
                                    /* TEXT */
                                  )
                                ],
                                2
                                /* CLASS */
                              );
                            }),
                            128
                            /* KEYED_FRAGMENT */
                          ))
                        ]),
                        _cache[4] || (_cache[4] = createElementVNode(
                          "p",
                          null,
                          "异常包含失败和部分成功",
                          -1
                          /* CACHED */
                        ))
                      ],
                      64
                      /* STABLE_FRAGMENT */
                    )) : (openBlock(), createElementBlock("p", _hoisted_10, "暂无运行数据，首次同步后将在这里显示统计。"))
                  ]),
                  createElementVNode("div", _hoisted_11, [
                    createElementVNode("span", _hoisted_12, [
                      createVNode(_component_VIcon, {
                        icon: "mdi-clock-outline",
                        size: 22
                      })
                    ]),
                    createElementVNode("div", _hoisted_13, [
                      _cache[5] || (_cache[5] = createElementVNode(
                        "span",
                        null,
                        "下次执行",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "strong",
                        null,
                        toDisplayString(__props.context.installation?.enabled ? localTime(__props.context.installation.next_run_at, "等待调度") : "已停用"),
                        1
                        /* TEXT */
                      )
                    ]),
                    createVNode(unref(UiChip), {
                      color: __props.context.installation?.enabled ? "primary" : void 0,
                      size: "small",
                      variant: "tonal"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(
                          toDisplayString(__props.context.installation?.enabled ? "调度已启用" : "调度已停用"),
                          1
                          /* TEXT */
                        )
                      ]),
                      _: 1
                      /* STABLE */
                    }, 8, ["color"])
                  ])
                ]))
              ]),
              createElementVNode("footer", _hoisted_14, [
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: loading.value,
                  onClick: load
                }, {
                  default: withCtx(() => [..._cache[7] || (_cache[7] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-24ea080e"]]);
const ID = "cookiecloud";
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const { Button, Card, Dialog, Chip, Alert } = sdk.ui.components;
  const Statistics = defineComponent2({
    name: "CookieCloudStatistics",
    inheritAttrs: false,
    props: { context: { type: Object, required: true } },
    setup(props, { attrs }) {
      return () => h(StatisticsView, {
        ...attrs,
        context: props.context,
        request: sdk.request,
        buttonComponent: Button,
        cardComponent: Card,
        dialogComponent: Dialog,
        chipComponent: Chip,
        alertComponent: Alert
      });
    }
  });
  const ConnectionEditor = defineComponent2({
    name: "CookieCloudConnectionEditor",
    inheritAttrs: false,
    props: { modelValue: { type: Object, required: true }, disabled: Boolean },
    emits: ["update:modelValue"],
    setup(props, { attrs, emit }) {
      return () => h(ConnectionEditorView, {
        ...attrs,
        disabled: props.disabled,
        modelValue: props.modelValue,
        request: (path, init) => sdk.request(path, init),
        "onUpdate:modelValue": (value) => emit("update:modelValue", value)
      });
    }
  });
  sdk.registerEditor({ domain: "plugin", key: ID, component: ConnectionEditor });
  sdk.registerEditor({ domain: "plugin", key: `${ID}:connection`, component: ConnectionEditor });
  sdk.registerContribution({ pluginId: ID, slot: "plugin.statistics", key: "overview", component: Statistics });
}
export {
  install
};
