if (typeof document !== "undefined") { const id = "douban_rank"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.douban-statistics[data-v-d7e575ef] { display: grid; gap: 22px; min-width: 0;\n}\n.douban-run[data-v-d7e575ef] { border-block: 1px solid var(--app-border-subtle); padding-block: 12px;\n}\n.douban-run__heading[data-v-d7e575ef] { display: flex; align-items: center; justify-content: space-between; gap: 12px;\n}\n.douban-run__heading h3[data-v-d7e575ef] { margin: 0; color: var(--app-text); font-size: var(--app-font-size-body);\n}\n.douban-run__heading span[data-v-d7e575ef] { color: var(--app-text-muted); font-weight: normal;\n}\n.douban-run__filters[data-v-d7e575ef] { display: flex; gap: 8px;\n}\n.douban-run__table[data-v-d7e575ef] { overflow-x: auto;\n}\n.douban-run table[data-v-d7e575ef] { width: 100%; min-width: 640px; table-layout: fixed; border-collapse: collapse; text-align: left;\n}\n.douban-run th[data-v-d7e575ef], .douban-run td[data-v-d7e575ef] { padding: 14px 12px; border-bottom: 1px solid var(--app-border-subtle);\n}\n.douban-run td[data-v-d7e575ef] { overflow-wrap: anywhere;\n}\n.douban-run th[data-v-d7e575ef] { color: var(--app-text-muted); background: var(--app-surface-muted); white-space: nowrap;\n}\n.douban-run__status[data-v-d7e575ef] { white-space: nowrap; color: var(--app-primary, #2968ff);\n}\n.douban-run__status.is-retry[data-v-d7e575ef] { color: var(--app-warning, #b76a00);\n}\n.douban-statistics__metrics[data-v-d7e575ef] { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; margin: 0 0 6px;\n}\n.douban-statistics__metrics > div[data-v-d7e575ef] { padding: 15px 16px; border: 1px solid var(--app-border-subtle); border-radius: 12px; background: var(--app-surface-muted);\n}\n.douban-statistics__metrics dt[data-v-d7e575ef] { color: var(--app-text-muted); font-size: 12px;\n}\n.douban-statistics__metrics dd[data-v-d7e575ef] { margin: 10px 0 0; color: var(--app-text); font-size: 24px; font-weight: 600; font-variant-numeric: tabular-nums;\n}\n.douban-statistics__metrics dd span[data-v-d7e575ef] { font-size: 11px; font-weight: 400;\n}\n.douban-statistics__page-info[data-v-d7e575ef] { display: flex; justify-content: space-between; color: var(--app-text-muted); font-size: 13px;\n}\n.douban-statistics__grid[data-v-d7e575ef] { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; align-items: start; margin-top: -10px;\n}\n.douban-subscription[data-v-d7e575ef] { display: grid; grid-template-columns: 64px minmax(0, 1fr); grid-template-rows: 96px; align-items: start; gap: 10px; padding: 10px; min-width: 0; overflow: hidden; border: 1px solid var(--app-border-subtle); border-radius: 11px; background: var(--app-surface);\n}\n.douban-subscription__poster[data-v-d7e575ef] { display: grid; place-items: center; width: 100%; aspect-ratio: 2 / 3; overflow: hidden; border-radius: 6px; background: var(--app-surface-muted); color: var(--app-text-muted); font-size: var(--app-font-size-caption, 12px);\n}\n.douban-subscription__poster img[data-v-d7e575ef] { width: 100%; height: 100%; min-height: 0; object-fit: contain;\n}\n.douban-subscription__body[data-v-d7e575ef] { display: flex; flex-direction: column; gap: 5px; min-width: 0; height: 96px; max-height: 96px; overflow: hidden;\n}\n.douban-subscription h3[data-v-d7e575ef] { flex-shrink: 0; margin: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--app-text); font-size: var(--app-font-size-caption, 12px); line-height: 18px; font-weight: 600;\n}\n.douban-subscription__tags[data-v-d7e575ef] { display: flex; flex-wrap: nowrap; flex-shrink: 0; gap: 4px; min-width: 0; overflow: hidden;\n}\n.douban-subscription__tags span[data-v-d7e575ef] { min-width: 0; max-width: 100%; padding: 1px 5px; border-radius: 16px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; background: var(--app-surface-muted); color: var(--app-text-secondary); font-size: var(--app-font-size-helper, 10px); line-height: 16px;\n}\n.douban-subscription__tags span[data-v-d7e575ef]:first-child { flex-shrink: 0;\n}\n.douban-subscription__release[data-v-d7e575ef] { flex-shrink: 0; margin: 0; color: var(--app-text-secondary); font-size: var(--app-font-size-helper, 10px); line-height: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;\n}\n.douban-subscription__time[data-v-d7e575ef] { flex-shrink: 0; height: 28px; margin: 0; margin-top: auto; color: var(--app-text-muted); font-size: var(--app-font-size-helper, 10px); line-height: 14px; overflow: hidden; font-variant-numeric: tabular-nums;\n}\n.douban-subscription__time span[data-v-d7e575ef] { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;\n}\n.douban-statistics__pagination[data-v-d7e575ef] { display: flex; align-items: center; justify-content: center; gap: 14px; color: var(--app-text-muted); font-size: 12px;\n}\n.douban-dialog[data-v-d7e575ef] { display: flex; flex-direction: column; max-height: calc(100dvh - 32px); border: 1px solid var(--app-border); border-radius: 18px !important; background: var(--app-dialog-surface) !important; color: var(--app-text);\n}\n.douban-dialog__header[data-v-d7e575ef] { display: flex; box-sizing: border-box; height: var(--app-plugin-dialog-header-height, 58px); min-height: var(--app-plugin-dialog-header-height, 58px); max-height: var(--app-plugin-dialog-header-height, 58px); flex: 0 0 var(--app-plugin-dialog-header-height, 58px); align-items: center; justify-content: space-between; gap: 12px; padding: 6px 24px;\n}\n.douban-dialog__header h2[data-v-d7e575ef] { margin: 0; font-size: 18px; font-weight: 750;\n}\n.douban-dialog__content[data-v-d7e575ef] { min-height: 0; overflow: auto; padding: 20px 24px; background: var(--app-surface-subtle);\n}\n.douban-dialog__actions[data-v-d7e575ef] { display: flex; align-items: center; justify-content: flex-end; gap: 12px; padding: 12px 24px; border-top: 1px solid var(--app-border-subtle);\n}\n.douban-dialog__message[data-v-d7e575ef] { padding: 40px 12px; text-align: center; color: var(--app-text-muted);\n}\n.douban-statistics__pagination button[data-v-d7e575ef]:focus-visible { outline: 2px solid var(--app-violet-text); outline-offset: 2px;\n}\n@media (max-width: 760px) {\n.douban-dialog[data-v-d7e575ef] { height: auto; max-height: min(680px, 76dvh); border-radius: 16px !important;\n}\n.douban-statistics__metrics[data-v-d7e575ef] { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px;\n}\n.douban-statistics__metrics > div[data-v-d7e575ef] { padding: 14px 16px;\n}\n.douban-dialog__content[data-v-d7e575ef] { padding: 16px;\n}\n.douban-dialog__header[data-v-d7e575ef] { padding: 6px 16px;\n}\n.douban-dialog__header h2[data-v-d7e575ef] { font-size: 18px;\n}\n}\n@media (max-width: 1100px) and (min-width: 851px) {\n.douban-statistics__grid[data-v-d7e575ef] { grid-template-columns: repeat(3, minmax(0, 1fr));\n}\n}\n@media (max-width: 850px) and (min-width: 601px) {\n.douban-statistics__grid[data-v-d7e575ef] { grid-template-columns: repeat(2, minmax(0, 1fr));\n}\n}\n@media (max-width: 600px) {\n.douban-statistics__grid[data-v-d7e575ef] { grid-template-columns: minmax(0, 1fr);\n}\n}\r\n\n.douban-rank-settings h3[data-v-c9cab76f],.rank-types[data-v-c9cab76f]{grid-column:1 / -1}\n.douban-rank-settings h3[data-v-c9cab76f]{margin:0;color:var(--app-text);font-size:var(--app-font-size-body,14px);font-weight:var(--app-font-weight-heading,600)}\r\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\r\n * Values mirror the host application's standard configuration dialog and\r\n * operational content density. Keep business-specific layouts in each plugin.\r\n */\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .signin-page,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace,\r\n  .signin-stat-dialog,\r\n  .cc-statistics-dialog,\r\n  .douban-dialog,\r\n  .maoyan-dialog,\r\n  .cover-history\r\n) {\r\n  color: var(--app-text, #1a2434);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field) {\r\n  min-height: var(--app-control-height, 52px);\r\n  border-radius: var(--app-control-radius, 11px);\r\n  background: var(--control-surface, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field__input) {\r\n  min-width: 0;\r\n  min-height: var(--app-control-height, 52px) !important;\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-label.v-field-label) {\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-label, 11px);\r\n}\r\n\r\n/* Custom plugin editors render Vuetify switches directly instead of through\r\n * the host's InlineSwitchRow. Pin their copy to the host's compact form-label\r\n * treatment so Vuetify's larger body label cannot change the visual scale. */\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-switch, .v-checkbox, .v-radio) .v-label {\r\n  color: var(--app-text-secondary, #657087) !important;\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-label, 13px) !important;\r\n  font-weight: var(--app-font-weight-regular, 400) !important;\r\n  line-height: 1.35;\r\n  opacity: 1;\r\n}\r\n\r\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .traffic-dialog, .cover-history) {\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border, #dfe4ee) !important;\r\n  border-radius: 18px !important;\r\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\r\n  color: var(--app-text, #202939);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) {\r\n  min-height: 80px;\r\n  padding: 18px 20px !important;\r\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) h2 {\r\n  margin: 0;\r\n  color: var(--app-text, #202939);\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-heading, 750) !important;\r\n  line-height: 1.2;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header\r\n) p {\r\n  margin: 3px 0 0;\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: var(--app-font-size-helper, 10px) !important;\r\n  line-height: 1.4;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__content,\r\n  .cc-statistics-content,\r\n  .douban-dialog__content,\r\n  .traffic-dialog-body,\r\n  .maoyan-dialog__content,\r\n  .cover-history > main\r\n) {\r\n  padding: 20px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__actions,\r\n  .cc-statistics-actions,\r\n  .douban-dialog__actions,\r\n  .traffic-dialog-actions,\r\n  .maoyan-dialog__actions,\r\n  .cover-history > footer\r\n) {\r\n  min-height: 64px;\r\n  padding: 13px 18px !important;\r\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface-raised, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) {\r\n  gap: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) > div {\r\n  min-width: 0;\r\n  padding: 15px 16px !important;\r\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  border-radius: 12px !important;\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) dt,\r\n:where(.cover-history .metrics) span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics\r\n) dd,\r\n:where(.cover-history .metrics) strong {\r\n  margin-top: 7px;\r\n  color: var(--app-text, #202939);\r\n  font-family: inherit !important;\r\n  font-size: var(--app-font-size-metric, 24px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  font-variant-numeric: tabular-nums;\r\n  line-height: 1.15;\r\n}\r\n\r\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\r\n.cookie-metric dd > span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 11px !important;\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n.signin-stat-results {\r\n  border-radius: 12px !important;\r\n}\r\n\r\n.signin-stat-results > header {\r\n  min-height: 44px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article {\r\n  min-height: 68px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article strong {\r\n  color: var(--app-text, #202939);\r\n  font-size: 13px;\r\n  font-weight: var(--app-font-weight-medium, 650);\r\n}\r\n\r\n.signin-stat-results article p {\r\n  font-size: 12px !important;\r\n}\r\n\r\n.signin-stat-results :is(article span, time) {\r\n  font-size: 10px !important;\r\n}\r\n\r\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\r\n  min-width: 0;\r\n  color: var(--app-text, #17243a);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  line-height: 1.5;\r\n}\r\n\r\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\r\n  font-size: 27px !important;\r\n  font-weight: 750;\r\n  line-height: 1.15;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  line-height: 1.3;\r\n}\r\n\r\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\r\n  min-height: 40px;\r\n  border-radius: 9px !important;\r\n  font-size: 13px;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\r\n  min-height: 52px;\r\n  border-radius: 11px;\r\n  color: var(--app-text-secondary, #657087);\r\n  font: inherit;\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n@media (max-width: 700px) {\r\n  :where(\r\n    .signin-stat-dialog__header,\r\n    .cc-statistics-header,\r\n    .douban-dialog__header,\r\n    .traffic-dialog-heading,\n    .maoyan-dialog__header,\n    .cover-history > header,\r\n    .signin-stat-dialog__content,\r\n    .cc-statistics-content,\r\n    .douban-dialog__content,\r\n    .traffic-dialog-body,\n    .maoyan-dialog__content,\n    .cover-history > main\r\n  ) {\r\n    padding: 16px !important;\r\n  }\r\n}\r\n\r\n/* Legacy-host fallback. On current hosts, the public form owns these tokens. */\r\n:where(.app-form-layout) {\r\n  display: grid;\r\n  grid-template-columns: repeat(var(--app-plugin-config-columns, 2), minmax(0, 1fr));\r\n  row-gap: var(--app-plugin-config-row-gap, 14px);\r\n  column-gap: var(--app-plugin-config-column-gap, 16px);\r\n}\r\n@media (max-width: 760px) {\r\n  :where(.app-form-layout) { grid-template-columns: minmax(0, 1fr); }\r\n}\r\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const normalizeStyle = runtime.normalizeStyle;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveDynamicComponent = runtime.resolveDynamicComponent;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1$1 = { class: "douban-dialog__header" };
const _hoisted_2 = { class: "douban-dialog__content" };
const _hoisted_3 = {
  key: 0,
  class: "douban-dialog__message",
  role: "status"
};
const _hoisted_4 = {
  key: 2,
  class: "douban-statistics",
  "aria-label": "豆瓣榜单订阅统计"
};
const _hoisted_5 = { class: "douban-statistics__metrics" };
const _hoisted_6 = { class: "douban-retry-metric" };
const _hoisted_7 = {
  class: "douban-run",
  "aria-label": "本次处理结果"
};
const _hoisted_8 = { class: "douban-run__heading" };
const _hoisted_9 = {
  key: 0,
  id: "douban-run-details"
};
const _hoisted_10 = { class: "douban-run__filters" };
const _hoisted_11 = { class: "douban-run__table" };
const _hoisted_12 = { key: 0 };
const _hoisted_13 = {
  key: 0,
  class: "douban-statistics__page-info"
};
const _hoisted_14 = {
  key: 1,
  class: "douban-statistics__pagination",
  "aria-label": "本次处理结果分页"
};
const _hoisted_15 = { class: "douban-run__heading" };
const _hoisted_16 = ["aria-busy"];
const _hoisted_17 = { class: "douban-subscription__poster" };
const _hoisted_18 = ["src", "alt", "onError"];
const _hoisted_19 = { key: 1 };
const _hoisted_20 = { class: "douban-subscription__body" };
const _hoisted_21 = ["title"];
const _hoisted_22 = { class: "douban-subscription__tags" };
const _hoisted_23 = ["title"];
const _hoisted_24 = ["title"];
const _hoisted_25 = ["title"];
const _hoisted_26 = ["datetime", "aria-label"];
const _hoisted_27 = {
  key: 0,
  class: "douban-statistics__pagination",
  "aria-label": "订阅记录分页"
};
const _hoisted_28 = {
  key: 1,
  class: "douban-dialog__message"
};
const _hoisted_29 = { class: "douban-dialog__actions" };
const ID$1 = "douban-hot";
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: {},
    buttonComponent: {},
    cardComponent: {},
    dialogComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiButton = props.buttonComponent;
    const UiCard = props.cardComponent;
    const UiDialog = props.dialogComponent;
    const UiAlert = props.alertComponent;
    const history = ref({ items: [], total: 0, movie_count: 0, tv_count: 0, board_count: 0, page: 1, pages: 1 });
    const loading = ref(false);
    const loaded = ref(false);
    const historyGrid = ref(null);
    const historyHeight = ref(0);
    const error = ref("");
    const failedPosters = ref(/* @__PURE__ */ new Set());
    let requestedPage = 1;
    const expanded = ref(false);
    const retryOnly = ref(false);
    const detailPage = ref(1);
    const latest = computed(() => history.value.latest_run);
    const cumulative = computed(() => history.value.cumulative);
    const detailItems = computed(() => (latest.value?.items || []).filter((item) => !retryOnly.value || item.retry));
    const detailPages = computed(() => Math.max(1, Math.ceil(detailItems.value.length / 5)));
    const visibleDetails = computed(() => detailItems.value.slice((detailPage.value - 1) * 5, detailPage.value * 5));
    function showRetry() {
      retryOnly.value = true;
      expanded.value = true;
      detailPage.value = 1;
    }
    function toggleDetails() {
      expanded.value = !expanded.value;
      if (expanded.value) {
        retryOnly.value = false;
        detailPage.value = 1;
      }
    }
    function statusLabel(item) {
      return { subscribed: "新增订阅", already_subscribed: "已订阅", duplicate: "已订阅", in_library: "已入库", skipped: "已跳过", unknown: "待重试", not_recognized: "待重试" }[item.status] || "待重试";
    }
    function failureMessage(reason, fallback) {
      if (reason && typeof reason === "object" && "message" in reason) return String(reason.message || fallback);
      return fallback;
    }
    function ratingLabel(value) {
      return value && Number.isFinite(value) ? `豆瓣评分 ${value.toFixed(1)}` : "暂无评分";
    }
    function posterUrl(value) {
      const raw = String(value || "");
      if (!raw) return "";
      if (raw.startsWith("/explore/image-proxy?")) return raw;
      try {
        const url = new URL(raw);
        if (!["https:", "http:"].includes(url.protocol)) return "";
        if (url.hostname === "image.tmdb.org") return `/explore/image-proxy?source_key=tmdb&url=${encodeURIComponent(raw)}`;
        if (url.hostname === "doubanio.com" || url.hostname.endsWith(".doubanio.com")) return `/explore/image-proxy?source_key=douban&url=${encodeURIComponent(raw)}`;
        return raw;
      } catch {
        return "";
      }
    }
    function subscriptionTime(value) {
      const text = String(value || "");
      const date = new Date(/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(text) ? `${text.replace(" ", "T")}Z` : text);
      return Number.isFinite(date.getTime()) ? date.toLocaleString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).replaceAll("/", "-") : "未知时间";
    }
    function markPosterFailed(id) {
      failedPosters.value = /* @__PURE__ */ new Set([...failedPosters.value, id]);
    }
    async function load(page = requestedPage) {
      if (loading.value) return;
      historyHeight.value = historyGrid.value?.getBoundingClientRect().height || historyHeight.value;
      loading.value = true;
      error.value = "";
      try {
        history.value = await props.request(`/plugins/${ID$1}/api/statistics?page=${page}`);
        detailPage.value = Math.min(detailPage.value, detailPages.value);
        requestedPage = history.value.page;
        loaded.value = true;
        failedPosters.value = /* @__PURE__ */ new Set();
      } catch (reason) {
        error.value = failureMessage(reason, "订阅统计加载失败");
      } finally {
        loading.value = false;
      }
    }
    onMounted(() => load());
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(UiDialog), {
        "model-value": true,
        "max-width": 1e3,
        width: "calc(100vw - 32px)",
        "onUpdate:modelValue": _cache[6] || (_cache[6] = (open) => {
          if (!open) __props.context.close();
        })
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "douban-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1$1, [
                _cache[7] || (_cache[7] = createElementVNode(
                  "h2",
                  null,
                  "豆瓣榜单追踪 · 数据统计",
                  -1
                  /* CACHED */
                )),
                createVNode(unref(UiButton), {
                  class: "app-dialog-close",
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: __props.context.close
                }, null, 8, ["onClick"])
              ]),
              createElementVNode("div", _hoisted_2, [
                loading.value && !loaded.value ? (openBlock(), createElementBlock("p", _hoisted_3, "正在读取订阅统计…")) : createCommentVNode("v-if", true),
                error.value ? (openBlock(), createBlock(unref(UiAlert), {
                  key: 1,
                  type: "error",
                  variant: "tonal",
                  role: "alert"
                }, {
                  default: withCtx(() => [
                    createTextVNode(
                      toDisplayString(error.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  _: 1
                  /* STABLE */
                })) : createCommentVNode("v-if", true),
                loaded.value ? (openBlock(), createElementBlock("section", _hoisted_4, [
                  createElementVNode("dl", _hoisted_5, [
                    createElementVNode("div", null, [
                      _cache[8] || (_cache[8] = createElementVNode(
                        "dt",
                        null,
                        "累计检查",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "dd",
                        null,
                        toDisplayString(cumulative.value?.checked ?? "—"),
                        1
                        /* TEXT */
                      )
                    ]),
                    createElementVNode("div", null, [
                      _cache[9] || (_cache[9] = createElementVNode(
                        "dt",
                        null,
                        "累计新增订阅",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "dd",
                        null,
                        toDisplayString(cumulative.value?.subscribed ?? "—"),
                        1
                        /* TEXT */
                      )
                    ]),
                    createElementVNode("div", null, [
                      _cache[10] || (_cache[10] = createElementVNode(
                        "dt",
                        null,
                        "累计已存在／已处理",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "dd",
                        null,
                        toDisplayString(cumulative.value?.existing ?? "—"),
                        1
                        /* TEXT */
                      )
                    ]),
                    createElementVNode("div", _hoisted_6, [
                      _cache[11] || (_cache[11] = createElementVNode(
                        "dt",
                        null,
                        "累计需重试次数",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "dd",
                        null,
                        toDisplayString(cumulative.value?.retry ?? "—"),
                        1
                        /* TEXT */
                      )
                    ])
                  ]),
                  createElementVNode("section", _hoisted_7, [
                    createElementVNode("div", _hoisted_8, [
                      createElementVNode("h3", null, [
                        _cache[12] || (_cache[12] = createTextVNode(
                          "本次处理结果",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode(
                          "span",
                          null,
                          " · " + toDisplayString(latest.value?.items.length ?? 0) + " 条",
                          1
                          /* TEXT */
                        )
                      ]),
                      createVNode(unref(UiButton), {
                        variant: "text",
                        disabled: !latest.value?.items.length,
                        "aria-expanded": expanded.value,
                        "aria-controls": "douban-run-details",
                        onClick: toggleDetails
                      }, {
                        default: withCtx(() => [
                          createTextVNode(
                            toDisplayString(expanded.value ? "收起明细" : "查看明细"),
                            1
                            /* TEXT */
                          )
                        ]),
                        _: 1
                        /* STABLE */
                      }, 8, ["disabled", "aria-expanded"])
                    ]),
                    expanded.value ? (openBlock(), createElementBlock("div", _hoisted_9, [
                      createElementVNode("div", _hoisted_10, [
                        createVNode(unref(UiButton), {
                          variant: "text",
                          "aria-pressed": !retryOnly.value,
                          onClick: _cache[0] || (_cache[0] = ($event) => {
                            retryOnly.value = false;
                            detailPage.value = 1;
                          })
                        }, {
                          default: withCtx(() => [..._cache[13] || (_cache[13] = [
                            createTextVNode(
                              "全部",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["aria-pressed"]),
                        createVNode(unref(UiButton), {
                          variant: "text",
                          "aria-pressed": retryOnly.value,
                          onClick: showRetry
                        }, {
                          default: withCtx(() => [..._cache[14] || (_cache[14] = [
                            createTextVNode(
                              "待重试",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["aria-pressed"])
                      ]),
                      createElementVNode("div", _hoisted_11, [
                        createElementVNode("table", null, [
                          _cache[15] || (_cache[15] = createElementVNode(
                            "colgroup",
                            null,
                            [
                              createElementVNode("col", { style: { "width": "40%" } }),
                              createElementVNode("col", { style: { "width": "20%" } }),
                              createElementVNode("col", { style: { "width": "16%" } }),
                              createElementVNode("col", { style: { "width": "24%" } })
                            ],
                            -1
                            /* CACHED */
                          )),
                          _cache[16] || (_cache[16] = createElementVNode(
                            "thead",
                            null,
                            [
                              createElementVNode("tr", null, [
                                createElementVNode("th", null, "作品／目标季"),
                                createElementVNode("th", null, "榜单来源"),
                                createElementVNode("th", null, "处理状态"),
                                createElementVNode("th", null, "原因")
                              ])
                            ],
                            -1
                            /* CACHED */
                          )),
                          createElementVNode("tbody", null, [
                            (openBlock(true), createElementBlock(
                              Fragment,
                              null,
                              renderList(visibleDetails.value, (item, index) => {
                                return openBlock(), createElementBlock("tr", { key: index }, [
                                  createElementVNode("td", null, [
                                    createTextVNode(
                                      toDisplayString(item.title),
                                      1
                                      /* TEXT */
                                    ),
                                    item.season ? (openBlock(), createElementBlock(
                                      "span",
                                      _hoisted_12,
                                      " · " + toDisplayString(item.season),
                                      1
                                      /* TEXT */
                                    )) : createCommentVNode("v-if", true)
                                  ]),
                                  createElementVNode(
                                    "td",
                                    null,
                                    toDisplayString(item.board || "—"),
                                    1
                                    /* TEXT */
                                  ),
                                  createElementVNode("td", null, [
                                    createElementVNode(
                                      "span",
                                      {
                                        class: normalizeClass(["douban-run__status", { "is-retry": item.retry }])
                                      },
                                      toDisplayString(statusLabel(item)),
                                      3
                                      /* TEXT, CLASS */
                                    )
                                  ]),
                                  createElementVNode(
                                    "td",
                                    null,
                                    toDisplayString(item.reason),
                                    1
                                    /* TEXT */
                                  )
                                ]);
                              }),
                              128
                              /* KEYED_FRAGMENT */
                            ))
                          ])
                        ])
                      ]),
                      !detailItems.value.length ? (openBlock(), createElementBlock(
                        "p",
                        _hoisted_13,
                        "暂无" + toDisplayString(retryOnly.value ? "待重试" : "处理") + "记录",
                        1
                        /* TEXT */
                      )) : createCommentVNode("v-if", true),
                      detailPages.value > 1 ? (openBlock(), createElementBlock("nav", _hoisted_14, [
                        createVNode(unref(UiButton), {
                          variant: "text",
                          disabled: detailPage.value <= 1,
                          onClick: _cache[1] || (_cache[1] = ($event) => detailPage.value--)
                        }, {
                          default: withCtx(() => [..._cache[17] || (_cache[17] = [
                            createTextVNode(
                              "上一页",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["disabled"]),
                        createElementVNode(
                          "span",
                          null,
                          toDisplayString(detailPage.value) + " / " + toDisplayString(detailPages.value),
                          1
                          /* TEXT */
                        ),
                        createVNode(unref(UiButton), {
                          variant: "text",
                          disabled: detailPage.value >= detailPages.value,
                          onClick: _cache[2] || (_cache[2] = ($event) => detailPage.value++)
                        }, {
                          default: withCtx(() => [..._cache[18] || (_cache[18] = [
                            createTextVNode(
                              "下一页",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["disabled"])
                      ])) : createCommentVNode("v-if", true)
                    ])) : createCommentVNode("v-if", true)
                  ]),
                  createElementVNode("div", _hoisted_15, [
                    _cache[19] || (_cache[19] = createElementVNode(
                      "h3",
                      null,
                      "订阅历史",
                      -1
                      /* CACHED */
                    )),
                    createElementVNode(
                      "span",
                      null,
                      "累计 " + toDisplayString(history.value.total) + " 条",
                      1
                      /* TEXT */
                    )
                  ]),
                  history.value.total ? (openBlock(), createElementBlock(
                    Fragment,
                    { key: 0 },
                    [
                      createElementVNode("div", {
                        ref_key: "historyGrid",
                        ref: historyGrid,
                        class: "douban-statistics__grid",
                        "aria-busy": loading.value,
                        style: normalizeStyle(historyHeight.value ? { minHeight: `${historyHeight.value}px` } : void 0)
                      }, [
                        (openBlock(true), createElementBlock(
                          Fragment,
                          null,
                          renderList(history.value.items, (item) => {
                            return openBlock(), createElementBlock("article", {
                              key: item.id,
                              class: "douban-subscription"
                            }, [
                              createElementVNode("div", _hoisted_17, [
                                posterUrl(item.poster) && !failedPosters.value.has(item.id) ? (openBlock(), createElementBlock("img", {
                                  key: 0,
                                  src: posterUrl(item.poster),
                                  alt: `${item.title}海报`,
                                  loading: "lazy",
                                  onError: ($event) => markPosterFailed(item.id)
                                }, null, 40, _hoisted_18)) : (openBlock(), createElementBlock("span", _hoisted_19, "无海报"))
                              ]),
                              createElementVNode("div", _hoisted_20, [
                                createElementVNode("h3", {
                                  title: item.title
                                }, toDisplayString(item.title), 9, _hoisted_21),
                                createElementVNode("div", _hoisted_22, [
                                  createElementVNode(
                                    "span",
                                    null,
                                    toDisplayString(item.media_label),
                                    1
                                    /* TEXT */
                                  ),
                                  createElementVNode("span", {
                                    title: item.board
                                  }, toDisplayString(item.board), 9, _hoisted_23)
                                ]),
                                createElementVNode("p", {
                                  class: "douban-subscription__release",
                                  title: ratingLabel(item.rating)
                                }, toDisplayString(ratingLabel(item.rating)), 9, _hoisted_24),
                                createElementVNode("p", {
                                  class: "douban-subscription__time",
                                  title: `订阅时间：${subscriptionTime(item.subscribed_at)}`
                                }, [
                                  createElementVNode("time", {
                                    datetime: item.subscribed_at,
                                    "aria-label": `订阅时间：${subscriptionTime(item.subscribed_at)}`
                                  }, [
                                    createElementVNode(
                                      "span",
                                      null,
                                      "订阅时间：" + toDisplayString(subscriptionTime(item.subscribed_at).split(" ")[0]),
                                      1
                                      /* TEXT */
                                    ),
                                    createElementVNode(
                                      "span",
                                      null,
                                      toDisplayString(subscriptionTime(item.subscribed_at).split(" ")[1] || "—"),
                                      1
                                      /* TEXT */
                                    )
                                  ], 8, _hoisted_26)
                                ], 8, _hoisted_25)
                              ])
                            ]);
                          }),
                          128
                          /* KEYED_FRAGMENT */
                        ))
                      ], 12, _hoisted_16),
                      history.value.pages > 1 ? (openBlock(), createElementBlock("nav", _hoisted_27, [
                        createVNode(unref(UiButton), {
                          variant: "text",
                          size: "small",
                          "prepend-icon": "mdi-chevron-left",
                          disabled: history.value.page <= 1 || loading.value,
                          onClick: _cache[3] || (_cache[3] = ($event) => load(history.value.page - 1))
                        }, {
                          default: withCtx(() => [..._cache[20] || (_cache[20] = [
                            createTextVNode(
                              "上一页",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["disabled"]),
                        createElementVNode(
                          "span",
                          null,
                          toDisplayString(history.value.page) + " / " + toDisplayString(history.value.pages),
                          1
                          /* TEXT */
                        ),
                        createVNode(unref(UiButton), {
                          variant: "text",
                          size: "small",
                          "append-icon": "mdi-chevron-right",
                          disabled: history.value.page >= history.value.pages || loading.value,
                          onClick: _cache[4] || (_cache[4] = ($event) => load(history.value.page + 1))
                        }, {
                          default: withCtx(() => [..._cache[21] || (_cache[21] = [
                            createTextVNode(
                              "下一页",
                              -1
                              /* CACHED */
                            )
                          ])]),
                          _: 1
                          /* STABLE */
                        }, 8, ["disabled"])
                      ])) : createCommentVNode("v-if", true)
                    ],
                    64
                    /* STABLE_FRAGMENT */
                  )) : (openBlock(), createElementBlock("div", _hoisted_28, [..._cache[22] || (_cache[22] = [
                    createElementVNode(
                      "h3",
                      null,
                      "暂无订阅记录",
                      -1
                      /* CACHED */
                    ),
                    createElementVNode(
                      "p",
                      null,
                      "豆瓣榜单中的作品成功加入订阅后，会显示在这里。",
                      -1
                      /* CACHED */
                    )
                  ])]))
                ])) : createCommentVNode("v-if", true)
              ]),
              createElementVNode("footer", _hoisted_29, [
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: loading.value,
                  onClick: _cache[5] || (_cache[5] = ($event) => load())
                }, {
                  default: withCtx(() => [..._cache[23] || (_cache[23] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-d7e575ef"]]);
function orderedFields(fields, order) {
  return order.flatMap((key) => {
    const field = fields.find((candidate) => candidate.key === key);
    return field ? [{ ...field }] : [];
  });
}
const _hoisted_1 = { class: "douban-rank-settings plugin-config-grid app-form-layout" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "RankEditor",
  props: {
    modelValue: {},
    fields: {},
    disabled: { type: Boolean },
    schemaFieldsComponent: {}
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const scheduleFields = computed(() => orderedFields(props.fields || [], ["clear", "cron", "proxy", "vote"]));
    const rssFields = computed(() => orderedFields(props.fields || [], ["rsshub", "rss_addrs"]));
    const selected = computed(() => {
      const value = props.modelValue.ranks ?? ["movie-real-time", "tv-hot"];
      return Array.isArray(value) ? value.map(String) : String(value).split(/[\n,，]+/).map((item) => item.trim()).filter(Boolean);
    });
    const groups = [{ title: "电影榜单", movie: true }, { title: "电视剧与综艺", movie: false }];
    function groupFields(movie) {
      return orderedFields(props.fields || [], ["ranks"]).map((field) => ({ ...field, label: "榜单类型", options: (field.options || []).filter((option) => String(option.value).startsWith("movie-") === movie) }));
    }
    function updateRanks(next, movie) {
      emit("update:modelValue", { ...props.modelValue, ranks: [...selected.value.filter((rank) => rank.startsWith("movie-") !== movie), ...Array.isArray(next.ranks) ? next.ranks : []] });
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        (openBlock(true), createElementBlock(
          Fragment,
          null,
          renderList(scheduleFields.value, (field) => {
            return openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
              key: field.key,
              fields: [field],
              "model-value": __props.modelValue,
              disabled: __props.disabled,
              compact: "",
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:modelValue", $event))
            }, null, 8, ["fields", "model-value", "disabled"]);
          }),
          128
          /* KEYED_FRAGMENT */
        )),
        (openBlock(), createElementBlock(
          Fragment,
          null,
          renderList(groups, (group) => {
            return openBlock(), createElementBlock(
              Fragment,
              {
                key: group.title
              },
              [
                createElementVNode(
                  "h3",
                  null,
                  toDisplayString(group.title),
                  1
                  /* TEXT */
                ),
                (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
                  class: "rank-types",
                  fields: groupFields(group.movie),
                  "model-value": { ...__props.modelValue, ranks: selected.value.filter((rank) => rank.startsWith("movie-") === group.movie) },
                  disabled: __props.disabled,
                  compact: "",
                  "onUpdate:modelValue": ($event) => updateRanks($event, group.movie)
                }, null, 8, ["fields", "model-value", "disabled", "onUpdate:modelValue"]))
              ],
              64
              /* STABLE_FRAGMENT */
            );
          }),
          64
          /* STABLE_FRAGMENT */
        )),
        _cache[2] || (_cache[2] = createElementVNode(
          "h3",
          null,
          "自定义榜单",
          -1
          /* CACHED */
        )),
        (openBlock(true), createElementBlock(
          Fragment,
          null,
          renderList(rssFields.value, (field) => {
            return openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
              key: field.key,
              class: "rank-types",
              fields: [field],
              "model-value": __props.modelValue,
              disabled: __props.disabled,
              compact: "",
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => emit("update:modelValue", $event))
            }, null, 8, ["fields", "model-value", "disabled"]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ]);
    };
  }
});
const RankEditor = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-c9cab76f"]]);
const ID = "douban-hot";
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const { Button, Card, Dialog, Alert } = sdk.ui.components;
  const fields = sdk.ui.components.SchemaFields;
  if (fields) sdk.registerEditor({
    domain: "plugin",
    key: ID,
    component: defineComponent2({
      inheritAttrs: false,
      props: { modelValue: { type: Object, required: true }, disabled: Boolean },
      emits: ["update:modelValue"],
      setup(props, { attrs, emit }) {
        return () => h(RankEditor, {
          ...attrs,
          modelValue: props.modelValue,
          disabled: props.disabled,
          schemaFieldsComponent: fields,
          "onUpdate:modelValue": (value) => emit("update:modelValue", value)
        });
      }
    })
  });
  const Statistics = defineComponent2({
    name: "DoubanStatistics",
    inheritAttrs: false,
    props: { context: { type: Object, required: true } },
    setup(props, { attrs }) {
      return () => h(StatisticsView, {
        ...attrs,
        context: props.context,
        request: sdk.request,
        buttonComponent: Button,
        cardComponent: Card,
        dialogComponent: Dialog,
        alertComponent: Alert
      });
    }
  });
  sdk.registerContribution({ pluginId: ID, slot: "plugin.statistics", key: "subscriptions", component: Statistics });
}
export {
  install
};
