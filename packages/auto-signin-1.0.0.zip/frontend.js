if (typeof document !== "undefined") { const id = "auto_signin"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.signin-page{display:grid;gap:18px;color:var(--app-text,#17243a)}.signin-hero,.signin-panel{border:1px solid var(--app-border,#dde4ef);border-radius:22px;background:var(--app-surface,#fff);box-shadow:0 16px 38px rgba(37,61,99,.06)}.signin-hero{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:24px}.signin-hero h1{margin:0;font-size:30px}.signin-hero p,.signin-panel p{margin:5px 0 0;color:var(--app-text-muted,#71809a)}.signin-actions{display:flex;gap:10px}.signin-button{min-height:42px;padding:0 16px;border:0;border-radius:12px;background:#2f74f6;color:#fff;font-weight:750;cursor:pointer}.signin-button.secondary{background:#edf3ff;color:#225fc7}.signin-button:disabled{opacity:.5}.signin-panel{padding:22px}.signin-panel-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:16px}.signin-panel h2{margin:0;font-size:20px}.signin-sites{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr));gap:12px}.signin-site{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;padding:16px;border:1px solid var(--app-border,#dde4ef);border-radius:16px;background:var(--app-surface-muted,#f7f9fc)}.signin-site strong,.signin-site small{display:block}.signin-site small{margin-top:4px;color:var(--app-text-muted,#71809a)}.signin-modes{display:flex;gap:8px;align-items:center}.signin-modes label{display:flex;gap:5px;align-items:center;font-size:13px}.signin-result{grid-column:1/-1;margin:0;padding-top:9px;border-top:1px solid var(--app-border,#dde4ef);font-size:13px}.signin-result.ok{color:#16865b}.signin-result.bad{color:#d04444}.signin-empty{padding:34px;text-align:center;color:var(--app-text-muted,#71809a)}@media(max-width:640px){.signin-hero,.signin-panel-head{align-items:stretch;flex-direction:column}.signin-actions{display:grid}.signin-site{grid-template-columns:1fr}.signin-modes{justify-content:flex-start;flex-wrap:wrap}}\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const toDisplayString = runtime.toDisplayString;
const _hoisted_1 = { class: "signin-page" };
const _hoisted_2 = { class: "signin-hero" };
const _hoisted_3 = { class: "signin-actions" };
const _hoisted_4 = ["disabled"];
const _hoisted_5 = ["disabled"];
const _hoisted_6 = { class: "signin-panel" };
const _hoisted_7 = { class: "signin-panel-head" };
const _hoisted_8 = {
  key: 0,
  class: "signin-sites"
};
const _hoisted_9 = { class: "signin-modes" };
const _hoisted_10 = ["checked", "onChange"];
const _hoisted_11 = ["checked", "onChange"];
const _hoisted_12 = ["disabled", "onClick"];
const _hoisted_13 = {
  key: 1,
  class: "signin-empty"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "AutoSigninPage",
  props: {
    request: { type: Function }
  },
  setup(__props) {
    const props = __props;
    const sites = ref([]);
    const signSites = ref([]);
    const loginSites = ref([]);
    const loading = ref(false);
    const saving = ref(false);
    const running = ref("");
    const results = ref({});
    const config = ref({});
    const message = ref("");
    async function load() {
      loading.value = true;
      try {
        const data = await props.request("/plugins/auto-signin/api/inventory");
        sites.value = Array.isArray(data?.items) ? data.items : [];
        config.value = data?.config && typeof data.config === "object" ? data.config : {};
        signSites.value = Array.isArray(data?.selected?.sign_sites) ? data.selected.sign_sites : [];
        loginSites.value = Array.isArray(data?.selected?.login_sites) ? data.selected.login_sites : [];
      } catch (error) {
        message.value = error instanceof Error ? error.message : "站点读取失败";
      } finally {
        loading.value = false;
      }
    }
    function toggle(target, id, checked) {
      const list = target === "sign" ? signSites : loginSites;
      const values = new Set(list.value);
      checked ? values.add(id) : values.delete(id);
      list.value = [...values];
    }
    async function save() {
      saving.value = true;
      try {
        await props.request("/plugins/auto-signin", { method: "PATCH", body: JSON.stringify({ config: { ...config.value, sign_sites: signSites.value, login_sites: loginSites.value } }) });
        config.value = { ...config.value, sign_sites: signSites.value, login_sites: loginSites.value };
        message.value = "站点选择已保存";
      } catch (error) {
        message.value = error instanceof Error ? error.message : "保存失败";
      } finally {
        saving.value = false;
      }
    }
    async function runSite(site, mode) {
      running.value = `${site.id}:${mode}`;
      try {
        const result = await props.request("/plugins/auto-signin/api/site", { method: "POST", body: JSON.stringify({ site_id: site.id, mode }) });
        results.value = { ...results.value, [site.id]: result };
      } catch (error) {
        results.value = { ...results.value, [site.id]: { ok: false, message: error instanceof Error ? error.message : "执行失败" } };
      } finally {
        running.value = "";
      }
    }
    function eventChecked(event) {
      return event.currentTarget.checked;
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("section", _hoisted_1, [
        createElementVNode("header", _hoisted_2, [
          _cache[0] || (_cache[0] = createElementVNode(
            "div",
            null,
            [
              createElementVNode("h1", null, "站点签到助手"),
              createElementVNode("p", null, "勾选需要每日签到或仅保持登录的站点；保存后由插件定时执行。")
            ],
            -1
            /* CACHED */
          )),
          createElementVNode("div", _hoisted_3, [
            createElementVNode("button", {
              class: "signin-button secondary",
              disabled: loading.value,
              onClick: load
            }, toDisplayString(loading.value ? "读取中…" : "刷新站点"), 9, _hoisted_4),
            createElementVNode("button", {
              class: "signin-button",
              disabled: saving.value,
              onClick: save
            }, toDisplayString(saving.value ? "保存中…" : "保存选择"), 9, _hoisted_5)
          ])
        ]),
        createElementVNode("main", _hoisted_6, [
          createElementVNode("div", _hoisted_7, [
            _cache[1] || (_cache[1] = createElementVNode(
              "div",
              null,
              [
                createElementVNode("h2", null, "站点列表"),
                createElementVNode("p", null, "签到与保持登录可以分别选择；单站测试不会修改选择。")
              ],
              -1
              /* CACHED */
            )),
            createElementVNode(
              "span",
              null,
              toDisplayString(message.value),
              1
              /* TEXT */
            )
          ]),
          sites.value.length ? (openBlock(), createElementBlock("div", _hoisted_8, [
            (openBlock(true), createElementBlock(
              Fragment,
              null,
              renderList(sites.value, (site) => {
                return openBlock(), createElementBlock("article", {
                  key: site.id,
                  class: "signin-site"
                }, [
                  createElementVNode("div", null, [
                    createElementVNode(
                      "strong",
                      null,
                      toDisplayString(site.name),
                      1
                      /* TEXT */
                    ),
                    createElementVNode(
                      "small",
                      null,
                      toDisplayString(site.enabled ? "站点已启用" : "站点已停用"),
                      1
                      /* TEXT */
                    )
                  ]),
                  createElementVNode("div", _hoisted_9, [
                    createElementVNode("label", null, [
                      createElementVNode("input", {
                        type: "checkbox",
                        checked: signSites.value.includes(site.id),
                        onChange: ($event) => toggle("sign", site.id, eventChecked($event))
                      }, null, 40, _hoisted_10),
                      _cache[2] || (_cache[2] = createTextVNode(
                        "每日签到",
                        -1
                        /* CACHED */
                      ))
                    ]),
                    createElementVNode("label", null, [
                      createElementVNode("input", {
                        type: "checkbox",
                        checked: loginSites.value.includes(site.id),
                        onChange: ($event) => toggle("login", site.id, eventChecked($event))
                      }, null, 40, _hoisted_11),
                      _cache[3] || (_cache[3] = createTextVNode(
                        "保持登录",
                        -1
                        /* CACHED */
                      ))
                    ]),
                    createElementVNode("button", {
                      class: "signin-button secondary",
                      disabled: Boolean(running.value),
                      onClick: ($event) => runSite(site, "sign")
                    }, toDisplayString(running.value === `${site.id}:sign` ? "执行中…" : "测试"), 9, _hoisted_12)
                  ]),
                  results.value[site.id] ? (openBlock(), createElementBlock(
                    "p",
                    {
                      key: 0,
                      class: normalizeClass(["signin-result", results.value[site.id].ok ? "ok" : "bad"])
                    },
                    toDisplayString(results.value[site.id].message || results.value[site.id].status),
                    3
                    /* TEXT, CLASS */
                  )) : createCommentVNode("v-if", true)
                ]);
              }),
              128
              /* KEYED_FRAGMENT */
            ))
          ])) : (openBlock(), createElementBlock(
            "div",
            _hoisted_13,
            toDisplayString(loading.value ? "正在读取站点…" : "尚未配置 PT 站点"),
            1
            /* TEXT */
          ))
        ])
      ]);
    };
  }
});
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const Page = defineComponent2({
    name: "SiteCheckinPage",
    inheritAttrs: false,
    setup() {
      return () => h(_sfc_main, {
        request: (path, init) => sdk.request(path, init)
      });
    }
  });
  sdk.registerPage({ pluginId: "auto-signin", route: "plugin-auto-signin", title: "自动签到", icon: "mdi-calendar-check-outline", section: "tools", order: 72, component: Page });
}
export {
  install
};
