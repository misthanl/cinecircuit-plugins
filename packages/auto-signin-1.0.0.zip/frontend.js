if (typeof document !== "undefined") { const id = "auto_signin"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.signin-page{display:grid;gap:18px;color:var(--app-text,#17243a)}.signin-hero,.signin-panel,.signin-stats{border:1px solid var(--app-border,#dde4ef);border-radius:22px;background:var(--app-surface,#fff);box-shadow:0 16px 38px rgba(37,61,99,.06)}.signin-hero{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:24px}.signin-hero h1{margin:0;font-size:30px}.signin-hero p,.signin-panel p{margin:5px 0 0;color:var(--app-text-muted,#71809a)}.signin-actions{display:flex;gap:10px}.signin-button{min-height:42px;padding:0 16px;border:0;border-radius:12px;background:#2f74f6;color:#fff;font-weight:750;cursor:pointer}.signin-button.secondary{background:#edf3ff;color:#225fc7}.signin-button.compact{min-height:32px;padding:0 11px;font-size:12px}.signin-button:disabled{opacity:.5}.signin-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));overflow:hidden}.signin-stats>div{display:grid;gap:5px;padding:17px 20px;border-right:1px solid var(--app-border,#dde4ef)}.signin-stats>div:last-child{border-right:0}.signin-stats span,.signin-checks span{color:var(--app-text-muted,#71809a);font-size:12px}.signin-stats strong{font-size:24px}.signin-panel{padding:22px}.signin-panel-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:16px}.signin-panel h2{margin:0;font-size:20px}.signin-sites{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:12px}.signin-site{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;padding:16px;border:1px solid var(--app-border,#dde4ef);border-radius:16px;background:var(--app-surface-muted,#f7f9fc)}.signin-site strong,.signin-site small{display:block}.signin-site small{margin-top:4px;color:var(--app-text-muted,#71809a)}.signin-modes{display:flex;gap:10px;align-items:center}.signin-modes label{display:flex;gap:5px;align-items:center;font-size:13px}.signin-checks{display:grid;grid-column:1/-1;grid-template-columns:repeat(2,minmax(0,1fr));gap:1px;overflow:hidden;border:1px solid var(--app-border,#dde4ef);border-radius:12px;background:var(--app-border,#dde4ef)}.signin-checks>div{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:4px 10px;padding:11px;background:var(--app-surface,#fff)}.signin-result{min-width:0;margin:0!important;overflow:hidden;font-size:12px;text-overflow:ellipsis;white-space:nowrap}.signin-result.ok{color:#16865b!important}.signin-result.bad{color:#d04444!important}.signin-empty{padding:34px;text-align:center;color:var(--app-text-muted,#71809a)}@media(max-width:720px){.signin-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.signin-stats>div:nth-child(2){border-right:0}.signin-stats>div:nth-child(-n+2){border-bottom:1px solid var(--app-border,#dde4ef)}.signin-checks{grid-template-columns:1fr}}@media(max-width:640px){.signin-hero,.signin-panel-head{align-items:stretch;flex-direction:column}.signin-actions{display:grid}.signin-site{grid-template-columns:1fr}.signin-modes{justify-content:flex-start;flex-wrap:wrap}}\n\n.signin-stat-dialog[data-v-5288a76e]{display:flex;max-height:calc(100dvh - 32px);flex-direction:column;border-radius:18px!important;color:var(--app-text)}\n.signin-stat-dialog__header[data-v-5288a76e]{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:20px 24px;border-bottom:1px solid var(--app-border-subtle)}\n.signin-stat-dialog__header h2[data-v-5288a76e]{margin:0;font-size:18px}.signin-stat-dialog__header p[data-v-5288a76e]{margin:4px 0 0;color:var(--app-text-muted);font-size:10px}\n.signin-stat-dialog__content[data-v-5288a76e]{display:grid;min-height:0;gap:18px;overflow:auto;padding:22px 24px;background:var(--app-surface-subtle)}\n.signin-stat-metrics[data-v-5288a76e]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:0}.signin-stat-metrics>div[data-v-5288a76e]{padding:15px 16px;border:1px solid var(--app-border-subtle);border-radius:12px;background:var(--app-surface)}.signin-stat-metrics dt[data-v-5288a76e]{color:var(--app-text-muted);font-size:12px}.signin-stat-metrics dd[data-v-5288a76e]{margin:7px 0 0;font-size:24px;font-weight:720}\n.signin-stat-results[data-v-5288a76e]{overflow:hidden;border:1px solid var(--app-border-subtle);border-radius:14px;background:var(--app-surface)}.signin-stat-results>header[data-v-5288a76e],.signin-stat-results article[data-v-5288a76e]{display:grid;grid-template-columns:minmax(180px,1fr) minmax(220px,2fr) auto;align-items:center;gap:16px;padding:13px 16px;border-bottom:1px solid var(--app-border-subtle)}.signin-stat-results>header[data-v-5288a76e]{display:flex;justify-content:space-between;background:var(--app-surface-muted)}.signin-stat-results>header span[data-v-5288a76e],.signin-stat-results article span[data-v-5288a76e],.signin-stat-results time[data-v-5288a76e]{color:var(--app-text-muted);font-size:11px}.signin-stat-results article[data-v-5288a76e]:last-child{border-bottom:0}.signin-stat-results article div[data-v-5288a76e]{display:grid;gap:3px}.signin-stat-results article p[data-v-5288a76e]{margin:0;color:#16865b;font-size:12px;overflow-wrap:anywhere}.signin-stat-results article p.bad[data-v-5288a76e]{color:#d04444}.signin-stat-results time[data-v-5288a76e]{white-space:nowrap}\n.signin-stat-empty[data-v-5288a76e]{padding:40px 16px;text-align:center;color:var(--app-text-muted)}.signin-stat-dialog__actions[data-v-5288a76e]{display:flex;justify-content:flex-end;gap:10px;padding:12px 24px;border-top:1px solid var(--app-border-subtle)}\n@media(max-width:700px){.signin-stat-metrics[data-v-5288a76e]{grid-template-columns:repeat(2,minmax(0,1fr))}.signin-stat-results article[data-v-5288a76e]{grid-template-columns:1fr}.signin-stat-dialog__header[data-v-5288a76e],.signin-stat-dialog__content[data-v-5288a76e]{padding:16px}}\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\n * Values mirror the host application's standard configuration dialog and\n * operational content density. Keep business-specific layouts in each plugin.\n */\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-field) {\n  min-height: var(--app-control-height, 52px);\n  border-radius: 11px;\n  background: var(--control-surface, var(--app-surface, #fff));\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-field__input) {\n  min-width: 0;\n  min-height: var(--app-control-height, 52px) !important;\n  color: var(--app-text-secondary, #657087);\n  font-size: 13px;\n}\n\n:where(\n  .cookiecloud-config-fields,\n  .cover-run-settings,\n  .cover-targets,\n  .style-editor,\n  .brush,\n  .cover,\n  .subtitle-workspace\n) :is(.v-label.v-field-label) {\n  color: var(--app-text-secondary, #657087);\n  font-size: 11px;\n}\n\n:where(.cookiecloud-config-fields, .cover-run-settings) .v-switch .v-label {\n  color: var(--app-text, #202939);\n  font-size: 12px !important;\n  font-weight: 400;\n  opacity: 1;\n}\n\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .cover-history) {\n  overflow: hidden;\n  border: 1px solid var(--app-border, #dfe4ee) !important;\n  border-radius: 18px !important;\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\n  color: var(--app-text, #202939);\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header,\n  .cover-history > header\n) {\n  min-height: 80px;\n  padding: 18px 20px !important;\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\n  background: var(--app-surface, #fff);\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header,\n  .cover-history > header\n) h2 {\n  margin: 0;\n  color: var(--app-text, #202939);\n  font-size: 18px !important;\n  font-weight: 750 !important;\n  line-height: 1.2;\n}\n\n:where(\n  .signin-stat-dialog__header,\n  .cc-statistics-header,\n  .douban-dialog__header,\n  .maoyan-dialog__header\n) p {\n  margin: 3px 0 0;\n  color: var(--app-text-muted, #7a869d);\n  font-size: 10px !important;\n  line-height: 1.4;\n}\n\n:where(\n  .signin-stat-dialog__content,\n  .cc-statistics-content,\n  .douban-dialog__content,\n  .maoyan-dialog__content,\n  .cover-history > main\n) {\n  padding: 20px !important;\n}\n\n:where(\n  .signin-stat-dialog__actions,\n  .cc-statistics-actions,\n  .douban-dialog__actions,\n  .maoyan-dialog__actions,\n  .cover-history > footer\n) {\n  min-height: 64px;\n  padding: 13px 18px !important;\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\n  background: var(--app-surface-raised, var(--app-surface, #fff));\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) {\n  gap: 12px !important;\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) > div {\n  min-width: 0;\n  padding: 15px 16px !important;\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\n  border-radius: 12px !important;\n  background: var(--app-surface, #fff);\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics,\n  .cover-history .metrics\n) dt,\n:where(.cover-history .metrics) span {\n  color: var(--app-text-muted, #7a869d);\n  font-size: 12px !important;\n}\n\n:where(\n  .signin-stat-metrics,\n  .cookie-metrics,\n  .douban-statistics__metrics,\n  .maoyan-statistics__metrics\n) dd,\n:where(.cover-history .metrics) strong {\n  margin-top: 7px;\n  color: var(--app-text, #202939);\n  font-family: inherit !important;\n  font-size: 24px !important;\n  font-weight: 700;\n  font-variant-numeric: tabular-nums;\n  line-height: 1.15;\n}\n\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\n.cookie-metric dd > span {\n  color: var(--app-text-muted, #7a869d);\n  font-size: 11px !important;\n  font-weight: 400;\n}\n\n.signin-stat-results {\n  border-radius: 12px !important;\n}\n\n.signin-stat-results > header {\n  min-height: 44px;\n  padding: 10px 12px !important;\n}\n\n.signin-stat-results article {\n  min-height: 68px;\n  padding: 10px 12px !important;\n}\n\n.signin-stat-results article strong {\n  color: var(--app-text, #202939);\n  font-size: 13px;\n  font-weight: 650;\n}\n\n.signin-stat-results article p {\n  font-size: 12px !important;\n}\n\n.signin-stat-results :is(article span, time) {\n  font-size: 10px !important;\n}\n\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\n  min-width: 0;\n  color: var(--app-text, #17243a);\n  font-family: inherit !important;\n  font-size: 14px;\n  line-height: 1.5;\n}\n\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\n  font-size: 27px !important;\n  font-weight: 750;\n  line-height: 1.15;\n  letter-spacing: 0;\n}\n\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\n  font-size: 18px !important;\n  font-weight: 700;\n  line-height: 1.3;\n}\n\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\n  min-height: 40px;\n  border-radius: 9px !important;\n  font-size: 13px;\n  letter-spacing: 0;\n}\n\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\n  min-height: 52px;\n  border-radius: 11px;\n  color: var(--app-text-secondary, #657087);\n  font: inherit;\n  font-size: 13px;\n}\n\n@media (max-width: 700px) {\n  :where(\n    .signin-stat-dialog__header,\n    .cc-statistics-header,\n    .douban-dialog__header,\n    .maoyan-dialog__header,\n    .cover-history > header,\n    .signin-stat-dialog__content,\n    .cc-statistics-content,\n    .douban-dialog__content,\n    .maoyan-dialog__content,\n    .cover-history > main\n  ) {\n    padding: 16px !important;\n  }\n}\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1$1 = { class: "signin-page" };
const _hoisted_2$1 = { class: "signin-hero" };
const _hoisted_3$1 = { class: "signin-actions" };
const _hoisted_4$1 = ["disabled"];
const _hoisted_5$1 = ["disabled"];
const _hoisted_6$1 = {
  class: "signin-stats",
  "aria-label": "任务数据统计"
};
const _hoisted_7$1 = { class: "signin-panel" };
const _hoisted_8 = { class: "signin-panel-head" };
const _hoisted_9 = {
  key: 0,
  class: "signin-sites"
};
const _hoisted_10 = { class: "signin-modes" };
const _hoisted_11 = ["checked", "onChange"];
const _hoisted_12 = ["checked", "onChange"];
const _hoisted_13 = { class: "signin-checks" };
const _hoisted_14 = ["disabled", "onClick"];
const _hoisted_15 = ["disabled", "onClick"];
const _hoisted_16 = {
  key: 1,
  class: "signin-empty"
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "AutoSigninPage",
  props: {
    request: { type: Function }
  },
  setup(__props) {
    const props = __props;
    const sites = ref([]);
    const signSites = ref([]);
    const loginSites = ref([]);
    const loading = ref(false);
    const saving = ref(false);
    const running = ref("");
    const results = ref({});
    const history = ref([]);
    const config = ref({});
    const message = ref("");
    const recentSuccess = computed(() => history.value.filter((item) => item.status === "signed").length);
    async function load() {
      loading.value = true;
      try {
        const data = await props.request("/plugins/auto-signin/api/inventory");
        sites.value = Array.isArray(data?.items) ? data.items : [];
        config.value = data?.config && typeof data.config === "object" ? data.config : {};
        signSites.value = Array.isArray(data?.selected?.sign_sites) ? data.selected.sign_sites : [];
        loginSites.value = Array.isArray(data?.selected?.login_sites) ? data.selected.login_sites : [];
        history.value = Array.isArray(data?.history) ? data.history : [];
      } catch (error) {
        message.value = error instanceof Error ? error.message : "站点读取失败";
      } finally {
        loading.value = false;
      }
    }
    function toggle(target, id, checked) {
      const list = target === "sign" ? signSites : loginSites;
      const values = new Set(list.value);
      checked ? values.add(id) : values.delete(id);
      list.value = [...values];
    }
    async function save() {
      saving.value = true;
      try {
        await props.request("/plugins/auto-signin", { method: "PATCH", body: JSON.stringify({ config: { ...config.value, sign_sites: signSites.value, login_sites: loginSites.value } }) });
        config.value = { ...config.value, sign_sites: signSites.value, login_sites: loginSites.value };
        message.value = "站点选择已保存";
      } catch (error) {
        message.value = error instanceof Error ? error.message : "保存失败";
      } finally {
        saving.value = false;
      }
    }
    async function runSite(site, mode) {
      const key = `${site.id}:${mode}`;
      running.value = key;
      try {
        const result = await props.request("/plugins/auto-signin/api/site", { method: "POST", body: JSON.stringify({ site_id: site.id, mode }) });
        results.value = { ...results.value, [key]: { ...result, mode, site_name: site.name } };
      } catch (error) {
        results.value = { ...results.value, [key]: { ok: false, mode, site_name: site.name, message: error instanceof Error ? error.message : "执行失败" } };
      } finally {
        running.value = "";
      }
    }
    function resultFor(siteId, mode) {
      const live = results.value[`${siteId}:${mode}`];
      if (live) return live;
      const saved = history.value.find((item) => item.payload?.site_id === siteId && item.payload?.mode === mode);
      return saved?.result;
    }
    function resultText(result, mode) {
      if (!result) return "暂无执行记录";
      if (result.message) return result.message;
      if (result.ok) return mode === "login" ? "登录状态正常" : "签到完成";
      return result.status || "执行失败";
    }
    function eventChecked(event) {
      return event.currentTarget.checked;
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("section", _hoisted_1$1, [
        createElementVNode("header", _hoisted_2$1, [
          _cache[0] || (_cache[0] = createElementVNode(
            "div",
            null,
            [
              createElementVNode("h1", null, "站点签到助手"),
              createElementVNode("p", null, "勾选需要每日签到或仅保持登录的站点；保存后由插件定时执行。")
            ],
            -1
            /* CACHED */
          )),
          createElementVNode("div", _hoisted_3$1, [
            createElementVNode("button", {
              class: "signin-button secondary",
              disabled: loading.value,
              onClick: load
            }, toDisplayString(loading.value ? "读取中…" : "刷新站点"), 9, _hoisted_4$1),
            createElementVNode("button", {
              class: "signin-button",
              disabled: saving.value,
              onClick: save
            }, toDisplayString(saving.value ? "保存中…" : "保存选择"), 9, _hoisted_5$1)
          ])
        ]),
        createElementVNode("div", _hoisted_6$1, [
          createElementVNode("div", null, [
            _cache[1] || (_cache[1] = createElementVNode(
              "span",
              null,
              "已配置站点",
              -1
              /* CACHED */
            )),
            createElementVNode(
              "strong",
              null,
              toDisplayString(sites.value.length),
              1
              /* TEXT */
            )
          ]),
          createElementVNode("div", null, [
            _cache[2] || (_cache[2] = createElementVNode(
              "span",
              null,
              "保持登录",
              -1
              /* CACHED */
            )),
            createElementVNode(
              "strong",
              null,
              toDisplayString(loginSites.value.length),
              1
              /* TEXT */
            )
          ]),
          createElementVNode("div", null, [
            _cache[3] || (_cache[3] = createElementVNode(
              "span",
              null,
              "每日签到",
              -1
              /* CACHED */
            )),
            createElementVNode(
              "strong",
              null,
              toDisplayString(signSites.value.length),
              1
              /* TEXT */
            )
          ]),
          createElementVNode("div", null, [
            _cache[4] || (_cache[4] = createElementVNode(
              "span",
              null,
              "最近成功",
              -1
              /* CACHED */
            )),
            createElementVNode(
              "strong",
              null,
              toDisplayString(recentSuccess.value),
              1
              /* TEXT */
            )
          ])
        ]),
        createElementVNode("main", _hoisted_7$1, [
          createElementVNode("div", _hoisted_8, [
            _cache[5] || (_cache[5] = createElementVNode(
              "div",
              null,
              [
                createElementVNode("h2", null, "站点状态"),
                createElementVNode("p", null, "分别检查保持登录与每日签到，结果按站点保存。")
              ],
              -1
              /* CACHED */
            )),
            createElementVNode(
              "span",
              null,
              toDisplayString(message.value),
              1
              /* TEXT */
            )
          ]),
          sites.value.length ? (openBlock(), createElementBlock("div", _hoisted_9, [
            (openBlock(true), createElementBlock(
              Fragment,
              null,
              renderList(sites.value, (site) => {
                return openBlock(), createElementBlock("article", {
                  key: site.id,
                  class: "signin-site"
                }, [
                  createElementVNode("div", null, [
                    createElementVNode(
                      "strong",
                      null,
                      toDisplayString(site.name),
                      1
                      /* TEXT */
                    ),
                    createElementVNode(
                      "small",
                      null,
                      toDisplayString(site.enabled ? "站点已启用" : "站点已停用"),
                      1
                      /* TEXT */
                    )
                  ]),
                  createElementVNode("div", _hoisted_10, [
                    createElementVNode("label", null, [
                      createElementVNode("input", {
                        type: "checkbox",
                        checked: loginSites.value.includes(site.id),
                        onChange: ($event) => toggle("login", site.id, eventChecked($event))
                      }, null, 40, _hoisted_11),
                      _cache[6] || (_cache[6] = createTextVNode(
                        "保持登录",
                        -1
                        /* CACHED */
                      ))
                    ]),
                    createElementVNode("label", null, [
                      createElementVNode("input", {
                        type: "checkbox",
                        checked: signSites.value.includes(site.id),
                        onChange: ($event) => toggle("sign", site.id, eventChecked($event))
                      }, null, 40, _hoisted_12),
                      _cache[7] || (_cache[7] = createTextVNode(
                        "每日签到",
                        -1
                        /* CACHED */
                      ))
                    ])
                  ]),
                  createElementVNode("div", _hoisted_13, [
                    createElementVNode("div", null, [
                      _cache[8] || (_cache[8] = createElementVNode(
                        "span",
                        null,
                        "保持登录",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "p",
                        {
                          class: normalizeClass(["signin-result", { ok: resultFor(site.id, "login")?.ok, bad: resultFor(site.id, "login") && !resultFor(site.id, "login")?.ok }])
                        },
                        toDisplayString(resultText(resultFor(site.id, "login"), "login")),
                        3
                        /* TEXT, CLASS */
                      ),
                      createElementVNode("button", {
                        class: "signin-button secondary compact",
                        disabled: Boolean(running.value),
                        onClick: ($event) => runSite(site, "login")
                      }, toDisplayString(running.value === `${site.id}:login` ? "检查中…" : "检查登录"), 9, _hoisted_14)
                    ]),
                    createElementVNode("div", null, [
                      _cache[9] || (_cache[9] = createElementVNode(
                        "span",
                        null,
                        "每日签到",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "p",
                        {
                          class: normalizeClass(["signin-result", { ok: resultFor(site.id, "sign")?.ok, bad: resultFor(site.id, "sign") && !resultFor(site.id, "sign")?.ok }])
                        },
                        toDisplayString(resultText(resultFor(site.id, "sign"), "sign")),
                        3
                        /* TEXT, CLASS */
                      ),
                      createElementVNode("button", {
                        class: "signin-button secondary compact",
                        disabled: Boolean(running.value),
                        onClick: ($event) => runSite(site, "sign")
                      }, toDisplayString(running.value === `${site.id}:sign` ? "执行中…" : "测试签到"), 9, _hoisted_15)
                    ])
                  ])
                ]);
              }),
              128
              /* KEYED_FRAGMENT */
            ))
          ])) : (openBlock(), createElementBlock(
            "div",
            _hoisted_16,
            toDisplayString(loading.value ? "正在读取站点…" : "尚未配置 PT 站点"),
            1
            /* TEXT */
          ))
        ])
      ]);
    };
  }
});
const _hoisted_1 = { class: "signin-stat-dialog__header" };
const _hoisted_2 = { class: "signin-stat-dialog__content" };
const _hoisted_3 = {
  key: 0,
  class: "signin-stat-empty"
};
const _hoisted_4 = { class: "signin-stat-metrics" };
const _hoisted_5 = {
  key: 0,
  class: "signin-stat-results",
  "aria-label": "最近站点结果"
};
const _hoisted_6 = {
  key: 1,
  class: "signin-stat-empty"
};
const _hoisted_7 = { class: "signin-stat-dialog__actions" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: {},
    buttonComponent: {},
    cardComponent: {},
    dialogComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiButton = props.buttonComponent;
    const UiCard = props.cardComponent;
    const UiDialog = props.dialogComponent;
    const UiAlert = props.alertComponent;
    const loading = ref(false);
    const error = ref("");
    const inventory = ref({});
    const history = computed(() => inventory.value.history || []);
    const loginCount = computed(() => inventory.value.selected?.login_sites?.length || 0);
    const signCount = computed(() => inventory.value.selected?.sign_sites?.length || 0);
    const successful = computed(() => history.value.filter((item) => item.result?.ok || item.status === "signed").length);
    const failed = computed(() => history.value.filter((item) => item.result?.ok === false || item.status === "failed").length);
    function siteName(item) {
      const id = String(item.payload?.site_id || "");
      return item.payload?.site_name || item.result?.site_name || inventory.value.items?.find((site) => site.id === id)?.name || id || "未知站点";
    }
    function modeName(item) {
      return item.payload?.mode === "login" ? "保持登录" : "签到";
    }
    function resultText(item) {
      if (item.result?.message) return item.result.message;
      if (item.result?.ok || item.status === "signed") return item.payload?.mode === "login" ? "登录状态正常" : "签到完成";
      return item.result?.status || "执行失败";
    }
    function localTime(value) {
      if (!value) return "时间未知";
      const date = new Date(value);
      return Number.isFinite(date.getTime()) ? date.toLocaleString("zh-CN", { hour12: false }) : value;
    }
    async function load() {
      loading.value = true;
      error.value = "";
      try {
        inventory.value = await props.request("/plugins/auto-signin/api/inventory");
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "签到统计加载失败";
      } finally {
        loading.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(UiDialog), {
        "model-value": true,
        "max-width": 1080,
        width: "calc(100vw - 32px)",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = (open) => {
          if (!open) __props.context.close();
        })
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "signin-stat-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1, [
                _cache[1] || (_cache[1] = createElementVNode(
                  "div",
                  null,
                  [
                    createElementVNode("h2", null, "站点签到与登录统计"),
                    createElementVNode("p", null, "签到和保持登录分别统计，同一站点的两类结果不会合并。")
                  ],
                  -1
                  /* CACHED */
                )),
                createVNode(unref(UiButton), {
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: __props.context.close
                }, null, 8, ["onClick"])
              ]),
              createElementVNode("main", _hoisted_2, [
                loading.value ? (openBlock(), createElementBlock("p", _hoisted_3, "正在读取统计…")) : error.value ? (openBlock(), createBlock(unref(UiAlert), {
                  key: 1,
                  type: "error",
                  variant: "tonal"
                }, {
                  default: withCtx(() => [
                    createTextVNode(
                      toDisplayString(error.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  _: 1
                  /* STABLE */
                })) : (openBlock(), createElementBlock(
                  Fragment,
                  { key: 2 },
                  [
                    createElementVNode("dl", _hoisted_4, [
                      createElementVNode("div", null, [
                        _cache[2] || (_cache[2] = createElementVNode(
                          "dt",
                          null,
                          "保持登录站点",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode(
                          "dd",
                          null,
                          toDisplayString(loginCount.value),
                          1
                          /* TEXT */
                        )
                      ]),
                      createElementVNode("div", null, [
                        _cache[3] || (_cache[3] = createElementVNode(
                          "dt",
                          null,
                          "签到站点",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode(
                          "dd",
                          null,
                          toDisplayString(signCount.value),
                          1
                          /* TEXT */
                        )
                      ]),
                      createElementVNode("div", null, [
                        _cache[4] || (_cache[4] = createElementVNode(
                          "dt",
                          null,
                          "最近成功",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode(
                          "dd",
                          null,
                          toDisplayString(successful.value),
                          1
                          /* TEXT */
                        )
                      ]),
                      createElementVNode("div", null, [
                        _cache[5] || (_cache[5] = createElementVNode(
                          "dt",
                          null,
                          "最近失败",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode(
                          "dd",
                          null,
                          toDisplayString(failed.value),
                          1
                          /* TEXT */
                        )
                      ])
                    ]),
                    history.value.length ? (openBlock(), createElementBlock("section", _hoisted_5, [
                      _cache[6] || (_cache[6] = createElementVNode(
                        "header",
                        null,
                        [
                          createElementVNode("strong", null, "最近站点结果"),
                          createElementVNode("span", null, "最多显示 100 条")
                        ],
                        -1
                        /* CACHED */
                      )),
                      (openBlock(true), createElementBlock(
                        Fragment,
                        null,
                        renderList(history.value, (item, index) => {
                          return openBlock(), createElementBlock("article", {
                            key: `${item.payload?.site_id}-${item.payload?.mode}-${index}`
                          }, [
                            createElementVNode("div", null, [
                              createElementVNode(
                                "strong",
                                null,
                                toDisplayString(siteName(item)),
                                1
                                /* TEXT */
                              ),
                              createElementVNode(
                                "span",
                                null,
                                toDisplayString(modeName(item)),
                                1
                                /* TEXT */
                              )
                            ]),
                            createElementVNode(
                              "p",
                              {
                                class: normalizeClass({ bad: item.result?.ok === false || item.status === "failed" })
                              },
                              toDisplayString(resultText(item)),
                              3
                              /* TEXT, CLASS */
                            ),
                            createElementVNode(
                              "time",
                              null,
                              toDisplayString(localTime(item.updated_at)),
                              1
                              /* TEXT */
                            )
                          ]);
                        }),
                        128
                        /* KEYED_FRAGMENT */
                      ))
                    ])) : (openBlock(), createElementBlock("p", _hoisted_6, "还没有执行记录。任务运行后，这里会按站点名称显示签到和登录结果。"))
                  ],
                  64
                  /* STABLE_FRAGMENT */
                ))
              ]),
              createElementVNode("footer", _hoisted_7, [
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: loading.value,
                  onClick: load
                }, {
                  default: withCtx(() => [..._cache[7] || (_cache[7] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading"]),
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-cog-outline",
                  variant: "flat",
                  color: "primary",
                  onClick: __props.context.configure
                }, {
                  default: withCtx(() => [..._cache[8] || (_cache[8] = [
                    createTextVNode(
                      "调整设置",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["onClick"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-5288a76e"]]);
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const { Alert, Button, Card, Dialog } = sdk.ui.components;
  const Page = defineComponent2({
    name: "SiteCheckinPage",
    inheritAttrs: false,
    setup() {
      return () => h(_sfc_main$1, {
        request: (path, init) => sdk.request(path, init)
      });
    }
  });
  const Statistics = defineComponent2({
    name: "SiteCheckinStatistics",
    inheritAttrs: false,
    props: { context: { type: Object, required: true } },
    setup(props, { attrs }) {
      return () => h(StatisticsView, {
        ...attrs,
        context: props.context,
        request: sdk.request,
        alertComponent: Alert,
        buttonComponent: Button,
        cardComponent: Card,
        dialogComponent: Dialog
      });
    }
  });
  sdk.registerPage({ pluginId: "auto-signin", route: "plugin-auto-signin", title: "自动签到", icon: "mdi-calendar-check-outline", section: "tools", order: 72, component: Page });
  sdk.registerContribution({ pluginId: "auto-signin", slot: "plugin.statistics", key: "site-results", component: Statistics });
}
export {
  install
};
