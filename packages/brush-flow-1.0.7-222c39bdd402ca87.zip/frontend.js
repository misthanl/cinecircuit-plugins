if (typeof document !== "undefined") { const id = "brush_flow"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.traffic-dialog[data-v-1ac1b330]{max-height:min(560px,calc(100dvh - 48px))}\n.traffic-dialog-heading[data-v-1ac1b330]{display:flex;justify-content:space-between;align-items:center;padding:10px 16px;border-bottom:1px solid var(--app-border-subtle,#e7ebf2)}\n.traffic-dialog-heading h2[data-v-1ac1b330]{margin:0;font-size:16px;font-weight:600}\n.traffic-dialog-tabs[data-v-1ac1b330]{padding:0 16px;border-bottom:1px solid var(--app-border-subtle,#e7ebf2);flex-shrink:0}\n.traffic-dialog-body[data-v-1ac1b330]{padding:16px!important;min-height:0}\n.traffic-dialog-section[data-v-1ac1b330]{display:grid;gap:10px}\n.traffic-resource-grid[data-v-1ac1b330]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px 16px}\n.traffic-dialog-actions[data-v-1ac1b330]{gap:8px;flex-wrap:wrap;justify-content:flex-end}\n.traffic-dialog-error[data-v-1ac1b330]{color:rgb(var(--v-theme-error));font-size:10px;font-weight:400}\n@media(max-width:560px){.traffic-resource-grid[data-v-1ac1b330]{grid-template-columns:1fr}}\r\n\n.task-card[data-v-704e567d]{border:1px solid var(--app-border-subtle);border-left:3px solid var(--app-success-text);border-radius:12px;background:var(--app-surface);color:var(--app-text);min-width:0}\n.task-card.paused[data-v-704e567d]{border-left-color:var(--app-border-subtle)}\n.task-header[data-v-704e567d]{display:flex;align-items:center;gap:12px;padding:14px 16px}\n.task-disclosure[data-v-704e567d]{display:flex;align-items:center;flex:1;min-width:0;gap:14px;padding:0;border:0;background:transparent;color:inherit;text-align:left;font:inherit;cursor:pointer;border-radius:6px}\n.task-disclosure[data-v-704e567d]:focus-visible{outline:2px solid rgb(var(--v-theme-primary));outline-offset:4px}\n.task-icon[data-v-704e567d]{display:grid;place-items:center;width:40px;height:40px;border-radius:9px;background:var(--app-info-soft);color:rgb(var(--v-theme-primary));flex-shrink:0}\n.task-title[data-v-704e567d]{display:grid;flex:1;gap:4px;min-width:0}\n.task-name[data-v-704e567d]{font-size:var(--app-font-size-body);font-weight:var(--app-font-weight-heading);overflow-wrap:anywhere}\n.task-metadata[data-v-704e567d]{display:flex;align-items:baseline;flex-wrap:wrap;gap:4px 8px;color:var(--app-text-secondary);font-size:var(--app-table-field-content-font-size);font-weight:var(--app-font-weight-regular);line-height:var(--app-line-height-body)}\n.task-route[data-v-704e567d]{min-width:0;overflow-wrap:anywhere}\n.task-route>span[data-v-704e567d]{margin:0 6px}\n.task-summary[data-v-704e567d]{min-width:0;overflow-wrap:anywhere}\n.task-summary>span[data-v-704e567d]{margin-right:6px}\n.task-status[data-v-704e567d]{border-radius:var(--app-radius-chip);background:var(--app-success-soft);color:var(--app-success-text);padding:4px 10px;font-size:var(--app-selection-chip-font-size);white-space:nowrap}\n.task-status.paused[data-v-704e567d]{background:var(--app-surface-subtle);color:var(--app-text-secondary)}\n.task-actions[data-v-704e567d]{display:flex;align-items:center;gap:4px;flex-shrink:0}\n.task-menu[data-v-704e567d]{display:inline-flex}\n.task-details[data-v-704e567d]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px 40px;margin:0 16px;padding:20px 0;border-top:1px solid var(--app-border-subtle)}\n.task-detail-group[data-v-704e567d]{min-width:0}\n.task-detail-group h5[data-v-704e567d]{display:flex;align-items:center;gap:10px;margin:0 0 14px;font-size:var(--app-font-size-body);font-weight:var(--app-font-weight-heading);color:var(--app-text)}\n.task-detail-group h5 .v-icon[data-v-704e567d]{color:rgb(var(--v-theme-primary));flex-shrink:0}\n.task-detail-group dl[data-v-704e567d]{display:grid;gap:10px;margin:0;font-size:var(--app-font-size-body);font-weight:var(--app-font-weight-regular)}\n.task-detail-group dl>div[data-v-704e567d]{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:12px;align-items:baseline}\n.task-detail-group dt[data-v-704e567d]{color:var(--app-text);overflow-wrap:anywhere}\n.task-detail-group dd[data-v-704e567d]{margin:0;text-align:right;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}\n.task-rules[data-v-704e567d]{grid-column:1/-1;border-top:1px solid var(--app-border-subtle);padding-top:18px}\n.task-rule-columns[data-v-704e567d]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:40px}\n.task-detail-group .task-keywords.long-rule[data-v-704e567d]{grid-template-columns:minmax(0,1fr);gap:6px}\n.task-keywords.long-rule dd[data-v-704e567d]{text-align:left}\n.task-notification[data-v-704e567d]{display:flex;align-items:center;justify-content:flex-end;gap:8px}\n.notification-dot[data-v-704e567d]{width:7px;height:7px;flex-shrink:0;border-radius:50%;background:var(--app-success-text)}\n@media(max-width:700px){.task-disclosure[data-v-704e567d]{gap:12px}.task-details[data-v-704e567d]{gap:20px}.task-rule-columns[data-v-704e567d]{gap:20px}}\n@media(max-width:480px){.task-header[data-v-704e567d]{display:grid;grid-template-columns:minmax(0,1fr) 36px;gap:8px}.task-disclosure[data-v-704e567d]{grid-column:1;grid-row:1}.task-status[data-v-704e567d]{grid-column:1;grid-row:2;justify-self:start;margin-left:52px}.task-actions[data-v-704e567d]{display:contents}.task-menu[data-v-704e567d]{grid-column:2;grid-row:1;align-self:start}.task-actions>.v-btn[data-v-704e567d]{grid-column:2;grid-row:2}.task-details[data-v-704e567d],.task-rule-columns[data-v-704e567d]{grid-template-columns:minmax(0,1fr)}.task-rule-columns[data-v-704e567d]{gap:10px}}\r\n\n.traffic-config[data-v-8716f009]{display:grid;grid-template-columns:minmax(0,1fr);gap:20px;grid-column:1/-1;min-width:0}\n.traffic-config h3[data-v-8716f009],.traffic-config h4[data-v-8716f009],.traffic-config p[data-v-8716f009]{margin:0}\n.traffic-config h3[data-v-8716f009],.traffic-config h4[data-v-8716f009]{color:var(--app-text);font-size:var(--app-font-size-body,14px);font-weight:var(--app-font-weight-heading, 600);overflow-wrap:anywhere}\n.traffic-config p[data-v-8716f009]{font-size:var(--app-font-size-helper,12px);line-height:1.5;color:var(--app-text-muted,#7a869d)}\n.global-heading[data-v-8716f009]{display:grid;gap:5px;min-width:0}\n.global-config-fields[data-v-8716f009] > .v-input{min-width:0}\n.traffic-heading[data-v-8716f009]{display:flex;align-items:center;justify-content:space-between;gap:16px;padding-top:16px;border-top:1px solid var(--app-border-subtle,#e7ebf2)}\n.traffic-heading h3 span[data-v-8716f009]{font-size:12px;margin-left:8px;color:var(--app-text-muted,#7a869d);font-weight:400}\n.traffic-empty[data-v-8716f009]{text-align:center;padding:28px 16px;border:1px solid var(--app-border-subtle,#e7ebf2);border-radius:12px}\n.traffic-empty h4[data-v-8716f009]{margin:10px 0 4px}.traffic-empty .v-icon[data-v-8716f009]{color:var(--app-text-muted,#7a869d)}\n.traffic-tasks[data-v-8716f009]{display:grid;gap:12px}\n.traffic-task[data-v-8716f009]{border:1px solid var(--app-border-subtle,#e7ebf2);border-radius:12px;padding:15px 16px;min-width:0;background:var(--app-surface,#fff)}\n.traffic-task header[data-v-8716f009],.traffic-task footer[data-v-8716f009]{display:flex;align-items:center;justify-content:space-between;gap:12px}\n.traffic-status[data-v-8716f009]{white-space:nowrap;font-size:9px;color:var(--app-text-secondary,#657087)}\n.paused .traffic-status[data-v-8716f009]{color:var(--app-text-muted,#7a869d)}\n.traffic-route[data-v-8716f009]{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:12px 0;color:var(--app-text-secondary,#657087);font-size:var(--app-font-size-body,14px)}\n.traffic-route span[data-v-8716f009]:nth-child(2){color:var(--app-text-muted,#7a869d)}\n.traffic-task dl[data-v-8716f009]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px 16px;margin:0 0 12px}\n.traffic-task dt[data-v-8716f009]{font-size:12px;color:var(--app-text-muted,#7a869d)}\n.traffic-task dd[data-v-8716f009]{margin:4px 0 0;font-size:var(--app-font-size-body,14px);overflow-wrap:anywhere;font-variant-numeric:tabular-nums}\n.traffic-rule[data-v-8716f009]{overflow-wrap:anywhere}\n.traffic-task footer[data-v-8716f009]{margin-top:12px;padding-top:12px;border-top:1px solid var(--app-border-subtle,#e7ebf2);font-size:12px;color:var(--app-text-muted,#7a869d)}\n.traffic-error[data-v-8716f009]{display:flex;align-items:center;gap:8px;color:rgb(var(--v-theme-error));font-size:10px;line-height:1.5;font-weight:400}\n.traffic-error>span[data-v-8716f009]{min-width:0;overflow-wrap:anywhere}\n.traffic-error[data-v-8716f009] > .v-btn{flex:0 0 auto;align-self:center;margin:0}\n@media(max-width:480px){.traffic-heading[data-v-8716f009]{align-items:flex-start}.traffic-task footer[data-v-8716f009]{align-items:flex-start;flex-wrap:wrap}}\r\n\n.plugin-statistic-placeholder[data-v-bdcf673e] {\n  display: inline-block;\n  color: var(--app-text-muted, #7b89a4);\n  font-size: 12px;\n  font-weight: 400;\n  line-height: 1;\n  vertical-align: middle;\n}\n\n.stat-task[data-v-29eeb43b]{min-width:0;border:1px solid var(--app-border-subtle);border-left:3px solid var(--app-success-text);border-radius:var(--app-radius-panel);background:var(--app-surface);color:var(--app-text)}\n.stat-task.paused[data-v-29eeb43b]{border-left-color:var(--app-border-subtle)}\n.stat-task-toggle[data-v-29eeb43b]{display:flex;align-items:center;width:100%;gap:16px;padding:16px;border:0;border-radius:var(--app-radius-panel);background:transparent;color:inherit;text-align:left;font:inherit;cursor:pointer}\n.stat-task-toggle[data-v-29eeb43b]:focus-visible{outline:2px solid rgb(var(--v-theme-primary));outline-offset:2px}\n.stat-task-info[data-v-29eeb43b]{display:grid;flex:1;min-width:0;gap:5px}\n.stat-task-name[data-v-29eeb43b]{font-size:var(--app-font-size-body);font-weight:var(--app-font-weight-heading);overflow-wrap:anywhere}\n.stat-task-metadata[data-v-29eeb43b]{display:flex;align-items:baseline;flex-wrap:wrap;gap:4px 8px;font-size:var(--app-table-field-content-font-size);font-weight:var(--app-font-weight-regular);line-height:var(--app-line-height-body);color:var(--app-text-secondary)}\n.stat-task-metadata>span[data-v-29eeb43b]{min-width:0;overflow-wrap:anywhere}\n.stat-task-status[data-v-29eeb43b]{flex-shrink:0;padding:4px 9px;border-radius:var(--app-radius-chip);font-size:var(--app-selection-chip-font-size);font-weight:var(--app-font-weight-regular);background:var(--app-success-soft);color:var(--app-success-text);white-space:nowrap}\n.stat-task-status.paused[data-v-29eeb43b]{background:var(--app-surface-muted);color:var(--app-text-secondary)}\n.stat-task-chevron[data-v-29eeb43b]{flex-shrink:0}\n.stat-task-details[data-v-29eeb43b]{margin:0 16px;padding:16px 0;border-top:1px solid var(--app-border-subtle)}\n.stat-task-metrics[data-v-29eeb43b]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px;margin:0}\n.stat-task-metrics>div[data-v-29eeb43b]{display:grid;grid-template-columns:20px minmax(0,1fr);gap:6px 12px;align-items:center;min-width:0}\n.stat-task-metrics .v-icon[data-v-29eeb43b]{grid-column:1;grid-row:1/3;color:rgb(var(--v-theme-primary))}\n.stat-task-metrics dt[data-v-29eeb43b]{font-size:var(--app-table-field-content-font-size);font-weight:var(--app-font-weight-regular);color:var(--app-text)}\n.stat-task-metrics dd[data-v-29eeb43b]{grid-column:2;margin:0;font-size:var(--app-font-size-body);font-weight:var(--app-font-weight-medium);font-variant-numeric:tabular-nums;overflow-wrap:anywhere}\n.stat-task-note[data-v-29eeb43b]{margin:16px 0 0;font-size:var(--app-font-size-explanation);font-weight:var(--app-font-weight-regular);color:var(--app-text-secondary)}\n.stat-task-capacity[data-v-29eeb43b]{appearance:none;display:block;width:100%;height:6px;margin-top:16px;border:0;border-radius:var(--app-radius-chip);overflow:hidden}\n.stat-task-capacity[data-v-29eeb43b]::-webkit-progress-bar{background:var(--app-surface-disabled)}\n.stat-task-capacity[data-v-29eeb43b]::-webkit-progress-value{background:rgb(var(--v-theme-primary))}\n.stat-task-capacity[data-v-29eeb43b]::-moz-progress-bar{background:rgb(var(--v-theme-primary))}\n@media(max-width:600px){.stat-task-toggle[data-v-29eeb43b]{gap:10px}.stat-task-metrics[data-v-29eeb43b]{grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.stat-task-status[data-v-29eeb43b]{font-size:var(--app-font-size-explanation)}}\n\n.traffic-statistics-dialog[data-v-8a723046]{display:flex;flex-direction:column;max-height:calc(100dvh - 32px);overflow:hidden;border-radius:var(--app-dialog-radius, 16px)!important;background:var(--app-dialog-surface,#fff);color:var(--app-text);font-weight:400}.statistics-heading[data-v-8a723046]{display:flex;align-items:center;justify-content:space-between;padding:10px 20px;border-bottom:1px solid var(--app-border-subtle,#e1e7f0);flex:0 0 auto}.statistics-heading h2[data-v-8a723046]{margin:0;font-size:16px;font-weight:600}.traffic-statistics[data-v-8a723046]{color:var(--app-text);font-size:14px;min-width:0;overflow:auto;padding:20px;font-weight:400}.stat-toolbar[data-v-8a723046]{display:flex;gap:16px;align-items:center;margin-bottom:18px}.stat-toolbar .v-input[data-v-8a723046]{max-width:190px;min-width:120px}.updated[data-v-8a723046]{color:var(--app-text-secondary,#657087);font-size:11px;flex:1;font-weight:400}.stat-totals[data-v-8a723046]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.stat-totals>div[data-v-8a723046]{display:flex;flex-direction:column;gap:7px;align-items:flex-start;text-align:left;min-width:0;padding:15px 16px;border:1px solid var(--app-border-subtle,#e2e7f0);border-radius:12px;background:var(--app-surface-muted,#f4f6fb)}.stat-totals>div>span[data-v-8a723046],.stat-heading>span[data-v-8a723046],dt[data-v-8a723046]{color:var(--app-text-secondary,#657087);font-size:10px;font-weight:400}.stat-totals strong[data-v-8a723046]{font-family:inherit;font-size:var(--app-font-size-metric,24px);font-weight:var(--app-font-weight-metric, 600);line-height:1.15;color:var(--app-text,#202939);font-variant-numeric:tabular-nums;overflow-wrap:anywhere}.stat-note[data-v-8a723046]{color:var(--app-text-muted,#7b89a4);font-size:9px;margin:9px 0}.stat-heading[data-v-8a723046]{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:22px 0 12px}.stat-heading h3[data-v-8a723046]{margin:0;font-size:12px;font-weight:500}.stat-task-list[data-v-8a723046]{display:grid;gap:12px}.status[data-v-8a723046]{display:inline-block;padding:4px 9px;border-radius:var(--app-radius-chip, 6px);font-size:var(--app-font-size-helper,9px);color:var(--app-success-text);background:var(--app-success-soft);white-space:nowrap;font-weight:400}.status.paused[data-v-8a723046]{color:var(--app-text-secondary,#657087);background:var(--app-surface-subtle,#f1f3f7)}.status.failed[data-v-8a723046]{color:var(--app-danger-text);background:var(--app-danger-soft)}.segments[data-v-8a723046]{display:flex;border:1px solid var(--app-border-subtle,#e1e7f0);padding:3px;border-radius:8px}.segments button[data-v-8a723046]{font:inherit;font-size:12px;background:none;border:0;padding:7px 13px;color:inherit;cursor:pointer}.segments .on[data-v-8a723046]{background:#2968ff;color:#fff;border-radius:5px}.execution-table[data-v-8a723046]{overflow:auto;border:1px solid var(--app-border-subtle,#e1e7f0);border-radius:var(--app-radius-panel, 12px)}table[data-v-8a723046]{width:100%;border-collapse:collapse;white-space:nowrap}th[data-v-8a723046],td[data-v-8a723046]{text-align:left;padding:12px;border-bottom:1px solid var(--app-border-subtle,#e1e7f0);font-size:12px;font-weight:400}th[data-v-8a723046]{font-weight:500;background:var(--app-surface-subtle,#f4f6fa);color:var(--app-text-secondary,#657087);font-size:11px}tbody tr:last-child td[data-v-8a723046]{border-bottom:0}td button[data-v-8a723046],.stat-pagination button[data-v-8a723046]{border:0;background:none;color:inherit;cursor:pointer;min-width:32px;min-height:32px}.execution-detail[data-v-8a723046]{background:var(--app-surface-subtle,#f4f6fa)}.stat-pagination[data-v-8a723046]{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 0;font-size:10px;color:var(--app-text-muted,#7b89a4);font-weight:400}.stat-pagination>div[data-v-8a723046]{display:flex;align-items:center;gap:6px}.stat-pagination input[data-v-8a723046]{width:48px;text-align:center;border:1px solid var(--app-border-subtle,#e1e7f0);border-radius:8px;padding:5px;background:var(--app-surface,#fff);color:inherit}.stat-pagination button[data-v-8a723046]:disabled{opacity:.35;cursor:default}button[data-v-8a723046]:focus-visible,input[data-v-8a723046]:focus-visible{outline:2px solid #2968ff;outline-offset:2px}.stat-empty[data-v-8a723046]{text-align:center;padding:24px;color:var(--app-text-muted,#7b89a4)}.stat-error[data-v-8a723046]{color:var(--app-danger-text);background:var(--app-danger-soft);padding:10px;border-radius:6px;font-size:10px}\n@media(max-width:700px){.traffic-statistics-dialog[data-v-8a723046]{max-height:min(720px,calc(100dvh - 112px))}.traffic-statistics[data-v-8a723046]{padding:16px;font-weight:400}.stat-toolbar[data-v-8a723046]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.stat-toolbar .v-input[data-v-8a723046]{max-width:none;min-width:0;width:100%}.updated[data-v-8a723046]{grid-column:1;line-height:1.5;font-size:11px;font-weight:400;color:var(--app-text-secondary,#657087)}.stat-toolbar>.v-btn[data-v-8a723046]{justify-self:end}.stat-totals[data-v-8a723046]{grid-template-columns:repeat(2,minmax(0,1fr))}.stat-pagination[data-v-8a723046]{flex-wrap:wrap;font-size:10px;font-weight:400}.stat-heading>span[data-v-8a723046]{font-size:10px;font-weight:400;color:var(--app-text-secondary,#657087)}.execution-table table[data-v-8a723046]{min-width:620px}}\n.statistics-footer[data-v-8a723046]{display:flex;flex:0 0 auto;align-items:center;justify-content:space-between;gap:12px;padding:10px 18px;border-top:1px solid var(--app-border-subtle,#e2e7f0);background:var(--app-surface,#fff)}\n.statistics-footer>.v-btn[data-v-8a723046]{flex:0 0 auto;color:var(--app-text,#202939)}\n.execution-table td[data-v-8a723046]:first-child{font-size:11px;font-weight:400}.execution-table td.execution-detail[data-v-8a723046]{font-size:var(--app-font-size-explanation,10px);font-weight:400}\r\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\r\n * Values mirror the host application's standard configuration dialog and\r\n * operational content density. Keep business-specific layouts in each plugin.\r\n */\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .signin-page,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace,\r\n  .signin-stat-dialog,\r\n  .cc-statistics-dialog,\r\n  .douban-dialog,\r\n  .maoyan-dialog,\r\n  .cover-history\r\n) {\r\n  color: var(--app-text, #1a2434);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field) {\r\n  min-height: var(--app-control-height, 52px);\r\n  border-radius: var(--app-control-radius, 12px);\r\n  background: var(--control-surface, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field__input) {\r\n  min-width: 0;\r\n  min-height: var(--app-control-height, 52px) !important;\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-label.v-field-label) {\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-label, 11px);\r\n}\r\n\r\n/* Custom plugin editors render Vuetify switches directly instead of through\r\n * the host's InlineSwitchRow. Pin their copy to the host's compact form-label\r\n * treatment so Vuetify's larger body label cannot change the visual scale. */\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-switch, .v-checkbox, .v-radio) .v-label {\r\n  color: var(--app-text-secondary, #657087) !important;\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: 12px !important;\r\n  font-weight: 500 !important;\r\n  line-height: 1.35;\r\n  opacity: 1;\r\n}\r\n\r\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .traffic-dialog, .cover-history) {\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border, #dfe4ee) !important;\r\n  border-radius: var(--app-dialog-radius, 16px) !important;\r\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\r\n  color: var(--app-text, #202939);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) {\r\n  min-height: 80px;\r\n  padding: 18px 20px !important;\r\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) h2 {\r\n  margin: 0;\r\n  color: var(--app-text, #202939);\r\n  font-size: 16px !important;\r\n  font-weight: 600 !important;\r\n  line-height: 1.2;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header\r\n) p {\r\n  margin: 3px 0 0;\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: var(--app-font-size-helper, 10px) !important;\r\n  line-height: 1.4;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__content,\r\n  .cc-statistics-content,\r\n  .douban-dialog__content,\r\n  .traffic-dialog-body,\r\n  .maoyan-dialog__content,\r\n  .cover-history > main\r\n) {\r\n  padding: 20px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__actions,\r\n  .cc-statistics-actions,\r\n  .douban-dialog__actions,\r\n  .traffic-dialog-actions,\r\n  .maoyan-dialog__actions,\r\n  .cover-history > footer\r\n) {\r\n  min-height: 64px;\r\n  padding: 13px 18px !important;\r\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface-raised, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) {\r\n  gap: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) > div {\r\n  min-width: 0;\r\n  padding: 15px 16px !important;\r\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  border-radius: 12px !important;\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) dt,\r\n:where(.cover-history .metrics) span {\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: 10px !important;\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics\r\n) dd,\r\n:where(.cover-history .metrics) strong {\r\n  margin-top: 7px;\r\n  color: var(--app-text, #202939);\r\n  font-family: inherit !important;\r\n  font-size: var(--app-font-size-metric, 24px) !important;\r\n  font-weight: var(--app-font-weight-metric, 600);\r\n  font-variant-numeric: tabular-nums;\r\n  line-height: 1.15;\r\n}\r\n\r\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span:not(.plugin-statistic-placeholder),\r\n.cookie-metric dd > span:not(.plugin-statistic-placeholder) {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: var(--app-font-size-helper, 9px) !important;\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n.signin-stat-results {\r\n  border-radius: 12px !important;\r\n}\r\n\r\n.signin-stat-results > header {\r\n  min-height: 44px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article {\r\n  min-height: 68px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article strong {\r\n  color: var(--app-text, #202939);\r\n  font-size: 13px;\r\n  font-weight: var(--app-font-weight-medium, 500);\r\n}\r\n\r\n.signin-stat-results article p {\r\n  font-size: var(--app-font-size-explanation, 10px) !important;\r\n}\r\n\r\n.signin-stat-results :is(article span, time) {\r\n  font-size: 10px !important;\r\n}\r\n\r\n.signin-stat-results time {\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: 11px !important;\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\r\n  min-width: 0;\r\n  color: var(--app-text, #17243a);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  line-height: 1.5;\r\n}\r\n\r\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\r\n  font-size: 27px !important;\r\n  font-weight: 600;\r\n  line-height: 1.15;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\r\n  font-size: 12px !important;\r\n  font-weight: 500;\r\n  line-height: 1.3;\r\n}\r\n\r\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\r\n  min-height: 40px;\r\n  border-radius: var(--app-radius-action) !important;\r\n  font-size: 13px;\r\n  letter-spacing: 0;\r\n  font-weight: 500;\r\n}\r\n\r\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\r\n  min-height: 52px;\r\n  border-radius: var(--app-control-radius, 12px);\r\n  color: var(--app-text-secondary, #657087);\r\n  font: inherit;\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n@media (max-width: 700px) {\r\n  :where(\r\n    .signin-stat-dialog__header,\r\n    .cc-statistics-header,\r\n    .douban-dialog__header,\r\n    .traffic-dialog-heading,\n    .maoyan-dialog__header,\n    .cover-history > header,\r\n    .signin-stat-dialog__content,\r\n    .cc-statistics-content,\r\n    .douban-dialog__content,\r\n    .traffic-dialog-body,\n    .maoyan-dialog__content,\n    .cover-history > main\r\n  ) {\r\n    padding: 16px !important;\r\n  }\r\n}\r\n\r\n/* Legacy-host fallback. On current hosts, the public form owns these tokens. */\r\n:where(.app-form-layout) {\r\n  display: grid;\r\n  grid-template-columns: repeat(var(--app-plugin-config-columns, 2), minmax(0, 1fr));\r\n  row-gap: var(--app-plugin-config-row-gap, 14px);\r\n  column-gap: var(--app-plugin-config-column-gap, 16px);\r\n}\r\n@media (max-width: 760px) {\r\n  :where(.app-form-layout) { grid-template-columns: minmax(0, 1fr); }\r\n}\r\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createCommentVNode = runtime.createCommentVNode;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const resolveComponent = runtime.resolveComponent;
const resolveDynamicComponent = runtime.resolveDynamicComponent;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
function pluginErrorText(error, fallback) {
  if (requestErrorNotified(error)) return "";
  return error instanceof Error ? error.message : fallback;
}
function requestErrorNotified(error) {
  return Boolean(error && typeof error === "object" && "notificationHandled" in error && error.notificationHandled);
}
function pluginErrorFallback(error, fallback) {
  return requestErrorNotified(error) ? "" : fallback;
}
function orderedFields(fields, order) {
  return order.flatMap((key) => {
    const field = fields.find((candidate) => candidate.key === key);
    return field ? [{ ...field }] : [];
  });
}
const basicFields = [
  { key: "enabled", label: "启用此任务", input_type: "switch", default: true },
  { key: "notification_enabled", label: "发送任务执行通知", input_type: "switch", default: false },
  { key: "name", label: "任务名称", input_type: "text" },
  { key: "save_path", label: "保存目录", input_type: "text" }
];
const limitFields = [
  { key: "max_add", label: "每次最多添加", input_type: "number", default: 3, validation: { minimum: 1 } },
  { key: "task_limit", label: "本任务下载数量上限", input_type: "number", default: 0, validation: { minimum: 0 } },
  { key: "upload_limit_kib", label: "单种上传限速（KiB/s）", input_type: "number", default: 0, validation: { minimum: 0 } },
  { key: "download_limit_kib", label: "单种下载限速（KiB/s）", input_type: "number", default: 0, validation: { minimum: 0 } },
  { key: "seeding_limit_gib", label: "保种总体积上限（GiB）", input_type: "number", default: 0, validation: { minimum: 0 } }
];
const selectionFields = [
  { key: "promotion", label: "促销", input_type: "select", default: "free", options: [{ value: "all", label: "全部（包括普通）" }, { value: "free", label: "免费" }, { value: "2xfree", label: "2X 免费" }] },
  { key: "exclude_hr", label: "排除 H&R", input_type: "select", default: true, options: [{ value: true, label: "是" }, { value: false, label: "否" }] },
  { key: "use_rss", label: "使用 RSS", input_type: "switch", default: false },
  { key: "site_hr", label: "全站 H&R", input_type: "switch", default: false },
  { key: "exclude_subscriptions", label: "排除订阅", input_type: "switch", default: false },
  { key: "size_range", label: "种子大小（GB）", input_type: "text", placeholder: "0-100" },
  { key: "seeders_range", label: "做种人数", input_type: "text", placeholder: "0-100" },
  { key: "publish_range", label: "发布时间（分钟）", input_type: "text", placeholder: "0-100" },
  { key: "include", label: "包含规则（正则）", input_type: "text" },
  { key: "exclude", label: "排除规则（正则）", input_type: "text" }
];
const deletionFields = [
  { key: "delete_ratio", label: "分享率达到后处理", input_type: "number", validation: { minimum: 0 } },
  { key: "delete_seed_hours", label: "做种小时达到后处理", input_type: "number", validation: { minimum: 0 } },
  { key: "delete_upload_gib", label: "上传量达到后处理（GiB）", input_type: "number", validation: { minimum: 0 } },
  { key: "delete_download_hours", label: "下载时长达到后处理（小时）", input_type: "number", validation: { minimum: 0 } },
  { key: "delete_inactive_hours", label: "未活动时间达到后处理（小时）", input_type: "number", validation: { minimum: 0 } },
  { key: "delete_avg_upload_kib", label: "平均上传速度低于时处理（KiB/s）", input_type: "number", validation: { minimum: 0 } },
  { key: "delete_expired_promotion", label: "删除促销过期的未完成下载", input_type: "switch", default: false },
  { key: "exclude_tags", label: "排除标签", input_type: "text", default: "CineCircuit,H&R", placeholder: "多个标签用逗号分隔" }
];
const executionFields = [
  { key: "intake_time_range", label: "进种时间段", input_type: "text", default: "", placeholder: "00:00-08:00，留空全天（北京时间）" },
  { key: "interval_minutes", label: "刷流刷新周期（分钟）", input_type: "number", default: 10, validation: { minimum: 1 } },
  { key: "check_interval_minutes", label: "状态检查周期（分钟）", input_type: "number", default: 5, validation: { minimum: 1 } },
  { key: "cron", label: "Cron 执行周期（可选）", input_type: "cron" }
];
function validIntakeTime(value) {
  const text = String(value ?? "").trim();
  if (!text) return true;
  if (!/^(?:[01]\d|2[0-3]):[0-5]\d-(?:[01]\d|2[0-3]):[0-5]\d$/.test(text)) return false;
  const [start, end] = text.split("-");
  return start !== end;
}
function validRange(value) {
  const text = String(value ?? "").trim();
  if (!text) return true;
  if (!/^\d+(?:\.\d+)?(?:\s*-\s*\d+(?:\.\d+)?)?$/.test(text)) return false;
  const [low, high = low] = text.split("-").map(Number);
  return Number.isFinite(high) && low <= high;
}
function validField(field, low, high) {
  return field.split(",").every((part) => {
    if (!/^(?:\*|\d+(?:-\d+)?)(?:\/\d+)?$/.test(part)) return false;
    const [base, step = "1"] = part.split("/");
    if (Number(step) < 1) return false;
    if (base === "*") return true;
    const [start, end = start] = base.split("-").map(Number);
    return start >= low && end <= high && start <= end;
  });
}
function validCron(value) {
  const text = String(value || "").trim();
  if (!text) return true;
  const fields = text.split(/\s+/);
  const limits = [[0, 59], [0, 23], [1, 31], [1, 12], [0, 7]];
  return fields.length === 5 && fields.every((field, index) => validField(field, ...limits[index]));
}
const _hoisted_1$5 = { class: "traffic-dialog-heading" };
const _hoisted_2$4 = {
  key: 0,
  role: "alert",
  class: "traffic-dialog-error"
};
const _hoisted_3$4 = {
  key: 1,
  class: "traffic-dialog-section"
};
const _hoisted_4$4 = { class: "traffic-resource-grid plugin-config-grid app-form-layout" };
const _hoisted_5$4 = {
  key: 2,
  class: "traffic-dialog-section"
};
const _hoisted_6$4 = {
  key: 3,
  class: "traffic-dialog-section"
};
const _hoisted_7$3 = {
  key: 4,
  class: "traffic-dialog-section"
};
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "TaskDialog",
  props: {
    task: {},
    isNew: { type: Boolean },
    sites: {},
    downloaders: {},
    disabled: { type: Boolean },
    loading: { type: Boolean },
    schemaFieldsComponent: {}
  },
  emits: ["save", "close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const draft = ref({ check_interval_minutes: 5, cleanup_enabled: true, allow_delete_files: true, delete_task: true, ...props.task });
    const error = ref("");
    const section = ref("basic");
    const siteOptions = computed(() => props.sites.map((site) => {
      const unavailable = site.enabled === false || site.capabilities && !site.capabilities.some((value) => ["latest", "feed"].includes(value));
      return { value: site.id, title: site.name + (unavailable ? "（请检查站点适配和凭据）" : ""), props: { disabled: !!unavailable } };
    }));
    const downloaderOptions = computed(() => props.downloaders.map((item) => ({ value: item.id, title: item.name, props: { disabled: item.enabled === false } })));
    function update(value) {
      if (!props.disabled) draft.value = { ...draft.value, ...value };
    }
    function validLimits(keys) {
      return keys.every((key) => {
        const value = Number(draft.value[key]);
        return Number.isInteger(value) && value >= (key === "task_limit" ? 0 : 1);
      });
    }
    function validateLimits() {
      if (!validLimits(["interval_minutes", "check_interval_minutes"])) {
        error.value = "刷新周期和状态检查周期须为大于 0 的整数。";
        section.value = "basic";
        return false;
      }
      if (!validLimits(["max_add", "task_limit"])) {
        error.value = "每次添加数量须为大于 0 的整数，任务上限须为非负整数。";
        section.value = "limits";
        return false;
      }
      const speeds = ["upload_limit_kib", "download_limit_kib"].map((key) => Number(draft.value[key] || 0));
      const volume = Number(draft.value.seeding_limit_gib || 0);
      if (speeds.some((value) => !Number.isInteger(value) || value < 0 || value > 2097151) || !Number.isFinite(volume) || volume < 0) {
        error.value = "限速须为非负整数，保种总体积须为非负数；0 表示不限。";
        section.value = "limits";
        return false;
      }
      return true;
    }
    function validatePatterns() {
      for (const key of ["include", "exclude"]) {
      }
    }
    function save() {
      if (props.disabled) return;
      if (!["size_range", "seeders_range", "publish_range"].every((key) => validRange(draft.value[key]))) {
        error.value = "范围请填写非负单值或最小值-最大值，例如 0-100。";
        section.value = "selection";
        return;
      }
      if (!String(draft.value.name || "").trim() || !draft.value.site_id) {
        error.value = "请填写任务名称并选择 PT 站点。";
        section.value = "basic";
        return;
      }
      if (!validateLimits()) return;
      if (!validIntakeTime(draft.value.intake_time_range)) {
        error.value = "进种时间段请填写 00:00-08:00 格式，起止不能相同；留空表示全天。";
        section.value = "basic";
        return;
      }
      if (!validCron(draft.value.cron)) {
        error.value = "请填写有效的 5 位 Cron 表达式，或留空使用执行间隔。";
        section.value = "basic";
        return;
      }
      try {
        validatePatterns();
      } catch {
        error.value = "请检查选种规则中的正则表达式。";
        section.value = "selection";
        return;
      }
      emit("save", { ...draft.value, name: String(draft.value.name).trim() });
    }
    return (_ctx, _cache) => {
      const _component_VBtn = resolveComponent("VBtn");
      const _component_VTab = resolveComponent("VTab");
      const _component_VTabs = resolveComponent("VTabs");
      const _component_VSelect = resolveComponent("VSelect");
      const _component_VCardText = resolveComponent("VCardText");
      const _component_VCardActions = resolveComponent("VCardActions");
      const _component_VCard = resolveComponent("VCard");
      const _component_VDialog = resolveComponent("VDialog");
      return openBlock(), createBlock(_component_VDialog, {
        "model-value": true,
        "max-width": "640",
        scrollable: "",
        "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => !$event && emit("close"))
      }, {
        default: withCtx(() => [
          createVNode(_component_VCard, { class: "traffic-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1$5, [
                createElementVNode("div", null, [
                  createElementVNode(
                    "h2",
                    null,
                    toDisplayString(__props.isNew ? "添加任务" : "编辑任务"),
                    1
                    /* TEXT */
                  )
                ]),
                createVNode(_component_VBtn, {
                  class: "app-dialog-close",
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭任务编辑",
                  onClick: _cache[0] || (_cache[0] = ($event) => emit("close"))
                })
              ]),
              createVNode(_component_VTabs, {
                modelValue: section.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => section.value = $event),
                color: "primary",
                class: "traffic-dialog-tabs app-section-tabs app-section-tabs--line",
                "show-arrows": ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_VTab, { value: "basic" }, {
                    default: withCtx(() => [..._cache[5] || (_cache[5] = [
                      createTextVNode(
                        "基本设置",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  }),
                  createVNode(_component_VTab, { value: "limits" }, {
                    default: withCtx(() => [..._cache[6] || (_cache[6] = [
                      createTextVNode(
                        "任务限制",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  }),
                  createVNode(_component_VTab, { value: "selection" }, {
                    default: withCtx(() => [..._cache[7] || (_cache[7] = [
                      createTextVNode(
                        "选种规则",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  }),
                  createVNode(_component_VTab, { value: "deletion" }, {
                    default: withCtx(() => [..._cache[8] || (_cache[8] = [
                      createTextVNode(
                        "删种规则",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  })
                ]),
                _: 1
                /* STABLE */
              }, 8, ["modelValue"]),
              createVNode(_component_VCardText, { class: "traffic-dialog-body" }, {
                default: withCtx(() => [
                  error.value ? (openBlock(), createElementBlock(
                    "p",
                    _hoisted_2$4,
                    toDisplayString(error.value),
                    1
                    /* TEXT */
                  )) : createCommentVNode("v-if", true),
                  section.value === "basic" ? (openBlock(), createElementBlock("section", _hoisted_3$4, [
                    (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
                      class: "standard-config-fields plugin-config-grid app-form-layout",
                      layout: { columns: 2, row_gap: 14, column_gap: 16 },
                      fields: unref(basicFields).slice(0, 2),
                      "model-value": draft.value,
                      disabled: __props.disabled,
                      compact: "",
                      "onUpdate:modelValue": update
                    }, null, 8, ["fields", "model-value", "disabled"])),
                    (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
                      class: "standard-config-fields plugin-config-grid app-form-layout",
                      layout: { columns: 2, row_gap: 14, column_gap: 16 },
                      fields: unref(basicFields).slice(2),
                      "model-value": draft.value,
                      disabled: __props.disabled,
                      compact: "",
                      "onUpdate:modelValue": update
                    }, null, 8, ["fields", "model-value", "disabled"])),
                    createElementVNode("div", _hoisted_4$4, [
                      createVNode(_component_VSelect, {
                        label: "任务 PT 站点",
                        items: siteOptions.value,
                        "model-value": draft.value.site_id || null,
                        disabled: __props.disabled || __props.loading,
                        variant: "outlined",
                        density: "comfortable",
                        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => update({ site_id: $event || "" }))
                      }, null, 8, ["items", "model-value", "disabled"]),
                      createVNode(_component_VSelect, {
                        label: "任务下载器",
                        items: downloaderOptions.value,
                        "model-value": draft.value.downloader_id || null,
                        disabled: __props.disabled || __props.loading,
                        clearable: "",
                        variant: "outlined",
                        density: "comfortable",
                        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => update({ downloader_id: $event || "" }))
                      }, null, 8, ["items", "model-value", "disabled"])
                    ]),
                    (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
                      class: "standard-config-fields plugin-config-grid app-form-layout",
                      layout: { columns: 2, row_gap: 14, column_gap: 16 },
                      fields: unref(executionFields),
                      "model-value": draft.value,
                      disabled: __props.disabled,
                      compact: "",
                      "onUpdate:modelValue": update
                    }, null, 8, ["fields", "model-value", "disabled"]))
                  ])) : createCommentVNode("v-if", true),
                  section.value === "limits" ? (openBlock(), createElementBlock("section", _hoisted_5$4, [
                    (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
                      class: "standard-config-fields plugin-config-grid app-form-layout",
                      layout: { columns: 2, row_gap: 14, column_gap: 16 },
                      fields: unref(limitFields),
                      "model-value": draft.value,
                      disabled: __props.disabled,
                      compact: "",
                      "onUpdate:modelValue": update
                    }, null, 8, ["fields", "model-value", "disabled"])),
                    _cache[9] || (_cache[9] = createElementVNode(
                      "p",
                      null,
                      "0 表示不限。保种体积包含下载中和已完成的本任务种子；限速用于新添加的种子。",
                      -1
                      /* CACHED */
                    ))
                  ])) : createCommentVNode("v-if", true),
                  section.value === "selection" ? (openBlock(), createElementBlock("section", _hoisted_6$4, [
                    (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
                      class: "standard-config-fields plugin-config-grid app-form-layout",
                      layout: { columns: 2, row_gap: 14, column_gap: 16 },
                      fields: unref(selectionFields),
                      "model-value": draft.value,
                      disabled: __props.disabled,
                      compact: "",
                      "onUpdate:modelValue": update
                    }, null, 8, ["fields", "model-value", "disabled"]))
                  ])) : createCommentVNode("v-if", true),
                  section.value === "deletion" ? (openBlock(), createElementBlock("section", _hoisted_7$3, [
                    (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
                      class: "standard-config-fields plugin-config-grid app-form-layout",
                      layout: { columns: 2, row_gap: 14, column_gap: 16 },
                      fields: unref(deletionFields),
                      "model-value": draft.value,
                      disabled: __props.disabled,
                      compact: "",
                      "onUpdate:modelValue": update
                    }, null, 8, ["fields", "model-value", "disabled"]))
                  ])) : createCommentVNode("v-if", true)
                ]),
                _: 1
                /* STABLE */
              }),
              createVNode(_component_VCardActions, { class: "traffic-dialog-actions" }, {
                default: withCtx(() => [
                  createVNode(_component_VBtn, {
                    class: "app-action-button",
                    color: "primary",
                    variant: "flat",
                    disabled: __props.disabled,
                    onClick: save
                  }, {
                    default: withCtx(() => [
                      createTextVNode(
                        toDisplayString(__props.isNew ? "添加任务" : "确认修改"),
                        1
                        /* TEXT */
                      )
                    ]),
                    _: 1
                    /* STABLE */
                  }, 8, ["disabled"])
                ]),
                _: 1
                /* STABLE */
              })
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const TaskDialog = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-1ac1b330"]]);
const _hoisted_1$4 = { class: "task-header" };
const _hoisted_2$3 = ["aria-label", "aria-expanded", "aria-controls"];
const _hoisted_3$3 = { class: "task-icon" };
const _hoisted_4$3 = { class: "task-title" };
const _hoisted_5$3 = { class: "task-name" };
const _hoisted_6$3 = { class: "task-metadata" };
const _hoisted_7$2 = { class: "task-route" };
const _hoisted_8$2 = {
  key: 0,
  class: "task-summary"
};
const _hoisted_9$1 = { class: "task-actions" };
const _hoisted_10$1 = { class: "task-menu" };
const _hoisted_11$1 = ["id"];
const _hoisted_12$1 = ["aria-label"];
const _hoisted_13$1 = {
  class: "task-detail-group task-rules",
  "aria-label": "筛选与处理"
};
const _hoisted_14$1 = { class: "task-rule-columns" };
const _hoisted_15$1 = { class: "task-notification" };
const _hoisted_16$1 = {
  key: 0,
  class: "notification-dot",
  "aria-hidden": "true"
};
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "TaskCard",
  props: {
    task: {},
    siteName: {},
    downloaderName: {},
    cadence: {},
    globalLimit: {},
    disabled: { type: Boolean }
  },
  emits: ["edit", "remove"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const expanded = ref(false);
    const name = computed(() => String(props.task.name || "未命名刷流任务"));
    const detailsId = computed(() => props.task.id ? `brush-task-${encodeURIComponent(String(props.task.id))}-details` : void 0);
    const rate = (value) => Number(value) > 0 ? `${Number(value).toLocaleString()} KiB/s` : "不限速";
    const volume = computed(() => Number(props.task.seeding_limit_gib) > 0 ? `${props.task.seeding_limit_gib} GiB` : "不限体积");
    const summary = computed(() => `${props.cadence} · 每次 ${props.task.max_add || 3} 个 · 保种${volume.value === "不限体积" ? "不限体积" : ` ≤ ${volume.value}`}`);
    const cleanup = computed(() => !props.task.cleanup_enabled ? "不自动清理" : !props.task.delete_task ? "命中后暂停" : props.task.allow_delete_files ? "删种及文件" : "仅删种");
    const keywords = computed(() => [props.task.include ? `包含：${props.task.include}` : "", props.task.exclude ? `排除：${props.task.exclude}` : ""].filter(Boolean).join("；") || "不限制");
    const resourceScope = computed(() => props.task.promotion === "free" ? "免费资源" : props.task.promotion === "2xfree" ? "2X 免费资源" : "全部资源");
    const groups = computed(() => [
      { title: "任务调度", icon: "mdi-clock-outline", rows: [
        ["执行周期", props.cadence],
        ["每次添加", `最多 ${props.task.max_add || 3} 个`],
        ["下载任务上限", Number(props.task.task_limit) > 0 ? `${props.task.task_limit} 个` : `遵循全局 · ${props.globalLimit} 个`]
      ] },
      { title: "保种与限速", icon: "mdi-database-outline", rows: [
        ["保种总体积上限", volume.value],
        ["单种上传限速", rate(props.task.upload_limit_kib)],
        ["单种下载限速", rate(props.task.download_limit_kib)]
      ] }
    ]);
    return (_ctx, _cache) => {
      const _component_VIcon = resolveComponent("VIcon");
      const _component_VBtn = resolveComponent("VBtn");
      const _component_VListItem = resolveComponent("VListItem");
      const _component_VList = resolveComponent("VList");
      const _component_VMenu = resolveComponent("VMenu");
      return openBlock(), createElementBlock(
        "article",
        {
          class: normalizeClass(["task-card app-surface-boundary", { paused: __props.task.enabled === false, expanded: expanded.value }])
        },
        [
          createElementVNode("header", _hoisted_1$4, [
            createElementVNode("button", {
              class: "task-disclosure",
              type: "button",
              "aria-label": `${expanded.value ? "收起" : "展开"}${name.value}详情`,
              "aria-expanded": expanded.value,
              "aria-controls": detailsId.value,
              onClick: _cache[0] || (_cache[0] = ($event) => expanded.value = !expanded.value)
            }, [
              createElementVNode("span", _hoisted_3$3, [
                createVNode(_component_VIcon, { icon: "mdi-swap-vertical" })
              ]),
              createElementVNode("span", _hoisted_4$3, [
                createElementVNode(
                  "span",
                  _hoisted_5$3,
                  toDisplayString(name.value),
                  1
                  /* TEXT */
                ),
                createElementVNode("span", _hoisted_6$3, [
                  createElementVNode("span", _hoisted_7$2, [
                    createTextVNode(
                      toDisplayString(__props.siteName) + " ",
                      1
                      /* TEXT */
                    ),
                    _cache[4] || (_cache[4] = createElementVNode(
                      "span",
                      { "aria-hidden": "true" },
                      "→",
                      -1
                      /* CACHED */
                    )),
                    createTextVNode(
                      " " + toDisplayString(__props.downloaderName),
                      1
                      /* TEXT */
                    )
                  ]),
                  !expanded.value ? (openBlock(), createElementBlock("span", _hoisted_8$2, [
                    _cache[5] || (_cache[5] = createElementVNode(
                      "span",
                      { "aria-hidden": "true" },
                      "·",
                      -1
                      /* CACHED */
                    )),
                    createTextVNode(
                      " " + toDisplayString(summary.value),
                      1
                      /* TEXT */
                    )
                  ])) : createCommentVNode("v-if", true)
                ])
              ])
            ], 8, _hoisted_2$3),
            createElementVNode(
              "span",
              {
                class: normalizeClass(["task-status", { paused: __props.task.enabled === false }])
              },
              toDisplayString(__props.task.enabled === false ? "已停用" : "已启用"),
              3
              /* TEXT, CLASS */
            ),
            createElementVNode("div", _hoisted_9$1, [
              createElementVNode("span", _hoisted_10$1, [
                createVNode(_component_VBtn, {
                  icon: "mdi-dots-vertical",
                  variant: "text",
                  size: "small",
                  "aria-label": "更多任务操作"
                }),
                createVNode(_component_VMenu, {
                  activator: "parent",
                  location: "bottom end",
                  "close-on-content-click": true
                }, {
                  default: withCtx(() => [
                    createVNode(_component_VList, {
                      class: "card-action-menu",
                      density: "compact",
                      nav: "",
                      "min-width": "128"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_VListItem, {
                          "prepend-icon": "mdi-pencil-outline",
                          title: "编辑任务",
                          disabled: __props.disabled,
                          onClick: _cache[1] || (_cache[1] = ($event) => emit("edit"))
                        }, null, 8, ["disabled"]),
                        createVNode(_component_VListItem, {
                          "prepend-icon": "mdi-trash-can-outline",
                          title: "移除任务",
                          "base-color": "error",
                          disabled: __props.disabled,
                          onClick: _cache[2] || (_cache[2] = ($event) => emit("remove"))
                        }, null, 8, ["disabled"])
                      ]),
                      _: 1
                      /* STABLE */
                    })
                  ]),
                  _: 1
                  /* STABLE */
                })
              ]),
              createVNode(_component_VBtn, {
                icon: expanded.value ? "mdi-chevron-up" : "mdi-chevron-down",
                variant: "text",
                size: "small",
                "aria-label": expanded.value ? "收起任务详情" : "展开任务详情",
                "aria-expanded": expanded.value,
                "aria-controls": detailsId.value,
                onClick: _cache[3] || (_cache[3] = ($event) => expanded.value = !expanded.value)
              }, null, 8, ["icon", "aria-label", "aria-expanded", "aria-controls"])
            ])
          ]),
          expanded.value ? (openBlock(), createElementBlock("div", {
            key: 0,
            id: detailsId.value,
            class: "task-details"
          }, [
            (openBlock(true), createElementBlock(
              Fragment,
              null,
              renderList(groups.value, (group) => {
                return openBlock(), createElementBlock("section", {
                  key: group.title,
                  class: "task-detail-group",
                  "aria-label": group.title
                }, [
                  createElementVNode("h5", null, [
                    createVNode(_component_VIcon, {
                      icon: group.icon,
                      size: "20"
                    }, null, 8, ["icon"]),
                    createTextVNode(
                      toDisplayString(group.title),
                      1
                      /* TEXT */
                    )
                  ]),
                  createElementVNode("dl", null, [
                    (openBlock(true), createElementBlock(
                      Fragment,
                      null,
                      renderList(group.rows, ([label, value]) => {
                        return openBlock(), createElementBlock("div", { key: label }, [
                          createElementVNode(
                            "dt",
                            null,
                            toDisplayString(label),
                            1
                            /* TEXT */
                          ),
                          createElementVNode(
                            "dd",
                            null,
                            toDisplayString(value),
                            1
                            /* TEXT */
                          )
                        ]);
                      }),
                      128
                      /* KEYED_FRAGMENT */
                    ))
                  ])
                ], 8, _hoisted_12$1);
              }),
              128
              /* KEYED_FRAGMENT */
            )),
            createElementVNode("section", _hoisted_13$1, [
              createElementVNode("h5", null, [
                createVNode(_component_VIcon, {
                  icon: "mdi-tune-variant",
                  size: "20"
                }),
                _cache[6] || (_cache[6] = createTextVNode(
                  "筛选与处理",
                  -1
                  /* CACHED */
                ))
              ]),
              createElementVNode("div", _hoisted_14$1, [
                createElementVNode("dl", null, [
                  createElementVNode("div", null, [
                    _cache[7] || (_cache[7] = createElementVNode(
                      "dt",
                      null,
                      "资源范围",
                      -1
                      /* CACHED */
                    )),
                    createElementVNode(
                      "dd",
                      null,
                      toDisplayString(resourceScope.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  createElementVNode(
                    "div",
                    {
                      class: normalizeClass(["task-keywords", { "long-rule": keywords.value.length > 24 }])
                    },
                    [
                      _cache[8] || (_cache[8] = createElementVNode(
                        "dt",
                        null,
                        "关键词限制",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "dd",
                        null,
                        toDisplayString(keywords.value),
                        1
                        /* TEXT */
                      )
                    ],
                    2
                    /* CLASS */
                  )
                ]),
                createElementVNode("dl", null, [
                  createElementVNode("div", null, [
                    _cache[9] || (_cache[9] = createElementVNode(
                      "dt",
                      null,
                      "删种策略",
                      -1
                      /* CACHED */
                    )),
                    createElementVNode(
                      "dd",
                      null,
                      toDisplayString(cleanup.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  createElementVNode("div", null, [
                    _cache[10] || (_cache[10] = createElementVNode(
                      "dt",
                      null,
                      "任务通知",
                      -1
                      /* CACHED */
                    )),
                    createElementVNode("dd", _hoisted_15$1, [
                      __props.task.notification_enabled ? (openBlock(), createElementBlock("span", _hoisted_16$1)) : createCommentVNode("v-if", true),
                      createTextVNode(
                        toDisplayString(__props.task.notification_enabled ? "已开启" : "已关闭"),
                        1
                        /* TEXT */
                      )
                    ])
                  ])
                ])
              ])
            ])
          ], 8, _hoisted_11$1)) : createCommentVNode("v-if", true)
        ],
        2
        /* CLASS */
      );
    };
  }
});
const TaskCard = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-704e567d"]]);
let sequence = 0;
function newTaskId() {
  const uuid = globalThis.crypto?.randomUUID?.();
  if (uuid) return `task-${uuid}`;
  sequence += 1;
  return `task-${Date.now().toString(36)}-${sequence.toString(36)}-${Math.random().toString(36).slice(2)}`;
}
const _hoisted_1$3 = { class: "traffic-config app-form-layout" };
const _hoisted_2$2 = { class: "traffic-heading" };
const _hoisted_3$2 = {
  key: 0,
  class: "traffic-error",
  role: "alert"
};
const _hoisted_4$2 = {
  key: 1,
  class: "traffic-empty"
};
const _hoisted_5$2 = { key: 0 };
const _hoisted_6$2 = { class: "traffic-tasks" };
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "ConfigEditor",
  props: {
    modelValue: {},
    fields: {},
    disabled: { type: Boolean },
    schemaFieldsComponent: {},
    request: { type: Function }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const sites = ref([]), downloaders = ref([]);
    const loading = ref(false), error = ref("");
    const editing = ref(null), editingIndex = ref(-1);
    const tasks = computed(() => Array.isArray(props.modelValue.tasks) ? props.modelValue.tasks : []);
    const globalFields = computed(() => orderedFields(props.fields || [], ["enabled", "max_tasks"]).map((field) => field.key === "max_tasks" ? { ...field, label: "全局下载任务上限" } : field));
    function resolved(task) {
      return {
        exclude_tags: "CineCircuit,H&R",
        promotion: "free",
        exclude_hr: true,
        notification_enabled: false,
        cron: props.modelValue.cron || "",
        interval_minutes: 10,
        task_limit: 0,
        max_add: 3,
        cleanup_enabled: true,
        allow_delete_files: true,
        delete_task: true,
        ...task,
        site_id: task.site_id || props.modelValue.default_site_id || "",
        downloader_id: task.downloader_id || props.modelValue.default_downloader_id || ""
      };
    }
    function editTask(index = -1) {
      if (props.disabled) return;
      editingIndex.value = index;
      editing.value = index >= 0 ? resolved(tasks.value[index]) : {
        exclude_tags: "CineCircuit,H&R",
        promotion: "free",
        exclude_hr: true,
        id: newTaskId(),
        name: "",
        enabled: true,
        site_id: "",
        downloader_id: "",
        max_add: 3,
        interval_minutes: 10,
        cron: "",
        task_limit: 0,
        cleanup_enabled: true,
        notification_enabled: false,
        allow_delete_files: true,
        delete_task: true
      };
    }
    function saveTask(task) {
      if (props.disabled) return;
      const next = tasks.value.map(resolved);
      if (editingIndex.value < 0) next.push(task);
      else next[editingIndex.value] = task;
      emit("update:modelValue", { ...props.modelValue, tasks: next });
      editing.value = null;
    }
    function removeTask(index) {
      if (!props.disabled) emit("update:modelValue", { ...props.modelValue, tasks: tasks.value.filter((_, i) => i !== index) });
    }
    function resourceName(resources, id, empty) {
      return resources.find((row) => row.id === id)?.name || (id ? "资源不可用" : empty);
    }
    function cadence(task) {
      const value = resolved(task);
      return value.cron ? `Cron ${value.cron}` : `每 ${value.interval_minutes || 10} 分钟`;
    }
    async function loadResources() {
      loading.value = true;
      error.value = "";
      try {
        const result = await props.request("/plugins/brush-flow/api/inventory");
        sites.value = result.sites || [];
        downloaders.value = result.downloaders || [];
        if (Array.isArray(result.tasks)) {
          emit("update:modelValue", { ...props.modelValue, tasks: result.tasks });
        }
      } catch (cause) {
        error.value = pluginErrorText(cause, "读取站点与下载器失败");
      } finally {
        loading.value = false;
      }
    }
    onMounted(loadResources);
    return (_ctx, _cache) => {
      const _component_VBtn = resolveComponent("VBtn");
      const _component_VIcon = resolveComponent("VIcon");
      return openBlock(), createElementBlock("div", _hoisted_1$3, [
        _cache[9] || (_cache[9] = createElementVNode(
          "header",
          { class: "global-heading" },
          [
            createElementVNode("h3", null, "全局控制"),
            createElementVNode("p", null, "统一控制刷流任务的运行状态和下载数量。")
          ],
          -1
          /* CACHED */
        )),
        (openBlock(), createBlock(resolveDynamicComponent(__props.schemaFieldsComponent), {
          class: "global-config-fields standard-config-fields plugin-config-grid app-form-layout",
          layout: { columns: 2, row_gap: 16, column_gap: 20 },
          fields: globalFields.value,
          "model-value": __props.modelValue,
          disabled: __props.disabled,
          compact: "",
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:modelValue", $event))
        }, null, 8, ["fields", "model-value", "disabled"])),
        createElementVNode("div", _hoisted_2$2, [
          createElementVNode("div", null, [
            createElementVNode("h3", null, [
              _cache[3] || (_cache[3] = createTextVNode(
                "刷流任务 ",
                -1
                /* CACHED */
              )),
              createElementVNode(
                "span",
                null,
                toDisplayString(tasks.value.length),
                1
                /* TEXT */
              )
            ]),
            _cache[4] || (_cache[4] = createElementVNode(
              "p",
              null,
              "任务调整后，使用页面底部的保存按钮应用更改。",
              -1
              /* CACHED */
            ))
          ]),
          createVNode(_component_VBtn, {
            class: "app-action-button",
            color: "primary",
            variant: "flat",
            disabled: __props.disabled,
            onClick: _cache[1] || (_cache[1] = ($event) => editTask())
          }, {
            default: withCtx(() => [..._cache[5] || (_cache[5] = [
              createTextVNode(
                "添加任务",
                -1
                /* CACHED */
              )
            ])]),
            _: 1
            /* STABLE */
          }, 8, ["disabled"])
        ]),
        error.value ? (openBlock(), createElementBlock("div", _hoisted_3$2, [
          createElementVNode(
            "span",
            null,
            toDisplayString(error.value),
            1
            /* TEXT */
          ),
          createVNode(_component_VBtn, {
            variant: "text",
            loading: loading.value,
            onClick: loadResources
          }, {
            default: withCtx(() => [..._cache[6] || (_cache[6] = [
              createTextVNode(
                "重试",
                -1
                /* CACHED */
              )
            ])]),
            _: 1
            /* STABLE */
          }, 8, ["loading"])
        ])) : createCommentVNode("v-if", true),
        !tasks.value.length ? (openBlock(), createElementBlock("div", _hoisted_4$2, [
          createVNode(_component_VIcon, {
            icon: "mdi-swap-vertical",
            size: "32"
          }),
          _cache[7] || (_cache[7] = createElementVNode(
            "h4",
            null,
            "创建第一个刷流任务",
            -1
            /* CACHED */
          )),
          _cache[8] || (_cache[8] = createElementVNode(
            "p",
            null,
            "选择 PT 站点和下载器，设置选种与删种规则。",
            -1
            /* CACHED */
          )),
          !loading.value && !sites.value.length && !error.value ? (openBlock(), createElementBlock("p", _hoisted_5$2, "没有已配置的 PT 站点，请先在站点管理中添加。")) : createCommentVNode("v-if", true)
        ])) : createCommentVNode("v-if", true),
        createElementVNode("div", _hoisted_6$2, [
          (openBlock(true), createElementBlock(
            Fragment,
            null,
            renderList(tasks.value, (task, index) => {
              return openBlock(), createBlock(TaskCard, {
                key: String(task.id || index),
                task: resolved(task),
                "site-name": resourceName(sites.value, resolved(task).site_id, "未选择站点"),
                "downloader-name": resourceName(downloaders.value, resolved(task).downloader_id, "当前默认下载器"),
                cadence: cadence(task),
                "global-limit": Number(__props.modelValue.max_tasks || 30),
                disabled: __props.disabled,
                onEdit: ($event) => editTask(index),
                onRemove: ($event) => removeTask(index)
              }, null, 8, ["task", "site-name", "downloader-name", "cadence", "global-limit", "disabled", "onEdit", "onRemove"]);
            }),
            128
            /* KEYED_FRAGMENT */
          ))
        ]),
        editing.value ? (openBlock(), createBlock(TaskDialog, {
          key: 2,
          task: editing.value,
          "is-new": editingIndex.value < 0,
          sites: sites.value,
          downloaders: downloaders.value,
          disabled: __props.disabled,
          loading: loading.value,
          "schema-fields-component": __props.schemaFieldsComponent,
          onSave: saveTask,
          onClose: _cache[2] || (_cache[2] = ($event) => editing.value = null)
        }, null, 8, ["task", "is-new", "sites", "downloaders", "disabled", "loading", "schema-fields-component"])) : createCommentVNode("v-if", true)
      ]);
    };
  }
});
const ConfigEditor = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-8716f009"]]);
const _hoisted_1$2 = {
  key: 0,
  class: "plugin-statistic-placeholder",
  "aria-label": "暂无数据"
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "StatisticValue",
  props: {
    value: {}
  },
  setup(__props) {
    const props = __props;
    const missing = computed(() => props.value == null || props.value === "—");
    return (_ctx, _cache) => {
      return missing.value ? (openBlock(), createElementBlock("span", _hoisted_1$2, "—")) : (openBlock(), createElementBlock(
        Fragment,
        { key: 1 },
        [
          createTextVNode(
            toDisplayString(__props.value),
            1
            /* TEXT */
          )
        ],
        64
        /* STABLE_FRAGMENT */
      ));
    };
  }
});
const StatisticValue = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-bdcf673e"]]);
const _hoisted_1$1 = ["aria-label", "aria-expanded", "aria-controls"];
const _hoisted_2$1 = { class: "stat-task-info" };
const _hoisted_3$1 = { class: "stat-task-name" };
const _hoisted_4$1 = { class: "stat-task-metadata" };
const _hoisted_5$1 = ["id"];
const _hoisted_6$1 = { class: "stat-task-metrics" };
const _hoisted_7$1 = ["value", "aria-label"];
const _hoisted_8$1 = {
  key: 1,
  class: "stat-task-note"
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "StatisticsTaskCard",
  props: {
    task: {},
    siteName: {},
    downloaderName: {},
    globalEnabled: { type: Boolean },
    formatBytes: { type: Function }
  },
  setup(__props) {
    const props = __props;
    const expanded = ref(false);
    const enabled = computed(() => !props.task.removed && props.task.enabled && props.globalEnabled);
    const detailsId = computed(() => `brush-stat-${encodeURIComponent(props.task.id)}-details`);
    const schedule = computed(() => !enabled.value ? "调度已停止" : props.task.cron ? `Cron：${props.task.cron}` : `每 ${props.task.interval_minutes} 分钟执行`);
    const capacity = computed(() => props.task.seeding_limit_gib > 0 ? `${props.task.seeding_limit_gib} GiB` : "不限体积");
    const percent = computed(() => Math.max(0, Math.min(100, props.task.size / (props.task.seeding_limit_gib * 1024 ** 3) * 100)));
    const metrics = computed(() => [
      { label: "下载中", icon: "mdi-download-outline", value: props.task.download_count },
      { label: "保种中", icon: "mdi-database-outline", value: props.task.seed_count },
      { label: "上传速度", icon: "mdi-arrow-up", value: `${props.formatBytes(props.task.upload_speed)}/s` },
      { label: "下载速度", icon: "mdi-download-outline", value: `${props.formatBytes(props.task.download_speed)}/s` }
    ]);
    return (_ctx, _cache) => {
      const _component_VIcon = resolveComponent("VIcon");
      return openBlock(), createElementBlock(
        "article",
        {
          class: normalizeClass(["stat-task app-surface-boundary", { paused: !enabled.value, expanded: expanded.value }])
        },
        [
          createElementVNode("button", {
            class: "stat-task-toggle",
            type: "button",
            "aria-label": `${expanded.value ? "收起" : "展开"}${__props.task.name}统计详情`,
            "aria-expanded": expanded.value,
            "aria-controls": detailsId.value,
            onClick: _cache[0] || (_cache[0] = ($event) => expanded.value = !expanded.value)
          }, [
            createElementVNode("span", _hoisted_2$1, [
              createElementVNode(
                "span",
                _hoisted_3$1,
                toDisplayString(__props.task.name),
                1
                /* TEXT */
              ),
              createElementVNode("span", _hoisted_4$1, [
                createElementVNode(
                  "span",
                  null,
                  toDisplayString(__props.siteName) + " → " + toDisplayString(__props.downloaderName),
                  1
                  /* TEXT */
                ),
                createElementVNode("span", null, [
                  _cache[1] || (_cache[1] = createElementVNode(
                    "span",
                    { "aria-hidden": "true" },
                    "·",
                    -1
                    /* CACHED */
                  )),
                  _cache[2] || (_cache[2] = createTextVNode(
                    " 保种 ",
                    -1
                    /* CACHED */
                  )),
                  createVNode(StatisticValue, {
                    value: __props.task.available ? __props.formatBytes(__props.task.size) : "—"
                  }, null, 8, ["value"]),
                  createTextVNode(
                    " / " + toDisplayString(capacity.value),
                    1
                    /* TEXT */
                  )
                ]),
                createElementVNode("span", null, [
                  _cache[3] || (_cache[3] = createElementVNode(
                    "span",
                    { "aria-hidden": "true" },
                    "·",
                    -1
                    /* CACHED */
                  )),
                  createTextVNode(
                    " " + toDisplayString(schedule.value),
                    1
                    /* TEXT */
                  )
                ])
              ])
            ]),
            createElementVNode(
              "span",
              {
                class: normalizeClass(["stat-task-status", { paused: !enabled.value }])
              },
              toDisplayString(__props.task.removed ? "已移除" : enabled.value ? "已启用" : "已停用"),
              3
              /* TEXT, CLASS */
            ),
            createVNode(_component_VIcon, {
              class: "stat-task-chevron",
              icon: expanded.value ? "mdi-chevron-up" : "mdi-chevron-down",
              size: "20"
            }, null, 8, ["icon"])
          ], 8, _hoisted_1$1),
          expanded.value ? (openBlock(), createElementBlock("div", {
            key: 0,
            id: detailsId.value,
            class: "stat-task-details"
          }, [
            createElementVNode("dl", _hoisted_6$1, [
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(metrics.value, (metric) => {
                  return openBlock(), createElementBlock("div", {
                    key: metric.label
                  }, [
                    createVNode(_component_VIcon, {
                      icon: metric.icon,
                      size: "20"
                    }, null, 8, ["icon"]),
                    createElementVNode(
                      "dt",
                      null,
                      toDisplayString(metric.label),
                      1
                      /* TEXT */
                    ),
                    createElementVNode("dd", null, [
                      createVNode(StatisticValue, {
                        value: __props.task.available ? metric.value : "—"
                      }, null, 8, ["value"])
                    ])
                  ]);
                }),
                128
                /* KEYED_FRAGMENT */
              ))
            ]),
            __props.task.available && __props.task.seeding_limit_gib > 0 ? (openBlock(), createElementBlock("progress", {
              key: 0,
              class: "stat-task-capacity",
              value: percent.value,
              max: "100",
              "aria-label": __props.task.name + "保种体积占用"
            }, null, 8, _hoisted_7$1)) : createCommentVNode("v-if", true),
            !__props.task.available ? (openBlock(), createElementBlock("p", _hoisted_8$1, "暂无实时数据，历史累计统计仍保留。")) : createCommentVNode("v-if", true)
          ], 8, _hoisted_5$1)) : createCommentVNode("v-if", true)
        ],
        2
        /* CLASS */
      );
    };
  }
});
const StatisticsTaskCard = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-29eeb43b"]]);
const _hoisted_1 = { class: "statistics-heading" };
const _hoisted_2 = ["aria-busy"];
const _hoisted_3 = { class: "stat-toolbar" };
const _hoisted_4 = {
  key: 0,
  class: "stat-error",
  role: "alert"
};
const _hoisted_5 = { class: "stat-totals" };
const _hoisted_6 = { class: "stat-heading" };
const _hoisted_7 = { class: "stat-task-list" };
const _hoisted_8 = {
  key: 0,
  class: "stat-empty"
};
const _hoisted_9 = { class: "stat-heading" };
const _hoisted_10 = { class: "segments" };
const _hoisted_11 = { class: "execution-table" };
const _hoisted_12 = ["aria-label", "aria-expanded", "onClick"];
const _hoisted_13 = { key: 0 };
const _hoisted_14 = {
  colspan: "7",
  class: "execution-detail"
};
const _hoisted_15 = {
  key: 0,
  class: "stat-empty"
};
const _hoisted_16 = { class: "stat-pagination" };
const _hoisted_17 = ["disabled"];
const _hoisted_18 = ["disabled"];
const _hoisted_19 = ["value", "max"];
const _hoisted_20 = ["disabled"];
const _hoisted_21 = ["disabled"];
const _hoisted_22 = { class: "statistics-footer" };
const _hoisted_23 = { class: "updated" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: { type: Function },
    buttonComponent: {},
    cardComponent: {},
    dialogComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiButton = props.buttonComponent, UiCard = props.cardComponent, UiDialog = props.dialogComponent;
    const report = ref(null), sites = ref([]), downloaders = ref([]);
    const busy = ref(false), error = ref(""), taskId = ref(""), siteId = ref(""), onlyErrors = ref(false), page = ref(1), expanded = ref("");
    const selected = computed(() => (report.value?.tasks || []).filter((t) => (!taskId.value || t.id === taskId.value) && (!siteId.value || t.site_id === siteId.value)));
    const history = computed(() => (report.value?.history || []).filter((e) => (!taskId.value || e.task_id === taskId.value) && (!siteId.value || e.site_id === siteId.value) && (!onlyErrors.value || e.failed > 0)));
    const pages = computed(() => Math.max(1, Math.ceil(history.value.length / 8)));
    const entries = computed(() => history.value.slice((page.value - 1) * 8, page.value * 8));
    const total = (key) => selected.value.reduce((sum, t) => sum + t[key], 0);
    const unavailable = computed(() => selected.value.some((t) => !t.available));
    const incomplete = computed(() => selected.value.some((t) => !t.history_complete));
    const ratio = computed(() => total("downloaded") > 0 ? (total("uploaded") / total("downloaded")).toFixed(2) : "—");
    function bytes(value) {
      if (!Number.isFinite(value)) return "—";
      const units = ["B", "KiB", "MiB", "GiB", "TiB"];
      let n = value, i = 0;
      while (n >= 1024 && i < 4) {
        n /= 1024;
        i++;
      }
      return `${n.toLocaleString(void 0, { maximumFractionDigits: i > 0 ? 1 : 0 })} ${units[i]}`;
    }
    function date(value) {
      return value ? new Date(value * 1e3).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }) : "—";
    }
    function resource(rows, id) {
      return rows.find((r) => r.id === id)?.name || (id ? "资源不可用" : "未指定");
    }
    function changePage(value) {
      page.value = Math.min(pages.value, Math.max(1, Math.trunc(Number(value) || 1)));
      expanded.value = "";
    }
    function reset() {
      changePage(1);
    }
    function inputPage(event) {
      const input = event.target;
      changePage(Number(input.value));
      input.value = String(page.value);
    }
    async function load() {
      if (busy.value) return;
      busy.value = true;
      error.value = "";
      try {
        const [stats, inventory] = await Promise.all([props.request("/plugins/brush-flow/api/statistics"), props.request("/plugins/brush-flow/api/inventory")]);
        report.value = stats;
        sites.value = inventory.sites || [];
        downloaders.value = inventory.downloaders || [];
        changePage(page.value);
      } catch (cause) {
        error.value = pluginErrorFallback(cause, "统计读取失败，请重试；已有数据保留为上次结果。");
      } finally {
        busy.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      const _component_VSelect = resolveComponent("VSelect");
      const _component_VIcon = resolveComponent("VIcon");
      return openBlock(), createBlock(unref(UiDialog), {
        "model-value": true,
        "max-width": "980",
        scrollable: "",
        "onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => !$event && __props.context.close())
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "traffic-statistics-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1, [
                _cache[11] || (_cache[11] = createElementVNode(
                  "h2",
                  null,
                  "站点刷流 · 数据统计",
                  -1
                  /* CACHED */
                )),
                createVNode(unref(UiButton), {
                  class: "app-dialog-close",
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: _cache[0] || (_cache[0] = ($event) => __props.context.close())
                })
              ]),
              createElementVNode("section", {
                class: "traffic-statistics",
                "aria-busy": busy.value
              }, [
                createElementVNode("div", _hoisted_3, [
                  createVNode(_component_VSelect, {
                    modelValue: taskId.value,
                    "onUpdate:modelValue": [
                      _cache[1] || (_cache[1] = ($event) => taskId.value = $event),
                      reset
                    ],
                    "aria-label": "筛选任务",
                    items: [{ title: "全部任务", value: "" }, ...(report.value?.tasks || []).map((t) => ({ title: t.name, value: t.id }))],
                    variant: "outlined",
                    density: "compact",
                    "hide-details": ""
                  }, null, 8, ["modelValue", "items"]),
                  createVNode(_component_VSelect, {
                    modelValue: siteId.value,
                    "onUpdate:modelValue": [
                      _cache[2] || (_cache[2] = ($event) => siteId.value = $event),
                      reset
                    ],
                    "aria-label": "筛选站点",
                    items: [{ title: "全部站点", value: "" }, ...sites.value.map((s) => ({ title: s.name, value: s.id }))],
                    variant: "outlined",
                    density: "compact",
                    "hide-details": ""
                  }, null, 8, ["modelValue", "items"])
                ]),
                error.value ? (openBlock(), createElementBlock(
                  "p",
                  _hoisted_4,
                  toDisplayString(error.value),
                  1
                  /* TEXT */
                )) : createCommentVNode("v-if", true),
                report.value ? (openBlock(), createElementBlock(
                  Fragment,
                  { key: 1 },
                  [
                    createElementVNode("div", _hoisted_5, [
                      createElementVNode("div", null, [
                        _cache[12] || (_cache[12] = createElementVNode(
                          "span",
                          null,
                          "累计上传",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("strong", null, [
                          createVNode(StatisticValue, {
                            value: incomplete.value && !total("uploaded") ? "—" : bytes(total("uploaded"))
                          }, null, 8, ["value"])
                        ])
                      ]),
                      createElementVNode("div", null, [
                        _cache[13] || (_cache[13] = createElementVNode(
                          "span",
                          null,
                          "累计下载",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("strong", null, [
                          createVNode(StatisticValue, {
                            value: incomplete.value && !total("downloaded") ? "—" : bytes(total("downloaded"))
                          }, null, 8, ["value"])
                        ])
                      ]),
                      createElementVNode("div", null, [
                        _cache[14] || (_cache[14] = createElementVNode(
                          "span",
                          null,
                          "分享率",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("strong", null, [
                          createVNode(StatisticValue, { value: ratio.value }, null, 8, ["value"])
                        ])
                      ]),
                      createElementVNode("div", null, [
                        _cache[15] || (_cache[15] = createElementVNode(
                          "span",
                          null,
                          "当前保种体积",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("strong", null, [
                          createVNode(StatisticValue, {
                            value: unavailable.value ? "—" : bytes(total("size"))
                          }, null, 8, ["value"])
                        ])
                      ])
                    ]),
                    createElementVNode("div", _hoisted_6, [
                      _cache[16] || (_cache[16] = createElementVNode(
                        "h3",
                        null,
                        "任务概览",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode(
                        "span",
                        null,
                        toDisplayString(selected.value.length) + " 个任务 · " + toDisplayString(selected.value.filter((t) => t.enabled && report.value?.enabled).length) + " 个已启用",
                        1
                        /* TEXT */
                      )
                    ]),
                    createElementVNode("div", _hoisted_7, [
                      (openBlock(true), createElementBlock(
                        Fragment,
                        null,
                        renderList(selected.value, (task) => {
                          return openBlock(), createBlock(StatisticsTaskCard, {
                            key: task.id,
                            task,
                            "site-name": resource(sites.value, task.site_id),
                            "downloader-name": resource(downloaders.value, task.downloader_id),
                            "global-enabled": report.value.enabled,
                            "format-bytes": bytes
                          }, null, 8, ["task", "site-name", "downloader-name", "global-enabled"]);
                        }),
                        128
                        /* KEYED_FRAGMENT */
                      )),
                      !selected.value.length ? (openBlock(), createElementBlock("p", _hoisted_8, "没有符合筛选条件的任务")) : createCommentVNode("v-if", true)
                    ]),
                    createElementVNode("div", _hoisted_9, [
                      _cache[17] || (_cache[17] = createElementVNode(
                        "h3",
                        null,
                        "最近执行",
                        -1
                        /* CACHED */
                      )),
                      createElementVNode("div", _hoisted_10, [
                        createElementVNode(
                          "button",
                          {
                            type: "button",
                            class: normalizeClass({ on: !onlyErrors.value }),
                            onClick: _cache[3] || (_cache[3] = ($event) => {
                              onlyErrors.value = false;
                              reset();
                            })
                          },
                          "全部",
                          2
                          /* CLASS */
                        ),
                        createElementVNode(
                          "button",
                          {
                            type: "button",
                            class: normalizeClass({ on: onlyErrors.value }),
                            onClick: _cache[4] || (_cache[4] = ($event) => {
                              onlyErrors.value = true;
                              reset();
                            })
                          },
                          "有异常",
                          2
                          /* CLASS */
                        )
                      ])
                    ]),
                    createElementVNode("div", _hoisted_11, [
                      createElementVNode("table", null, [
                        _cache[18] || (_cache[18] = createElementVNode(
                          "thead",
                          null,
                          [
                            createElementVNode("tr", null, [
                              createElementVNode("th", null, "执行时间"),
                              createElementVNode("th", null, "任务"),
                              createElementVNode("th", null, "新增"),
                              createElementVNode("th", null, "清理"),
                              createElementVNode("th", null, "跳过"),
                              createElementVNode("th", null, "结果"),
                              createElementVNode("th", { "aria-label": "详情" })
                            ])
                          ],
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("tbody", null, [
                          (openBlock(true), createElementBlock(
                            Fragment,
                            null,
                            renderList(entries.value, (entry) => {
                              return openBlock(), createElementBlock(
                                Fragment,
                                {
                                  key: entry.id
                                },
                                [
                                  createElementVNode("tr", null, [
                                    createElementVNode(
                                      "td",
                                      null,
                                      toDisplayString(date(entry.timestamp)),
                                      1
                                      /* TEXT */
                                    ),
                                    createElementVNode(
                                      "td",
                                      null,
                                      toDisplayString(entry.name),
                                      1
                                      /* TEXT */
                                    ),
                                    createElementVNode(
                                      "td",
                                      null,
                                      toDisplayString(entry.added),
                                      1
                                      /* TEXT */
                                    ),
                                    createElementVNode(
                                      "td",
                                      null,
                                      toDisplayString(entry.cleaned),
                                      1
                                      /* TEXT */
                                    ),
                                    createElementVNode(
                                      "td",
                                      null,
                                      toDisplayString(entry.skipped),
                                      1
                                      /* TEXT */
                                    ),
                                    createElementVNode("td", null, [
                                      createElementVNode(
                                        "span",
                                        {
                                          class: normalizeClass(["status", { failed: entry.failed > 0, paused: entry.reason !== "成功" && !entry.failed }])
                                        },
                                        toDisplayString(entry.reason),
                                        3
                                        /* TEXT, CLASS */
                                      )
                                    ]),
                                    createElementVNode("td", null, [
                                      createElementVNode("button", {
                                        type: "button",
                                        "aria-label": "查看 " + entry.name + " 执行详情",
                                        "aria-expanded": expanded.value === entry.id,
                                        onClick: ($event) => expanded.value = expanded.value === entry.id ? "" : entry.id
                                      }, [
                                        createVNode(_component_VIcon, {
                                          icon: expanded.value === entry.id ? "mdi-chevron-down" : "mdi-chevron-right"
                                        }, null, 8, ["icon"])
                                      ], 8, _hoisted_12)
                                    ])
                                  ]),
                                  expanded.value === entry.id ? (openBlock(), createElementBlock("tr", _hoisted_13, [
                                    createElementVNode(
                                      "td",
                                      _hoisted_14,
                                      "匹配 " + toDisplayString(entry.matched) + " · 失败 " + toDisplayString(entry.failed) + " · " + toDisplayString(entry.reason),
                                      1
                                      /* TEXT */
                                    )
                                  ])) : createCommentVNode("v-if", true)
                                ],
                                64
                                /* STABLE_FRAGMENT */
                              );
                            }),
                            128
                            /* KEYED_FRAGMENT */
                          ))
                        ])
                      ]),
                      !entries.value.length ? (openBlock(), createElementBlock("p", _hoisted_15, "暂无执行记录，新执行结果会显示在这里。")) : createCommentVNode("v-if", true)
                    ]),
                    createElementVNode("div", _hoisted_16, [
                      createElementVNode(
                        "span",
                        null,
                        "最近 " + toDisplayString(history.value.length) + " 条记录",
                        1
                        /* TEXT */
                      ),
                      createElementVNode("div", null, [
                        createElementVNode("button", {
                          "aria-label": "第一页",
                          disabled: page.value <= 1,
                          onClick: _cache[5] || (_cache[5] = ($event) => changePage(1))
                        }, [
                          createVNode(_component_VIcon, { icon: "mdi-page-first" })
                        ], 8, _hoisted_17),
                        createElementVNode("button", {
                          "aria-label": "上一页",
                          disabled: page.value <= 1,
                          onClick: _cache[6] || (_cache[6] = ($event) => changePage(page.value - 1))
                        }, [
                          createVNode(_component_VIcon, { icon: "mdi-chevron-left" })
                        ], 8, _hoisted_18),
                        createElementVNode("input", {
                          value: page.value,
                          "aria-label": "页码",
                          type: "number",
                          min: "1",
                          max: pages.value,
                          onChange: inputPage,
                          onKeydown: _cache[7] || (_cache[7] = ($event) => $event.key === "Enter" && inputPage($event))
                        }, null, 40, _hoisted_19),
                        createElementVNode(
                          "span",
                          null,
                          "/ " + toDisplayString(pages.value),
                          1
                          /* TEXT */
                        ),
                        createElementVNode("button", {
                          "aria-label": "下一页",
                          disabled: page.value >= pages.value,
                          onClick: _cache[8] || (_cache[8] = ($event) => changePage(page.value + 1))
                        }, [
                          createVNode(_component_VIcon, { icon: "mdi-chevron-right" })
                        ], 8, _hoisted_20),
                        createElementVNode("button", {
                          "aria-label": "最后一页",
                          disabled: page.value >= pages.value,
                          onClick: _cache[9] || (_cache[9] = ($event) => changePage(pages.value))
                        }, [
                          createVNode(_component_VIcon, { icon: "mdi-page-last" })
                        ], 8, _hoisted_21)
                      ])
                    ])
                  ],
                  64
                  /* STABLE_FRAGMENT */
                )) : createCommentVNode("v-if", true)
              ], 8, _hoisted_2),
              createElementVNode("footer", _hoisted_22, [
                createElementVNode(
                  "span",
                  _hoisted_23,
                  toDisplayString(report.value ? "更新于 " + date(report.value.updated_at) : busy.value ? "正在读取统计…" : "暂无统计数据"),
                  1
                  /* TEXT */
                ),
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: busy.value,
                  disabled: busy.value,
                  onClick: load
                }, {
                  default: withCtx(() => [..._cache[19] || (_cache[19] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading", "disabled"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-8a723046"]]);
const PLUGIN_ID = "brush-flow";
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const fields = sdk.ui?.components.SchemaFields;
  const { Button, Card, Dialog } = sdk.ui.components;
  sdk.registerContribution?.({ pluginId: PLUGIN_ID, slot: "plugin.statistics", key: "traffic-statistics", component: defineComponent2({
    inheritAttrs: false,
    props: { context: { type: Object, required: true } },
    setup(props) {
      return () => h(StatisticsView, {
        context: props.context,
        request: sdk.request,
        buttonComponent: Button,
        cardComponent: Card,
        dialogComponent: Dialog
      });
    }
  }) });
  if (fields) sdk.registerEditor({
    domain: "plugin",
    key: PLUGIN_ID,
    component: defineComponent2({
      inheritAttrs: false,
      props: { modelValue: { type: Object, required: true }, disabled: Boolean },
      emits: ["update:modelValue"],
      setup(props, { attrs, emit }) {
        return () => h(ConfigEditor, {
          ...attrs,
          modelValue: props.modelValue,
          disabled: props.disabled,
          request: sdk.request,
          schemaFieldsComponent: fields,
          "onUpdate:modelValue": (value) => emit("update:modelValue", value)
        });
      }
    })
  });
}
export {
  install
};
