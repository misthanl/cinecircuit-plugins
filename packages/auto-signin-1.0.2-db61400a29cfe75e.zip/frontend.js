if (typeof document !== "undefined") { const id = "auto_signin"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.signin-stat-dialog[data-v-45432016]{--stat-amber:#f5a524;--stat-red:#e45c72;--stat-blue:#2f93f1;--stat-violet:#7c64df;--stat-green:#39a96b;display:flex;height:auto;max-height:min(820px,calc(100svh - 48px - env(safe-area-inset-top,0px) - env(safe-area-inset-bottom,0px)));flex-direction:column;overflow:hidden;border:1px solid var(--app-border-subtle);border-radius:20px!important;background:var(--app-surface);color:var(--app-text);box-shadow:0 28px 80px rgba(18,26,45,.22)}\n.signin-stat-dialog__header[data-v-45432016]{display:flex;box-sizing:border-box;height:var(--app-plugin-dialog-header-height,58px);min-height:var(--app-plugin-dialog-header-height,58px);max-height:var(--app-plugin-dialog-header-height,58px);flex:0 0 var(--app-plugin-dialog-header-height,58px);align-items:center;justify-content:space-between;gap:18px;padding:6px 24px;border-bottom:1px solid var(--app-border-subtle)}\n.signin-stat-dialog__header h2[data-v-45432016]{margin:0;font-size:18px;font-weight:750;line-height:1.2}\n.signin-stat-dialog__content[data-v-45432016]{display:grid;flex:1 1 auto;grid-template-rows:auto minmax(0,1fr);min-height:0;gap:20px;overflow:hidden;padding:22px 24px;background:var(--app-surface-subtle)}\n.signin-stat-metrics[data-v-45432016]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.metric[data-v-45432016]{position:relative;display:flex;min-width:0;align-items:flex-start;gap:12px;padding:16px 17px;overflow:hidden;border:1px solid var(--app-border-subtle);border-radius:14px;background:var(--app-surface)}.metric[data-v-45432016]::before{position:absolute;inset:0 auto 0 0;width:3px;background:var(--metric-color);content:\"\"}.metric__icon[data-v-45432016]{display:grid;width:29px;height:29px;flex:0 0 auto;place-items:center;border-radius:9px;background:color-mix(in srgb,var(--metric-color) 14%,transparent);color:var(--metric-color);font-weight:850}.metric>div[data-v-45432016]{min-width:0}.metric__label[data-v-45432016]{display:block;color:var(--app-text-muted);font-size:12px;font-weight:700}.metric strong[data-v-45432016]{display:block;margin-top:5px;color:var(--metric-color);font-size:27px;font-variant-numeric:tabular-nums;line-height:1}.metric strong small[data-v-45432016]{font-size:16px;font-weight:720}.metric p[data-v-45432016]{margin:7px 0 0;overflow:hidden;color:var(--app-text-muted);font-size:11px;text-overflow:ellipsis;white-space:nowrap}.metric--amber[data-v-45432016]{--metric-color:var(--stat-amber)}.metric--red[data-v-45432016]{--metric-color:var(--stat-red)}.metric--blue[data-v-45432016]{--metric-color:var(--stat-blue)}.metric--violet[data-v-45432016]{--metric-color:var(--stat-violet)}\n.signin-stat-board[data-v-45432016]{display:flex;flex-direction:column;min-height:0;overflow:hidden;border:1px solid var(--app-border-subtle);border-radius:16px;background:var(--app-surface)}.signin-stat-board__header[data-v-45432016]{display:flex;flex:0 0 auto;align-items:center;justify-content:space-between;gap:18px;padding:15px 16px;border-bottom:1px solid var(--app-border-subtle)}.signin-stat-board__header h3[data-v-45432016]{margin:0;font-size:15px}.signin-stat-board__header h3 span[data-v-45432016]{color:var(--stat-violet)}.signin-stat-board__header p[data-v-45432016]{margin:4px 0 0;color:var(--app-text-muted);font-size:11px}.signin-stat-legend[data-v-45432016]{display:flex;align-items:center;gap:13px;color:var(--app-text-muted);font-size:11px;white-space:nowrap}.signin-stat-legend span[data-v-45432016]{display:flex;align-items:center;gap:5px}.signin-stat-legend b[data-v-45432016]{padding:5px 9px;border-radius:999px;background:color-mix(in srgb,var(--stat-violet) 12%,transparent);color:var(--stat-violet);font-weight:750}.dot[data-v-45432016]{width:7px;height:7px;border-radius:50%}.dot--success[data-v-45432016]{background:var(--stat-green)}.dot--failed[data-v-45432016]{background:var(--stat-red)}.dot--empty[data-v-45432016]{border:1px solid var(--app-text-muted)}\n.signin-stat-table-wrap[data-v-45432016]{flex:1 1 auto;min-height:0;overflow:auto;overscroll-behavior:contain}.signin-stat-table[data-v-45432016]{width:100%;min-width:890px;border-collapse:collapse;table-layout:fixed}.signin-stat-table th[data-v-45432016],.signin-stat-table td[data-v-45432016]{height:54px;padding:8px 10px;border-bottom:1px solid var(--app-border-subtle);text-align:center}.signin-stat-table thead th[data-v-45432016]{position:sticky;top:0;z-index:2;height:48px;background:var(--app-surface-muted);color:var(--app-text-muted);font-size:11px;font-weight:750}.signin-stat-table thead th[data-v-45432016]:first-child,.signin-stat-table tbody th[data-v-45432016]{width:190px;text-align:left}.signin-stat-table thead th[data-v-45432016]:nth-child(2){width:175px;text-align:left}.signin-stat-table thead th span[data-v-45432016],.signin-stat-table thead th small[data-v-45432016]{display:block}.signin-stat-table thead th span[data-v-45432016]{color:var(--app-text);font-size:12px}.signin-stat-table thead th small[data-v-45432016]{margin-top:2px;font-weight:500}.signin-stat-table tbody tr:last-child th[data-v-45432016],.signin-stat-table tbody tr:last-child td[data-v-45432016]{border-bottom:0}.signin-stat-table tbody tr[data-v-45432016]:hover{background:color-mix(in srgb,var(--stat-violet) 4%,transparent)}.signin-stat-table tbody th[data-v-45432016]{position:sticky;left:0;z-index:1;background:var(--app-surface)}.signin-stat-table tbody th strong[data-v-45432016],.signin-stat-table tbody th small[data-v-45432016]{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.signin-stat-table tbody th strong[data-v-45432016]{font-size:13px}.signin-stat-table tbody th small[data-v-45432016]{margin-top:3px;color:var(--app-text-muted);font-size:10px;font-weight:500}.signin-stat-table tbody td[data-v-45432016]:nth-child(2){text-align:left}\n.today-pill[data-v-45432016]{display:inline-flex;align-items:center;gap:6px;max-width:150px;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:750;white-space:nowrap}.today-pill i[data-v-45432016]{width:6px;height:6px;border-radius:50%;background:currentColor}.today-pill--success[data-v-45432016]{background:color-mix(in srgb,var(--stat-green) 13%,transparent);color:var(--stat-green)}.today-pill--failed[data-v-45432016]{background:color-mix(in srgb,var(--stat-red) 13%,transparent);color:var(--stat-red)}.today-pill--empty[data-v-45432016]{background:var(--app-surface-muted);color:var(--app-text-muted)}\n.status-cell[data-v-45432016]{display:inline-grid;width:28px;height:28px;place-items:center;border-radius:50%;font-size:14px;font-weight:850}.status-cell--success[data-v-45432016]{border:1px solid color-mix(in srgb,var(--stat-green) 48%,transparent);background:color-mix(in srgb,var(--stat-green) 16%,transparent);color:var(--stat-green)}.status-cell--failed[data-v-45432016]{border:1px solid color-mix(in srgb,var(--stat-red) 48%,transparent);background:color-mix(in srgb,var(--stat-red) 15%,transparent);color:var(--stat-red)}.status-cell--empty[data-v-45432016]{border:1px solid color-mix(in srgb,var(--app-text-muted) 38%,transparent);background:var(--app-surface-muted);color:var(--app-text-muted);font-weight:500}\n.signin-stat-empty[data-v-45432016]{display:flex;min-height:180px;align-items:center;justify-content:center;gap:10px;padding:30px;color:var(--app-text-muted);font-size:12px;text-align:center}.signin-stat-loader[data-v-45432016]{width:18px;height:18px;border:2px solid var(--app-border-subtle);border-top-color:var(--stat-violet);border-radius:50%;animation:signin-spin-45432016 .8s linear infinite}.signin-stat-dialog__actions[data-v-45432016]{display:flex;flex:0 0 auto;justify-content:flex-end;padding:12px 20px;border-top:1px solid var(--app-border-subtle)}@keyframes signin-spin-45432016{to{transform:rotate(360deg)}}\n@media(max-width:900px){.signin-stat-metrics[data-v-45432016]{grid-template-columns:repeat(2,minmax(0,1fr))}.signin-stat-board__header[data-v-45432016]{align-items:flex-start;flex-direction:column}.signin-stat-legend[data-v-45432016]{width:100%;overflow:auto}}\n@media(max-width:620px){.signin-stat-dialog[data-v-45432016]{height:auto;max-height:min(820px,calc(92svh - env(safe-area-inset-top,0px) - env(safe-area-inset-bottom,0px)));border-radius:16px!important}.signin-stat-dialog__header[data-v-45432016]{padding:6px 16px}.signin-stat-dialog__content[data-v-45432016]{padding:16px}.signin-stat-dialog__header h2[data-v-45432016]{font-size:16px}.signin-stat-metrics[data-v-45432016]{grid-template-columns:1fr 1fr;gap:8px}.metric[data-v-45432016]{gap:8px;padding:13px 11px}.metric__icon[data-v-45432016]{width:25px;height:25px}.metric strong[data-v-45432016]{font-size:22px}.metric p[data-v-45432016]{font-size:10px}.signin-stat-board__header[data-v-45432016]{padding:13px}.signin-stat-dialog__actions[data-v-45432016]{padding:10px 16px}}\n@media(prefers-reduced-motion:reduce){.signin-stat-loader[data-v-45432016]{animation:none}}\r\n/* Shared visual contract for plugin configuration, statistics and workspace pages.\r\n * Values mirror the host application's standard configuration dialog and\r\n * operational content density. Keep business-specific layouts in each plugin.\r\n */\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .signin-page,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace,\r\n  .signin-stat-dialog,\r\n  .cc-statistics-dialog,\r\n  .douban-dialog,\r\n  .maoyan-dialog,\r\n  .cover-history\r\n) {\r\n  color: var(--app-text, #1a2434);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field) {\r\n  min-height: var(--app-control-height, 52px);\r\n  border-radius: var(--app-control-radius, 11px);\r\n  background: var(--control-surface, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-field__input) {\r\n  min-width: 0;\r\n  min-height: var(--app-control-height, 52px) !important;\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-label.v-field-label) {\r\n  color: var(--app-text-secondary, #657087);\r\n  font-size: var(--app-font-size-label, 11px);\r\n}\r\n\r\n/* Custom plugin editors render Vuetify switches directly instead of through\r\n * the host's InlineSwitchRow. Pin their copy to the host's compact form-label\r\n * treatment so Vuetify's larger body label cannot change the visual scale. */\r\n:where(\r\n  .cookiecloud-config-fields,\r\n  .cover-run-settings,\r\n  .cover-targets,\r\n  .style-editor,\r\n  .traffic-config,\r\n  .traffic-dialog,\r\n  .brush,\r\n  .cover,\r\n  .subtitle-workspace\r\n) :is(.v-switch, .v-checkbox, .v-radio) .v-label {\r\n  color: var(--app-text-secondary, #657087) !important;\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-label, 13px) !important;\r\n  font-weight: var(--app-font-weight-regular, 400) !important;\r\n  line-height: 1.35;\r\n  opacity: 1;\r\n}\r\n\r\n:where(.signin-stat-dialog, .cc-statistics-dialog, .douban-dialog, .maoyan-dialog, .traffic-dialog, .cover-history) {\r\n  overflow: hidden;\r\n  border: 1px solid var(--app-border, #dfe4ee) !important;\r\n  border-radius: 18px !important;\r\n  background: var(--app-dialog-surface, var(--app-surface, #fff)) !important;\r\n  color: var(--app-text, #202939);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) {\r\n  min-height: 80px;\r\n  padding: 18px 20px !important;\r\n  border-bottom: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header,\r\n  .cover-history > header\r\n) h2 {\r\n  margin: 0;\r\n  color: var(--app-text, #202939);\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-heading, 750) !important;\r\n  line-height: 1.2;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__header,\r\n  .cc-statistics-header,\r\n  .douban-dialog__header,\r\n  .traffic-dialog-heading,\r\n  .maoyan-dialog__header\r\n) p {\r\n  margin: 3px 0 0;\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: var(--app-font-size-helper, 10px) !important;\r\n  line-height: 1.4;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__content,\r\n  .cc-statistics-content,\r\n  .douban-dialog__content,\r\n  .traffic-dialog-body,\r\n  .maoyan-dialog__content,\r\n  .cover-history > main\r\n) {\r\n  padding: 20px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-dialog__actions,\r\n  .cc-statistics-actions,\r\n  .douban-dialog__actions,\r\n  .traffic-dialog-actions,\r\n  .maoyan-dialog__actions,\r\n  .cover-history > footer\r\n) {\r\n  min-height: 64px;\r\n  padding: 13px 18px !important;\r\n  border-top: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  background: var(--app-surface-raised, var(--app-surface, #fff));\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) {\r\n  gap: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) > div {\r\n  min-width: 0;\r\n  padding: 15px 16px !important;\r\n  border: 1px solid var(--app-border-subtle, #e7ebf2);\r\n  border-radius: 12px !important;\r\n  background: var(--app-surface, #fff);\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics,\r\n  .cover-history .metrics\r\n) dt,\r\n:where(.cover-history .metrics) span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 12px !important;\r\n}\r\n\r\n:where(\r\n  .signin-stat-metrics,\r\n  .cookie-metrics,\r\n  .douban-statistics__metrics,\r\n  .maoyan-statistics__metrics\r\n) dd,\r\n:where(.cover-history .metrics) strong {\r\n  margin-top: 7px;\r\n  color: var(--app-text, #202939);\r\n  font-family: inherit !important;\r\n  font-size: var(--app-font-size-metric, 24px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  font-variant-numeric: tabular-nums;\r\n  line-height: 1.15;\r\n}\r\n\r\n:where(.douban-statistics__metrics, .maoyan-statistics__metrics) dd span,\r\n.cookie-metric dd > span {\r\n  color: var(--app-text-muted, #7a869d);\r\n  font-size: 11px !important;\r\n  font-weight: var(--app-font-weight-regular, 400);\r\n}\r\n\r\n.signin-stat-results {\r\n  border-radius: 12px !important;\r\n}\r\n\r\n.signin-stat-results > header {\r\n  min-height: 44px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article {\r\n  min-height: 68px;\r\n  padding: 10px 12px !important;\r\n}\r\n\r\n.signin-stat-results article strong {\r\n  color: var(--app-text, #202939);\r\n  font-size: 13px;\r\n  font-weight: var(--app-font-weight-medium, 650);\r\n}\r\n\r\n.signin-stat-results article p {\r\n  font-size: 12px !important;\r\n}\r\n\r\n.signin-stat-results :is(article span, time) {\r\n  font-size: 10px !important;\r\n}\r\n\r\n:where(.signin-page, .brush, .cover, .subtitle-workspace) {\r\n  min-width: 0;\r\n  color: var(--app-text, #17243a);\r\n  font-family: var(--app-font-family, inherit) !important;\r\n  font-size: var(--app-font-size-body, 14px);\r\n  line-height: 1.5;\r\n}\r\n\r\n:where(.signin-hero, .brush-head, .cover-head, .subtitle-hero) h1 {\r\n  font-size: 27px !important;\r\n  font-weight: 750;\r\n  line-height: 1.15;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.signin-panel, .brush-panel, .cover-card, .subtitle-panel) h2 {\r\n  font-size: var(--app-font-size-section-title, 18px) !important;\r\n  font-weight: var(--app-font-weight-metric, 700);\r\n  line-height: 1.3;\r\n}\r\n\r\n:where(.signin-button, .brush button, .cover button, .subtitle-button) {\r\n  min-height: 40px;\r\n  border-radius: 9px !important;\r\n  font-size: 13px;\r\n  letter-spacing: 0;\r\n}\r\n\r\n:where(.brush-field input, .brush-field select, .cover-field input, .cover-field select, .subtitle-search, .subtitle-upload input) {\r\n  min-height: 52px;\r\n  border-radius: 11px;\r\n  color: var(--app-text-secondary, #657087);\r\n  font: inherit;\r\n  font-size: var(--app-font-size-control, 14px);\r\n}\r\n\r\n@media (max-width: 700px) {\r\n  :where(\r\n    .signin-stat-dialog__header,\r\n    .cc-statistics-header,\r\n    .douban-dialog__header,\r\n    .traffic-dialog-heading,\n    .maoyan-dialog__header,\n    .cover-history > header,\r\n    .signin-stat-dialog__content,\r\n    .cc-statistics-content,\r\n    .douban-dialog__content,\r\n    .traffic-dialog-body,\n    .maoyan-dialog__content,\n    .cover-history > main\r\n  ) {\r\n    padding: 16px !important;\r\n  }\r\n}\r\n\r\n/* Legacy-host fallback. On current hosts, the public form owns these tokens. */\r\n:where(.app-form-layout) {\r\n  display: grid;\r\n  grid-template-columns: repeat(var(--app-plugin-config-columns, 2), minmax(0, 1fr));\r\n  row-gap: var(--app-plugin-config-row-gap, 14px);\r\n  column-gap: var(--app-plugin-config-column-gap, 16px);\r\n}\r\n@media (max-width: 760px) {\r\n  :where(.app-form-layout) { grid-template-columns: minmax(0, 1fr); }\r\n}\r\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const computed = runtime.computed;
const createBlock = runtime.createBlock;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const createVNode = runtime.createVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const toDisplayString = runtime.toDisplayString;
const unref = runtime.unref;
const withCtx = runtime.withCtx;
const _hoisted_1 = { class: "signin-stat-dialog__header" };
const _hoisted_2 = { class: "signin-stat-dialog__content" };
const _hoisted_3 = {
  key: 0,
  class: "signin-stat-empty"
};
const _hoisted_4 = {
  class: "signin-stat-metrics",
  "aria-label": "今日签到概览"
};
const _hoisted_5 = { class: "metric metric--amber" };
const _hoisted_6 = { class: "metric metric--red" };
const _hoisted_7 = { class: "metric metric--blue" };
const _hoisted_8 = {
  class: "signin-stat-board",
  "aria-labelledby": "signin-matrix-title"
};
const _hoisted_9 = { class: "signin-stat-board__header" };
const _hoisted_10 = {
  class: "signin-stat-legend",
  "aria-label": "状态图例"
};
const _hoisted_11 = {
  key: 0,
  class: "signin-stat-table-wrap"
};
const _hoisted_12 = { class: "signin-stat-table" };
const _hoisted_13 = { scope: "row" };
const _hoisted_14 = ["title", "aria-label"];
const _hoisted_15 = {
  key: 1,
  class: "signin-stat-empty"
};
const _hoisted_16 = { class: "signin-stat-dialog__actions" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "StatisticsView",
  props: {
    context: {},
    request: {},
    buttonComponent: {},
    cardComponent: {},
    dialogComponent: {},
    alertComponent: {}
  },
  setup(__props) {
    const props = __props;
    const UiButton = props.buttonComponent;
    const UiCard = props.cardComponent;
    const UiDialog = props.dialogComponent;
    const UiAlert = props.alertComponent;
    const loading = ref(false);
    const error = ref("");
    const inventory = ref({});
    const history = computed(() => Array.isArray(inventory.value.history) ? inventory.value.history : []);
    const signSiteIds = computed(() => inventory.value.selected?.sign_sites || []);
    const loginSiteIds = computed(() => inventory.value.selected?.login_sites || []);
    const todayKey = computed(() => dateKey(/* @__PURE__ */ new Date()));
    const days = computed(() => Array.from({ length: 7 }, (_, index) => {
      const date = /* @__PURE__ */ new Date();
      date.setHours(12, 0, 0, 0);
      date.setDate(date.getDate() - index);
      return { key: dateKey(date), short: `${date.getMonth() + 1}/${date.getDate()}`, weekday: index === 0 ? "今天" : weekday(date) };
    }));
    const siteRows = computed(() => {
      const ids = new Set(signSiteIds.value);
      history.value.forEach((item) => {
        if ((item.payload?.mode || "sign") === "sign" && item.payload?.site_id) ids.add(String(item.payload.site_id));
      });
      return [...ids].map((id) => ({ id, name: findSiteName(id), records: history.value.filter((item) => String(item.payload?.site_id || "") === id && (item.payload?.mode || "sign") === "sign").length })).sort((left, right) => sitePriority(left.id) - sitePriority(right.id) || left.name.localeCompare(right.name, "zh-CN"));
    });
    const todaySigns = computed(() => recordsFor("sign", todayKey.value));
    const todayLogins = computed(() => recordsFor("login", todayKey.value));
    const signSuccess = computed(() => todaySigns.value.filter(isSuccess).length);
    const signFailed = computed(() => todaySigns.value.filter((item) => !isSuccess(item)).length);
    const loginSuccess = computed(() => todayLogins.value.filter(isSuccess).length);
    const signUnrecorded = computed(() => Math.max(0, signSiteIds.value.length - new Set(todaySigns.value.map(siteId)).size));
    const loginUnrecorded = computed(() => Math.max(0, loginSiteIds.value.length - new Set(todayLogins.value.map(siteId)).size));
    function dateKey(date) {
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, "0");
      const day = String(date.getDate()).padStart(2, "0");
      return `${year}-${month}-${day}`;
    }
    function historyDate(item) {
      if (!item.updated_at) return "";
      const parsed = new Date(item.updated_at);
      return Number.isFinite(parsed.getTime()) ? dateKey(parsed) : String(item.updated_at).slice(0, 10);
    }
    function weekday(date) {
      return ["周日", "周一", "周二", "周三", "周四", "周五", "周六"][date.getDay()];
    }
    function siteId(item) {
      return String(item.payload?.site_id || "");
    }
    function isSuccess(item) {
      return item.result?.ok === true || item.status === "signed";
    }
    function recordsFor(mode, day) {
      return history.value.filter((item) => (item.payload?.mode || "sign") === mode && historyDate(item) === day);
    }
    function findSiteName(id) {
      const saved = history.value.find((item) => siteId(item) === id);
      const recordedName = saved?.payload?.site_name || saved?.result?.site_name;
      return inventory.value.items?.find((site) => String(site.id) === id)?.name || recordedName || inventorySiteName(id);
    }
    function sitePriority(id) {
      return Number(inventory.value.items?.find((site) => String(site.id) === id)?.priority ?? 0);
    }
    function inventorySiteName(id) {
      return inventory.value.items?.find((site) => String(site.id) === id)?.name || id || "未知站点";
    }
    function recordFor(site, day) {
      return history.value.find((item) => siteId(item) === site && (item.payload?.mode || "sign") === "sign" && historyDate(item) === day);
    }
    function stateFor(site, day) {
      const item = recordFor(site, day);
      if (!item) return "empty";
      return isSuccess(item) ? "success" : "failed";
    }
    function stateLabel(state) {
      return state === "success" ? "签到成功" : state === "failed" ? "签到失败，需要重试" : "暂无记录";
    }
    async function load() {
      loading.value = true;
      error.value = "";
      try {
        inventory.value = await props.request("/plugins/auto-signin/api/inventory");
      } catch (reason) {
        error.value = reason instanceof Error ? reason.message : "签到统计加载失败";
      } finally {
        loading.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(UiDialog), {
        "model-value": true,
        "max-width": 972,
        width: "calc(100vw - 32px)",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = (open) => {
          if (!open) __props.context.close();
        })
      }, {
        default: withCtx(() => [
          createVNode(unref(UiCard), { class: "signin-stat-dialog" }, {
            default: withCtx(() => [
              createElementVNode("header", _hoisted_1, [
                _cache[1] || (_cache[1] = createElementVNode(
                  "h2",
                  null,
                  "站点签到助手 · 数据统计",
                  -1
                  /* CACHED */
                )),
                createVNode(unref(UiButton), {
                  class: "app-dialog-close",
                  icon: "mdi-close",
                  variant: "text",
                  "aria-label": "关闭",
                  onClick: __props.context.close
                }, null, 8, ["onClick"])
              ]),
              createElementVNode("main", _hoisted_2, [
                loading.value && !history.value.length ? (openBlock(), createElementBlock("div", _hoisted_3, [..._cache[2] || (_cache[2] = [
                  createElementVNode(
                    "span",
                    { class: "signin-stat-loader" },
                    null,
                    -1
                    /* CACHED */
                  ),
                  createTextVNode(
                    "正在读取签到记录…",
                    -1
                    /* CACHED */
                  )
                ])])) : error.value ? (openBlock(), createBlock(unref(UiAlert), {
                  key: 1,
                  type: "error",
                  variant: "tonal"
                }, {
                  default: withCtx(() => [
                    createTextVNode(
                      toDisplayString(error.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  _: 1
                  /* STABLE */
                })) : (openBlock(), createElementBlock(
                  Fragment,
                  { key: 2 },
                  [
                    createElementVNode("section", _hoisted_4, [
                      createElementVNode("article", _hoisted_5, [
                        _cache[4] || (_cache[4] = createElementVNode(
                          "span",
                          { class: "metric__icon" },
                          "✓",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("div", null, [
                          _cache[3] || (_cache[3] = createElementVNode(
                            "span",
                            { class: "metric__label" },
                            "今日签到",
                            -1
                            /* CACHED */
                          )),
                          createElementVNode("strong", null, [
                            createTextVNode(
                              toDisplayString(signSuccess.value),
                              1
                              /* TEXT */
                            ),
                            createElementVNode(
                              "small",
                              null,
                              "/" + toDisplayString(signSiteIds.value.length),
                              1
                              /* TEXT */
                            )
                          ]),
                          createElementVNode(
                            "p",
                            null,
                            "异常 " + toDisplayString(signFailed.value) + " · 未记录 " + toDisplayString(signUnrecorded.value),
                            1
                            /* TEXT */
                          )
                        ])
                      ]),
                      createElementVNode("article", _hoisted_6, [
                        _cache[6] || (_cache[6] = createElementVNode(
                          "span",
                          { class: "metric__icon" },
                          "!",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("div", null, [
                          _cache[5] || (_cache[5] = createElementVNode(
                            "span",
                            { class: "metric__label" },
                            "待处理异常",
                            -1
                            /* CACHED */
                          )),
                          createElementVNode(
                            "strong",
                            null,
                            toDisplayString(signFailed.value),
                            1
                            /* TEXT */
                          ),
                          createElementVNode(
                            "p",
                            null,
                            toDisplayString(signFailed.value ? "需要检查失败原因" : "今日暂无签到异常"),
                            1
                            /* TEXT */
                          )
                        ])
                      ]),
                      createElementVNode("article", _hoisted_7, [
                        _cache[8] || (_cache[8] = createElementVNode(
                          "span",
                          { class: "metric__icon" },
                          "↪",
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("div", null, [
                          _cache[7] || (_cache[7] = createElementVNode(
                            "span",
                            { class: "metric__label" },
                            "今日登录",
                            -1
                            /* CACHED */
                          )),
                          createElementVNode("strong", null, [
                            createTextVNode(
                              toDisplayString(loginSuccess.value),
                              1
                              /* TEXT */
                            ),
                            createElementVNode(
                              "small",
                              null,
                              "/" + toDisplayString(loginSiteIds.value.length),
                              1
                              /* TEXT */
                            )
                          ]),
                          createElementVNode(
                            "p",
                            null,
                            "未记录 " + toDisplayString(loginUnrecorded.value),
                            1
                            /* TEXT */
                          )
                        ])
                      ]),
                      _cache[9] || (_cache[9] = createElementVNode(
                        "article",
                        { class: "metric metric--violet" },
                        [
                          createElementVNode("span", { class: "metric__icon" }, "↺"),
                          createElementVNode("div", null, [
                            createElementVNode("span", { class: "metric__label" }, "历史范围"),
                            createElementVNode("strong", null, [
                              createTextVNode("7"),
                              createElementVNode("small", null, " 天")
                            ]),
                            createElementVNode("p", null, "按站点展示每日结果")
                          ])
                        ],
                        -1
                        /* CACHED */
                      ))
                    ]),
                    createElementVNode("section", _hoisted_8, [
                      createElementVNode("header", _hoisted_9, [
                        _cache[13] || (_cache[13] = createElementVNode(
                          "div",
                          null,
                          [
                            createElementVNode("h3", { id: "signin-matrix-title" }, [
                              createElementVNode("span", { "aria-hidden": "true" }, "▣"),
                              createTextVNode(" 签到状态")
                            ]),
                            createElementVNode("p", null, "每一格代表该站点当天最后一次签到结果")
                          ],
                          -1
                          /* CACHED */
                        )),
                        createElementVNode("div", _hoisted_10, [
                          _cache[10] || (_cache[10] = createElementVNode(
                            "span",
                            null,
                            [
                              createElementVNode("i", { class: "dot dot--success" }),
                              createTextVNode("成功")
                            ],
                            -1
                            /* CACHED */
                          )),
                          _cache[11] || (_cache[11] = createElementVNode(
                            "span",
                            null,
                            [
                              createElementVNode("i", { class: "dot dot--failed" }),
                              createTextVNode("异常")
                            ],
                            -1
                            /* CACHED */
                          )),
                          _cache[12] || (_cache[12] = createElementVNode(
                            "span",
                            null,
                            [
                              createElementVNode("i", { class: "dot dot--empty" }),
                              createTextVNode("未记录")
                            ],
                            -1
                            /* CACHED */
                          )),
                          createElementVNode(
                            "b",
                            null,
                            toDisplayString(siteRows.value.length) + " 个站点",
                            1
                            /* TEXT */
                          )
                        ])
                      ]),
                      siteRows.value.length ? (openBlock(), createElementBlock("div", _hoisted_11, [
                        createElementVNode("table", _hoisted_12, [
                          createElementVNode("thead", null, [
                            createElementVNode("tr", null, [
                              _cache[14] || (_cache[14] = createElementVNode(
                                "th",
                                { scope: "col" },
                                "站点",
                                -1
                                /* CACHED */
                              )),
                              _cache[15] || (_cache[15] = createElementVNode(
                                "th",
                                { scope: "col" },
                                "今日状态",
                                -1
                                /* CACHED */
                              )),
                              (openBlock(true), createElementBlock(
                                Fragment,
                                null,
                                renderList(days.value, (day) => {
                                  return openBlock(), createElementBlock("th", {
                                    key: day.key,
                                    scope: "col"
                                  }, [
                                    createElementVNode(
                                      "span",
                                      null,
                                      toDisplayString(day.short),
                                      1
                                      /* TEXT */
                                    ),
                                    createElementVNode(
                                      "small",
                                      null,
                                      toDisplayString(day.weekday),
                                      1
                                      /* TEXT */
                                    )
                                  ]);
                                }),
                                128
                                /* KEYED_FRAGMENT */
                              ))
                            ])
                          ]),
                          createElementVNode("tbody", null, [
                            (openBlock(true), createElementBlock(
                              Fragment,
                              null,
                              renderList(siteRows.value, (site) => {
                                return openBlock(), createElementBlock("tr", {
                                  key: site.id
                                }, [
                                  createElementVNode("th", _hoisted_13, [
                                    createElementVNode(
                                      "strong",
                                      null,
                                      toDisplayString(site.name),
                                      1
                                      /* TEXT */
                                    ),
                                    createElementVNode(
                                      "small",
                                      null,
                                      toDisplayString(site.records) + " 条签到记录",
                                      1
                                      /* TEXT */
                                    )
                                  ]),
                                  createElementVNode("td", null, [
                                    createElementVNode(
                                      "span",
                                      {
                                        class: normalizeClass(["today-pill", `today-pill--${stateFor(site.id, todayKey.value)}`])
                                      },
                                      [
                                        _cache[16] || (_cache[16] = createElementVNode(
                                          "i",
                                          null,
                                          null,
                                          -1
                                          /* CACHED */
                                        )),
                                        createTextVNode(
                                          toDisplayString(stateLabel(stateFor(site.id, todayKey.value))),
                                          1
                                          /* TEXT */
                                        )
                                      ],
                                      2
                                      /* CLASS */
                                    )
                                  ]),
                                  (openBlock(true), createElementBlock(
                                    Fragment,
                                    null,
                                    renderList(days.value, (day) => {
                                      return openBlock(), createElementBlock("td", {
                                        key: day.key
                                      }, [
                                        createElementVNode("span", {
                                          class: normalizeClass(["status-cell", `status-cell--${stateFor(site.id, day.key)}`]),
                                          title: `${site.name} · ${day.short} · ${stateLabel(stateFor(site.id, day.key))}`,
                                          "aria-label": stateLabel(stateFor(site.id, day.key))
                                        }, toDisplayString(stateFor(site.id, day.key) === "success" ? "✓" : stateFor(site.id, day.key) === "failed" ? "!" : "−"), 11, _hoisted_14)
                                      ]);
                                    }),
                                    128
                                    /* KEYED_FRAGMENT */
                                  ))
                                ]);
                              }),
                              128
                              /* KEYED_FRAGMENT */
                            ))
                          ])
                        ])
                      ])) : (openBlock(), createElementBlock("div", _hoisted_15, "还没有签到站点。先在插件设置中选择站点，任务运行后即可查看每日结果。"))
                    ])
                  ],
                  64
                  /* STABLE_FRAGMENT */
                ))
              ]),
              createElementVNode("footer", _hoisted_16, [
                createVNode(unref(UiButton), {
                  "prepend-icon": "mdi-refresh",
                  variant: "text",
                  loading: loading.value,
                  onClick: load
                }, {
                  default: withCtx(() => [..._cache[17] || (_cache[17] = [
                    createTextVNode(
                      "刷新",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["loading"])
              ])
            ]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      });
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const StatisticsView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-45432016"]]);
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const { Alert, Button, Card, Dialog } = sdk.ui.components;
  const Statistics = defineComponent2({
    name: "SiteCheckinStatistics",
    inheritAttrs: false,
    props: { context: { type: Object, required: true } },
    setup(props, { attrs }) {
      return () => h(StatisticsView, {
        ...attrs,
        context: props.context,
        request: sdk.request,
        alertComponent: Alert,
        buttonComponent: Button,
        cardComponent: Card,
        dialogComponent: Dialog
      });
    }
  });
  sdk.registerContribution({ pluginId: "auto-signin", slot: "plugin.statistics", key: "site-results", component: Statistics });
}
export {
  install
};
