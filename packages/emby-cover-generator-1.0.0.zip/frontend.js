if (typeof document !== "undefined") { const id = "media_cover_generator"; document.querySelector(`style[data-cinecircuit-plugin-style="${id}"]`)?.remove(); const style = document.createElement("style"); style.dataset.cinecircuitPluginStyle = id; style.textContent = "\n.cover[data-v-a3a5f493]{display:grid;gap:18px;color:var(--app-text,#17243a)}.cover[data-v-a3a5f493] *{box-sizing:border-box}.cover-head[data-v-a3a5f493],.cover-card[data-v-a3a5f493]{border:1px solid var(--app-border,#dfe5ef);border-radius:22px;background:#fff;box-shadow:0 14px 36px rgba(37,61,99,.06)}.cover-head[data-v-a3a5f493]{display:flex;justify-content:space-between;align-items:center;padding:24px}.cover h1[data-v-a3a5f493],.cover h2[data-v-a3a5f493]{margin:0}.cover p[data-v-a3a5f493]{margin:5px 0 0;color:#71809a}.cover button[data-v-a3a5f493]{min-height:41px;padding:0 16px;border:0;border-radius:12px;background:#2f74f6;color:#fff;font-weight:750;cursor:pointer}.cover button.alt[data-v-a3a5f493]{background:#edf3ff;color:#245fc4}.cover-layout[data-v-a3a5f493]{display:grid;grid-template-columns:minmax(280px,.8fr) minmax(0,1.25fr);gap:16px}.cover-card[data-v-a3a5f493]{padding:20px}.cover-list[data-v-a3a5f493]{display:grid;gap:9px;margin-top:14px}.cover-row[data-v-a3a5f493]{display:grid;grid-template-columns:auto minmax(0,1fr);gap:10px;align-items:center;padding:12px;border:1px solid #e0e6ef;border-radius:13px;background:#f8fafc}.cover-grid[data-v-a3a5f493]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.cover-field[data-v-a3a5f493]{display:grid;gap:6px}.cover-field.full[data-v-a3a5f493]{grid-column:1/-1}.cover-field span[data-v-a3a5f493]{font-size:13px;font-weight:700;color:#60708a}.cover-field input[data-v-a3a5f493],.cover-field select[data-v-a3a5f493],.cover-field textarea[data-v-a3a5f493]{width:100%;min-height:42px;padding:0 12px;border:1px solid #d7dfeb;border-radius:11px;background:#fff}.cover-field textarea[data-v-a3a5f493]{min-height:90px;padding-top:10px}.cover-styles[data-v-a3a5f493]{grid-column:1/-1;display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.cover-style[data-v-a3a5f493]{padding:14px 8px!important;background:#f0f4fa!important;color:#43536b!important}.cover-style.on[data-v-a3a5f493]{background:#2f74f6!important;color:#fff!important}@media(max-width:820px){.cover-layout[data-v-a3a5f493]{grid-template-columns:1fr}.cover-grid[data-v-a3a5f493]{grid-template-columns:1fr}.cover-field.full[data-v-a3a5f493]{grid-column:auto}.cover-styles[data-v-a3a5f493]{grid-column:auto;grid-template-columns:repeat(2,1fr)}.cover-head[data-v-a3a5f493]{align-items:stretch;flex-direction:column;gap:14px}}\n"; document.head.appendChild(style); }
const runtime = globalThis.__CINECIRCUIT_PLUGIN_VUE_RUNTIME__;
if (!runtime) throw new Error("CineCircuit host Vue runtime is unavailable");
const Fragment = runtime.Fragment;
const createElementBlock = runtime.createElementBlock;
const createElementVNode = runtime.createElementVNode;
const createTextVNode = runtime.createTextVNode;
const defineComponent = runtime.defineComponent;
const normalizeClass = runtime.normalizeClass;
const onMounted = runtime.onMounted;
const openBlock = runtime.openBlock;
const ref = runtime.ref;
const renderList = runtime.renderList;
const toDisplayString = runtime.toDisplayString;
const _hoisted_1 = { class: "cover" };
const _hoisted_2 = { class: "cover-head" };
const _hoisted_3 = ["disabled"];
const _hoisted_4 = ["disabled"];
const _hoisted_5 = { class: "cover-layout" };
const _hoisted_6 = { class: "cover-card" };
const _hoisted_7 = { class: "cover-list" };
const _hoisted_8 = { class: "cover-field" };
const _hoisted_9 = ["value"];
const _hoisted_10 = ["value"];
const _hoisted_11 = ["checked", "onChange"];
const _hoisted_12 = { class: "cover-card" };
const _hoisted_13 = { class: "cover-grid" };
const _hoisted_14 = { class: "cover-styles" };
const _hoisted_15 = ["onClick"];
const _hoisted_16 = { class: "cover-field" };
const _hoisted_17 = ["value"];
const _hoisted_18 = ["value"];
const _hoisted_19 = { class: "cover-field" };
const _hoisted_20 = ["value"];
const _hoisted_21 = ["value"];
const _hoisted_22 = { class: "cover-field" };
const _hoisted_23 = ["value"];
const _hoisted_24 = { class: "cover-field" };
const _hoisted_25 = ["value"];
const _hoisted_26 = { class: "cover-field full" };
const _hoisted_27 = ["value"];
const _hoisted_28 = { class: "cover-field full" };
const _hoisted_29 = ["checked"];
const _hoisted_30 = { class: "cover-field full" };
const ID$1 = "emby-cover-generator";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "LibraryArtworkView",
  props: {
    request: { type: Function }
  },
  setup(__props) {
    const props = __props;
    const servers = ref([]);
    const libraries = ref([]);
    const config = ref({});
    const busy = ref(false);
    const message = ref("");
    const styles = [["single", "单图"], ["multi", "多图"], ["poster", "海报墙"], ["animated", "动态"]];
    const sortOptions = [["DateCreated", "入库时间"], ["PremiereDate", "首映时间"], ["Random", "随机"]];
    function errorMessage(error, fallback) {
      return error instanceof Error ? error.message : fallback;
    }
    function set(key, value) {
      config.value = { ...config.value, [key]: value };
    }
    function setInput(key, event, numeric = false) {
      const value = event.target.value;
      set(key, numeric ? Number(value) : value);
    }
    function toggle(key, value) {
      const current = config.value[key];
      const selected = new Set(Array.isArray(current) ? current : []);
      if (selected.has(value)) selected.delete(value);
      else selected.add(value);
      set(key, [...selected]);
    }
    async function load() {
      busy.value = true;
      try {
        const data = await props.request(`/plugins/${ID$1}/api/inventory`);
        servers.value = data.servers || [];
        libraries.value = data.libraries || [];
        config.value = data.config || {};
      } catch (error) {
        message.value = errorMessage(error, "读取失败");
      } finally {
        busy.value = false;
      }
    }
    async function chooseServer(id) {
      set("selected_servers", id ? [id] : []);
      busy.value = true;
      try {
        const data = await props.request(`/plugins/${ID$1}/api/libraries?server_id=${encodeURIComponent(id)}`);
        libraries.value = data.items || [];
        set("include_libraries", []);
      } finally {
        busy.value = false;
      }
    }
    async function save() {
      busy.value = true;
      try {
        config.value = { ...config.value, dry_run: false };
        await props.request(`/plugins/${ID$1}`, { method: "PATCH", body: JSON.stringify({ config: config.value }) });
        message.value = "封面设置已保存";
      } catch (error) {
        message.value = errorMessage(error, "保存失败");
      } finally {
        busy.value = false;
      }
    }
    async function generate() {
      await save();
      busy.value = true;
      try {
        await props.request(`/plugins/${ID$1}/run`, { method: "POST", body: "{}" });
        message.value = "封面生成任务已加入后台队列";
      } catch (error) {
        message.value = errorMessage(error, "生成失败");
      } finally {
        busy.value = false;
      }
    }
    onMounted(load);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("section", _hoisted_1, [
        createElementVNode("header", _hoisted_2, [
          _cache[7] || (_cache[7] = createElementVNode(
            "div",
            null,
            [
              createElementVNode("h1", null, "媒体库视觉封面"),
              createElementVNode("p", null, "选择媒体服务器和媒体库，再设置样式；不再要求手工填写服务器 ID。")
            ],
            -1
            /* CACHED */
          )),
          createElementVNode("div", null, [
            createElementVNode("button", {
              class: "alt",
              disabled: busy.value,
              onClick: load
            }, "刷新", 8, _hoisted_3),
            createElementVNode("button", {
              disabled: busy.value,
              onClick: generate
            }, toDisplayString(busy.value ? "处理中…" : "保存并生成"), 9, _hoisted_4)
          ])
        ]),
        createElementVNode("div", _hoisted_5, [
          createElementVNode("aside", _hoisted_6, [
            _cache[10] || (_cache[10] = createElementVNode(
              "h2",
              null,
              "生成范围",
              -1
              /* CACHED */
            )),
            createElementVNode("div", _hoisted_7, [
              createElementVNode("label", _hoisted_8, [
                _cache[9] || (_cache[9] = createElementVNode(
                  "span",
                  null,
                  "媒体服务器",
                  -1
                  /* CACHED */
                )),
                createElementVNode("select", {
                  value: config.value.selected_servers?.[0] || "",
                  onChange: _cache[0] || (_cache[0] = ($event) => chooseServer($event.target.value))
                }, [
                  _cache[8] || (_cache[8] = createElementVNode(
                    "option",
                    { value: "" },
                    "请选择",
                    -1
                    /* CACHED */
                  )),
                  (openBlock(true), createElementBlock(
                    Fragment,
                    null,
                    renderList(servers.value, (server) => {
                      return openBlock(), createElementBlock("option", {
                        key: server.id,
                        value: server.id
                      }, toDisplayString(server.name), 9, _hoisted_10);
                    }),
                    128
                    /* KEYED_FRAGMENT */
                  ))
                ], 40, _hoisted_9)
              ]),
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(libraries.value, (library) => {
                  return openBlock(), createElementBlock("label", {
                    key: library.id,
                    class: "cover-row"
                  }, [
                    createElementVNode("input", {
                      type: "checkbox",
                      checked: (config.value.include_libraries || []).includes(library.id),
                      onChange: ($event) => toggle("include_libraries", library.id)
                    }, null, 40, _hoisted_11),
                    createElementVNode("span", null, [
                      createElementVNode(
                        "strong",
                        null,
                        toDisplayString(library.name),
                        1
                        /* TEXT */
                      ),
                      createElementVNode(
                        "small",
                        null,
                        toDisplayString(library.collection_type || "媒体库"),
                        1
                        /* TEXT */
                      )
                    ])
                  ]);
                }),
                128
                /* KEYED_FRAGMENT */
              ))
            ])
          ]),
          createElementVNode("main", _hoisted_12, [
            createElementVNode("div", _hoisted_13, [
              createElementVNode("div", _hoisted_14, [
                (openBlock(), createElementBlock(
                  Fragment,
                  null,
                  renderList(styles, ([value, label]) => {
                    return createElementVNode("button", {
                      key: value,
                      class: normalizeClass(["cover-style", { on: config.value.cover_style_base === value }]),
                      onClick: ($event) => set("cover_style_base", value)
                    }, toDisplayString(label), 11, _hoisted_15);
                  }),
                  64
                  /* STABLE_FRAGMENT */
                ))
              ]),
              createElementVNode("label", _hoisted_16, [
                _cache[11] || (_cache[11] = createElementVNode(
                  "span",
                  null,
                  "输出分辨率",
                  -1
                  /* CACHED */
                )),
                createElementVNode("select", {
                  value: config.value.resolution || "480p",
                  onChange: _cache[1] || (_cache[1] = ($event) => set("resolution", $event.target.value))
                }, [
                  (openBlock(), createElementBlock(
                    Fragment,
                    null,
                    renderList(["480p", "720p", "1080p", "custom"], (value) => {
                      return createElementVNode("option", {
                        key: value,
                        value
                      }, toDisplayString(value), 9, _hoisted_18);
                    }),
                    64
                    /* STABLE_FRAGMENT */
                  ))
                ], 40, _hoisted_17)
              ]),
              createElementVNode("label", _hoisted_19, [
                _cache[12] || (_cache[12] = createElementVNode(
                  "span",
                  null,
                  "媒体排序",
                  -1
                  /* CACHED */
                )),
                createElementVNode("select", {
                  value: config.value.sort_by || "DateCreated",
                  onChange: _cache[2] || (_cache[2] = ($event) => set("sort_by", $event.target.value))
                }, [
                  (openBlock(), createElementBlock(
                    Fragment,
                    null,
                    renderList(sortOptions, ([value, label]) => {
                      return createElementVNode("option", {
                        key: value,
                        value
                      }, toDisplayString(label), 9, _hoisted_21);
                    }),
                    64
                    /* STABLE_FRAGMENT */
                  ))
                ], 40, _hoisted_20)
              ]),
              createElementVNode("label", _hoisted_22, [
                _cache[13] || (_cache[13] = createElementVNode(
                  "span",
                  null,
                  "中文字号",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  type: "number",
                  value: config.value.zh_font_size ?? "",
                  onInput: _cache[3] || (_cache[3] = ($event) => setInput("zh_font_size", $event, true))
                }, null, 40, _hoisted_23)
              ]),
              createElementVNode("label", _hoisted_24, [
                _cache[14] || (_cache[14] = createElementVNode(
                  "span",
                  null,
                  "英文字号",
                  -1
                  /* CACHED */
                )),
                createElementVNode("input", {
                  type: "number",
                  value: config.value.en_font_size ?? "",
                  onInput: _cache[4] || (_cache[4] = ($event) => setInput("en_font_size", $event, true))
                }, null, 40, _hoisted_25)
              ]),
              createElementVNode("label", _hoisted_26, [
                _cache[15] || (_cache[15] = createElementVNode(
                  "span",
                  null,
                  "媒体库标题配置",
                  -1
                  /* CACHED */
                )),
                createElementVNode("textarea", {
                  value: config.value.title_config || "",
                  placeholder: "电影=电影|MOVIES",
                  onInput: _cache[5] || (_cache[5] = ($event) => set("title_config", $event.target.value))
                }, null, 40, _hoisted_27)
              ]),
              createElementVNode("label", _hoisted_28, [
                createElementVNode("input", {
                  type: "checkbox",
                  checked: Boolean(config.value.show_item_count),
                  onChange: _cache[6] || (_cache[6] = ($event) => set("show_item_count", $event.target.checked))
                }, null, 40, _hoisted_29),
                _cache[16] || (_cache[16] = createTextVNode(
                  " 显示媒体数量角标",
                  -1
                  /* CACHED */
                ))
              ]),
              createElementVNode(
                "p",
                _hoisted_30,
                toDisplayString(message.value),
                1
                /* TEXT */
              )
            ])
          ])
        ])
      ]);
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const LibraryArtworkView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-a3a5f493"]]);
const ID = "emby-cover-generator";
function install(sdk) {
  const { defineComponent: defineComponent2, h } = sdk.vue;
  const Page = defineComponent2({
    name: "LibraryArtworkPage",
    setup() {
      return () => h(LibraryArtworkView, {
        request: (path, init) => sdk.request(path, init)
      });
    }
  });
  sdk.registerPage({ pluginId: ID, route: `plugin-${ID}`, title: "视觉封面", icon: "mdi-image-multiple-outline", section: "tools", order: 80, component: Page });
}
export {
  install
};
